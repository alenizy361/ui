# ✅ Storage Buckets Created Successfully!

## 🎉 Current Status

You have successfully created both required storage buckets in your Supabase Dashboard:

### Buckets Created:
- ✅ **product-images** (Public, 5 MB limit)
- ✅ **profile-images** (Public, 5 MB limit)

---

## 🔐 Next Step: Configure RLS Policies

Now you need to configure Row-Level Security (RLS) policies to allow authenticated users to upload images.

### Quick Setup (2 minutes):

#### 1. **Configure `product-images` bucket:**

1. Go to: **Supabase Dashboard** → **Storage** → **Buckets**
2. Click on **`product-images`** (the bucket name)
3. Click on **"Configuration"** tab at the top
4. Scroll down to **"Policies"** section
5. Click **"New Policy"** button
6. Select template: **"Allow public access"**
   - This allows authenticated users to upload
   - Public can view images (needed for marketplace)
7. Click **"Review"** → **"Save policy"**

#### 2. **Configure `profile-images` bucket:**

1. Go back to **Storage** → **Buckets**
2. Click on **`profile-images`**
3. Configuration → Policies → New Policy
4. Select template: **"Allow public access"**
5. Review → Save policy

---

## 🧪 Test Your Setup

After configuring RLS policies, test the storage functionality:

### Option 1: Use the Test Screen
Navigate to the Storage Test screen by temporarily modifying the initial screen in App.tsx:

```typescript
// In App.tsx, find this line (around line 244):
const [currentScreen, setCurrentScreen] = useState<Screen>("splash");

// Change it to:
const [currentScreen, setCurrentScreen] = useState<Screen>("storageTest");
```

Then:
1. Refresh the app
2. Sign in with a test account
3. Try uploading a product image and profile image
4. Check for success/error messages

### Option 2: Use Add Product Screen
1. Sign in to the app
2. Switch to Seller mode
3. Navigate to Add Product screen
4. Try uploading product images
5. Images should upload successfully

---

## 📋 What Each Policy Does

### Product Images Policy:
```sql
-- Allow authenticated users to INSERT (upload)
CREATE POLICY "Allow authenticated uploads"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'product-images');

-- Allow anyone to SELECT (view/download)
CREATE POLICY "Allow public access"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'product-images');

-- Allow users to DELETE their own files
CREATE POLICY "Allow users to delete own files"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'product-images' AND auth.uid() = owner);
```

### Profile Images Policy:
```sql
-- Same as above, but for 'profile-images' bucket
```

---

## ❓ Troubleshooting

### "new row violates row-level security policy"
- **Cause:** RLS policies not configured yet
- **Fix:** Follow the RLS policy setup steps above

### "Bucket not found"
- **Cause:** Bucket doesn't exist or wrong name
- **Fix:** Double-check bucket names are exactly:
  - `product-images` (not "product_images" or "productImages")
  - `profile-images` (not "profile_images" or "profileImages")

### "Failed to upload image"
- **Cause:** Not authenticated
- **Fix:** Make sure you're signed in before uploading

### "Image size must be less than 5MB"
- **Cause:** File too large
- **Fix:** Compress the image or use a smaller file

---

## ✨ After RLS Policies Are Configured

Once you've set up the RLS policies, your app will be able to:

1. ✅ Upload product images (up to 5MB each)
2. ✅ Upload profile images (up to 2MB each)
3. ✅ View uploaded images publicly
4. ✅ Delete user's own images

---

## 🚀 Next Steps

After storage is working:

1. ✅ **Storage Setup** (You are here)
2. 🔄 **Test Image Uploads** (Next)
3. 📱 **Test Full User Journey**
   - Registration → Login → Add Product → Upload Images
4. 🎨 **Customize as needed**

---

## 📸 Quick Reference: Where to Find RLS Policies

```
Supabase Dashboard
├── Left Sidebar
│   └── 📦 Storage  ← Click here
│
└── Storage Page
    ├── Buckets
    │   ├── product-images  ← Click bucket name
    │   └── profile-images  ← Click bucket name
    │
    └── Bucket Details
        ├── Files tab
        ├── Configuration tab  ← Click here
        │   ├── Settings
        │   └── 🔒 Policies  ← Click here
        │
        └── Policies Section
            └── [New Policy] button  ← Click to add policies
```

---

## 💡 Need Help?

If you encounter any issues:

1. Check the browser console (F12) for detailed error messages
2. Verify bucket names match exactly
3. Ensure RLS policies are enabled and active
4. Make sure you're signed in before testing uploads

---

## ✅ Verification Checklist

Before testing, ensure:

- [ ] Both buckets created (`product-images` and `profile-images`)
- [ ] Both buckets are set to Public
- [ ] RLS policies configured for both buckets
- [ ] Policies are Active/Enabled
- [ ] User is authenticated before upload attempts

---

**You're almost done! Just configure the RLS policies and you're ready to test! 🎉**
