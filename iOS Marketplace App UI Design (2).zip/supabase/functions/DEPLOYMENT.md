# Supabase Edge Functions Deployment Guide

## Overview
This Rabit Platform app uses Supabase Edge Functions for backend API endpoints including user authentication, registration, and profile management.

## Current Status
⚠️ **Backend health check is failing** because the Edge Functions have not been deployed yet.

The app will currently work in **frontend-only mode** with localStorage persistence until the backend is deployed.

## How to Deploy

### Prerequisites
1. Install the Supabase CLI:
   ```bash
   npm install -g supabase
   ```

2. Login to Supabase:
   ```bash
   supabase login
   ```

### Deployment Steps

1. **Link your project** (if not already linked):
   ```bash
   supabase link --project-ref wfpsfiivvfnriqehlwas
   ```

2. **Deploy the Edge Functions**:
   ```bash
   supabase functions deploy server
   ```

3. **Verify deployment**:
   ```bash
   supabase functions list
   ```

### Testing the Deployment

After deployment, the app will automatically detect the backend and switch from frontend-only mode to full backend mode.

You should see this in the browser console:
```
🔍 Testing backend connection...
✅ Backend is connected and healthy!
```

## Available Endpoints

All endpoints are prefixed with `/make-server-4aa84d2f`:

### Health Check
- `GET /make-server-4aa84d2f/health` - Check if server is running

### Authentication
- `POST /make-server-4aa84d2f/auth/register` - Register new user
- `POST /make-server-4aa84d2f/auth/send-otp` - Send OTP verification code
- `POST /make-server-4aa84d2f/auth/verify-otp` - Verify OTP code
- `POST /make-server-4aa84d2f/auth/check-user` - Check if user exists
- `POST /make-server-4aa84d2f/auth/login-otp` - Login with OTP
- `POST /make-server-4aa84d2f/auth/set-role` - Set user role (buyer/seller/both)
- `POST /make-server-4aa84d2f/auth/profile` - Get user profile
- `POST /make-server-4aa84d2f/auth/update-profile` - Update user profile

## Database Structure

The backend uses the pre-configured `kv_store_4aa84d2f` table with the following data:

### User Records
Stored with key pattern: `user:{userId}`

```typescript
{
  id: string;              // user_1234567890_abc123def
  fullName: string;        // "Ahmed Al-Rashid"
  nationalId: string;      // Saudi national ID
  email: string;           // "ahmed@example.com"
  phone: string;           // "966501234567" (normalized)
  passwordHash: string;    // Base64 encoded (demo only)
  verified: boolean;       // true after OTP verification
  role: "buyer" | "seller" | "both";
  rating: number;          // 0-5 stars
  reviewCount: number;     // Number of reviews
  createdAt: string;       // ISO timestamp
}
```

## Security Notes

- Current password hashing uses base64 (demo only) - use bcrypt in production
- OTP is currently hardcoded to "1234" for development
- CORS is open to all origins - restrict in production
- Service role key is used server-side only (never exposed to frontend)

## Troubleshooting

### Health check still failing after deployment?
1. Check function logs:
   ```bash
   supabase functions logs server
   ```

2. Verify the function is deployed:
   ```bash
   supabase functions list
   ```

3. Test the endpoint directly:
   ```bash
   curl https://wfpsfiivvfnriqehlwas.supabase.co/functions/v1/make-server-4aa84d2f/health
   ```

### Database errors?
The `kv_store_4aa84d2f` table should exist automatically. If not, it will be created by Figma Make's system.

## Next Steps

Once deployed:
1. ✅ Register a new user through the app
2. ✅ Verify with OTP (use "1234")
3. ✅ Select role (Buyer, Seller, or Both)
4. ✅ All data will be permanently stored in Supabase
5. ✅ Session will persist across page reloads

## Need Help?

Visit the [Supabase Edge Functions documentation](https://supabase.com/docs/guides/functions) for more information.
