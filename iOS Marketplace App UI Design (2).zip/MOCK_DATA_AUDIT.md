# 🔍 Mock Data Audit - Complete List

## 📊 Summary

This document lists **ALL MOCK DATA** in the Rabit Platform codebase that needs to be replaced with real database calls.

---

## 🗂️ Mock Data Files

### 1. `/src/app/data/rabitProducts.ts`
**Contains:**
- ✅ `RabitProduct` interface (KEEP - needed for type definitions)
- ✅ `RabitCategory` interface (KEEP - needed for type definitions)
- ❌ `rabitCategories[]` array - Mock categories with hardcoded counts
- ❌ `rabitProducts[]` array - Mock product listings (14 products)

**Action Required:**
- Keep interfaces
- Remove or comment out mock arrays
- Create real categories in database
- All products should come from `products` table

---

## 📱 Screens Using Mock Data

### **HIGH PRIORITY - Core Functionality**

#### 1. **RabitBuyerHomeScreen.tsx**
**Mock Data:**
```typescript
- rabitProducts (full array)
- rabitCategories (categories list)
- filteredProducts = rabitProducts.filter(...)
```

**What Needs Real Data:**
- ✅ Browse products (trending, featured, all)
- ✅ Categories list with product counts
- ✅ Filter products by category
- ✅ Pull to refresh

**Database Tables Needed:**
- `products` table ✅ (exists)
- `categories` table ❌ (needs to be created)

---

#### 2. **RabitSellerHomeScreen.tsx**
**Mock Data:**
```typescript
- rabitProducts.filter(p => p.sellerId === "seller1") // Fallback only
```

**Status:** ✅ PARTIALLY FIXED
- Now fetches from database
- Still has mock data as fallback

**Action:** Remove fallback to mock data

---

#### 3. **RabitSellerDashboardScreen.tsx**
**Mock Data:**
```typescript
// Stats - COMPLETELY MOCKED
- totalSales: 156
- activeListings: 12
- rating: 4.8
- reviews: 89
- revenue: 45600
- platformFees: 2280
- netRevenue: 43320

// Sales array - COMPLETELY MOCKED
- Array of recent sales/orders

// Products - PARTIALLY FIXED
- rabitProducts.slice(0, 5) // Fallback only
```

**What Needs Real Data:**
- ❌ Seller statistics (sales count, revenue, fees)
- ❌ Recent orders/sales list
- ✅ Products list (already using database with fallback)

**Database Tables Needed:**
- `orders` table ❌ (needs to be created)
- `seller_stats` or calculated from orders ❌

---

#### 4. **RabitCategoriesScreen.tsx**
**Mock Data:**
```typescript
- rabitCategories (full array)
- rabitProducts.filter(p => p.categoryAr === selectedCategory)
```

**What Needs Real Data:**
- ❌ Categories list with counts
- ❌ Products filtered by category

---

#### 5. **RabitSearchScreen.tsx**
**Mock Data:**
```typescript
- rabitProducts.filter(...) // Search filtering
```

**What Needs Real Data:**
- ❌ Product search (title, description)
- ❌ Search history (currently in localStorage - OK)

**Database Tables Needed:**
- `products` table with full-text search ❌

---

#### 6. **RabitSellerProfileScreen.tsx**
**Mock Data:**
```typescript
// Seller info - COMPLETELY MOCKED
const sellerInfo = {
  name: "متجر التقنية السعودية",
  rating: 4.8,
  totalReviews: 456,
  totalSales: 1234,
  joinDate: "انضم في 2023",
  location: "الرياض، السعودية",
  responseTime: "خلال ساعة",
  verified: true,
  bio: "متجر متخصص في الإلكترونيات..."
}

// Products
- rabitProducts.length // Product count
- rabitProducts.slice(0, 6) // Seller products
```

**What Needs Real Data:**
- ❌ Seller profile information
- ❌ Seller ratings and reviews
- ❌ Seller statistics
- ❌ Seller's products

**Database Tables Needed:**
- `sellers` or `profiles` table ❌
- `seller_reviews` table ❌

---

### **MEDIUM PRIORITY - Orders & Sales**

#### 7. **RabitSellerSalesScreen.tsx**
**Mock Data:**
```typescript
// COMPLETELY MOCKED
const sales: Sale[] = [
  {
    id: "1",
    productName: "ساعة ذكية",
    orderNumber: "#12345",
    price: 1200,
    platformFee: 60,
    netAmount: 1140,
    status: "ready_to_ship",
    date: "منذ ساعة",
    buyerName: "أحمد محمد",
  },
  // ... more mock sales
]
```

**What Needs Real Data:**
- ❌ All seller sales/orders
- ❌ Order statuses
- ❌ Payment breakdown

**Database Tables Needed:**
- `orders` table ❌

---

#### 8. **RabitCheckoutScreen.tsx**
**Mock Data:**
- Uses `RabitProduct` type (OK)
- No backend integration for order creation

**What Needs Real Data:**
- ❌ Create order in database
- ❌ Payment processing
- ❌ Shipping address save

**Database Tables Needed:**
- `orders` table ❌
- `addresses` table ❌

---

#### 9. **RabitOrderTrackingScreen.tsx**
**Mock Data:**
```typescript
const currentStatus: TrackingStatus = "in_transit"; // HARDCODED
```

**What Needs Real Data:**
- ❌ Real order tracking status
- ❌ Tracking history
- ❌ Shipment updates

---

### **MEDIUM PRIORITY - Messaging**

#### 10. **RabitMessagesScreen.tsx**
**Mock Data:**
```typescript
const mockMessages: Message[] = [
  {
    id: "1",
    userName: "أحمد محمد",
    userAvatar: "AM",
    lastMessage: "مرحباً، هل المنتج متوفر؟",
    timestamp: "منذ 5 دقائق",
    unread: true,
    productName: "iPhone 14 Pro",
    productImage: "...",
  },
  // ... more mock messages
]
```

**What Needs Real Data:**
- ❌ User conversations list
- ❌ Unread message counts
- ❌ Last message preview

**Database Tables Needed:**
- `messages` or `conversations` table ❌

---

#### 11. **RabitChatScreen.tsx**
**Mock Data:**
```typescript
const [messages, setMessages] = useState<ChatMessage[]>([
  {
    id: "1",
    senderId: "user1",
    text: "مرحباً! هل المنتج لا يزال متوفر؟",
    timestamp: new Date(),
    isMe: false,
  },
  // ... more mock messages
])
```

**What Needs Real Data:**
- ❌ Chat messages history
- ❌ Real-time messaging
- ❌ Message sending/receiving

**Database Tables Needed:**
- `messages` table ❌
- Real-time subscriptions ❌

---

### **LOW PRIORITY - Reviews & Analytics**

#### 12. **RabitProductReviewsScreen.tsx**
**Mock Data:**
```typescript
const mockReviews: Review[] = [
  {
    id: "1",
    userName: "محمد السعيد",
    rating: 5,
    date: "منذ يومين",
    comment: "منتج ممتاز جداً...",
    verified: true,
  },
  // ... more mock reviews
]
```

**What Needs Real Data:**
- ❌ Product reviews
- ❌ Rating distribution
- ❌ Verified purchase badges

**Database Tables Needed:**
- `reviews` table ❌

---

#### 13. **RabitSellerAnalyticsScreen.tsx**
**Mock Data:**
```typescript
// Stats - COMPLETELY MOCKED
const stats = [
  { label: "إجمالي المبيعات", value: "156", icon: TrendingUp, color: "#163300" },
  { label: "الإيرادات", value: "45,600 ر.س", icon: DollarSign, color: "#9fe870" },
  { label: "المشاهدات", value: "12.5K", icon: Eye, color: "#df8700" },
  { label: "معدل التحويل", value: "12.4%", icon: Target, color: "#163300" },
]

// Charts data
const chartData = [...] // Mock chart data
```

**What Needs Real Data:**
- ❌ Sales analytics
- ❌ Revenue charts
- ❌ View counts
- ❌ Conversion rates

---

#### 14. **RabitFavoritesScreen.tsx**
**Mock Data:**
```typescript
const favoriteProducts = rabitProducts.filter(p => favorites.includes(p.id))
```

**Status:** PARTIALLY OK
- Favorites IDs stored in localStorage (OK for MVP)
- Product data from mock array (needs real fetch)

**What Needs Real Data:**
- ❌ Fetch products by favorite IDs from database

---

### **UTILITIES - Auth**

#### 15. **RabitOTPScreen.tsx**
**Mock Data:**
```typescript
import { getMockOTP } from "../../utils/auth"
```

**What Needs Real Data:**
- ❌ Real OTP sending (SMS)
- ❌ Real OTP verification

**Note:** Currently using Supabase auth which is real, but OTP is mocked

---

## 📋 Database Tables Required

### ✅ Already Created:
1. **products** - Product listings
2. **kv_store_4aa84d2f** - Key-value storage (unused)

### ❌ Need to Create:

#### **HIGH PRIORITY:**
1. **categories**
   ```sql
   - id (uuid)
   - name (text)
   - name_ar (text)
   - icon (text)
   - icon_component (text)
   - gradient (text)
   - created_at (timestamp)
   ```

2. **orders**
   ```sql
   - id (uuid)
   - buyer_id (uuid) FK to auth.users
   - seller_id (uuid) FK to auth.users
   - product_id (uuid) FK to products
   - quantity (int)
   - total_price (decimal)
   - platform_fee (decimal)
   - seller_amount (decimal)
   - status (enum: pending, confirmed, shipped, delivered, cancelled)
   - shipping_address (jsonb)
   - created_at (timestamp)
   - updated_at (timestamp)
   ```

3. **profiles** (or seller_profiles)
   ```sql
   - id (uuid) FK to auth.users
   - full_name (text)
   - display_name (text)
   - bio (text)
   - location (text)
   - avatar_url (text)
   - verified (boolean)
   - rating (decimal)
   - total_sales (int)
   - total_reviews (int)
   - response_time (text)
   - joined_at (timestamp)
   ```

#### **MEDIUM PRIORITY:**
4. **messages/conversations**
   ```sql
   - id (uuid)
   - conversation_id (uuid)
   - sender_id (uuid)
   - receiver_id (uuid)
   - product_id (uuid) - optional
   - message (text)
   - is_read (boolean)
   - created_at (timestamp)
   ```

5. **reviews**
   ```sql
   - id (uuid)
   - product_id (uuid)
   - user_id (uuid)
   - order_id (uuid) - to verify purchase
   - rating (int 1-5)
   - comment (text)
   - verified_purchase (boolean)
   - created_at (timestamp)
   ```

6. **addresses**
   ```sql
   - id (uuid)
   - user_id (uuid)
   - full_name (text)
   - phone (text)
   - street (text)
   - city (text)
   - postal_code (text)
   - is_default (boolean)
   ```

#### **LOW PRIORITY:**
7. **notifications**
8. **favorites** (or use localStorage)
9. **seller_analytics** (or calculate from orders)
10. **tracking_updates**

---

## 🔧 API Services Needed

### ✅ Already Created:
- `products.service.ts` - Create, browse, get seller products

### ❌ Need to Create:

1. **categories.service.ts**
   - `getCategories()` - Get all categories with product counts
   - `getCategoryProducts(categoryId)` - Get products by category

2. **orders.service.ts**
   - `createOrder()` - Create new order
   - `getSellerOrders()` - Get seller's orders
   - `getBuyerOrders()` - Get buyer's orders
   - `updateOrderStatus()` - Update order status
   - `getOrderDetails()` - Get single order

3. **sellers.service.ts**
   - `getSellerProfile()` - Get seller info
   - `getSellerStats()` - Get stats (sales, revenue, etc.)
   - `updateSellerProfile()` - Update profile

4. **messages.service.ts**
   - `getConversations()` - List conversations
   - `getMessages(conversationId)` - Get chat messages
   - `sendMessage()` - Send message
   - Real-time subscriptions

5. **reviews.service.ts**
   - `getProductReviews()` - Get product reviews
   - `createReview()` - Add review
   - `getSellerReviews()` - All seller reviews

6. **search.service.ts**
   - `searchProducts(query)` - Full-text search

---

## 🎯 Priority Action Plan

### **Phase 1: Core Product Features** (DO THIS FIRST)
1. ✅ Products table (DONE)
2. ❌ Create categories table
3. ❌ Create categories.service.ts
4. ❌ Update RabitBuyerHomeScreen to use real categories
5. ❌ Update RabitCategoriesScreen to use real data
6. ❌ Update RabitSearchScreen to use real search
7. ❌ Remove mock product fallbacks

### **Phase 2: Seller Dashboard**
1. ❌ Create orders table
2. ❌ Create profiles table
3. ❌ Create orders.service.ts
4. ❌ Create sellers.service.ts
5. ❌ Update RabitSellerDashboardScreen with real stats
6. ❌ Update RabitSellerSalesScreen with real orders
7. ❌ Update RabitSellerProfileScreen with real data

### **Phase 3: Orders & Checkout**
1. ❌ Implement createOrder() in orders.service.ts
2. ❌ Update RabitCheckoutScreen to create real orders
3. ❌ Update RabitPaymentScreen integration
4. ❌ Create addresses table and service

### **Phase 4: Messaging**
1. ❌ Create messages table
2. ❌ Create messages.service.ts
3. ❌ Update RabitMessagesScreen
4. ❌ Update RabitChatScreen
5. ❌ Add real-time subscriptions

### **Phase 5: Reviews & Analytics**
1. ❌ Create reviews table
2. ❌ Create reviews.service.ts
3. ❌ Update RabitProductReviewsScreen
4. ❌ Update RabitSellerAnalyticsScreen with real analytics

---

## 📝 Files to Modify/Remove

### Remove Completely:
- None (keep for type definitions)

### Modify (Remove mock arrays, keep interfaces):
- `/src/app/data/rabitProducts.ts`
  - Comment out `rabitProducts` array
  - Comment out `rabitCategories` array
  - Keep all interfaces

### Update to Remove Mock Fallbacks:
1. `/src/app/screens/rabit/RabitBuyerHomeScreen.tsx`
2. `/src/app/screens/rabit/RabitSellerHomeScreen.tsx`
3. `/src/app/screens/rabit/RabitSellerDashboardScreen.tsx`
4. `/src/app/screens/rabit/RabitCategoriesScreen.tsx`
5. `/src/app/screens/rabit/RabitSearchScreen.tsx`
6. `/src/app/screens/rabit/RabitSellerProfileScreen.tsx`
7. `/src/app/screens/rabit/RabitFavoritesScreen.tsx`

### Create New Services:
1. `/src/app/services/categories.service.ts`
2. `/src/app/services/orders.service.ts`
3. `/src/app/services/sellers.service.ts`
4. `/src/app/services/messages.service.ts`
5. `/src/app/services/reviews.service.ts`
6. `/src/app/services/search.service.ts`

---

## 🚀 Quick Start - Remove Mock Data NOW

Want to start now? Here's the fastest path:

1. **Comment out mock arrays** in rabitProducts.ts
2. **Update buyer home** to show empty state when no products
3. **Remove fallbacks** in seller screens
4. **Add loading states** everywhere
5. **Show error messages** when data fails to load

This will expose what's truly broken and force real implementations.

---

**Total Mock Data Instances:** 50+ occurrences across 21 files
**Screens Affected:** 14 main screens
**Database Tables Needed:** 10 tables (2 exist, 8 need creation)
**Services Needed:** 6 new service files

Let me know which phase you want to tackle first! 🚀
