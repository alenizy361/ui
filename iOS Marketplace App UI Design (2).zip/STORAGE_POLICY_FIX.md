# 🔧 How to Fix Supabase Storage RLS Policies

## ⚠️ The Problem
You're seeing this error:
```
StorageApiError: new row violates row-level security policy
```

This means your storage buckets exist, but they don't have permission policies to allow uploads.

---

## ✅ The Solution (2 minutes)

### **Step 1: Open Supabase Dashboard**

1. Go to: https://supabase.com/dashboard
2. Click on your project (the Rabit Platform project)
3. In the left sidebar, click **"Storage"**
4. You should see your buckets: `product-images` and `profile-images`

---

### **Step 2: Add Policy to `product-images` Bucket**

#### 2.1 Click on the bucket name
- Click directly on **`product-images`** (the bucket name, not the checkbox)
- This opens the bucket details page

#### 2.2 Go to Configuration tab
- At the top of the page, you'll see tabs: **"Files"**, **"Configuration"**, etc.
- Click on **"Configuration"** tab

#### 2.3 Go to Policies
- Inside Configuration, you'll see sections
- Click on **"Policies"** section (or look for a "Policies" button)
- You should see "No policies created" or similar

#### 2.4 Create New Policy
- Click the **"New Policy"** button
- A modal/page will appear with policy templates

#### 2.5 Select Policy Template
You have 2 options (choose ONE):

**OPTION A: Allow Public Access (Recommended for Marketplace)**
- Find and click: **"Allow public access"** template
- This template allows:
  - ✅ Anyone can view images (public)
  - ✅ Authenticated users can upload
  - ✅ Users can delete their own images
  
**OPTION B: Authenticated Users Only**
- Find and click: **"Allow authenticated users to upload"** template
- This template allows:
  - ✅ Only logged-in users can view/upload
  - ✅ More secure but requires auth for viewing

#### 2.6 Apply the Template
- After selecting a template, click **"Use this template"**
- The policy will be pre-filled with SQL code
- Click **"Review"** button
- Then click **"Save policy"** button

#### 2.7 Verify Policy Created
- You should now see the policy listed
- Status should be **"Active"** or similar

---

### **Step 3: Add Policy to `profile-images` Bucket**

**Repeat Step 2 for the `profile-images` bucket:**
1. Go back to Storage → Buckets
2. Click on **`profile-images`**
3. Configuration → Policies
4. New Policy
5. Select same template (Allow public access)
6. Use this template → Review → Save policy

---

### **Step 4: Test the Fix**

1. Go back to your Rabit Platform app
2. Refresh the page (Ctrl + Shift + R)
3. Try uploading a product image
4. ✅ Should work now!

---

## 🎯 Quick Reference

### What the Policy Does:
```sql
-- Allows authenticated users to INSERT (upload)
CREATE POLICY "Allow authenticated uploads"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'product-images');

-- Allows anyone to SELECT (view/download)
CREATE POLICY "Allow public access"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'product-images');

-- Allows users to DELETE their own files
CREATE POLICY "Allow users to delete own files"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'product-images' AND auth.uid() = owner);
```

---

## 📸 Visual Guide

### Where to find things in Supabase Dashboard:

```
Supabase Dashboard
├── Left Sidebar
│   ├── Table Editor
│   ├── Authentication
│   ├── 📦 Storage  ← Click here
│   ├── Edge Functions
│   └── ...
│
└── Storage Page
    ├── Buckets list
    │   ├── product-images  ← Click bucket name
    │   └── profile-images  ← Click bucket name
    │
    └── Bucket Details (after clicking)
        ├── Files tab
        ├── Configuration tab  ← Click here
        │   ├── Settings
        │   ├── 🔒 Policies  ← Click here
        │   └── ...
        │
        └── Policies Section
            ├── No policies created
            ├── [New Policy] button  ← Click here
            └── Templates modal appears
                ├── "Allow public access"  ← Select this
                ├── "Allow authenticated uploads"
                └── ...
```

---

## ❓ Troubleshooting

### "I don't see the Policies section"
- Make sure you clicked on the **bucket name** itself
- Make sure you're in the **Configuration** tab
- Try refreshing the Supabase dashboard page

### "I don't see policy templates"
- After clicking "New Policy", look for a "Templates" or "Get started quickly" section
- If you don't see templates, you can create a custom policy:
  1. Click "Create policy from scratch"
  2. Name: `Allow authenticated uploads`
  3. Policy command: `INSERT`
  4. Target roles: `authenticated`
  5. USING expression: `true`
  6. WITH CHECK expression: `bucket_id = 'product-images'`
  7. Save

### "Policy created but still getting errors"
- Make sure you created policies for BOTH buckets:
  - ✅ product-images
  - ✅ profile-images
- Refresh your app and try again
- Check browser console for different error messages

---

## 🚀 After This Works

Once storage policies are working, you should also:
1. ✅ Disable email confirmation (Authentication → Providers → Email)
2. ✅ Test user registration and login
3. ✅ Test product image uploads
4. ✅ Everything should work smoothly!

---

## 💡 Need More Help?

If you're still stuck:
1. Open browser console (F12)
2. Try uploading again
3. Copy the FULL error message
4. Share it with me and I'll help debug!
