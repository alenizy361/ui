# 🎯 NEXT STEPS: Configure Storage RLS Policies

## ✅ What You've Done
- ✅ Created `product-images` bucket (Public, 5 MB)
- ✅ Created `profile-images` bucket (Public, 5 MB)
- ✅ Storage service is configured
- ✅ AuthContext stores access tokens correctly

## 🔐 What You Need to Do NOW (2 minutes)

### Step 1: Configure RLS Policies for `product-images`

1. **Open Supabase Dashboard** → **Storage** → Click **`product-images`**
2. Click **"Configuration"** tab → **"Policies"** section
3. Click **"New Policy"** button
4. Select template: **"Allow public access"**
5. Click **"Use this template"** → **"Review"** → **"Save policy"**

### Step 2: Configure RLS Policies for `profile-images`

1. Go back to **Storage** → Click **`profile-images`**
2. Configuration → Policies → New Policy
3. Select template: **"Allow public access"**
4. Use this template → Review → Save policy

**That's it! Takes 2 minutes total.**

---

## 🧪 Test Your Setup

### Quick Test Method:

1. **Temporarily modify the initial screen** in `/src/app/App.tsx`:

```typescript
// Find this line (around line 244):
const [currentScreen, setCurrentScreen] = useState<Screen>("splash");

// Change to:
const [currentScreen, setCurrentScreen] = useState<Screen>("storageTest");
```

2. **Refresh the app** (Ctrl + Shift + R)

3. **Sign in** with a test account (or create one)

4. **Test uploads:**
   - Upload a product image
   - Upload a profile image
   - Check for ✅ Success or ❌ Error messages

5. **If successful**, you'll see:
   - ✅ Green checkmark
   - Thumbnail preview of uploaded image
   - Public URL link

6. **When done testing**, change back to:
```typescript
const [currentScreen, setCurrentScreen] = useState<Screen>("splash");
```

---

## 🎯 Alternative Test Method

If you don't want to modify code:

1. Sign in to the app normally
2. Switch to **Seller** role
3. Navigate to **Add Product** screen
4. Try uploading product images
5. Images should upload successfully

---

## ❌ Common Errors & Fixes

### Error: "new row violates row-level security policy"
- **Cause:** RLS policies not configured
- **Fix:** Follow Step 1 & 2 above to add policies

### Error: "SETUP_REQUIRED: Bucket not found"
- **Cause:** Bucket name mismatch
- **Fix:** Verify bucket names are exactly:
  - `product-images` (not product_images)
  - `profile-images` (not profile_images)

### Error: "Please sign in to upload images"
- **Cause:** Not authenticated
- **Fix:** Sign in before testing uploads

### Error: "Image size must be less than 5MB"
- **Cause:** File too large
- **Fix:** Use a smaller image file

---

## 📋 Expected Results After Setup

### ✅ When Working Correctly:

**Product Image Upload:**
```
📤 [Storage Service] Uploading product image: abc123-uuid/1234567890.jpg
📦 [Storage Service] File size: 234.56 KB
🪣 [Storage Service] Bucket: product-images
✅ [Storage Service] Upload successful
🔗 [Storage Service] Public URL: https://...supabase.co/storage/v1/object/public/product-images/...
```

**Profile Image Upload:**
```
📤 [Storage Service] Uploading profile image: abc123-uuid/profile.jpg
✅ [Storage Service] Profile image upload successful: https://...
```

### ❌ When NOT Working (RLS policies missing):

```
❌ [Storage Service] Upload failed: StorageApiError: new row violates row-level security policy
```

---

## 🎉 After Everything Works

Once storage is working, your Rabit Platform will have:

1. ✅ Full authentication flow (sign up, login, OTP)
2. ✅ Product image uploads (up to 5MB)
3. ✅ Profile image uploads (up to 2MB)
4. ✅ Public image viewing (for marketplace)
5. ✅ Secure user-based upload permissions

**The app will be fully functional for testing the complete user journey! 🚀**

---

## 📞 If You Need Help

1. Open browser console (F12)
2. Try uploading again
3. Copy the **full error message** from console
4. Share it and I'll help debug!

---

## 📚 Additional Resources

- **Detailed Guide:** See `/STORAGE_SETUP_COMPLETE.md`
- **RLS Policy Reference:** See `/STORAGE_POLICY_FIX.md`
- **Test Screen Code:** See `/src/app/screens/rabit/RabitStorageTestScreen.tsx`

---

**Ready? Configure those RLS policies and test! 🎯**
