# 🔧 Fixed: JWT Error + Database Setup Required

## ✅ What I Fixed

### 1. **Removed Edge Functions for Product Creation**
- **Before:** Used `/products/create` API endpoint (Edge Functions)
- **After:** Direct Supabase database integration using `supabase-js`
- **Result:** No more "Invalid JWT" errors from API calls

### 2. **Created Products Service**
New file: `/src/app/services/products.service.ts`
- Direct database operations (no API calls)
- Proper authentication handling
- Helpful error messages

### 3. **Updated Add Product Screen**
- Now uses `createProduct()` from products service
- No more JWT token passing
- Better error handling with setup instructions

---

## ⚠️ Database Setup Required

The JWT error is now fixed, but you'll need to create the `products` table in Supabase.

### Quick Setup (3 minutes):

#### Step 1: Create Products Table

1. **Go to Supabase Dashboard** → **SQL Editor**
2. **Click "New Query"**
3. **Paste this SQL:**

```sql
-- Create products table
CREATE TABLE products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  price DECIMAL(10, 2) NOT NULL,
  category TEXT NOT NULL,
  condition TEXT NOT NULL CHECK (condition IN ('new', 'used')),
  images TEXT[] NOT NULL DEFAULT '{}',
  location TEXT,
  quantity INTEGER NOT NULL DEFAULT 1,
  delivery_options TEXT[] DEFAULT '{}',
  seller_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  
  -- Indexes for faster queries
  CONSTRAINT products_price_positive CHECK (price > 0),
  CONSTRAINT products_quantity_positive CHECK (quantity >= 0)
);

-- Create indexes
CREATE INDEX products_seller_id_idx ON products(seller_id);
CREATE INDEX products_category_idx ON products(category);
CREATE INDEX products_created_at_idx ON products(created_at DESC);
CREATE INDEX products_price_idx ON products(price);

-- Enable Row Level Security
ALTER TABLE products ENABLE ROW LEVEL SECURITY;

-- RLS Policies

-- 1. Anyone can view products
CREATE POLICY "Anyone can view products"
ON products FOR SELECT
USING (true);

-- 2. Authenticated users can create their own products
CREATE POLICY "Users can create their own products"
ON products FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = seller_id);

-- 3. Users can update their own products
CREATE POLICY "Users can update their own products"
ON products FOR UPDATE
TO authenticated
USING (auth.uid() = seller_id)
WITH CHECK (auth.uid() = seller_id);

-- 4. Users can delete their own products
CREATE POLICY "Users can delete their own products"
ON products FOR DELETE
TO authenticated
USING (auth.uid() = seller_id);

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_products_updated_at
BEFORE UPDATE ON products
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();
```

4. **Click "Run"** (or press Ctrl+Enter)
5. **Verify:** You should see "Success. No rows returned"

---

## 🎯 What This Enables

Once the table is created, your app will be able to:

### ✅ Product Operations:
- Create new products (with images, price, category, etc.)
- View all products (public marketplace)
- Get seller's own products
- Update product details
- Delete products
- Search/filter by category

### 🔐 Security (RLS Policies):
- ✅ Anyone can browse products (public marketplace)
- ✅ Only authenticated users can create products
- ✅ Users can only edit/delete their own products
- ✅ Automatic seller_id assignment from auth token

---

## 📋 Table Schema

| Column | Type | Description |
|--------|------|-------------|
| `id` | UUID | Unique product ID |
| `title` | TEXT | Product title |
| `description` | TEXT | Product description |
| `price` | DECIMAL | Product price (SAR) |
| `category` | TEXT | Product category |
| `condition` | TEXT | 'new' or 'used' |
| `images` | TEXT[] | Array of image URLs |
| `location` | TEXT | City/location |
| `quantity` | INTEGER | Available quantity |
| `delivery_options` | TEXT[] | ['delivery', 'meetup'] |
| `seller_id` | UUID | User who created product |
| `created_at` | TIMESTAMPTZ | Creation timestamp |
| `updated_at` | TIMESTAMPTZ | Last update timestamp |

---

## 🧪 Testing After Setup

### Test Product Creation:

1. **Sign in to the app**
2. **Switch to Seller role**
3. **Navigate to Add Product**
4. **Fill in product details:**
   - Upload images (RLS policies must be configured first)
   - Add title, description, price
   - Select category, condition, city
   - Set quantity
5. **Click "Publish"**
6. **Expected Result:** ✅ Success! Product created

### If You See Errors:

| Error Message | Cause | Fix |
|---------------|-------|-----|
| `relation "products" does not exist` | Table not created | Run the SQL above in SQL Editor |
| `new row violates row-level security policy` | RLS policies not created | The SQL includes policies - make sure you ran the full script |
| `SETUP_REQUIRED: Bucket not found` | Storage buckets not configured | See `/NEXT_STEPS.md` for storage setup |

---

## 📂 What Changed in Code

### New Files:
- `/src/app/services/products.service.ts` - Direct Supabase database service

### Modified Files:
- `/src/app/screens/rabit/RabitAddProductScreen.tsx` - Uses new products service

### Removed Dependencies:
- ❌ No more `/products/create` API calls
- ❌ No more JWT token passing to backend
- ❌ No more Edge Functions dependency

---

## 🎉 Benefits

### Before:
```typescript
// ❌ Old way - API call with JWT
const result = await productsAPI.createProduct(data, accessToken);
// Error: Invalid JWT
```

### After:
```typescript
// ✅ New way - Direct database
const result = await createProduct(data);
// Uses session automatically, no JWT needed
```

---

## 🔄 Complete Setup Checklist

Before testing product creation:

- [ ] **Step 1:** Create products table (SQL above)
- [ ] **Step 2:** Configure storage buckets (see `/NEXT_STEPS.md`)
- [ ] **Step 3:** Configure storage RLS policies
- [ ] **Step 4:** Test image upload
- [ ] **Step 5:** Test product creation

---

## 💡 Pro Tips

1. **Test with mock data first:** Create a test product with dummy text before real data
2. **Check console logs:** Look for `📦 [Products Service]` messages
3. **Verify RLS policies:** Make sure you're signed in before creating products
4. **Storage first:** Set up storage buckets/policies before creating products (so images work)

---

## 📞 Need Help?

If you see any errors:

1. **Check browser console (F12)** for detailed error messages
2. **Look for these specific errors:**
   - `relation "products" does not exist` → Run SQL above
   - `SETUP_REQUIRED` → Create storage buckets
   - `RLS_POLICY_ERROR` → Policies not configured
3. **Copy full error message** and share it for debugging

---

**Ready? Run the SQL and test product creation! 🚀**
