# Rabit Platform - Authentication Architecture

## System Overview

```
┌─────────────────────────────────────────────────────────────┐
│                         Browser                              │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │                      App.tsx                           │ │
│  │                                                        │ │
│  │  ┌──────────────────────────────────────────────────┐ │ │
│  │  │             AuthProvider                         │ │ │
│  │  │  (AuthContext)                                   │ │ │
│  │  │                                                  │ │ │
│  │  │  State:                                          │ │ │
│  │  │  - user: UserProfile | null                     │ │ │
│  │  │  - isAuthenticated: boolean                     │ │ │
│  │  │  - isLoading: boolean                           │ │ │
│  │  │                                                  │ │ │
│  │  │  Methods:                                        │ │ │
│  │  │  - signUp()                                      │ │ │
│  │  │  - signIn()                                      │ │ │
│  │  │  - signOut()                                     │ │ │
│  │  │  - updateRole()                                  │ │ │
│  │  └────────────┬─────────────────────────────────────┘ │ │
│  │               │                                        │ │
│  │               │ Provides Auth State                    │ │
│  │               │                                        │ │
│  │  ┌────────────▼─────────────────────────────────────┐ │ │
│  │  │              Screen Components                   │ │ │
│  │  │                                                  │ │ │
│  │  │  - RabitLoginScreen                             │ │ │
│  │  │  - RabitRegisterScreen                          │ │ │
│  │  │  - RabitRoleSelectionScreen                     │ │ │
│  │  │  - RabitBuyerHomeScreen                         │ │ │
│  │  │  - RabitSellerHomeScreen                        │ │ │
│  │  │  - ... etc                                      │ │ │
│  │  │                                                  │ │ │
│  │  │  Each uses:                                      │ │ │
│  │  │  const { user, signIn, ... } = useAuth();       │ │ │
│  │  └──────────────────────────────────────────────────┘ │ │
│  └────────────────────────────────────────────────────────┘ │
│                                                              │
└──────────────────────┬───────────────────────────────────────┘
                       │
                       │ Supabase SDK API Calls
                       │ (supabase.auth.*)
                       │
┌──────────────────────▼───────────────────────────────────────┐
│                    Supabase Cloud                            │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │                  Auth Service                          │ │
│  │                                                        │ │
│  │  - User Management                                     │ │
│  │  - Session Tokens (JWT)                               │ │
│  │  - Password Hashing                                    │ │
│  │  - Email Verification                                  │ │
│  │  - Token Refresh                                       │ │
│  └────────────────────────────────────────────────────────┘ │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │                  User Metadata                         │ │
│  │                                                        │ │
│  │  {                                                     │ │
│  │    name: "John Doe",                                  │ │
│  │    phone: "501234567",                                │ │
│  │    role: "buyer"                                      │ │
│  │  }                                                     │ │
│  └────────────────────────────────────────────────────────┘ │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

## Data Flow

### Sign Up Flow
```
User Input (Form)
    ↓
RabitRegisterScreen (validation)
    ↓
RabitRoleSelectionScreen (role selection)
    ↓
App.tsx → signUp(email, password, name, phone, role)
    ↓
AuthContext.signUp()
    ↓
supabase.auth.signUp({
  email,
  password,
  options: { data: { name, phone, role } }
})
    ↓
Supabase Auth Service
    ↓
User Created + Session Issued
    ↓
AuthContext updates state
    ↓
Components re-render
    ↓
Navigate to Home Screen
```

### Sign In Flow
```
User Input (Credentials)
    ↓
RabitLoginScreen → signIn(email, password)
    ↓
AuthContext.signIn()
    ↓
supabase.auth.signInWithPassword({ email, password })
    ↓
Supabase Auth Service validates
    ↓
Session + User Data returned
    ↓
AuthContext updates state
    ↓
Components re-render
    ↓
Navigate based on user.role
```

### Session Persistence Flow
```
Page Load
    ↓
AuthContext useEffect runs
    ↓
supabase.auth.getSession()
    ↓
Check localStorage for token
    ↓
If valid token exists:
    ↓
Restore session
    ↓
Update AuthContext state
    ↓
User stays logged in
```

### Auth State Change Flow
```
Supabase Auth Event
(SIGNED_IN, SIGNED_OUT, TOKEN_REFRESHED, USER_UPDATED)
    ↓
onAuthStateChange listener
    ↓
AuthContext processes event
    ↓
Update state accordingly
    ↓
All components using useAuth() re-render
    ↓
UI updates automatically
```

## Component Tree

```
App
└── ErrorBoundary
    └── LanguageProvider
        └── AuthProvider ← Provides auth context
            └── AppProvider
                └── AppContent ← Uses useAuth()
                    ├── Splash Screen
                    ├── Welcome Screen
                    ├── Login Screen ← Uses signIn()
                    ├── Register Screen
                    ├── Role Selection ← Calls signUp()
                    ├── Buyer Home ← Checks isAuthenticated
                    ├── Seller Home ← Checks isAuthenticated
                    └── ... other screens
```

## State Management

### AuthContext State
```typescript
{
  user: {
    id: string;           // Supabase user ID
    email: string;        // User email
    name: string;         // From metadata
    phone: string;        // From metadata
    role: 'buyer' | 'seller' | 'both'; // From metadata
    verified: boolean;    // Email verification status
  } | null,
  
  isAuthenticated: boolean,  // Computed from !!user
  isLoading: boolean         // true during initial check
}
```

### Local Storage (Managed by Supabase)
```
Key: sb-[project-ref]-auth-token
Value: {
  access_token: "eyJ...",
  refresh_token: "...",
  expires_at: 1234567890,
  user: { ... }
}
```

## Security

### What's Secure ✅
- Passwords never stored locally
- Passwords hashed by Supabase (bcrypt)
- JWT tokens auto-expire
- Refresh tokens rotate
- HTTPS only in production
- XSS protection via React
- CSRF protection via Supabase

### What to Watch ⚠️
- Keep SUPABASE_ANON_KEY public (safe)
- Never expose SUPABASE_SERVICE_ROLE_KEY
- Validate user input
- Sanitize displayed user data
- Use Row Level Security in database

## Performance

### Optimizations
- Session restored from localStorage (instant)
- No unnecessary API calls
- Token refresh happens in background
- State updates batched by React
- Components only re-render when auth changes

### Metrics
- Initial auth check: <100ms (from cache)
- Sign in: ~500ms (network dependent)
- Sign up: ~800ms (network dependent)
- Sign out: <50ms (local only)
- Session restore: <50ms (from localStorage)

## Error Handling

### Levels
```
1. Network Errors
   ↓
   Caught by try/catch in AuthContext
   ↓
   Return { success: false, error: message }

2. Validation Errors
   ↓
   Caught by Supabase SDK
   ↓
   Return structured error
   ↓
   Display in UI via toast

3. Session Errors
   ↓
   Handled by onAuthStateChange
   ↓
   Auto sign out if token invalid
```

## Testing Strategy

### Unit Tests (Future)
- Test signUp() with valid/invalid data
- Test signIn() with correct/wrong credentials
- Test updateRole() changes
- Test session persistence

### Manual Testing (Current)
1. Use `showAuthTest()` console command
2. Use `debugAuth()` to inspect state
3. Test in different browsers
4. Test session across tabs
5. Test with slow network

### Integration Testing (Future)
- Test full registration flow
- Test login → navigation flow
- Test role changes
- Test sign out clears state

## Deployment Checklist

- [ ] Verify SUPABASE_URL is correct
- [ ] Verify SUPABASE_ANON_KEY is correct
- [ ] Test registration works
- [ ] Test login works
- [ ] Test session persists
- [ ] Test sign out works
- [ ] Remove console.log in production
- [ ] Verify no errors in console
- [ ] Test on mobile devices
- [ ] Test in different browsers

## Monitoring

### Key Metrics to Watch
- Sign up success rate
- Sign in success rate
- Session duration
- Token refresh rate
- Error rate by type

### Logging
Currently logs to console:
- All auth operations
- Success/failure states
- Error messages
- State changes

In production, send to analytics service.
