-- ============================================================================
-- RABIT PLATFORM - COMPLETE DATABASE SCHEMA
-- ============================================================================
-- This script creates ALL tables needed to replace mock data
-- Run this in Supabase SQL Editor
-- ============================================================================

-- ============================================================================
-- 1. CATEGORIES TABLE (HIGH PRIORITY)
-- ============================================================================
CREATE TABLE IF NOT EXISTS categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  name_ar TEXT NOT NULL,
  icon TEXT, -- Emoji like "📱"
  icon_component TEXT, -- Lucide icon name like "Smartphone"
  gradient TEXT, -- Tailwind classes like "from-blue-500 to-purple-600"
  description TEXT,
  description_ar TEXT,
  product_count INTEGER DEFAULT 0, -- Cached count for performance
  is_active BOOLEAN DEFAULT true,
  display_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add RLS policies for categories (public read)
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Categories are viewable by everyone"
  ON categories FOR SELECT
  USING (is_active = true);

CREATE POLICY "Only admins can insert categories"
  ON categories FOR INSERT
  WITH CHECK (false); -- Change to admin check when you add admin system

CREATE POLICY "Only admins can update categories"
  ON categories FOR UPDATE
  USING (false); -- Change to admin check when you add admin system

-- Insert default categories
INSERT INTO categories (name, name_ar, icon, icon_component, gradient, display_order) VALUES
  ('Electronics', 'إلكترونيات', '📱', 'Smartphone', 'from-blue-500 to-purple-600', 1),
  ('Fashion', 'أزياء', '👔', 'Shirt', 'from-pink-500 to-rose-600', 2),
  ('Home & Garden', 'المنزل والحديقة', '🏡', 'Home', 'from-green-500 to-emerald-600', 3),
  ('Sports', 'رياضة', '⚽', 'Dumbbell', 'from-orange-500 to-red-600', 4),
  ('Books', 'كتب', '📚', 'Book', 'from-indigo-500 to-blue-600', 5),
  ('Toys', 'ألعاب', '🧸', 'Baby', 'from-yellow-500 to-orange-600', 6),
  ('Beauty', 'تجميل', '💄', 'Sparkles', 'from-purple-500 to-pink-600', 7),
  ('Automotive', 'سيارات', '🚗', 'Car', 'from-gray-500 to-slate-600', 8)
ON CONFLICT DO NOTHING;

-- ============================================================================
-- 2. PROFILES TABLE (HIGH PRIORITY)
-- ============================================================================
CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  display_name TEXT,
  phone TEXT,
  bio TEXT,
  bio_ar TEXT,
  location TEXT, -- e.g., "Riyadh, Saudi Arabia"
  location_ar TEXT, -- e.g., "الرياض، السعودية"
  city TEXT,
  city_ar TEXT,
  avatar_url TEXT,
  
  -- Seller-specific fields
  is_seller BOOLEAN DEFAULT false,
  is_verified_seller BOOLEAN DEFAULT false,
  seller_rating DECIMAL(3,2) DEFAULT 0.0, -- Average rating (0.00 to 5.00)
  total_sales INTEGER DEFAULT 0,
  total_reviews INTEGER DEFAULT 0,
  response_time_minutes INTEGER, -- Average response time
  
  -- Timestamps
  joined_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  last_active_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add RLS policies for profiles
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Profiles are viewable by everyone"
  ON profiles FOR SELECT
  USING (true);

CREATE POLICY "Users can insert their own profile"
  ON profiles FOR INSERT
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update their own profile"
  ON profiles FOR UPDATE
  USING (auth.uid() = id);

-- Create function to create profile on user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, phone)
  VALUES (
    NEW.id,
    NEW.raw_user_meta_data->>'full_name',
    NEW.phone
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to create profile on signup
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============================================================================
-- 3. ADDRESSES TABLE (MEDIUM PRIORITY)
-- ============================================================================
CREATE TABLE IF NOT EXISTS addresses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  
  -- Address details
  label TEXT, -- e.g., "Home", "Work", "منزل", "العمل"
  full_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  street TEXT NOT NULL,
  street_ar TEXT,
  district TEXT, -- الحي
  district_ar TEXT,
  city TEXT NOT NULL,
  city_ar TEXT NOT NULL,
  region TEXT, -- المنطقة
  region_ar TEXT,
  postal_code TEXT,
  country TEXT DEFAULT 'Saudi Arabia',
  country_ar TEXT DEFAULT 'المملكة العربية السعودية',
  
  -- Additional fields
  building_number TEXT,
  additional_number TEXT, -- الرقم الإضافي (Saudi address system)
  unit_number TEXT,
  is_default BOOLEAN DEFAULT false,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add RLS policies for addresses
ALTER TABLE addresses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own addresses"
  ON addresses FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own addresses"
  ON addresses FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own addresses"
  ON addresses FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own addresses"
  ON addresses FOR DELETE
  USING (auth.uid() = user_id);

-- ============================================================================
-- 4. ORDERS TABLE (HIGH PRIORITY)
-- ============================================================================
CREATE TYPE order_status AS ENUM (
  'pending',           -- Order created, awaiting payment
  'payment_confirmed', -- Payment received
  'confirmed',         -- Seller confirmed
  'processing',        -- Seller preparing shipment
  'ready_to_ship',     -- Ready for pickup
  'shipped',           -- In transit
  'out_for_delivery',  -- Out for delivery
  'delivered',         -- Delivered to buyer
  'cancelled',         -- Cancelled by buyer/seller
  'refunded',          -- Payment refunded
  'disputed'           -- Dispute opened
);

CREATE TABLE IF NOT EXISTS orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number TEXT UNIQUE NOT NULL, -- e.g., "ORD-20240127-ABC123"
  
  -- Participants
  buyer_id UUID NOT NULL REFERENCES auth.users(id),
  seller_id UUID NOT NULL REFERENCES auth.users(id),
  product_id UUID NOT NULL REFERENCES products(id),
  
  -- Order details
  quantity INTEGER NOT NULL DEFAULT 1,
  unit_price DECIMAL(10,2) NOT NULL,
  total_price DECIMAL(10,2) NOT NULL,
  
  -- Platform fees (5%)
  platform_fee_percentage DECIMAL(5,2) DEFAULT 5.00,
  platform_fee_amount DECIMAL(10,2) NOT NULL,
  seller_amount DECIMAL(10,2) NOT NULL, -- Amount seller receives
  
  -- Product snapshot (in case product gets deleted/modified)
  product_snapshot JSONB, -- Store title, image, etc.
  
  -- Shipping
  shipping_address_id UUID REFERENCES addresses(id),
  shipping_address JSONB, -- Snapshot of address at time of order
  tracking_number TEXT,
  courier_service TEXT, -- e.g., "SMSA", "Aramex", "شركة الشحن"
  
  -- Status
  status order_status DEFAULT 'pending',
  
  -- Payment
  payment_method TEXT, -- e.g., "credit_card", "apple_pay", "mada"
  payment_intent_id TEXT, -- Stripe/payment gateway reference
  paid_at TIMESTAMP WITH TIME ZONE,
  
  -- Notes
  buyer_notes TEXT,
  seller_notes TEXT,
  cancellation_reason TEXT,
  
  -- Timestamps
  confirmed_at TIMESTAMP WITH TIME ZONE,
  shipped_at TIMESTAMP WITH TIME ZONE,
  delivered_at TIMESTAMP WITH TIME ZONE,
  cancelled_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add RLS policies for orders
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Buyers can view their purchases"
  ON orders FOR SELECT
  USING (auth.uid() = buyer_id);

CREATE POLICY "Sellers can view their sales"
  ON orders FOR SELECT
  USING (auth.uid() = seller_id);

CREATE POLICY "Authenticated users can create orders"
  ON orders FOR INSERT
  WITH CHECK (auth.uid() = buyer_id);

CREATE POLICY "Sellers can update their orders"
  ON orders FOR UPDATE
  USING (auth.uid() = seller_id);

CREATE POLICY "Buyers can update their orders (cancel)"
  ON orders FOR UPDATE
  USING (auth.uid() = buyer_id AND status IN ('pending', 'payment_confirmed'));

-- Create function to generate order number
CREATE OR REPLACE FUNCTION generate_order_number()
RETURNS TEXT AS $$
DECLARE
  new_number TEXT;
BEGIN
  new_number := 'ORD-' || TO_CHAR(NOW(), 'YYYYMMDD') || '-' || UPPER(SUBSTRING(MD5(RANDOM()::TEXT) FROM 1 FOR 6));
  RETURN new_number;
END;
$$ LANGUAGE plpgsql;

-- Trigger to auto-generate order number
CREATE OR REPLACE FUNCTION set_order_number()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.order_number IS NULL THEN
    NEW.order_number := generate_order_number();
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS before_insert_order ON orders;
CREATE TRIGGER before_insert_order
  BEFORE INSERT ON orders
  FOR EACH ROW
  EXECUTE FUNCTION set_order_number();

-- ============================================================================
-- 5. ORDER_TRACKING TABLE (MEDIUM PRIORITY)
-- ============================================================================
CREATE TABLE IF NOT EXISTS order_tracking (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  
  status order_status NOT NULL,
  location TEXT, -- e.g., "Riyadh Distribution Center"
  location_ar TEXT,
  description TEXT,
  description_ar TEXT,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add RLS policies
ALTER TABLE order_tracking ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view tracking for their orders"
  ON order_tracking FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_tracking.order_id
      AND (orders.buyer_id = auth.uid() OR orders.seller_id = auth.uid())
    )
  );

-- ============================================================================
-- 6. REVIEWS TABLE (MEDIUM PRIORITY)
-- ============================================================================
CREATE TABLE IF NOT EXISTS reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Relations
  product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  seller_id UUID NOT NULL REFERENCES auth.users(id),
  reviewer_id UUID NOT NULL REFERENCES auth.users(id),
  order_id UUID REFERENCES orders(id), -- To verify purchase
  
  -- Review content
  rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  title TEXT,
  title_ar TEXT,
  comment TEXT,
  comment_ar TEXT,
  
  -- Verification
  verified_purchase BOOLEAN DEFAULT false,
  
  -- Helpful votes
  helpful_count INTEGER DEFAULT 0,
  
  -- Moderation
  is_approved BOOLEAN DEFAULT true,
  is_flagged BOOLEAN DEFAULT false,
  flagged_reason TEXT,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add RLS policies
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Reviews are viewable by everyone"
  ON reviews FOR SELECT
  USING (is_approved = true);

CREATE POLICY "Users can create reviews for their purchases"
  ON reviews FOR INSERT
  WITH CHECK (
    auth.uid() = reviewer_id
    AND EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_id
      AND orders.buyer_id = auth.uid()
      AND orders.status = 'delivered'
    )
  );

CREATE POLICY "Users can update their own reviews"
  ON reviews FOR UPDATE
  USING (auth.uid() = reviewer_id);

-- ============================================================================
-- 7. MESSAGES/CONVERSATIONS TABLE (MEDIUM PRIORITY)
-- ============================================================================
CREATE TABLE IF NOT EXISTS conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Participants
  user1_id UUID NOT NULL REFERENCES auth.users(id),
  user2_id UUID NOT NULL REFERENCES auth.users(id),
  
  -- Context
  product_id UUID REFERENCES products(id), -- Optional: conversation about a product
  
  -- Metadata
  last_message_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  last_message_preview TEXT,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  UNIQUE(user1_id, user2_id, product_id)
);

CREATE TABLE IF NOT EXISTS messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  
  sender_id UUID NOT NULL REFERENCES auth.users(id),
  receiver_id UUID NOT NULL REFERENCES auth.users(id),
  
  -- Message content
  message TEXT NOT NULL,
  message_type TEXT DEFAULT 'text', -- 'text', 'image', 'offer'
  
  -- Offer details (if message_type = 'offer')
  offer_amount DECIMAL(10,2),
  offer_status TEXT, -- 'pending', 'accepted', 'rejected'
  
  -- Status
  is_read BOOLEAN DEFAULT false,
  read_at TIMESTAMP WITH TIME ZONE,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add RLS policies for conversations
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their conversations"
  ON conversations FOR SELECT
  USING (auth.uid() = user1_id OR auth.uid() = user2_id);

CREATE POLICY "Users can create conversations"
  ON conversations FOR INSERT
  WITH CHECK (auth.uid() = user1_id);

-- Add RLS policies for messages
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their messages"
  ON messages FOR SELECT
  USING (auth.uid() = sender_id OR auth.uid() = receiver_id);

CREATE POLICY "Users can send messages"
  ON messages FOR INSERT
  WITH CHECK (auth.uid() = sender_id);

CREATE POLICY "Users can update their received messages (mark as read)"
  ON messages FOR UPDATE
  USING (auth.uid() = receiver_id);

-- ============================================================================
-- 8. FAVORITES TABLE (LOW PRIORITY - can use localStorage)
-- ============================================================================
CREATE TABLE IF NOT EXISTS favorites (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  UNIQUE(user_id, product_id)
);

-- Add RLS policies
ALTER TABLE favorites ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their favorites"
  ON favorites FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can add favorites"
  ON favorites FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can remove favorites"
  ON favorites FOR DELETE
  USING (auth.uid() = user_id);

-- ============================================================================
-- 9. NOTIFICATIONS TABLE (LOW PRIORITY)
-- ============================================================================
CREATE TYPE notification_type AS ENUM (
  'new_message',
  'new_order',
  'order_status_update',
  'payment_received',
  'product_sold',
  'new_review',
  'price_drop',
  'system'
);

CREATE TABLE IF NOT EXISTS notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  
  type notification_type NOT NULL,
  title TEXT NOT NULL,
  title_ar TEXT NOT NULL,
  message TEXT,
  message_ar TEXT,
  
  -- Related entities
  related_user_id UUID REFERENCES auth.users(id),
  related_product_id UUID REFERENCES products(id),
  related_order_id UUID REFERENCES orders(id),
  
  -- Action
  action_url TEXT,
  
  -- Status
  is_read BOOLEAN DEFAULT false,
  read_at TIMESTAMP WITH TIME ZONE,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add RLS policies
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their notifications"
  ON notifications FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their notifications (mark as read)"
  ON notifications FOR UPDATE
  USING (auth.uid() = user_id);

-- ============================================================================
-- 10. PRODUCT VIEWS TABLE (for analytics)
-- ============================================================================
CREATE TABLE IF NOT EXISTS product_views (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  user_id UUID REFERENCES auth.users(id), -- NULL for anonymous
  
  -- Session tracking
  session_id TEXT,
  ip_address INET,
  user_agent TEXT,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add RLS policies
ALTER TABLE product_views ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can record product views"
  ON product_views FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Sellers can view their product analytics"
  ON product_views FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM products
      WHERE products.id = product_views.product_id
      AND products.seller_id = auth.uid()
    )
  );

-- ============================================================================
-- INDEXES FOR PERFORMANCE
-- ============================================================================

-- Products
CREATE INDEX IF NOT EXISTS idx_products_seller ON products(seller_id);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);
CREATE INDEX IF NOT EXISTS idx_products_created ON products(created_at DESC);

-- Orders
CREATE INDEX IF NOT EXISTS idx_orders_buyer ON orders(buyer_id);
CREATE INDEX IF NOT EXISTS idx_orders_seller ON orders(seller_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(created_at DESC);

-- Messages
CREATE INDEX IF NOT EXISTS idx_messages_conversation ON messages(conversation_id);
CREATE INDEX IF NOT EXISTS idx_messages_sender ON messages(sender_id);
CREATE INDEX IF NOT EXISTS idx_messages_receiver ON messages(receiver_id);

-- Reviews
CREATE INDEX IF NOT EXISTS idx_reviews_product ON reviews(product_id);
CREATE INDEX IF NOT EXISTS idx_reviews_seller ON reviews(seller_id);

-- Notifications
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_unread ON notifications(user_id, is_read);

-- Product views
CREATE INDEX IF NOT EXISTS idx_product_views_product ON product_views(product_id);
CREATE INDEX IF NOT EXISTS idx_product_views_created ON product_views(created_at DESC);

-- ============================================================================
-- FUNCTIONS FOR ANALYTICS
-- ============================================================================

-- Function to get seller statistics
CREATE OR REPLACE FUNCTION get_seller_stats(seller_uuid UUID)
RETURNS TABLE (
  total_sales BIGINT,
  total_revenue DECIMAL,
  platform_fees DECIMAL,
  net_revenue DECIMAL,
  active_listings BIGINT,
  avg_rating DECIMAL,
  total_reviews BIGINT
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    COUNT(DISTINCT o.id)::BIGINT as total_sales,
    COALESCE(SUM(o.total_price), 0) as total_revenue,
    COALESCE(SUM(o.platform_fee_amount), 0) as platform_fees,
    COALESCE(SUM(o.seller_amount), 0) as net_revenue,
    (SELECT COUNT(*) FROM products WHERE seller_id = seller_uuid AND status = 'active')::BIGINT as active_listings,
    COALESCE((SELECT AVG(rating) FROM reviews WHERE seller_id = seller_uuid), 0) as avg_rating,
    (SELECT COUNT(*) FROM reviews WHERE seller_id = seller_uuid)::BIGINT as total_reviews
  FROM orders o
  WHERE o.seller_id = seller_uuid
    AND o.status IN ('delivered', 'shipped', 'confirmed');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to update product category counts
CREATE OR REPLACE FUNCTION update_category_counts()
RETURNS VOID AS $$
BEGIN
  UPDATE categories
  SET product_count = (
    SELECT COUNT(*)
    FROM products
    WHERE products.category = categories.name
      AND products.status = 'active'
  );
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- TRIGGERS
-- ============================================================================

-- Update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply to all tables with updated_at
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_products_updated_at BEFORE UPDATE ON products
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_orders_updated_at BEFORE UPDATE ON orders
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_addresses_updated_at BEFORE UPDATE ON addresses
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_categories_updated_at BEFORE UPDATE ON categories
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================================================
-- DONE!
-- ============================================================================
-- All tables created successfully!
-- Next steps:
-- 1. Run this script in Supabase SQL Editor
-- 2. Verify all tables exist in Database > Tables
-- 3. Check RLS policies are enabled
-- 4. Create corresponding service files in /src/app/services/
-- ============================================================================
