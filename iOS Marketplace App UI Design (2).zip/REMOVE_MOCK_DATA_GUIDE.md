# 🚀 Complete Guide: Remove ALL Mock Data

## 📋 What You Have Now

I've created **3 essential documents** for you:

1. **`/MOCK_DATA_AUDIT.md`** - Complete list of all mock data (50+ instances across 21 files)
2. **`/DATABASE_TABLES_COMPLETE.sql`** - SQL script to create ALL database tables
3. **`/REMOVE_MOCK_DATA_GUIDE.md`** - This file (step-by-step instructions)

---

## 🎯 Quick Summary

**Mock Data Found:**
- ✅ Products (14 mock products) - **PARTIALLY FIXED** (database integration done, fallbacks remain)
- ❌ Categories (8 mock categories)
- ❌ Seller stats (sales, revenue, fees) - **COMPLETELY MOCKED**
- ❌ Orders/Sales data - **COMPLETELY MOCKED**
- ❌ Seller profiles - **COMPLETELY MOCKED**
- ❌ Messages/Chats - **COMPLETELY MOCKED**
- ❌ Reviews - **COMPLETELY MOCKED**
- ❌ Analytics - **COMPLETELY MOCKED**

---

## 📊 Step-by-Step Implementation Plan

### **STEP 1: Create All Database Tables** ⏱️ 5 minutes

1. **Open Supabase Dashboard**
   - Go to your project: https://supabase.com/dashboard
   - Click "SQL Editor" in left sidebar

2. **Run the Complete SQL Script**
   - Open `/DATABASE_TABLES_COMPLETE.sql`
   - Copy the ENTIRE file
   - Paste into Supabase SQL Editor
   - Click "Run" button

3. **Verify Tables Created**
   - Go to "Database" → "Tables" in Supabase
   - You should see these NEW tables:
     - ✅ `categories` (with 8 default categories inserted)
     - ✅ `profiles`
     - ✅ `addresses`
     - ✅ `orders`
     - ✅ `order_tracking`
     - ✅ `reviews`
     - ✅ `conversations`
     - ✅ `messages`
     - ✅ `favorites`
     - ✅ `notifications`
     - ✅ `product_views`

4. **Check Default Data**
   - Click on `categories` table
   - You should see 8 categories already inserted:
     - Electronics / إلكترونيات
     - Fashion / أزياء
     - Home & Garden / المنزل والحديقة
     - Sports / رياضة
     - Books / كتب
     - Toys / ألعاب
     - Beauty / تجميل
     - Automotive / سيارات

**✅ Checkpoint:** All tables exist with RLS policies enabled

---

### **STEP 2: Create Service Files** ⏱️ 30 minutes

You need to create service files to interact with the new tables. I'll help you create them one by one.

**Do you want me to:**
- A) Create ALL service files at once (automated, fast)
- B) Create them step-by-step with explanations (educational, slower)

**Service files needed:**
1. `/src/app/services/categories.service.ts`
2. `/src/app/services/orders.service.ts`
3. `/src/app/services/sellers.service.ts`
4. `/src/app/services/messages.service.ts`
5. `/src/app/services/reviews.service.ts`
6. `/src/app/services/search.service.ts`

---

### **STEP 3: Update Screens to Use Real Data** ⏱️ 60-90 minutes

Once services are created, update each screen:

#### **Priority 1: Buyer Home (CRITICAL)**
- File: `/src/app/screens/rabit/RabitBuyerHomeScreen.tsx`
- Replace: `rabitProducts` with `browseProducts()` service
- Replace: `rabitCategories` with `getCategories()` service
- Remove: All mock data references

#### **Priority 2: Categories Screen**
- File: `/src/app/screens/rabit/RabitCategoriesScreen.tsx`
- Replace: `rabitCategories` with `getCategories()`
- Replace: Product filtering with `getCategoryProducts(categoryId)`

#### **Priority 3: Search Screen**
- File: `/src/app/screens/rabit/RabitSearchScreen.tsx`
- Replace: Local filtering with `searchProducts(query)` service

#### **Priority 4: Seller Dashboard**
- File: `/src/app/screens/rabit/RabitSellerDashboardScreen.tsx`
- Replace: Mock stats with `getSellerStats()` service
- Replace: Mock sales with `getSellerOrders()` service
- Remove: All fallbacks to `rabitProducts`

#### **Priority 5: Seller Profile**
- File: `/src/app/screens/rabit/RabitSellerProfileScreen.tsx`
- Replace: Mock seller info with `getSellerProfile()` service
- Replace: Product list with `getSellerProducts()` (already exists)

**And so on for remaining screens...**

---

### **STEP 4: Remove Mock Data Arrays** ⏱️ 5 minutes

Once everything uses real services:

1. **Edit `/src/app/data/rabitProducts.ts`**
   ```typescript
   // ============================================================================
   // KEEP THESE INTERFACES - NEEDED FOR TYPE DEFINITIONS
   // ============================================================================
   export interface RabitProduct {
     id: string;
     title: string;
     titleAr: string;
     price: number;
     // ... rest of interface
   }

   export interface RabitCategory {
     id: string;
     name: string;
     nameAr: string;
     // ... rest of interface
   }

   // ============================================================================
   // MOCK DATA - COMMENTED OUT (Everything now from database)
   // ============================================================================
   /*
   export const rabitCategories: RabitCategory[] = [
     // ... commented out
   ];

   export const rabitProducts: RabitProduct[] = [
     // ... commented out
   ];
   */

   // ============================================================================
   // TEMPORARY: Empty arrays to prevent import errors during migration
   // ============================================================================
   export const rabitCategories: RabitCategory[] = [];
   export const rabitProducts: RabitProduct[] = [];
   ```

2. **Or completely delete the arrays** once all screens are updated

---

### **STEP 5: Test Everything** ⏱️ 30 minutes

Go through each screen and verify:

#### **Buyer Flow:**
1. ✅ Home shows real products from database
2. ✅ Categories show real data with counts
3. ✅ Search works with real products
4. ✅ Product details load correctly
5. ✅ Favorites work (either localStorage or database)

#### **Seller Flow:**
1. ✅ Seller home shows YOUR products only
2. ✅ Add product → appears in seller home
3. ✅ Dashboard shows real stats (or 0 if no sales yet)
4. ✅ Products tab shows your listings
5. ✅ Edit/delete products work

#### **Future Features (After Orders Table is Used):**
1. ⏳ Checkout creates real order
2. ⏳ Seller sees orders in sales screen
3. ⏳ Order tracking shows real status
4. ⏳ Messages work between users
5. ⏳ Reviews appear after order delivery

---

## 🚦 Current Status vs After Implementation

### **BEFORE (Current State):**
```
Products: ⚠️  Database + Mock Fallbacks
Categories: ❌ 100% Mock Data
Seller Stats: ❌ 100% Hardcoded
Orders: ❌ 100% Mock Data
Messages: ❌ 100% Mock Data
Reviews: ❌ 100% Mock Data
Analytics: ❌ 100% Mock Data
```

### **AFTER (Full Implementation):**
```
Products: ✅ 100% Database
Categories: ✅ 100% Database
Seller Stats: ✅ 100% Real (calculated from orders)
Orders: ✅ 100% Database
Messages: ✅ 100% Database (+ Real-time)
Reviews: ✅ 100% Database
Analytics: ✅ 100% Real (calculated)
```

---

## 🎯 Recommended Approach

### **Option A: All at Once (Advanced)**
**Time:** 2-3 hours
**Risk:** High (everything breaks if something goes wrong)
**Best for:** Experienced developers

1. Run SQL script
2. Create all services
3. Update all screens
4. Remove mock data
5. Test everything

### **Option B: Incremental (Recommended)**
**Time:** 4-6 hours over multiple sessions
**Risk:** Low (one feature at a time)
**Best for:** Learning & stability

**Session 1: Categories (1 hour)**
- Create categories table ✅ (already done with SQL script)
- Create categories.service.ts
- Update RabitBuyerHomeScreen
- Update RabitCategoriesScreen
- Test categories work

**Session 2: Search (1 hour)**
- Create search.service.ts
- Update RabitSearchScreen
- Test search works

**Session 3: Seller Stats (1.5 hours)**
- Create sellers.service.ts
- Update RabitSellerDashboardScreen
- Update RabitSellerProfileScreen
- Test seller data shows correctly

**Session 4: Orders System (2 hours)**
- Create orders.service.ts
- Update RabitCheckoutScreen
- Update RabitSellerSalesScreen
- Update RabitOrderTrackingScreen
- Test full order flow

**Session 5: Messages & Reviews (1.5 hours)**
- Create messages.service.ts
- Create reviews.service.ts
- Update messaging screens
- Update review screens
- Test real-time features

---

## 🛠️ What Do You Want Me to Do Next?

**Choose one:**

### **A) Start with Categories (Quick Win)**
- ✅ Database tables already created
- ✅ Default data already inserted
- ⏱️ 30 minutes to implement
- ✨ Immediate visual impact

I'll create:
- `categories.service.ts`
- Update `RabitBuyerHomeScreen`
- Update `RabitCategoriesScreen`

### **B) Complete Seller Dashboard (High Impact)**
- ⏱️ 1 hour to implement
- Shows real stats, orders, products
- No more mock numbers

I'll create:
- `sellers.service.ts`
- `orders.service.ts` (basic)
- Update `RabitSellerDashboardScreen`

### **C) Full Search Implementation**
- ⏱️ 45 minutes
- Real product search
- Better UX

I'll create:
- `search.service.ts`
- Update `RabitSearchScreen`
- Add full-text search

### **D) Everything at Once (Automated)**
- ⏱️ 2 hours (for me to code)
- All services created
- All screens updated
- Mock data removed
- You just test

### **E) Custom Priority**
Tell me which feature is most important to you and I'll start there.

---

## 📝 Notes

- **Keep the SQL script** - You might need to run it on production later
- **Backup first** - Export your current Supabase database before running SQL
- **Test incrementally** - Don't update everything at once
- **Check console** - Browser console will show API errors if something breaks

---

## 🎉 Final Goal

By the end, you'll have:
- ✅ Zero mock data anywhere
- ✅ 100% real database integration
- ✅ All features working with Supabase
- ✅ Production-ready marketplace
- ✅ Real-time features (messages, notifications)
- ✅ Scalable architecture

**Choose your path and let me know! I'm ready to help implement whichever option you prefer.** 🚀
