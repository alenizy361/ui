# 🔧 Database Setup Required - Products Table Missing

## ❌ Current Error

```
Could not find the table 'public.products' in the schema cache
```

**Translation:** The `products` table doesn't exist in your Supabase database yet.

---

## ✅ How to Fix (3 Minutes)

### Step 1: Open Supabase SQL Editor

Choose one of these methods:

**Method A - Direct Link:**
```
https://supabase.com/dashboard/project/YOUR_PROJECT_ID/sql
```

**Method B - Navigate:**
1. Go to https://supabase.com/dashboard
2. Click your project
3. Click "SQL Editor" in the left sidebar
4. Click "+ New query" button

---

### Step 2: Paste This SQL

Copy and paste this **ENTIRE** SQL script:

```sql
-- ============================================
-- RABIT PLATFORM - PRODUCTS TABLE SETUP
-- ============================================
-- This creates the products table with RLS policies
-- Run this ONCE in Supabase SQL Editor
-- ============================================

-- Create products table
CREATE TABLE IF NOT EXISTS public.products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  price DECIMAL(10, 2) NOT NULL,
  category TEXT NOT NULL,
  condition TEXT NOT NULL CHECK (condition IN ('new', 'used')),
  images TEXT[] NOT NULL DEFAULT '{}',
  location TEXT,
  quantity INTEGER NOT NULL DEFAULT 1,
  delivery_options TEXT[] DEFAULT '{}',
  seller_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  
  -- Constraints
  CONSTRAINT products_price_positive CHECK (price > 0),
  CONSTRAINT products_quantity_positive CHECK (quantity >= 0)
);

-- Create indexes for faster queries
CREATE INDEX IF NOT EXISTS products_seller_id_idx ON public.products(seller_id);
CREATE INDEX IF NOT EXISTS products_category_idx ON public.products(category);
CREATE INDEX IF NOT EXISTS products_created_at_idx ON public.products(created_at DESC);
CREATE INDEX IF NOT EXISTS products_price_idx ON public.products(price);

-- Enable Row Level Security
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if any (prevents duplicate errors)
DROP POLICY IF EXISTS "Anyone can view products" ON public.products;
DROP POLICY IF EXISTS "Users can create their own products" ON public.products;
DROP POLICY IF EXISTS "Users can update their own products" ON public.products;
DROP POLICY IF EXISTS "Users can delete their own products" ON public.products;

-- RLS Policy 1: Anyone can view products (public marketplace)
CREATE POLICY "Anyone can view products"
ON public.products FOR SELECT
USING (true);

-- RLS Policy 2: Authenticated users can create their own products
CREATE POLICY "Users can create their own products"
ON public.products FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = seller_id);

-- RLS Policy 3: Users can update their own products
CREATE POLICY "Users can update their own products"
ON public.products FOR UPDATE
TO authenticated
USING (auth.uid() = seller_id)
WITH CHECK (auth.uid() = seller_id);

-- RLS Policy 4: Users can delete their own products
CREATE POLICY "Users can delete their own products"
ON public.products FOR DELETE
TO authenticated
USING (auth.uid() = seller_id);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to auto-update updated_at
DROP TRIGGER IF EXISTS update_products_updated_at ON public.products;
CREATE TRIGGER update_products_updated_at
BEFORE UPDATE ON public.products
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

-- Verify setup (optional - shows table structure)
SELECT 
  'Products table created successfully!' AS status,
  COUNT(*) AS product_count
FROM public.products;
```

---

### Step 3: Run the SQL

1. **Click "Run"** (bottom right)
   - OR press `Ctrl+Enter` (Windows/Linux)
   - OR press `Cmd+Enter` (Mac)

2. **Wait for confirmation** (should take 2-3 seconds)

3. **Look for success message:**
   ```
   ✅ Success. No rows returned
   ```
   OR
   ```
   ✅ Products table created successfully! | product_count: 0
   ```

---

### Step 4: Verify Setup

Run this query to verify:

```sql
-- Check if table exists
SELECT 
  table_name, 
  table_type
FROM information_schema.tables
WHERE table_schema = 'public' 
  AND table_name = 'products';
```

Expected result:
```
table_name: products
table_type: BASE TABLE
```

---

## 🎯 What This Creates

### Table Structure:
- ✅ `products` table with 12 columns
- ✅ Foreign key to `auth.users` (seller_id)
- ✅ 4 indexes for fast queries
- ✅ Automatic timestamps

### Security (RLS):
- ✅ Public viewing (anyone can browse)
- ✅ Authenticated creation (logged-in users)
- ✅ Owner-only updates (edit your own products)
- ✅ Owner-only deletion (delete your own products)

---

## 🔍 Troubleshooting

### Error: "relation already exists"
**Cause:** Table already created
**Fix:** It's fine! The SQL uses `IF NOT EXISTS` to prevent errors

### Error: "permission denied"
**Cause:** Not logged in as project owner
**Fix:** Make sure you're logged into the correct Supabase account

### Error: "syntax error"
**Cause:** SQL not copied completely
**Fix:** Copy the ENTIRE SQL block above (all 100+ lines)

---

## ✅ After Running SQL

Your app will immediately work! Try:

1. **Sign in to Rabit Platform**
2. **Switch to Seller role**
3. **Click "Add Product"**
4. **Upload images**
5. **Fill product details**
6. **Click "Publish"**
7. **Success! 🎉**

---

## 📋 Complete Setup Checklist

Before testing product creation:

- [x] Storage buckets created (`product-images`, `profile-images`)
- [ ] Storage RLS policies configured (for image uploads)
- [ ] **Products table created (YOU ARE HERE)**
- [ ] Test product creation end-to-end

---

## 🚀 Quick Links

- [Supabase Dashboard](https://supabase.com/dashboard)
- [SQL Editor Direct](https://supabase.com/dashboard/project/YOUR_PROJECT_ID/sql)
- [Table Editor](https://supabase.com/dashboard/project/YOUR_PROJECT_ID/editor)

---

**Action:** Open SQL Editor and run the SQL above NOW! Takes 2 minutes. 🎯
