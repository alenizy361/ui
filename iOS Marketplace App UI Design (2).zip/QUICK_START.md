# Quick Start - Testing the New Auth Flow

## Console Commands

Open browser console and run:

```javascript
// 1. Check current auth state
debugAuth()

// 2. Show test page for quick testing
showAuthTest()
```

## Test Registration

### Option 1: Use Test Page
1. Run `showAuthTest()` in console
2. Fill in form:
   - Email: `test@example.com`
   - Password: `Test123456`
   - Name: `Test User`
   - Phone: `501234567`
3. Click "Sign Up"
4. Check status display

### Option 2: Use App Flow
1. Start app → Welcome Screen
2. Click "Sign Up"
3. Fill registration form
4. Accept terms
5. Click Continue
6. Select role (Buyer/Seller)
7. Automatically signed in

## Test Login

### Option 1: Use Test Page
1. Run `showAuthTest()` in console
2. Fill in credentials
3. Click "Sign In"
4. Check status display

### Option 2: Use App Flow
1. Start app → Welcome Screen
2. Click "Sign In"
3. Enter credentials
4. Click "Sign In"
5. Navigate to home based on role

## Verify Session Persistence

1. Sign in (via any method)
2. Refresh the page
3. Run `debugAuth()` in console
4. Verify user is still logged in
5. Check email, role, etc.

## Test Sign Out

### Via Test Page
1. Click "Sign Out" button
2. Status should show "Authenticated: ❌ NO"

### Via App
1. Go to Settings/Profile
2. Click sign out
3. Should return to Welcome screen

## Debug Info

The `debugAuth()` function shows:
- ✅ Authentication status
- 👤 User details (email, name, role, ID)
- 📱 Current screen
- ⏳ Loading state

Example output:
```
=== AUTH DEBUG INFO ===
🔐 isAuthenticated: true
⏳ isLoading: false
👤 user: {id: "...", email: "test@example.com", ...}
📧 email: test@example.com
🎭 role: buyer
✅ verified: true
🆔 id: abc123...
📱 currentScreen: buyerHome
======================
```

## Common Issues

### User Not Signed In After Registration
- Check browser console for errors
- Run `debugAuth()` to see state
- Verify Supabase project is active (not paused)

### Session Not Persisting
- Check browser localStorage
- Look for key: `sb-[project-id]-auth-token`
- Verify cookies are enabled

### Role Not Set
- Role is set during registration
- Can be updated via `updateRole()` in context
- Stored in `user.user_metadata.role`

## Environment Check

Verify Supabase is configured:
1. Check `/.env` file exists
2. Contains `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`
3. Values match your Supabase project
4. Project is not paused in Supabase dashboard

## Success Criteria

✅ Can register new user
✅ Can sign in existing user
✅ Session persists across refresh
✅ Role is correctly set and displayed
✅ Can sign out
✅ Can update role
✅ No console errors
✅ Auth state updates immediately
