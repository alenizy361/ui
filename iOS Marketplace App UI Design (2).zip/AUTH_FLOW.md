# Rabit Platform - Clean Auth Flow

## Overview
The authentication system has been completely rebuilt from scratch with a simple, clean architecture using only Supabase Auth API (no Edge Functions, no backend routes).

## Architecture

### AuthContext (`/src/app/contexts/AuthContext.tsx`)
Single source of truth for authentication state:

- **State**: `user`, `isAuthenticated`, `isLoading`
- **Methods**:
  - `signUp(email, password, name, phone, role)` - Register new user
  - `signIn(email, password)` - Sign in existing user
  - `signOut()` - Sign out current user
  - `updateRole(role)` - Update user's role

### User Profile
Stored in Supabase Auth `user_metadata`:
```typescript
{
  id: string;
  email: string;
  name: string;
  phone: string;
  role: 'buyer' | 'seller' | 'both';
  verified: boolean;
}
```

## User Flows

### Registration Flow
1. User fills out registration form → **RabitRegisterScreen**
2. Data validated, passed to App.tsx
3. User selects role (Buyer/Seller) → **RabitRoleSelectionScreen**
4. App calls `signUp(email, password, name, phone, role)`
5. Supabase creates user with metadata
6. User is automatically signed in
7. Navigate to home screen based on role

### Login Flow
1. User enters credentials → **RabitLoginScreen**
2. Screen calls `signIn(email, password)`
3. Supabase validates credentials
4. User profile loaded from metadata
5. Navigate to home screen based on role

### Role Update Flow
1. User changes role in settings
2. App calls `updateRole(newRole)`
3. Supabase updates user metadata
4. User profile refreshed
5. Navigate to appropriate home screen

## Key Changes

### ✅ What Changed
- **Deleted**: All debug components (AuthDebugPanel, QuickAuthCheck, RoleFixHelper)
- **Simplified**: AuthContext now handles everything directly
- **Removed**: Dependency on auth.service.ts functions
- **Clean**: Direct Supabase API calls, no intermediary layers

### ✅ What Stayed
- All screen components (Login, Register, etc.)
- UI/UX exactly the same
- RTL layout preserved
- Validation logic unchanged
- Role selection flow unchanged

## Testing

Use the console commands:
```javascript
// Check auth status
debugAuth()

// Show simple test page
showAuthTest()
```

The test page (`SimpleAuthTest`) provides:
- Direct sign up/sign in interface
- Real-time status display
- Error messages
- Sign out functionality

## Session Management

- **Persistence**: Supabase handles session storage automatically
- **Refresh**: Tokens auto-refresh via Supabase SDK
- **Sync**: Auth state changes trigger context updates
- **Events**: Listens to SIGNED_IN, SIGNED_OUT, TOKEN_REFRESHED, USER_UPDATED

## Error Handling

All auth methods return:
```typescript
{
  success: boolean;
  error?: string;
}
```

Errors are displayed via:
- Toast notifications (sonner)
- Form validation errors
- Status messages in test UI

## Files Modified

1. `/src/app/contexts/AuthContext.tsx` - Complete rewrite
2. `/src/app/screens/rabit/RabitLoginScreen.tsx` - Updated to use new context
3. `/src/app/App.tsx` - Updated to use signUp/signIn/signOut/updateRole
4. `/src/app/screens/rabit/RabitRegisterScreen.tsx` - Removed unused imports

## Files Deleted

1. `/src/app/components/AuthDebugPanel.tsx`
2. `/src/app/components/QuickAuthCheck.tsx`
3. `/src/app/components/RoleFixHelper.tsx`

## Next Steps

1. Test registration flow
2. Test login flow
3. Test role changes
4. Test session persistence (refresh page)
5. Test sign out
6. Verify all user roles work correctly
