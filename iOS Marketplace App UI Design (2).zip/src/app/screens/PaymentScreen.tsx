import { motion, AnimatePresence } from "motion/react";
import { ChevronLeft, CreditCard, Lock, Apple, Check } from "lucide-react";
import { Product } from "../data/products";
import { WiseButton } from "../components/WiseButton";
import { useState } from "react";

interface PaymentScreenProps {
  product: Product;
  onBack: () => void;
  onPaymentSuccess: () => void;
}

type ButtonState = "default" | "loading" | "success" | "error";

export function PaymentScreen({
  product,
  onBack,
  onPaymentSuccess,
}: PaymentScreenProps) {
  const shippingCost = 15;
  const serviceFee = 5.99;
  const total = product.price + shippingCost + serviceFee;

  const [selectedPayment, setSelectedPayment] = useState("card");
  const [buttonState, setButtonState] = useState<ButtonState>("default");

  const handlePayment = () => {
    setButtonState("loading");
    setTimeout(() => {
      setButtonState("success");
      setTimeout(() => {
        onPaymentSuccess();
      }, 1000);
    }, 2000);
  };

  const paymentMethods = [
    {
      id: "card",
      name: "Credit/Debit Card",
      icon: CreditCard,
      description: "•••• 4242",
    },
    {
      id: "apple",
      name: "Apple Pay",
      icon: Apple,
      description: "Fast & secure",
    },
    {
      id: "mada",
      name: "Mada",
      icon: CreditCard,
      description: "Saudi payment",
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white/95 backdrop-blur-lg border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 flex items-center gap-4 z-10"
      >
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center text-[#0e0f0c] hover:bg-[rgba(22,51,0,0.12941)] transition-colors"
          disabled={buttonState !== "default"}
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-semibold text-[#0e0f0c]">Payment</h1>
      </motion.div>

      <div className="p-6 space-y-6">
        {/* Total Amount - Wise Style */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="text-center py-8"
        >
          <p className="text-sm text-[#6a6c6a] mb-2">Total Amount</p>
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-5xl font-semibold mb-1 text-[#0e0f0c]"
          >
            ${total.toFixed(2)}
          </motion.h1>
          <p className="text-sm text-[#6a6c6a]">SAR {(total * 3.75).toFixed(2)}</p>
        </motion.div>

        {/* Price Breakdown - Wise Style */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-[rgba(22,51,0,0.07843)] rounded-[10px] p-5 border border-[rgba(14,15,12,0.12157)]"
        >
          <h3 className="text-sm font-medium text-[#454745] mb-4">
            Payment breakdown
          </h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-[#0e0f0c]">{product.title}</span>
              <span className="font-medium text-[#0e0f0c]">${product.price.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-[#0e0f0c]">Shipping</span>
              <span className="font-medium text-[#0e0f0c]">${shippingCost.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-1">
                <span className="text-[#0e0f0c]">Service fee</span>
                <div className="w-4 h-4 rounded-full bg-[rgba(14,15,12,0.12157)] flex items-center justify-center text-xs text-[#6a6c6a]">
                  ?
                </div>
              </div>
              <span className="font-medium text-[#0e0f0c]">${serviceFee.toFixed(2)}</span>
            </div>
            <div className="pt-3 border-t border-[rgba(14,15,12,0.12157)] flex justify-between items-center">
              <span className="font-semibold text-[#0e0f0c]">You pay</span>
              <span className="font-semibold text-xl text-[#163300]">${total.toFixed(2)}</span>
            </div>
          </div>
        </motion.div>

        {/* Payment Methods */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="space-y-3"
        >
          <h3 className="text-sm font-medium text-[#454745] mb-3">
            Payment method
          </h3>
          {paymentMethods.map((method, index) => (
            <motion.button
              key={method.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 + index * 0.1 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setSelectedPayment(method.id)}
              disabled={buttonState !== "default"}
              className={`w-full bg-white rounded-[10px] p-4 flex items-center gap-4 transition-all ${
                selectedPayment === method.id
                  ? "ring-2 ring-[#163300] border-transparent"
                  : "border border-[rgba(14,15,12,0.12157)]"
              }`}
            >
              <div
                className={`w-12 h-12 rounded-[10px] flex items-center justify-center ${
                  selectedPayment === method.id
                    ? "bg-[#163300] text-white"
                    : "bg-[rgba(22,51,0,0.07843)] text-[#163300]"
                }`}
              >
                <method.icon className="w-6 h-6" />
              </div>
              <div className="flex-1 text-left">
                <p className="font-medium text-[#0e0f0c]">{method.name}</p>
                <p className="text-sm text-[#6a6c6a]">{method.description}</p>
              </div>
              <div
                className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                  selectedPayment === method.id
                    ? "border-[#163300] bg-[#163300]"
                    : "border-[rgba(14,15,12,0.12157)]"
                }`}
              >
                {selectedPayment === method.id && (
                  <Check className="w-4 h-4 text-white" />
                )}
              </div>
            </motion.button>
          ))}
        </motion.div>

        {/* Security Badge */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="flex items-center justify-center gap-2 text-sm text-[#6a6c6a]"
        >
          <Lock className="w-4 h-4" />
          <span>Secured by 256-bit SSL encryption</span>
        </motion.div>
      </div>

      {/* Bottom CTA - Wise Style */}
      <motion.div
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        transition={{ delay: 0.6 }}
        className="fixed bottom-0 left-0 right-0 bg-white border-t border-[rgba(14,15,12,0.12157)] p-6 safe-area-bottom"
      >
        <WiseButton
          onClick={handlePayment}
          variant="primary"
          fullWidth
          size="lg"
          loading={buttonState === "loading"}
          disabled={buttonState !== "default"}
        >
          {buttonState === "success" ? "Payment Successful" : `Pay $${total.toFixed(2)}`}
        </WiseButton>

        <p className="text-center text-xs text-[#6a6c6a] mt-3">
          By confirming payment, you agree to the seller's terms
        </p>
      </motion.div>
    </div>
  );
}