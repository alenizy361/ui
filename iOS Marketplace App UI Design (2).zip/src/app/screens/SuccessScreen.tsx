import { motion } from "motion/react";
import { WiseButton } from "../components/WiseButton";
import { Check } from "lucide-react";

interface SuccessScreenProps {
  onContinue: () => void;
}

export function SuccessScreen({ onContinue }: SuccessScreenProps) {
  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center p-6">
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{
          type: "spring",
          stiffness: 200,
          damping: 15,
          delay: 0.2,
        }}
        className="w-24 h-24 bg-[#163300] rounded-full flex items-center justify-center mb-8 relative"
      >
        <motion.div
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{
            type: "spring",
            stiffness: 200,
            damping: 15,
            delay: 0.4,
          }}
        >
          <Check className="w-12 h-12 text-[#9fe870]" strokeWidth={3} />
        </motion.div>
        <motion.div
          initial={{ scale: 1, opacity: 1 }}
          animate={{ scale: 2, opacity: 0 }}
          transition={{
            duration: 1,
            delay: 0.3,
            repeat: 2,
          }}
          className="absolute inset-0 bg-[#9fe870] rounded-full"
        />
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="text-center mb-12"
      >
        <h1 className="text-3xl font-semibold mb-3 text-[#0e0f0c]">Account Created!</h1>
        <p className="text-[#6a6c6a]">
          Your account has been successfully verified
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
        className="w-full"
      >
        <WiseButton onClick={onContinue} variant="primary" fullWidth size="lg">
          Start Shopping
        </WiseButton>
      </motion.div>
    </div>
  );
}