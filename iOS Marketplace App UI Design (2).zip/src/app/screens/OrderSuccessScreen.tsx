import { motion } from "motion/react";
import { Button } from "../components/Button";
import { Check, Package, Clock } from "lucide-react";

interface OrderSuccessScreenProps {
  orderNumber: string;
  onTrackOrder: () => void;
  onContinueShopping: () => void;
}

export function OrderSuccessScreen({
  orderNumber,
  onTrackOrder,
  onContinueShopping,
}: OrderSuccessScreenProps) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white flex flex-col items-center justify-center p-6">
      {/* Success Animation */}
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{
          type: "spring",
          stiffness: 200,
          damping: 15,
          delay: 0.2,
        }}
        className="w-28 h-28 bg-green-500 rounded-full flex items-center justify-center mb-8 relative"
      >
        <motion.div
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{
            type: "spring",
            stiffness: 200,
            damping: 15,
            delay: 0.4,
          }}
        >
          <Check className="w-14 h-14 text-white" strokeWidth={3} />
        </motion.div>

        {/* Ripple Effect */}
        <motion.div
          initial={{ scale: 1, opacity: 1 }}
          animate={{ scale: 2.5, opacity: 0 }}
          transition={{
            duration: 1.5,
            delay: 0.3,
            repeat: Infinity,
            repeatDelay: 1,
          }}
          className="absolute inset-0 bg-green-400 rounded-full"
        />
      </motion.div>

      {/* Success Message */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="text-center mb-8"
      >
        <h1 className="text-3xl font-bold mb-3">Payment Successful!</h1>
        <p className="text-gray-600 mb-6">
          Your order has been placed successfully
        </p>

        {/* Order Info Card */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.8 }}
          className="bg-white rounded-[20px] p-6 shadow-lg border border-gray-100 mb-6"
        >
          <div className="flex items-center justify-center gap-2 mb-4">
            <Package className="w-5 h-5 text-gray-600" />
            <span className="text-sm text-gray-600">Order Number</span>
          </div>
          <p className="text-2xl font-bold mb-4">{orderNumber}</p>

          <div className="bg-blue-50 rounded-[12px] p-4 flex items-start gap-3">
            <Clock className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div className="text-left">
              <p className="text-sm font-medium text-blue-900 mb-1">
                Waiting for seller to ship
              </p>
              <p className="text-xs text-blue-700">
                You'll receive a notification once the seller ships your order
              </p>
            </div>
          </div>
        </motion.div>
      </motion.div>

      {/* Action Buttons */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1 }}
        className="w-full space-y-3"
      >
        <Button onClick={onTrackOrder} variant="primary" fullWidth>
          Track Order
        </Button>
        <Button onClick={onContinueShopping} variant="secondary" fullWidth>
          Continue Shopping
        </Button>
      </motion.div>
    </div>
  );
}
