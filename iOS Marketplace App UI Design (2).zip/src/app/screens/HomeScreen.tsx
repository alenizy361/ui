import { motion } from "motion/react";
import { Search, ShoppingBag, User, Heart, Grid3x3 } from "lucide-react";
import { useState } from "react";
import { Product, products, categories } from "../data/products";

interface HomeScreenProps {
  onProductClick: (product: Product) => void;
  onSearchClick: () => void;
  onCategoryClick: () => void;
  onOrdersClick: () => void;
}

export function HomeScreen({
  onProductClick,
  onSearchClick,
  onCategoryClick,
  onOrdersClick,
}: HomeScreenProps) {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState("home");

  const filteredProducts = selectedCategory
    ? products.filter((p) => p.category === selectedCategory)
    : products;

  return (
    <div className="min-h-screen bg-white pb-20">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white px-6 pt-12 pb-4 border-b border-[rgba(14,15,12,0.12157)]"
      >
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-semibold text-[#0e0f0c]">Marketplace</h1>
            <p className="text-sm text-[#6a6c6a]">Discover unique products</p>
          </div>
          <button
            onClick={onOrdersClick}
            className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center text-[#163300] hover:bg-[rgba(22,51,0,0.12941)] transition-colors"
          >
            <ShoppingBag className="w-5 h-5" />
          </button>
        </div>

        <motion.button
          whileTap={{ scale: 0.98 }}
          onClick={onSearchClick}
          className="w-full h-12 bg-[rgba(22,51,0,0.07843)] rounded-[10px] flex items-center gap-3 px-4 hover:bg-[rgba(22,51,0,0.12941)] transition-colors"
        >
          <Search className="w-5 h-5 text-[#6a6c6a]" />
          <span className="text-[#6a6c6a]">Search products...</span>
        </motion.button>
      </motion.div>

      {/* Categories Chips */}
      <div className="px-6 py-4 overflow-x-auto">
        <div className="flex gap-2">
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={onCategoryClick}
            className="px-4 py-2 rounded-full bg-[rgba(22,51,0,0.07843)] border border-[rgba(14,15,12,0.12157)] flex items-center gap-2 whitespace-nowrap hover:bg-[rgba(22,51,0,0.12941)] transition-colors"
          >
            <Grid3x3 className="w-4 h-4 text-[#163300]" />
            <span className="text-sm font-medium text-[#0e0f0c]">All Categories</span>
          </motion.button>
          {categories.slice(0, 5).map((category) => (
            <motion.button
              key={category.id}
              whileTap={{ scale: 0.95 }}
              onClick={() =>
                setSelectedCategory(
                  selectedCategory === category.name ? null : category.name
                )
              }
              className={`px-4 py-2 rounded-full whitespace-nowrap transition-all ${
                selectedCategory === category.name
                  ? "bg-[#163300] text-white"
                  : "bg-[rgba(22,51,0,0.07843)] border border-[rgba(14,15,12,0.12157)] hover:bg-[rgba(22,51,0,0.12941)]"
              }`}
            >
              <span className="text-sm font-medium">{category.name}</span>
            </motion.button>
          ))}
        </div>
      </div>

      {/* Product Grid */}
      <div className="px-6 pb-4">
        <div className="grid grid-cols-2 gap-4">
          {filteredProducts.map((product, index) => (
            <motion.button
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => onProductClick(product)}
              className="bg-white rounded-[16px] overflow-hidden shadow-sm"
            >
              <div className="relative aspect-square">
                <img
                  src={product.image}
                  alt={product.title}
                  className="w-full h-full object-cover"
                />
                <button className="absolute top-2 right-2 w-8 h-8 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center">
                  <Heart className="w-4 h-4" />
                </button>
              </div>
              <div className="p-3 text-left">
                <h3 className="font-semibold text-sm mb-1 line-clamp-2">
                  {product.title}
                </h3>
                <p className="text-xs text-gray-600 mb-2">{product.city}</p>
                <div className="flex items-center justify-between">
                  <span className="text-lg font-bold">${product.price}</span>
                  <div className="flex items-center gap-1">
                    <span className="text-xs text-gray-600">
                      ⭐ {product.seller.rating}
                    </span>
                  </div>
                </div>
              </div>
            </motion.button>
          ))}
        </div>
      </div>

      {/* Bottom Navigation */}
      <motion.div
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 px-6 py-3 safe-area-bottom"
      >
        <div className="flex items-center justify-around">
          <button
            onClick={() => setActiveTab("home")}
            className={`flex flex-col items-center gap-1 ${
              activeTab === "home" ? "text-[#030213]" : "text-gray-400"
            }`}
          >
            <ShoppingBag className="w-6 h-6" />
            <span className="text-xs">Home</span>
          </button>
          <button
            onClick={onSearchClick}
            className={`flex flex-col items-center gap-1 ${
              activeTab === "search" ? "text-[#030213]" : "text-gray-400"
            }`}
          >
            <Search className="w-6 h-6" />
            <span className="text-xs">Search</span>
          </button>
          <button
            onClick={onOrdersClick}
            className={`flex flex-col items-center gap-1 ${
              activeTab === "orders" ? "text-[#030213]" : "text-gray-400"
            }`}
          >
            <Grid3x3 className="w-6 h-6" />
            <span className="text-xs">Orders</span>
          </button>
          <button
            className={`flex flex-col items-center gap-1 ${
              activeTab === "profile" ? "text-[#030213]" : "text-gray-400"
            }`}
          >
            <User className="w-6 h-6" />
            <span className="text-xs">Profile</span>
          </button>
        </div>
      </motion.div>
    </div>
  );
}