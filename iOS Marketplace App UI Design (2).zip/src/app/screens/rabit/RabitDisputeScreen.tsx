import { motion } from "motion/react";
import { ChevronRight, AlertTriangle, MessageCircle, Paperclip, Image as ImageIcon, Send, Upload, X, Clock, MessageSquare, CheckCircle, XCircle } from "lucide-react";
import { WiseButton } from "../../components/WiseButton";
import { useState } from "react";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";

interface Message {
  id: string;
  sender: "user" | "seller" | "admin";
  message: string;
  timestamp: string;
  image?: string;
}

interface RabitDisputeScreenProps {
  orderId: string;
  onBack: () => void;
}

export function RabitDisputeScreen({ orderId, onBack }: RabitDisputeScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);
  const [activeTab, setActiveTab] = useState<"create" | "status" | "chat">("create");
  const [disputeReason, setDisputeReason] = useState("");
  const [description, setDescription] = useState("");
  const [evidence, setEvidence] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [disputeStatus, setDisputeStatus] = useState<DisputeStatus>("pending");
  const [chatMessage, setChatMessage] = useState("");
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: "1",
      senderAr: "فريق الدعم",
      messageAr: "شكراً لتواصلك معنا. نحن نراجع نزاعك حالياً وسنرد عليك قريباً.",
      time: "منذ ساعة",
      isSupport: true,
    },
  ]);

  const [showAppealForm, setShowAppealForm] = useState(false);
  const [appealReason, setAppealReason] = useState("");

  const reasons = [
    { id: "not_received", labelAr: "لم أستلم المنتج", descAr: "المنتج لم يصل رغم مرور الوقت المحدد" },
    { id: "damaged", labelAr: "المنتج تالف أو معطوب", descAr: "وصل المنتج بحالة تالفة أو معطوبة" },
    { id: "not_as_described", labelAr: "المنتج لا يطابق الوصف", descAr: "المنتج مختلف عما هو موضح في الإعلان" },
    { id: "fake", labelAr: "المنتج مزيف أو مقلد", descAr: "المنتج غير أصلي أو مقلد" },
    { id: "wrong_item", labelAr: "منتج خاطئ", descAr: "استلمت منتج مختلف عما طلبته" },
    { id: "other", labelAr: "سبب آخر", descAr: "لدي مشكلة أخرى مع الطلب" },
  ];

  const handleSubmitDispute = () => {
    setLoading(true);
    setTimeout(() => {
      setDisputeStatus("under_review");
      setActiveTab("status");
      setLoading(false);
      toast.success("تم فتح النزاع، سنراجعه خلال 3-5 أيام ⚖️");
    }, 1500);
  };

  const handleSendMessage = () => {
    if (chatMessage.trim()) {
      setChatMessages([
        ...chatMessages,
        {
          id: Date.now().toString(),
          senderAr: "أنت",
          messageAr: chatMessage,
          time: "الآن",
          isSupport: false,
        },
      ]);
      setChatMessage("");
    }
  };

  const handleAppeal = () => {
    setLoading(true);
    setTimeout(() => {
      setDisputeStatus("appealed");
      setShowAppealForm(false);
      setLoading(false);
    }, 1500);
  };

  const handleAddEvidence = () => {
    // Simulate file upload
    setEvidence([...evidence, `evidence-${Date.now()}.jpg`]);
  };

  const handleRemoveEvidence = (index: number) => {
    setEvidence(evidence.filter((_, i) => i !== index));
  };

  const getStatusIcon = (status: DisputeStatus) => {
    switch (status) {
      case "pending":
        return Clock;
      case "under_review":
      case "appealed":
        return MessageSquare;
      case "resolved":
        return CheckCircle;
      case "rejected":
        return XCircle;
    }
  };

  const getStatusColor = (status: DisputeStatus) => {
    switch (status) {
      case "pending":
        return "text-[#df8700]";
      case "under_review":
      case "appealed":
        return "text-[#163300]";
      case "resolved":
        return "text-[#008026]";
      case "rejected":
        return "text-[#cb272f]";
    }
  };

  const getStatusTextAr = (status: DisputeStatus) => {
    switch (status) {
      case "pending":
        return "قيد الانتظار";
      case "under_review":
        return "قيد المراجعة";
      case "appealed":
        return "تم تقديم استئناف";
      case "resolved":
        return "تم الحل";
      case "rejected":
        return "مرفوض";
    }
  };

  const selectedReason = reasons.find((r) => r.id === disputeReason);

  return (
    <div className="min-h-screen bg-white flex flex-col" style={{ fontFamily: "Cairo, sans-serif" }}>
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white/95 backdrop-blur-lg border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 z-10"
      >
        <div className="flex items-center gap-4 mb-4">
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-semibold text-[#0e0f0c]">النزاعات والشكاوى</h1>
        </div>

        {/* Tabs */}
        <div className="flex gap-2">
          <button
            onClick={() => setActiveTab("create")}
            className={`flex-1 py-2 px-4 rounded-full text-sm font-medium transition-all ${
              activeTab === "create"
                ? "bg-[#163300] text-white"
                : "bg-[rgba(22,51,0,0.07843)] text-[#6a6c6a]"
            }`}
          >
            فتح نزاع
          </button>
          <button
            onClick={() => setActiveTab("status")}
            className={`flex-1 py-2 px-4 rounded-full text-sm font-medium transition-all ${
              activeTab === "status"
                ? "bg-[#163300] text-white"
                : "bg-[rgba(22,51,0,0.07843)] text-[#6a6c6a]"
            }`}
          >
            حالة النزاع
          </button>
          <button
            onClick={() => setActiveTab("chat")}
            className={`flex-1 py-2 px-4 rounded-full text-sm font-medium transition-all relative ${
              activeTab === "chat"
                ? "bg-[#163300] text-white"
                : "bg-[rgba(22,51,0,0.07843)] text-[#6a6c6a]"
            }`}
          >
            المحادثة
            {chatMessages.length > 0 && (
              <span className="absolute -top-1 -left-1 w-4 h-4 bg-[#cb272f] rounded-full text-xs text-white flex items-center justify-center">
                {chatMessages.length}
              </span>
            )}
          </button>
        </div>
      </motion.div>

      {/* Create Dispute Tab */}
      {activeTab === "create" && (
        <div className="flex-1 overflow-y-auto p-6">
          <div className="bg-[#df8700]/10 border border-[#df8700]/30 rounded-[10px] p-4 mb-6 flex gap-3">
            <AlertTriangle className="w-5 h-5 text-[#df8700] flex-shrink-0 mt-0.5" />
            <div className="text-right flex-1">
              <p className="text-sm text-[#0e0f0c] font-medium mb-1">
                تنبيه مهم
              </p>
              <p className="text-xs text-[#6a6c6a] leading-relaxed">
                فتح نزاع هو إجراء جدي. يرجى محاولة التواصل مع البائع أولاً لحل المشكلة.
                سيتم مراجعة النزاع من قبل فريقنا خلال 24-48 ساعة.
              </p>
            </div>
          </div>

          <div className="space-y-4">
            {/* Order Info */}
            <div className="bg-[rgba(22,51,0,0.07843)] rounded-[10px] p-4 border border-[rgba(14,15,12,0.12157)]">
              <p className="text-xs text-[#6a6c6a] mb-1">رقم الطلب</p>
              <p className="font-bold text-[#163300]">{orderId}</p>
            </div>

            {/* Reason Selection */}
            <div>
              <label className="block text-sm font-medium text-[#0e0f0c] mb-2">
                سبب النزاع <span className="text-[#cb272f]">*</span>
              </label>
              <div className="space-y-2">
                {reasons.map((reason) => (
                  <button
                    key={reason.id}
                    onClick={() => setDisputeReason(reason.id)}
                    className={`w-full p-4 rounded-[10px] text-right transition-all ${
                      disputeReason === reason.id
                        ? "bg-[#163300] text-white ring-2 ring-[#163300]"
                        : "bg-[rgba(22,51,0,0.07843)] border border-[rgba(14,15,12,0.12157)] text-[#0e0f0c]"
                    }`}
                  >
                    <p className="font-medium mb-1">{reason.labelAr}</p>
                    <p className={`text-xs ${disputeReason === reason.id ? "text-[#9fe870]" : "text-[#6a6c6a]"}`}>
                      {reason.descAr}
                    </p>
                  </button>
                ))}
              </div>
            </div>

            {/* Description */}
            <div>
              <label className="block text-sm font-medium text-[#0e0f0c] mb-2">
                وصف المشكلة <span className="text-[#cb272f]">*</span>
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="اشرح المشكلة بالتفصيل... (على الأقل 50 حرف)"
                className="w-full h-32 px-4 py-3 rounded-[10px] bg-[rgba(22,51,0,0.07843)] border border-transparent text-[#0e0f0c] placeholder:text-[#6a6c6a] focus:outline-none focus:ring-2 focus:ring-[#163300] focus:bg-white transition-all resize-none text-right"
                style={{ fontFamily: "Cairo, sans-serif" }}
              />
              <p className="text-xs text-[#6a6c6a] mt-1 text-right">
                {description.length}/500 حرف
              </p>
            </div>

            {/* Evidence Upload */}
            <div>
              <label className="block text-sm font-medium text-[#0e0f0c] mb-2">
                إرفاق دليل (صور، فيديو، إيصالات)
              </label>
              
              {/* Uploaded Files */}
              {evidence.length > 0 && (
                <div className="grid grid-cols-3 gap-2 mb-3">
                  {evidence.map((file, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="relative aspect-square bg-[rgba(22,51,0,0.07843)] rounded-[10px] border border-[rgba(14,15,12,0.12157)] overflow-hidden"
                    >
                      <div className="absolute inset-0 flex items-center justify-center">
                        <ImageIcon className="w-8 h-8 text-[#6a6c6a]" />
                      </div>
                      <button
                        onClick={() => handleRemoveEvidence(index)}
                        className="absolute top-1 left-1 w-6 h-6 bg-[#cb272f] rounded-full flex items-center justify-center text-white"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </motion.div>
                  ))}
                </div>
              )}

              <button
                onClick={handleAddEvidence}
                className="w-full p-6 rounded-[10px] border-2 border-dashed border-[rgba(14,15,12,0.12157)] hover:border-[#163300] transition-colors flex flex-col items-center gap-2"
              >
                <Upload className="w-8 h-8 text-[#6a6c6a]" />
                <span className="text-sm text-[#6a6c6a]">اضغط لرفع الملفات</span>
                <span className="text-xs text-[#6a6c6a]">PNG, JPG, PDF (حد أقصى 10 ميجا)</span>
              </button>
              <p className="text-xs text-[#163300] mt-2 text-right">
                💡 نصيحة: إرفاق صور واضحة وإيصالات يزيد من فرص قبول نزاعك
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Status Tab */}
      {activeTab === "status" && (
        <div className="flex-1 overflow-y-auto p-6">
          <div className="text-center mb-8">
            {(() => {
              const StatusIcon = getStatusIcon(disputeStatus);
              const statusColor = getStatusColor(disputeStatus);
              return (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", stiffness: 200, damping: 15 }}
                  className="mb-4"
                >
                  <div className={`w-20 h-20 rounded-full mx-auto flex items-center justify-center ${
                    disputeStatus === "resolved" ? "bg-[#008026]" :
                    disputeStatus === "rejected" ? "bg-[#cb272f]" :
                    "bg-[rgba(22,51,0,0.07843)]"
                  }`}>
                    <StatusIcon className={`w-10 h-10 ${
                      disputeStatus === "resolved" || disputeStatus === "rejected" ? "text-white" : statusColor
                    }`} />
                  </div>
                </motion.div>
              );
            })()}
            
            <h3 className="text-xl font-bold text-[#0e0f0c] mb-2">
              {getStatusTextAr(disputeStatus)}
            </h3>
            <p className="text-sm text-[#6a6c6a]">
              {disputeStatus === "under_review" && "جاري مراجعة النزاع من قبل فريقنا"}
              {disputeStatus === "pending" && "في انتظار المراجعة"}
              {disputeStatus === "resolved" && "تم حل النزاع لصالحك"}
              {disputeStatus === "rejected" && "تم رفض النزاع"}
              {disputeStatus === "appealed" && "جاري مراجعة استئنافك"}
            </p>
          </div>

          {/* Dispute Summary */}
          {selectedReason && (
            <div className="bg-[rgba(22,51,0,0.07843)] rounded-[10px] p-4 border border-[rgba(14,15,12,0.12157)] mb-6">
              <h4 className="font-semibold text-[#0e0f0c] mb-3 text-right">ملخص النزاع</h4>
              <div className="space-y-2 text-right">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-[#0e0f0c]">{selectedReason.labelAr}</span>
                  <span className="text-xs text-[#6a6c6a]">السبب:</span>
                </div>
                <div className="flex justify-between items-start">
                  <span className="text-sm text-[#0e0f0c] flex-1">{description.substring(0, 100)}...</span>
                  <span className="text-xs text-[#6a6c6a] flex-shrink-0 mr-2">الوصف:</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-[#163300] font-medium">{evidence.length} ملف</span>
                  <span className="text-xs text-[#6a6c6a]">الأدلة:</span>
                </div>
              </div>
            </div>
          )}

          {/* Timeline */}
          <div className="space-y-4 mb-6">
            <div className="flex gap-4">
              <div className="flex flex-col items-center">
                <div className="w-8 h-8 rounded-full bg-[#163300] flex items-center justify-center text-white">
                  ✓
                </div>
                <div className="flex-1 w-0.5 bg-[#163300] my-2" />
              </div>
              <div className="flex-1 pb-6 text-right">
                <p className="font-medium text-[#0e0f0c]">تم فتح النزاع</p>
                <p className="text-xs text-[#6a6c6a]">منذ ساعتين</p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="flex flex-col items-center">
                <div className={`w-8 h-8 rounded-full ${
                  disputeStatus !== "pending" ? "bg-[#163300]" : "bg-[rgba(22,51,0,0.07843)]"
                } flex items-center justify-center text-white`}>
                  {disputeStatus !== "pending" ? "✓" : "2"}
                </div>
                {disputeStatus !== "pending" && <div className="flex-1 w-0.5 bg-[#163300] my-2" />}
              </div>
              <div className="flex-1 pb-6 text-right">
                <p className="font-medium text-[#0e0f0c]">قيد المراجعة</p>
                <p className="text-xs text-[#6a6c6a]">
                  {disputeStatus !== "pending" ? "منذ ساعة" : "في انتظار المراجعة"}
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="flex flex-col items-center">
                <div className={`w-8 h-8 rounded-full ${
                  disputeStatus === "resolved" || disputeStatus === "rejected" || disputeStatus === "appealed"
                    ? "bg-[#163300]"
                    : "bg-[rgba(22,51,0,0.07843)]"
                } flex items-center justify-center text-white`}>
                  {disputeStatus === "resolved" || disputeStatus === "rejected" || disputeStatus === "appealed" ? "✓" : "3"}
                </div>
              </div>
              <div className="flex-1 text-right">
                <p className="font-medium text-[#0e0f0c]">القرار النهائي</p>
                <p className="text-xs text-[#6a6c6a]">
                  {disputeStatus === "resolved" || disputeStatus === "rejected" || disputeStatus === "appealed"
                    ? "تم اتخاذ القرار"
                    : "في انتظار القرار"}
                </p>
              </div>
            </div>
          </div>

          {/* Resolution Details */}
          {(disputeStatus === "resolved" || disputeStatus === "rejected") && !showAppealForm && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className={`p-4 rounded-[10px] border ${
                disputeStatus === "resolved"
                  ? "bg-[#008026]/10 border-[#008026]/30"
                  : "bg-[#cb272f]/10 border-[#cb272f]/30"
              }`}
            >
              <h4 className="font-semibold text-[#0e0f0c] mb-2 text-right">
                تفاصيل القرار
              </h4>
              <p className="text-sm text-[#6a6c6a] text-right leading-relaxed mb-4">
                {disputeStatus === "resolved"
                  ? "تم حل النزاع لصالحك. سيتم إرجاع المبلغ إلى محفظتك خلال 3-5 أيام عمل."
                  : "لم يتم قبول النزاع بعد مراجعة الأدلة المقدمة."}
              </p>
              
              {disputeStatus === "rejected" && (
                <WiseButton
                  onClick={() => setShowAppealForm(true)}
                  variant="outline"
                  fullWidth
                  size="md"
                >
                  تقديم استئناف
                </WiseButton>
              )}
            </motion.div>
          )}

          {/* Appeal Form */}
          {showAppealForm && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-4"
            >
              <div className="bg-[#163300]/10 border border-[#163300]/30 rounded-[10px] p-4">
                <h4 className="font-semibold text-[#0e0f0c] mb-2 text-right">
                  تقديم استئناف
                </h4>
                <p className="text-xs text-[#6a6c6a] text-right leading-relaxed">
                  لديك 7 أيام لتقديم استئناف. يرجى تقديم معلومات إضافية أو أدلة جديدة.
                </p>
              </div>

              <textarea
                value={appealReason}
                onChange={(e) => setAppealReason(e.target.value)}
                placeholder="اشرح سبب الاستئناف وقدم أي أدلة إضافية..."
                className="w-full h-32 px-4 py-3 rounded-[10px] bg-[rgba(22,51,0,0.07843)] border border-transparent text-[#0e0f0c] placeholder:text-[#6a6c6a] focus:outline-none focus:ring-2 focus:ring-[#163300] focus:bg-white transition-all resize-none text-right"
                style={{ fontFamily: "Cairo, sans-serif" }}
              />

              <div className="flex gap-3">
                <WiseButton
                  onClick={() => setShowAppealForm(false)}
                  variant="ghost"
                  fullWidth
                  size="md"
                >
                  إلغاء
                </WiseButton>
                <WiseButton
                  onClick={handleAppeal}
                  variant="primary"
                  fullWidth
                  size="md"
                  loading={loading}
                  disabled={!appealReason}
                >
                  تقديم
                </WiseButton>
              </div>
            </motion.div>
          )}

          {disputeStatus === "appealed" && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-[#163300]/10 border border-[#163300]/30 rounded-[10px] p-4 mt-4"
            >
              <h4 className="font-semibold text-[#0e0f0c] mb-2 text-right">
                تم تقديم الاستئناف
              </h4>
              <p className="text-sm text-[#6a6c6a] text-right leading-relaxed">
                جاري مراجعة استئنافك من قبل فريق متخصص. سنرد خلال 3-5 أيام عمل.
              </p>
            </motion.div>
          )}
        </div>
      )}

      {/* Chat Tab */}
      {activeTab === "chat" && (
        <div className="flex-1 flex flex-col">
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {chatMessages.map((msg) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex gap-3 ${msg.isSupport ? "flex-row-reverse" : "flex-row"}`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                  msg.isSupport ? "bg-[#163300]" : "bg-[#9fe870]"
                }`}>
                  <span className={`text-xs font-bold ${msg.isSupport ? "text-white" : "text-[#163300]"}`}>
                    {msg.senderAr[0]}
                  </span>
                </div>
                <div className={`flex-1 ${msg.isSupport ? "text-right" : "text-right"}`}>
                  <div className={`inline-block p-3 rounded-[10px] ${
                    msg.isSupport
                      ? "bg-[#163300] text-white"
                      : "bg-[rgba(22,51,0,0.07843)] text-[#0e0f0c]"
                  }`}>
                    <p className="text-sm leading-relaxed">{msg.messageAr}</p>
                  </div>
                  <p className="text-xs text-[#6a6c6a] mt-1">{msg.time}</p>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Chat Input */}
          <div className="border-t border-[rgba(14,15,12,0.12157)] p-4 bg-white">
            <div className="flex gap-3 items-end">
              <button className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center text-[#163300]">
                <Paperclip className="w-5 h-5" />
              </button>
              <textarea
                value={chatMessage}
                onChange={(e) => setChatMessage(e.target.value)}
                placeholder="اكتب رسالتك..."
                className="flex-1 h-10 max-h-24 px-4 py-2 rounded-[10px] bg-[rgba(22,51,0,0.07843)] border border-transparent text-[#0e0f0c] placeholder:text-[#6a6c6a] focus:outline-none focus:ring-2 focus:ring-[#163300] focus:bg-white transition-all resize-none text-right"
                style={{ fontFamily: "Cairo, sans-serif" }}
                rows={1}
              />
              <button
                onClick={handleSendMessage}
                disabled={!chatMessage.trim()}
                className="w-10 h-10 rounded-full bg-[#163300] flex items-center justify-center text-white disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bottom CTA */}
      {activeTab === "create" && (
        <motion.div
          initial={{ y: 100 }}
          animate={{ y: 0 }}
          transition={{ delay: 0.3 }}
          className="sticky bottom-0 bg-white border-t border-[rgba(14,15,12,0.12157)] p-6"
        >
          <WiseButton
            onClick={handleSubmitDispute}
            variant="primary"
            fullWidth
            size="lg"
            loading={loading}
            disabled={!disputeReason || !description || description.length < 50}
          >
            تقديم النزاع
          </WiseButton>
        </motion.div>
      )}
    </div>
  );
}