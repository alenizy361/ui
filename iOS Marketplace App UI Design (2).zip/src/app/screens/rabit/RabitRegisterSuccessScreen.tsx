import { motion } from "motion/react";
import { WiseButton } from "../../components/WiseButton";
import { Check, AlertCircle, Settings } from "lucide-react";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";

interface RabitRegisterSuccessScreenProps {
  onContinue: () => void;
  emailConfirmationRequired?: boolean;
  onShowSetupGuide?: () => void;
}

export function RabitRegisterSuccessScreen({ onContinue, emailConfirmationRequired, onShowSetupGuide }: RabitRegisterSuccessScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);

  return (
    <div 
      className="min-h-screen bg-white flex flex-col items-center justify-center p-6" 
      style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{
          type: "spring",
          stiffness: 200,
          damping: 15,
          delay: 0.2,
        }}
        className="w-24 h-24 bg-[#163300] rounded-full flex items-center justify-center mb-8 relative"
      >
        <motion.div
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{
            type: "spring",
            stiffness: 200,
            damping: 15,
            delay: 0.4,
          }}
        >
          <Check className="w-12 h-12 text-[#9fe870]" strokeWidth={3} />
        </motion.div>
        <motion.div
          initial={{ scale: 1, opacity: 1 }}
          animate={{ scale: 2, opacity: 0 }}
          transition={{
            duration: 1,
            delay: 0.3,
            repeat: 2,
          }}
          className="absolute inset-0 bg-[#9fe870] rounded-full"
        />
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="text-center mb-12"
      >
        <h1 className="text-3xl font-bold mb-3 text-[#0e0f0c]">{t.accountCreated}!</h1>
        <p className="text-[#6a6c6a]">
          {emailConfirmationRequired
            ? (language === 'ar' ? 'يرجى تأكيد بريدك الإلكتروني للمتابعة' : 'Please confirm your email to continue')
            : (language === 'ar' ? 'تم التحقق من حسابك بنجاح' : 'Your account has been verified successfully')
          }
        </p>
        
        {/* Email confirmation warning */}
        {emailConfirmationRequired && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
            className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-2xl"
          >
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-yellow-800" dir={isRTL ? 'rtl' : 'ltr'}>
                {language === 'ar' ? (
                  <>
                    <p className="font-semibold mb-1">التأكيد مطلوب</p>
                    <p>تم إرسال رابط التأكيد إلى بريدك الإلكتروني. يرجى التحقق من بريدك الإلكتروني والنقر على رابط التأكيد للمتابعة.</p>
                  </>
                ) : (
                  <>
                    <p className="font-semibold mb-1">Confirmation Required</p>
                    <p>A confirmation link has been sent to your email. Please check your email and click the confirmation link to continue.</p>
                  </>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
        className="w-full"
      >
        <WiseButton onClick={onContinue} variant="primary" fullWidth size="lg">
          {emailConfirmationRequired 
            ? (language === 'ar' ? 'الذهاب لتسجيل الدخول' : 'Go to Login')
            : t.continue
          }
        </WiseButton>
      </motion.div>

      {onShowSetupGuide && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="w-full mt-4"
        >
          <WiseButton onClick={onShowSetupGuide} variant="secondary" fullWidth size="lg">
            {language === 'ar' ? 'دليل الإعداد' : 'Setup Guide'}
          </WiseButton>
        </motion.div>
      )}
    </div>
  );
}