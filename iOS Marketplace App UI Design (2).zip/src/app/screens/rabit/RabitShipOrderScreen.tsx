import { motion } from "motion/react";
import { WiseButton } from "../../components/WiseButton";
import { ChevronRight, Package, Truck, MapPin, Phone, Clock, AlertCircle } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { useLanguage } from "../../contexts/LanguageContext";

interface RabitShipOrderScreenProps {
  orderNumber: string;
  productName: string;
  buyerName: string;
  buyerPhone: string;
  shippingAddress: string;
  city: string;
  amount: number;
  onBack: () => void;
  onShippingConfirmed: () => void;
}

export function RabitShipOrderScreen({
  orderNumber,
  productName,
  buyerName,
  buyerPhone,
  shippingAddress,
  city,
  amount,
  onBack,
  onShippingConfirmed,
}: RabitShipOrderScreenProps) {
  const { language, isRTL } = useLanguage();
  const [selectedShipping, setSelectedShipping] = useState("");
  const [isShipping, setIsShipping] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const content = {
    ar: {
      shippingConfirmed: "تم تأكيد الشحن",
      shippingNotificationSent: "تم إرسال إشعار للمشتري بتفاصيل الشحن",
      confirmShipping: "تأكيد الشحن",
      orderNumber: "رقم الطلب",
      product: "المنتج",
      status: "الحالة",
      inShipping: "قيد الشحن",
      confirmed: "تم التأكيد",
      buyerInfo: "معلومات المشتري",
      name: "الاسم",
      phone: "رقم الجوال",
      shippingAddress: "عنوان الشحن",
      shippingInstructions: "تعليمات الشحن:",
      instruction1: "• تأكد من تغليف المنتج بشكل آمن",
      instruction2: "• اكتب عنوان المشتري بشكل واضح",
      instruction3: "• احتفظ برقم الشحنة للمتابعة",
      instruction4: "• أبلغ المشتري بتفاصيل شركة الشحن",
      instruction5: "• سيتم تحرير الأموال بعد استلام المشتري",
      readyToShip: "جاهز للشحن؟",
      clickToConfirm: "اضغط على الزر بالأسفل لتأكيد شحن الطلب",
      confirming: "جاري التأكيد...",
      confirmShipButton: "تأكيد الشحن",
    },
    en: {
      shippingConfirmed: "Shipping Confirmed",
      shippingNotificationSent: "Buyer has been notified with shipping details",
      confirmShipping: "Confirm Shipping",
      orderNumber: "Order Number",
      product: "Product",
      status: "Status",
      inShipping: "In Shipping",
      confirmed: "Confirmed",
      buyerInfo: "Buyer Information",
      name: "Name",
      phone: "Phone Number",
      shippingAddress: "Shipping Address",
      shippingInstructions: "Shipping Instructions:",
      instruction1: "• Ensure product is safely packaged",
      instruction2: "• Write buyer's address clearly",
      instruction3: "• Keep tracking number for follow-up",
      instruction4: "• Notify buyer of courier details",
      instruction5: "• Funds will be released after buyer receives",
      readyToShip: "Ready to Ship?",
      clickToConfirm: "Click the button below to confirm shipping",
      confirming: "Confirming...",
      confirmShipButton: "Confirm Shipping",
    },
  };
  const c = content[language];

  const handleConfirmShip = () => {
    setIsShipping(true);
    setTimeout(() => {
      setIsShipping(false);
      setShowSuccess(true);
      toast.success(c.shippingConfirmed + " 📦");
      setTimeout(() => {
        onShippingConfirmed();
      }, 3000);
    }, 2000);
  };

  if (showSuccess) {
    return (
      <div 
        className="min-h-screen bg-white flex flex-col items-center justify-center p-6" 
        style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
        dir={isRTL ? 'rtl' : 'ltr'}
      >
        {/* Animated Truck */}
        <motion.div
          initial={{ x: -100, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ 
            type: "spring", 
            stiffness: 100, 
            damping: 15,
            duration: 0.8
          }}
          className="mb-8"
        >
          <motion.div
            animate={{ 
              y: [0, -10, 0],
            }}
            transition={{
              repeat: Infinity,
              duration: 1.5,
              ease: "easeInOut"
            }}
            className="w-32 h-32 bg-[#163300] rounded-full flex items-center justify-center relative"
          >
            <Truck className="w-16 h-16 text-white" />
            
            {/* Movement lines */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: [0, 1, 0], x: [-20, -40, -60] }}
              transition={{
                repeat: Infinity,
                duration: 1,
                ease: "linear"
              }}
              className={`absolute ${isRTL ? 'left-full ml-2' : 'right-full mr-2'}`}
            >
              <div className="flex gap-1">
                <div className="w-2 h-0.5 bg-[#163300]" />
                <div className="w-2 h-0.5 bg-[#163300]" />
                <div className="w-2 h-0.5 bg-[#163300]" />
              </div>
            </motion.div>
          </motion.div>
        </motion.div>

        {/* Success checkmark */}
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ 
            delay: 0.3,
            type: "spring", 
            stiffness: 200, 
            damping: 15 
          }}
          className="w-20 h-20 bg-[#008026] rounded-full flex items-center justify-center mb-6"
        >
          <motion.svg
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="w-10 h-10 text-white"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
          >
            <motion.path
              d="M5 13l4 4L19 7"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </motion.svg>
        </motion.div>

        {/* Success text */}
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="text-2xl font-bold text-[#163300] mb-2 text-center"
        >
          {c.shippingConfirmed} 🚚
        </motion.h2>
        
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="text-[#6a6c6a] text-center mb-6"
        >
          {c.shippingNotificationSent}
        </motion.p>

        {/* Order info card */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.8 }}
          className="bg-[rgba(22,51,0,0.07843)] rounded-[16px] p-5 w-full max-w-sm"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm text-[#6a6c6a]">{c.orderNumber}</span>
            <span className="font-bold text-[#0e0f0c]" dir="ltr">#{orderNumber}</span>
          </div>
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm text-[#6a6c6a]">{c.product}</span>
            <span className="font-medium text-[#0e0f0c] text-sm">{productName.substring(0, 20)}...</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-[#6a6c6a]">{c.status}</span>
            <span className="px-3 py-1 bg-[#9c27b0] text-white text-xs rounded-full font-medium flex items-center gap-1.5">
              <Truck className="w-3.5 h-3.5" />
              {c.inShipping}
            </span>
          </div>
        </motion.div>

        {/* Animated dots */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="flex gap-2 mt-8"
        >
          {[0, 1, 2].map((i) => (
            <motion.div
              key={i}
              animate={{
                scale: [1, 1.5, 1],
                opacity: [0.3, 1, 0.3],
              }}
              transition={{
                repeat: Infinity,
                duration: 1.5,
                delay: i * 0.2,
              }}
              className="w-2 h-2 bg-[#163300] rounded-full"
            />
          ))}
        </motion.div>
      </div>
    );
  }

  return (
    <div 
      className="min-h-screen bg-white pb-32" 
      style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 flex items-center justify-between z-10"
      >
        <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
          <ChevronRight className="w-6 h-6 text-[#0e0f0c]" />
        </button>
        <h1 className="text-xl font-semibold text-[#0e0f0c]">{c.confirmShipping}</h1>
        <div className="w-10" />
      </motion.div>

      <div className="p-6 space-y-6">
        {/* Order Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[rgba(22,51,0,0.07843)] rounded-[16px] p-5 border border-[rgba(14,15,12,0.12157)]"
        >
          <div className="flex items-center justify-between mb-4">
            <div className={isRTL ? 'text-right' : 'text-left'}>
              <p className="text-sm text-[#6a6c6a] mb-1">{c.orderNumber}</p>
              <p className="font-bold text-[#0e0f0c]" dir="ltr">#{orderNumber}</p>
            </div>
            <span className="px-4 py-1.5 bg-[#0091ea] text-white text-sm rounded-full font-medium">
              {c.confirmed}
            </span>
          </div>
          
          <div className="flex items-center gap-3">
            <img 
              src="/path/to/product/image.jpg" 
              alt={productName}
              className="w-20 h-20 rounded-[12px] object-cover border border-[rgba(14,15,12,0.12157)]"
            />
            <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
              <p className="font-semibold text-[#0e0f0c] mb-1">{productName}</p>
              <p className="text-lg font-bold text-[#163300]">{amount.toLocaleString('ar-SA')} ر.س</p>
            </div>
          </div>
        </motion.div>

        {/* Buyer Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-[16px] border border-[rgba(14,15,12,0.12157)] p-5"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-[rgba(22,51,0,0.07843)] rounded-full flex items-center justify-center">
              <Package className="w-5 h-5 text-[#163300]" />
            </div>
            <h3 className="font-bold text-[#0e0f0c]">{c.buyerInfo}</h3>
          </div>
          
          <div className="bg-[rgba(22,51,0,0.07843)] rounded-[12px] p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-[#6a6c6a]">{c.name}</span>
              <span className="font-medium text-[#0e0f0c]">{buyerName}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-[#6a6c6a]">{c.phone}</span>
              <div className="flex items-center gap-2">
                <span className="font-medium text-[#0e0f0c]" dir="ltr">{buyerPhone}</span>
                <Phone className="w-4 h-4 text-[#163300]" />
              </div>
            </div>
          </div>
        </motion.div>

        {/* Shipping Address */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-[16px] border border-[rgba(14,15,12,0.12157)] p-5"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-[rgba(22,51,0,0.07843)] rounded-full flex items-center justify-center">
              <MapPin className="w-5 h-5 text-[#163300]" />
            </div>
            <h3 className="font-bold text-[#0e0f0c]">{c.shippingAddress}</h3>
          </div>
          
          <div className={`bg-[rgba(22,51,0,0.07843)] rounded-[12px] p-4 ${isRTL ? 'text-right' : 'text-left'}`}>
            <p className="font-semibold text-[#0e0f0c] mb-2">{shippingAddress}</p>
            <p className="text-sm text-[#6a6c6a] mb-1">{city}</p>
            <div className="flex items-center gap-2 pt-3 border-t border-[rgba(14,15,12,0.12157)]">
              <Phone className="w-4 h-4 text-[#163300]" />
              <p className="text-sm text-[#0e0f0c]" dir="ltr">{buyerPhone}</p>
            </div>
          </div>
        </motion.div>

        {/* Important Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-[rgba(159,232,112,0.1)] rounded-[12px] p-4 border border-[rgba(22,51,0,0.2)]"
        >
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-[#163300] flex-shrink-0 mt-0.5" />
            <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
              <p className="text-sm font-semibold text-[#163300] mb-2">{c.shippingInstructions}</p>
              <ul className="text-xs text-[#6a6c6a] space-y-1">
                <li>{c.instruction1}</li>
                <li>{c.instruction2}</li>
                <li>{c.instruction3}</li>
                <li>{c.instruction4}</li>
                <li>{c.instruction5}</li>
              </ul>
            </div>
          </div>
        </motion.div>

        {/* Ship Icon Animation Preview */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.4 }}
          className="bg-gradient-to-br from-[#163300] to-[#1a3d00] rounded-[16px] p-6 text-center"
        >
          <motion.div
            animate={{ 
              x: [0, 10, 0],
            }}
            transition={{
              repeat: Infinity,
              duration: 2,
              ease: "easeInOut"
            }}
            className="inline-block"
          >
            <Truck className="w-12 h-12 text-white mx-auto mb-3" />
          </motion.div>
          <p className="text-white font-semibold mb-1">{c.readyToShip}</p>
          <p className="text-white/70 text-sm">{c.clickToConfirm}</p>
        </motion.div>
      </div>

      {/* Fixed Bottom Button */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-[rgba(14,15,12,0.12157)] px-6 py-4 max-w-[430px] mx-auto">
        <WiseButton
          onClick={handleConfirmShip}
          variant="primary"
          fullWidth
          loading={isShipping}
          disabled={isShipping}
        >
          {isShipping ? (
            <span className="flex items-center justify-center gap-2">
              <Truck className="w-5 h-5 animate-pulse" />
              {c.confirming}
            </span>
          ) : (
            <span className="flex items-center justify-center gap-2">
              <Truck className="w-5 h-5" />
              {c.confirmShipButton}
            </span>
          )}
        </WiseButton>
      </div>
    </div>
  );
}