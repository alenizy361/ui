import { motion } from "motion/react";
import { Search, ShoppingBag, Wallet, Settings, Grid3x3, Bell, Package, Heart, ShoppingCart, MessageCircle } from "lucide-react";
import { useState, useEffect } from "react";
import { type RabitProduct } from "../../data/rabitProducts";
import { PullToRefresh } from "../../components/PullToRefresh";
import { CategoryIcon } from "../../components/CategoryIcon";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";
import { useApp } from "../../contexts/AppContext";
import { useUnreadCounts } from "../../hooks/useUnreadCounts";
import { getCategories, getCategoryProducts, type Category } from "../../services/categories.service";
import { getProducts } from "../../services/products.service";

interface RabitBuyerHomeScreenProps {
  onProductClick: (product: RabitProduct) => void;
  onSearchClick: () => void;
  onCategoryClick: () => void;
  onOrdersClick: () => void;
  onWalletClick: () => void;
  onSettingsClick: () => void;
  onNotificationsClick: () => void;
  onFavoritesClick?: () => void;
  onCartClick?: () => void;
  onMessagesClick?: () => void;
  onSwitchToSeller?: () => void;
  canSwitchToSeller?: boolean;
}

export function RabitBuyerHomeScreen({
  onProductClick,
  onSearchClick,
  onCategoryClick,
  onOrdersClick,
  onWalletClick,
  onSettingsClick,
  onNotificationsClick,
  onFavoritesClick,
  onCartClick,
  onMessagesClick,
  onSwitchToSeller,
  canSwitchToSeller,
}: RabitBuyerHomeScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);
  const { cartItemCount, favoritesCount } = useApp();
  const { notifications: unreadNotifications, messages: unreadMessages } = useUnreadCounts();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState("home");
  
  // Real data from database
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Fetch categories and products
  const fetchData = async () => {
    setLoading(true);
    setError(null);

    try {
      // Fetch categories
      const categoriesResult = await getCategories();
      if (categoriesResult.success && categoriesResult.categories) {
        console.log('✅ Loaded categories:', categoriesResult.categories.length);
        setCategories(categoriesResult.categories);
      } else {
        console.error('❌ Failed to load categories:', categoriesResult.error);
        setError(categoriesResult.error || 'Failed to load categories');
      }

      // Fetch products (all or filtered by category)
      if (selectedCategory) {
        const productsResult = await getCategoryProducts(selectedCategory);
        if (productsResult.success && productsResult.products) {
          setProducts(productsResult.products);
        }
      } else {
        const productsResult = await getProducts();
        if (productsResult.success && productsResult.products) {
          setProducts(productsResult.products);
        }
      }
    } catch (err: any) {
      console.error('❌ Error fetching data:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  // Initial fetch
  useEffect(() => {
    fetchData();
  }, [selectedCategory]);

  const handleRefresh = async () => {
    console.log("Refreshing buyer home data...");
    await fetchData();
  };

  const handleCategorySelect = (categoryName: string) => {
    if (selectedCategory === categoryName) {
      setSelectedCategory(null); // Deselect
    } else {
      setSelectedCategory(categoryName);
    }
  };

  return (
    <PullToRefresh onRefresh={handleRefresh}>
      <div 
        className="min-h-screen bg-[#fafafa] pb-20" 
        style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
        dir={isRTL ? 'rtl' : 'ltr'}
      >
        {/* Header - Clean & Minimal */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white px-6 pt-12 pb-6 border-b border-[rgba(0,0,0,0.06)]"
        >
          {/* Top Bar */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex gap-2">
              <button
                onClick={onNotificationsClick}
                className="w-10 h-10 rounded-xl bg-[#fafafa] flex items-center justify-center text-[#163300] relative transition-all duration-200 hover:bg-[#f0fde8] active:scale-95"
              >
                <Bell className="w-5 h-5" />
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#ef4444] rounded-full text-white text-[9px] flex items-center justify-center font-bold">
                  {unreadNotifications}
                </span>
              </button>
              <button
                onClick={onSettingsClick}
                className="w-10 h-10 rounded-xl bg-[#fafafa] flex items-center justify-center text-[#163300] transition-all duration-200 hover:bg-[#f0fde8] active:scale-95"
              >
                <Settings className="w-5 h-5" />
              </button>
            </div>
            
            {/* Mode Switcher */}
            {canSwitchToSeller && onSwitchToSeller && (
              <motion.div
                whileTap={{ scale: 0.95 }}
                onClick={onSwitchToSeller}
                className="flex items-center gap-2 bg-[#fafafa] rounded-2xl p-1.5 cursor-pointer transition-all duration-200 hover:bg-[#f0fde8]"
              >
                <div className="bg-[#163300] text-white px-4 py-2 rounded-xl flex items-center gap-2 shadow-sm">
                  <ShoppingBag className="w-4 h-4" />
                  <span className="text-sm font-semibold">{t.buyer}</span>
                </div>
                <div className="text-[#6a6c6a] px-4 py-2 rounded-xl flex items-center gap-2">
                  <Package className="w-4 h-4" />
                  <span className="text-sm font-medium">{t.seller}</span>
                </div>
              </motion.div>
            )}
            
            {/* If can't switch, just show mode badge */}
            {!canSwitchToSeller && (
              <div className="bg-[#163300] text-white px-4 py-2 rounded-2xl flex items-center gap-2 shadow-sm">
                <ShoppingBag className="w-4 h-4" />
                <span className="text-sm font-semibold">{language === 'ar' ? 'مشتري' : 'Buyer'}</span>
              </div>
            )}
          </div>

          {/* Search Bar */}
          <motion.button
            whileTap={{ scale: 0.98 }}
            onClick={onSearchClick}
            className="w-full h-12 bg-[#fafafa] rounded-2xl flex items-center gap-3 px-4 border border-[rgba(0,0,0,0.08)] transition-all duration-200 hover:border-[rgba(22,51,0,0.2)]"
            style={{ flexDirection: isRTL ? 'row-reverse' : 'row', textAlign: isRTL ? 'right' : 'left' }}
          >
            <Search className="w-5 h-5 text-[#6a6c6a]" />
            <span className="text-sm text-[#6a6c6a]">
              {language === 'ar' ? 'ابحث عن منتجات...' : 'Search for products...'}
            </span>
          </motion.button>
        </motion.div>

        {/* Categories - Premium Grid Design */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="px-6 py-6"
        >
          <div className="flex items-center justify-between mb-4" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={onCategoryClick}
              className="text-sm text-[#163300] hover:underline font-medium"
            >
              {language === 'ar' ? 'عرض الكل' : 'View All'}
            </motion.button>
            <h2 className="text-lg font-bold text-[#0a0b09]" style={{ textAlign: isRTL ? 'right' : 'left' }}>
              {language === 'ar' ? 'تصفح حسب الفئة' : 'Browse by Category'}
            </h2>
          </div>
          
          {/* Category Grid */}
          <div className="grid grid-cols-4 gap-3">
            {categories.slice(0, 8).map((category, i) => (
              <motion.button
                key={category.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => handleCategorySelect(language === 'ar' ? category.nameAr : category.name)}
                className={`aspect-square rounded-2xl flex flex-col items-center justify-center gap-2.5 transition-all duration-200 overflow-hidden ${
                  selectedCategory === (language === 'ar' ? category.nameAr : category.name)
                    ? "bg-gradient-to-br from-[#163300] to-[#0f2409] shadow-lg scale-105"
                    : "bg-white border border-[rgba(0,0,0,0.08)] hover:shadow-md"
                }`}
              >
                {category.iconComponent && category.gradient ? (
                  <CategoryIcon 
                    iconName={category.iconComponent}
                    gradient={category.gradient}
                    isActive={selectedCategory === (language === 'ar' ? category.nameAr : category.name)}
                    size="md"
                  />
                ) : (
                  <div className="text-2xl">{category.icon}</div>
                )}
                <span className={`text-[10px] font-semibold text-center leading-tight px-1 ${
                  selectedCategory === (language === 'ar' ? category.nameAr : category.name) ? "text-white" : "text-[#6a6c6a]"
                }`}>
                  {language === 'ar' ? category.nameAr : category.name}
                </span>
              </motion.button>
            ))}
          </div>
        </motion.div>

        {/* Products Grid */}
        <div className="px-6 py-6">
          <h2 className="text-lg font-bold text-[#0a0b09] mb-5" style={{ textAlign: isRTL ? 'right' : 'left' }}>
            {selectedCategory ? selectedCategory : (language === 'ar' ? 'المنتجات المميزة' : 'Featured Products')}
          </h2>
          <div className="grid grid-cols-2 gap-4">
            {products.map((product, index) => {
              // Handle both mock data (image) and database data (images array)
              const productImage = product.images?.[0] || product.image || '';
              
              return (
              <motion.button
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05, duration: 0.3 }}
                whileTap={{ scale: 0.97 }}
                onClick={() => onProductClick(product)}
                className="bg-white rounded-2xl overflow-hidden border border-[rgba(0,0,0,0.08)] hover:border-[rgba(22,51,0,0.2)] transition-all duration-200 group"
                style={{ boxShadow: '0 1px 3px rgba(0, 0, 0, 0.06)' }}
                onMouseEnter={(e) => e.currentTarget.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.08)'}
                onMouseLeave={(e) => e.currentTarget.style.boxShadow = '0 1px 3px rgba(0, 0, 0, 0.06)'}
              >
                <div className="aspect-square bg-[#fafafa] relative overflow-hidden">
                  <img
                    src={productImage}
                    alt={language === 'ar' ? product.titleAr : product.title}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  {product.verified && (
                    <div className="absolute top-2 left-2 w-7 h-7 bg-[#163300] rounded-xl flex items-center justify-center shadow-md">
                      <span className="text-white text-xs font-bold">✓</span>
                    </div>
                  )}
                </div>
                <div className="p-3.5" style={{ textAlign: isRTL ? 'right' : 'left' }}>
                  <p className="text-sm font-semibold text-[#0a0b09] mb-1 truncate">
                    {language === 'ar' ? product.titleAr : product.title}
                  </p>
                  <p className="text-xs text-[#6a6c6a] mb-2.5">
                    {language === 'ar' ? product.sellerAr : product.seller}
                  </p>
                  <div className="flex items-center justify-between mb-2" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                    <span className="text-xs text-[#6a6c6a] flex items-center gap-1">
                      <span className="text-[#f59e0b]">★</span>
                      {product.rating || '5.0'}
                    </span>
                    <span className="font-bold text-[#163300] text-base">
                      {product.price} {language === 'ar' ? 'ر.س' : 'SAR'}
                    </span>
                  </div>
                  
                  {/* Payment Options */}
                  <div className="flex items-center gap-1.5 pt-2 border-t border-[rgba(0,0,0,0.06)]" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                    <span className="text-[9px] text-[#6a6c6a]">
                      {language === 'ar' ? 'أو قسمها' : 'or split it'}
                    </span>
                    <div className="flex items-center gap-1">
                      {/* Tabby Logo */}
                      <div className="h-3.5 px-1.5 bg-[#3AFFA3] rounded flex items-center justify-center">
                        <span className="text-[8px] font-bold text-black" style={{ fontFamily: 'system-ui, sans-serif' }}>tabby</span>
                      </div>
                      {/* Tamara Logo */}
                      <div className="h-3.5 px-1.5 bg-black rounded flex items-center justify-center">
                        <span className="text-[8px] font-bold text-white" style={{ fontFamily: 'system-ui, sans-serif' }}>tamara</span>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.button>
            )})}
          </div>
        </div>

        {/* Bottom Navigation - Buyer */}
        <div className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-lg border-t border-[rgba(0,0,0,0.06)] px-6 py-4" style={{ boxShadow: '0 -4px 12px rgba(0, 0, 0, 0.04)' }}>
          <div className="flex justify-around items-center max-w-[430px] mx-auto">
            <button
              onClick={() => setActiveTab("home")}
              className={`flex flex-col items-center gap-1.5 transition-all duration-200 ${
                activeTab === "home" ? "text-[#163300] scale-105" : "text-[#6a6c6a] scale-100"
              }`}
            >
              <div className={`p-2 rounded-xl transition-all duration-200 ${
                activeTab === "home" ? "bg-[#f0fde8]" : "bg-transparent"
              }`}>
                <ShoppingBag className="w-5 h-5" />
              </div>
              <span className="text-xs font-medium">{language === 'ar' ? 'التسوق' : 'Shop'}</span>
            </button>
            <button
              onClick={onOrdersClick}
              className={`flex flex-col items-center gap-1.5 transition-all duration-200 ${
                activeTab === "orders" ? "text-[#163300] scale-105" : "text-[#6a6c6a] scale-100"
              }`}
            >
              <div className={`p-2 rounded-xl transition-all duration-200 ${
                activeTab === "orders" ? "bg-[#f0fde8]" : "bg-transparent"
              }`}>
                <Package className="w-5 h-5" />
              </div>
              <span className="text-xs font-medium">{language === 'ar' ? 'طلباتي' : 'My Orders'}</span>
            </button>
            <button
              onClick={onWalletClick}
              className={`flex flex-col items-center gap-1.5 transition-all duration-200 ${
                activeTab === "wallet" ? "text-[#163300] scale-105" : "text-[#6a6c6a] scale-100"
              }`}
            >
              <div className={`p-2 rounded-xl transition-all duration-200 ${
                activeTab === "wallet" ? "bg-[#f0fde8]" : "bg-transparent"
              }`}>
                <Wallet className="w-5 h-5" />
              </div>
              <span className="text-xs font-medium">{language === 'ar' ? 'المحفظة' : 'Wallet'}</span>
            </button>
            {onFavoritesClick && (
              <button
                onClick={onFavoritesClick}
                className={`relative flex flex-col items-center gap-1.5 transition-all duration-200 ${
                  activeTab === "favorites" ? "text-[#163300] scale-105" : "text-[#6a6c6a] scale-100"
                }`}
              >
                <div className={`p-2 rounded-xl transition-all duration-200 ${
                  activeTab === "favorites" ? "bg-[#f0fde8]" : "bg-transparent"
                }`}>
                  <Heart className="w-5 h-5" />
                </div>
                <span className="text-xs font-medium">{language === 'ar' ? 'المفضلة' : 'Favorites'}</span>
                {favoritesCount > 0 && (
                  <span className="absolute top-0 right-0 w-4 h-4 bg-[#ef4444] rounded-full text-white text-[9px] flex items-center justify-center font-bold">
                    {favoritesCount}
                  </span>
                )}
              </button>
            )}
            {onCartClick && (
              <button
                onClick={onCartClick}
                className={`relative flex flex-col items-center gap-1.5 transition-all duration-200 ${
                  activeTab === "cart" ? "text-[#163300] scale-105" : "text-[#6a6c6a] scale-100"
                }`}
              >
                <div className={`p-2 rounded-xl transition-all duration-200 ${
                  activeTab === "cart" ? "bg-[#f0fde8]" : "bg-transparent"
                }`}>
                  <ShoppingCart className="w-5 h-5" />
                </div>
                <span className="text-xs font-medium">{language === 'ar' ? 'السلة' : 'Cart'}</span>
                {cartItemCount > 0 && (
                  <span className="absolute top-0 right-0 w-4 h-4 bg-[#ef4444] rounded-full text-white text-[9px] flex items-center justify-center font-bold">
                    {cartItemCount}
                  </span>
                )}
              </button>
            )}
            {onMessagesClick && (
              <button
                onClick={onMessagesClick}
                className={`relative flex flex-col items-center gap-1.5 transition-all duration-200 ${
                  activeTab === "messages" ? "text-[#163300] scale-105" : "text-[#6a6c6a] scale-100"
                }`}
              >
                <div className={`p-2 rounded-xl transition-all duration-200 ${
                  activeTab === "messages" ? "bg-[#f0fde8]" : "bg-transparent"
                }`}>
                  <MessageCircle className="w-5 h-5" />
                </div>
                <span className="text-xs font-medium">{language === 'ar' ? 'الرسائل' : 'Messages'}</span>
                {unreadMessages > 0 && (
                  <span className="absolute top-0 right-0 w-4 h-4 bg-[#ef4444] rounded-full text-white text-[9px] flex items-center justify-center font-bold">
                    {unreadMessages}
                  </span>
                )}
              </button>
            )}
          </div>
        </div>
      </div>
    </PullToRefresh>
  );
}