import { motion } from "motion/react";
import { ChevronRight, Package, MapPin, Phone, Truck } from "lucide-react";
import { WiseButton } from "../../components/WiseButton";
import { useLanguage } from "../../contexts/LanguageContext";

export function RabitShippingInstructionsScreen({ onBack, onComplete }: { onBack: () => void; onComplete: () => void }) {
  const { language, isRTL } = useLanguage();

  const content = {
    ar: {
      shippingInstructions: "تعليمات الشحن",
      shippingSteps: "خطوات الشحن",
      prepareProduct: "تحضير المنتج",
      fillProductSafely: "قم بتغليف المنتج بشكل آمن",
      printLabel: "طباعة بطاقة الشحن",
      printShippingLabel: "اطبع بطاقة الشحن وألصقها على الطرد",
      deliverShipment: "تسليم الشحنة",
      deliverWithin24Hours: "سلّم الشحنة لشركة الشحن خلال 24 ساعة",
      note: "ملاحظة:",
      amountTransferAfterDelivery: "سيتم تحويل المبلغ إلى محفظتك بعد تأكيد استلام المشتري",
      confirmShipment: "تأكيد الشحن",
    },
    en: {
      shippingInstructions: "Shipping Instructions",
      shippingSteps: "Shipping Steps",
      prepareProduct: "Prepare Product",
      fillProductSafely: "Package the product safely",
      printLabel: "Print Label",
      printShippingLabel: "Print and attach the shipping label to the package",
      deliverShipment: "Deliver Shipment",
      deliverWithin24Hours: "Deliver the shipment to the courier within 24 hours",
      note: "Note:",
      amountTransferAfterDelivery: "The amount will be transferred to your wallet after buyer confirms receipt",
      confirmShipment: "Confirm Shipment",
    },
  };
  const c = content[language];

  return (
    <div 
      className="min-h-screen bg-white flex flex-col" 
      style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 flex items-center gap-4">
        <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
          <ChevronRight className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-semibold text-[#0e0f0c]">{c.shippingInstructions}</h1>
      </motion.div>
      
      <div className="flex-1 p-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-[rgba(22,51,0,0.07843)] rounded-[12px] p-6 mb-4 border border-[rgba(14,15,12,0.12157)]"
        >
          <h2 className={`font-bold text-[#0e0f0c] mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>{c.shippingSteps}</h2>
          
          <motion.div
            initial={{ opacity: 0, x: isRTL ? 20 : -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className={`flex gap-3 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}
          >
            <div className="flex-1">
              <h3 className="font-semibold text-[#163300] mb-1">1. {c.prepareProduct}</h3>
              <p className="text-sm text-[#6a6c6a]">{c.fillProductSafely}</p>
            </div>
            <div className="w-8 h-8 rounded-full bg-[#163300] text-white flex items-center justify-center font-bold flex-shrink-0">
              1
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: isRTL ? 20 : -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className={`flex gap-3 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}
          >
            <div className="flex-1">
              <h3 className="font-semibold text-[#163300] mb-1">2. {c.printLabel}</h3>
              <p className="text-sm text-[#6a6c6a]">{c.printShippingLabel}</p>
            </div>
            <div className="w-8 h-8 rounded-full bg-[#163300] text-white flex items-center justify-center font-bold flex-shrink-0">
              2
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: isRTL ? 20 : -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className={`flex gap-3 ${isRTL ? 'text-right' : 'text-left'}`}
          >
            <div className="flex-1">
              <h3 className="font-semibold text-[#163300] mb-1">3. {c.deliverShipment}</h3>
              <p className="text-sm text-[#6a6c6a]">{c.deliverWithin24Hours}</p>
            </div>
            <div className="w-8 h-8 rounded-full bg-[#163300] text-white flex items-center justify-center font-bold flex-shrink-0">
              3
            </div>
          </motion.div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5 }}
          className={`bg-[#9fe870]/10 border border-[#9fe870] rounded-[12px] p-4 ${isRTL ? 'text-right' : 'text-left'}`}
        >
          <p className="text-sm text-[#163300]">
            <span className="font-bold">{c.note}</span> {c.amountTransferAfterDelivery}
          </p>
        </motion.div>
      </div>
      
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="sticky bottom-0 bg-white border-t border-[rgba(14,15,12,0.12157)] p-6"
      >
        <WiseButton onClick={onComplete} variant="primary" fullWidth size="lg">
          {c.confirmShipment}
        </WiseButton>
      </motion.div>
    </div>
  );
}