import { motion } from "motion/react";
import { ChevronRight, ChevronLeft, Package, Clock, CheckCircle, XCircle, TruckIcon, DollarSign, ArrowDownToLine } from "lucide-react";
import { useState } from "react";
import { PullToRefresh } from "../../components/PullToRefresh";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";
import { ordersAPI } from "../../utils/api";

interface Sale {
  id: string;
  orderId: string;
  productTitle: string;
  productTitleAr: string;
  productImage: string;
  buyerName: string;
  buyerNameAr: string;
  price: number;
  status: "pending" | "shipped" | "delivered" | "cancelled";
  date: string;
  quantity: number;
}

interface RabitSellerSalesScreenProps {
  onBack: () => void;
  onSaleClick: (saleId: string) => void;
  onWithdraw?: () => void;
}

export function RabitSellerSalesScreen({ onBack, onSaleClick, onWithdraw }: RabitSellerSalesScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);
  const [activeTab, setActiveTab] = useState<"all" | "pending" | "shipped" | "completed">("all");
  const [isLoadingOrders, setIsLoadingOrders] = useState(false);

  // TODO: Connect to real backend when ready
  // Fetch seller's orders on component mount:
  // useEffect(() => {
  //   const fetchOrders = async () => {
  //     setIsLoadingOrders(true);
  //     const response = await ordersAPI.getSellerOrders(accessToken);
  //     if (response.success) {
  //       setSales(response.orders);
  //     }
  //     setIsLoadingOrders(false);
  //   };
  //   fetchOrders();
  // }, []);

  // Mock sales data
  const sales: Sale[] = [
    {
      id: "sale1",
      orderId: "#ORD-2401",
      productTitle: "iPhone 14 Pro Max",
      productTitleAr: "آيفون 14 برو ماكس",
      productImage: "https://images.unsplash.com/photo-1678685888221-cda773a3dcdb?w=400&h=400&fit=crop",
      buyerName: "Ahmed Al-Rashid",
      buyerNameAr: "أحمد الراشد",
      price: 4500,
      status: "shipped",
      date: "2024-01-20",
      quantity: 1,
    },
    {
      id: "sale2",
      orderId: "#ORD-2402",
      productTitle: "Nike Air Max",
      productTitleAr: "نايكي اير ماكس",
      productImage: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=400&fit=crop",
      buyerName: "Sara Mohammed",
      buyerNameAr: "سارة محمد",
      price: 650,
      status: "pending",
      date: "2024-01-22",
      quantity: 1,
    },
    {
      id: "sale3",
      orderId: "#ORD-2403",
      productTitle: "PlayStation 5",
      productTitleAr: "بلايستيشن 5",
      productImage: "https://images.unsplash.com/photo-1606813907291-d86efa9b94db?w=400&h=400&fit=crop",
      buyerName: "Khalid Fahad",
      buyerNameAr: "خالد فهد",
      price: 2200,
      status: "delivered",
      date: "2024-01-18",
      quantity: 1,
    },
  ];

  const handleRefresh = async () => {
    await new Promise(resolve => setTimeout(resolve, 1500));
    console.log("Refreshing sales data...");
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Clock className="w-4 h-4" />;
      case "shipped":
        return <TruckIcon className="w-4 h-4" />;
      case "delivered":
        return <CheckCircle className="w-4 h-4" />;
      case "cancelled":
        return <XCircle className="w-4 h-4" />;
      default:
        return <Package className="w-4 h-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-[#df8700] text-white";
      case "shipped":
        return "bg-[#0066ff] text-white";
      case "delivered":
        return "bg-[#008026] text-white";
      case "cancelled":
        return "bg-[#cb272f] text-white";
      default:
        return "bg-[rgba(22,51,0,0.07843)] text-[#0e0f0c]";
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "pending":
        return t.pending;
      case "shipped":
        return t.shipped;
      case "delivered":
        return t.delivered;
      case "cancelled":
        return t.cancelled;
      default:
        return status;
    }
  };

  const filteredSales = sales.filter(sale => {
    if (activeTab === "all") return true;
    if (activeTab === "completed") return sale.status === "delivered";
    return sale.status === activeTab;
  });

  const totalRevenue = sales
    .filter(s => s.status === "delivered")
    .reduce((acc, s) => acc + s.price, 0);

  const pendingSales = sales.filter(s => s.status === "pending").length;
  const shippedSales = sales.filter(s => s.status === "shipped").length;
  const completedSales = sales.filter(s => s.status === "delivered").length;

  return (
    <PullToRefresh onRefresh={handleRefresh}>
      <div 
        className="min-h-screen bg-[#fafafa]" 
        style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
        dir={isRTL ? 'rtl' : 'ltr'}
      >
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }} 
          animate={{ opacity: 1, y: 0 }} 
          className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 flex items-center gap-4 z-10"
        >
          <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
            {isRTL ? <ChevronRight className="w-6 h-6 text-[#0e0f0c]" /> : <ChevronLeft className="w-6 h-6 text-[#0e0f0c]" />}
          </button>
          <h1 className={`text-xl font-semibold text-[#0e0f0c] flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
            {t.sales}
          </h1>
        </motion.div>

        {/* Stats Summary */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="px-6 pt-6 pb-4 bg-white border-b border-[rgba(14,15,12,0.12157)]"
        >
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-gradient-to-br from-[#163300] to-[#1a3d00] rounded-2xl p-4 text-white">
              <div className={`flex items-center gap-2 mb-2 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
                <DollarSign className="w-5 h-5 text-[#9fe870]" />
                <span className="text-xs opacity-90">{t.totalRevenue}</span>
              </div>
              <div className={`text-2xl font-bold ${isRTL ? 'text-right' : 'text-left'}`}>
                {totalRevenue.toLocaleString()} {t.sar}
              </div>
            </div>
            <div className="bg-[#fafafa] rounded-2xl p-4 border border-[rgba(14,15,12,0.12157)]">
              <div className={`flex items-center gap-2 mb-2 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
                <Package className="w-5 h-5 text-[#163300]" />
                <span className="text-xs text-[#6a6c6a]">{language === 'ar' ? 'إجمالي المبيعات' : 'Total Sales'}</span>
              </div>
              <div className={`text-2xl font-bold text-[#163300] ${isRTL ? 'text-right' : 'text-left'}`}>
                {sales.length}
              </div>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-3 gap-2 mt-3">
            <div className="text-center bg-[#fafafa] rounded-xl p-2 border border-[rgba(14,15,12,0.08)]">
              <div className="text-base font-bold text-[#df8700] mb-0.5">{pendingSales}</div>
              <div className="text-[10px] text-[#6a6c6a]">{t.pending}</div>
            </div>
            <div className="text-center bg-[#fafafa] rounded-xl p-2 border border-[rgba(14,15,12,0.08)]">
              <div className="text-base font-bold text-[#0066ff] mb-0.5">{shippedSales}</div>
              <div className="text-[10px] text-[#6a6c6a]">{t.shipped}</div>
            </div>
            <div className="text-center bg-[#fafafa] rounded-xl p-2 border border-[rgba(14,15,12,0.08)]">
              <div className="text-base font-bold text-[#008026] mb-0.5">{completedSales}</div>
              <div className="text-[10px] text-[#6a6c6a]">{t.delivered}</div>
            </div>
          </div>

          {/* Withdraw Button */}
          {onWithdraw && totalRevenue > 0 && (
            <motion.button
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              whileTap={{ scale: 0.98 }}
              onClick={onWithdraw}
              className={`w-full mt-4 bg-[#9fe870] text-[#163300] rounded-2xl py-3.5 px-6 font-semibold flex items-center justify-center gap-2 shadow-lg hover:bg-[#8dd960] transition-colors ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}
            >
              <ArrowDownToLine className="w-5 h-5" />
              <span>{language === 'ar' ? 'سحب الأرباح' : 'Withdraw Earnings'}</span>
            </motion.button>
          )}
        </motion.div>

        {/* Filter Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="px-6 pt-4 pb-2 bg-white"
        >
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            {[
              { id: "all", label: t.allOrders, count: sales.length },
              { id: "pending", label: t.pending, count: pendingSales },
              { id: "shipped", label: t.shipped, count: shippedSales },
              { id: "completed", label: t.delivered, count: completedSales },
            ].map((tab, index) => (
              <motion.button
                key={tab.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
                onClick={() => setActiveTab(tab.id as typeof activeTab)}
                className={`px-4 py-2.5 rounded-full whitespace-nowrap transition-all flex items-center gap-2 ${
                  activeTab === tab.id
                    ? "bg-[#163300] text-white"
                    : "bg-[rgba(22,51,0,0.07843)] text-[#6a6c6a] border border-[rgba(14,15,12,0.12157)]"
                }`}
              >
                <span className="text-sm font-medium">{tab.label}</span>
                <span className={`text-xs px-1.5 py-0.5 rounded-full ${
                  activeTab === tab.id ? "bg-white/20" : "bg-[rgba(22,51,0,0.12)]"
                }`}>
                  {tab.count}
                </span>
              </motion.button>
            ))}
          </div>
        </motion.div>

        {/* Sales List */}
        <div className="px-6 pt-4 pb-6 space-y-3">
          {filteredSales.length === 0 ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex flex-col items-center justify-center py-16"
            >
              <Package className="w-16 h-16 text-[#6a6c6a] mb-4" />
              <p className="text-[#6a6c6a] text-center">
                {language === 'ar' ? 'لا توجد مبيعات' : 'No sales found'}
              </p>
            </motion.div>
          ) : (
            filteredSales.map((sale, index) => (
              <motion.div
                key={sale.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                onClick={() => onSaleClick(sale.id)}
                whileTap={{ scale: 0.98 }}
                className="bg-white rounded-2xl border border-[rgba(14,15,12,0.12157)] p-4 shadow-sm cursor-pointer hover:shadow-lg transition-all"
              >
                <div className={`flex gap-4 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
                  {/* Product Image */}
                  <div className="w-20 h-20 bg-[rgba(22,51,0,0.07843)] rounded-xl flex-shrink-0 overflow-hidden">
                    <img
                      src={sale.productImage}
                      alt={language === 'ar' ? sale.productTitleAr : sale.productTitle}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Sale Details */}
                  <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                    <div className={`flex items-start justify-between mb-2 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
                      <div className="flex-1">
                        <p className="font-semibold text-[#0e0f0c] mb-1 text-sm">
                          {language === 'ar' ? sale.productTitleAr : sale.productTitle}
                        </p>
                        <p className="text-xs text-[#6a6c6a] mb-1">
                          {language === 'ar' ? 'المشتري: ' : 'Buyer: '}
                          {language === 'ar' ? sale.buyerNameAr : sale.buyerName}
                        </p>
                        <p className="text-lg font-bold text-[#163300]">
                          {sale.price} {t.sar}
                        </p>
                      </div>
                    </div>

                    {/* Status and Order ID */}
                    <div className={`flex items-center justify-between gap-2 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
                      <span className={`px-2.5 py-1 rounded-full text-xs font-medium flex items-center gap-1 ${getStatusColor(sale.status)}`}>
                        {getStatusIcon(sale.status)}
                        {getStatusText(sale.status)}
                      </span>
                      <span className="text-xs text-[#6a6c6a]">{sale.orderId}</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))
          )}
        </div>
      </div>
    </PullToRefresh>
  );
}