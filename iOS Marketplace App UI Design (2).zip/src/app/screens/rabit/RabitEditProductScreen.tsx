import { motion } from "motion/react";
import { WiseButton } from "../../components/WiseButton";
import { ChevronRight, Trash2, Camera, AlertCircle, Package } from "lucide-react";
import { useState, useEffect } from "react";
import { type RabitProduct } from "../../data/rabitProducts";
import { toast } from "sonner";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";
import { getCategories, type Category } from "../../services/categories.service";
import { updateProduct } from "../../services/products.service";
import { uploadProductImage } from "../../services/storage.service";
import { useAuth } from "../../contexts/AuthContext";

interface RabitEditProductScreenProps {
  product: RabitProduct;
  onBack: () => void;
  onUpdateSuccess: () => void;
}

export function RabitEditProductScreen({ product, onBack, onUpdateSuccess }: RabitEditProductScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);
  const [formData, setFormData] = useState({
    title: product.titleAr,
    price: product.price.toString(),
    category: product.categoryAr,
    condition: product.condition,
    city: product.cityAr,
    description: product.descriptionAr,
    quantity: product.quantity?.toString() || product.stock?.toString() || "1", // Add quantity field
  });
  const [images, setImages] = useState<string[]>(product.images);
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [showSuccess, setShowSuccess] = useState(false);
  const [categories, setCategories] = useState<Category[]>([]);
  const [isLoadingCategories, setIsLoadingCategories] = useState(false);
  const { user } = useAuth();

  useEffect(() => {
    const fetchCategories = async () => {
      setIsLoadingCategories(true);
      try {
        const result = await getCategories();
        if (result.success && result.categories) {
          setCategories(result.categories);
        } else {
          toast.error(language === 'ar' ? 'فشل تحميل الفئات' : 'Failed to load categories');
          setCategories([]);
        }
      } catch (error) {
        console.error('Error fetching categories:', error);
        toast.error(language === 'ar' ? 'حدث خطأ أثناء تحميل الفئات' : 'Error loading categories');
        setCategories([]);
      }
      setIsLoadingCategories(false);
    };
    fetchCategories();
  }, [language]);

  const handleImageUpload = async () => {
    const newImage = "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400";
    if (images.length < 5) {
      const uploadedImageUrl = await uploadProductImage(newImage, user?.uid || "");
      setImages([...images, uploadedImageUrl]);
    }
  };

  const removeImage = (index: number) => {
    setImages(images.filter((_, i) => i !== index));
  };

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.title.trim()) newErrors.title = "عنوان المنتج مطلوب";
    if (!formData.price || parseFloat(formData.price) <= 0) newErrors.price = "السعر غير صحيح";
    if (!formData.category) newErrors.category = "الفئة مطلوبة";
    if (images.length === 0) newErrors.images = "صورة واحدة على الأقل مطلوبة";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleUpdate = async () => {
    if (!validate()) return;
    
    setIsLoading(true);
    const updatedProduct = {
      ...product,
      titleAr: formData.title,
      price: parseFloat(formData.price),
      categoryAr: formData.category,
      condition: formData.condition,
      cityAr: formData.city,
      descriptionAr: formData.description,
      quantity: parseInt(formData.quantity),
      images: images,
    };
    await updateProduct(updatedProduct);
    setIsLoading(false);
    setShowSuccess(true);
    toast.success("تم تحديث المنتج بنجاح ✨");
    setTimeout(() => {
      onUpdateSuccess();
    }, 2000);
  };

  if (showSuccess) {
    return (
      <div className="min-h-screen bg-white flex flex-col items-center justify-center p-6" style={{ fontFamily: 'Cairo, sans-serif' }}>
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 200, damping: 15 }}
          className="w-24 h-24 bg-[#163300] rounded-full flex items-center justify-center mb-6"
        >
          <motion.svg
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="w-12 h-12 text-white"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
          >
            <motion.path
              d="M5 13l4 4L19 7"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </motion.svg>
        </motion.div>
        
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-2xl font-bold text-[#163300] mb-2 text-center"
        >
          تم التحديث بنجاح! ✓
        </motion.h2>
        
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="text-[#6a6c6a] text-center"
        >
          تم تحديث معلومات المنتج
        </motion.p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white pb-32" style={{ fontFamily: 'Cairo, sans-serif' }}>
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 flex items-center justify-between z-10"
      >
        <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
          <ChevronRight className="w-6 h-6 text-[#0e0f0c]" />
        </button>
        <h1 className="text-xl font-semibold text-[#0e0f0c]">تعديل المنتج</h1>
        <div className="w-10" />
      </motion.div>

      <div className="p-6 space-y-6">
        {/* Images */}
        <div>
          <label className="block text-sm font-semibold text-[#0e0f0c] mb-3 text-right">
            صور المنتج ({images.length}/5)
          </label>
          <div className="grid grid-cols-3 gap-3">
            {images.map((img, index) => (
              <div key={index} className="relative aspect-square rounded-[12px] overflow-hidden">
                <img src={img} alt="" className="w-full h-full object-cover" />
                <button
                  onClick={() => removeImage(index)}
                  className="absolute top-2 right-2 w-6 h-6 bg-[#cb272f] rounded-full flex items-center justify-center"
                >
                  <Trash2 className="w-4 h-4 text-white" />
                </button>
              </div>
            ))}
            {images.length < 5 && (
              <button
                onClick={handleImageUpload}
                className="aspect-square rounded-[12px] border-2 border-dashed border-[rgba(14,15,12,0.12157)] bg-[rgba(22,51,0,0.07843)] flex flex-col items-center justify-center gap-2"
              >
                <Camera className="w-6 h-6 text-[#6a6c6a]" />
                <span className="text-xs text-[#6a6c6a]">إضافة صورة</span>
              </button>
            )}
          </div>
          {errors.images && (
            <div className="flex items-center gap-2 mt-2 text-[#cb272f] text-sm">
              <AlertCircle className="w-4 h-4" />
              <span>{errors.images}</span>
            </div>
          )}
        </div>

        {/* Title */}
        <div>
          <label className="block text-sm font-semibold text-[#0e0f0c] mb-2 text-right">عنوان المنتج</label>
          <input
            type="text"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            placeholder="مثال: آيفون 14 برو ماكس - 256 جيجا"
            className="w-full px-4 py-3 rounded-[10px] border border-[rgba(14,15,12,0.12157)] text-right focus:outline-none focus:border-[#163300]"
          />
          {errors.title && (
            <div className="flex items-center gap-2 mt-2 text-[#cb272f] text-sm">
              <AlertCircle className="w-4 h-4" />
              <span>{errors.title}</span>
            </div>
          )}
        </div>

        {/* Price */}
        <div>
          <label className="block text-sm font-semibold text-[#0e0f0c] mb-2 text-right">السعر (ر.س)</label>
          <input
            type="number"
            value={formData.price}
            onChange={(e) => setFormData({ ...formData, price: e.target.value })}
            placeholder="0.00"
            className="w-full px-4 py-3 rounded-[10px] border border-[rgba(14,15,12,0.12157)] text-right focus:outline-none focus:border-[#163300]"
          />
          {errors.price && (
            <div className="flex items-center gap-2 mt-2 text-[#cb272f] text-sm">
              <AlertCircle className="w-4 h-4" />
              <span>{errors.price}</span>
            </div>
          )}
        </div>

        {/* Quantity */}
        <div>
          <label className="block text-sm font-semibold text-[#0e0f0c] mb-2 text-right">
            <div className="flex items-center justify-end gap-2">
              <span>الكمية المتاحة</span>
              <Package className="w-4 h-4 text-[#163300]" />
            </div>
          </label>
          <div className="relative">
            <input
              type="number"
              value={formData.quantity}
              onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
              placeholder="1"
              min="0"
              className="w-full px-4 py-3 rounded-[10px] border border-[rgba(14,15,12,0.12157)] text-right focus:outline-none focus:border-[#163300]"
            />
            {parseInt(formData.quantity) === 0 && (
              <div className="absolute left-3 top-1/2 -translate-y-1/2 px-2 py-1 bg-[#cb272f] text-white text-xs rounded-full">
                غير متاح
              </div>
            )}
            {parseInt(formData.quantity) > 0 && parseInt(formData.quantity) <= 5 && (
              <div className="absolute left-3 top-1/2 -translate-y-1/2 px-2 py-1 bg-[#ff8c00] text-white text-xs rounded-full">
                ⚠️ مخزون منخفض
              </div>
            )}
          </div>
          <p className="text-xs text-[#6a6c6a] mt-2 text-right">
            {parseInt(formData.quantity) === 0 
              ? "🚫 سيتم إخفاء المنتج من نتائج البحث" 
              : `✓ ${formData.quantity} قطعة متاحة للبيع`}
          </p>
        </div>

        {/* Category */}
        <div>
          <label className="block text-sm font-semibold text-[#0e0f0c] mb-2 text-right">الفئة</label>
          <select
            value={formData.category}
            onChange={(e) => setFormData({ ...formData, category: e.target.value })}
            className="w-full px-4 py-3 rounded-[10px] border border-[rgba(14,15,12,0.12157)] text-right focus:outline-none focus:border-[#163300] bg-white"
            disabled={isLoadingCategories}
          >
            <option value="">{isLoadingCategories ? 'جاري التحميل...' : 'اختر الفئة'}</option>
            {categories && categories.length > 0 && categories.map((cat) => (
              <option key={cat.id} value={cat.nameAr}>{cat.nameAr}</option>
            ))}
          </select>
          {errors.category && (
            <div className="flex items-center gap-2 mt-2 text-[#cb272f] text-sm">
              <AlertCircle className="w-4 h-4" />
              <span>{errors.category}</span>
            </div>
          )}
        </div>

        {/* Condition */}
        <div>
          <label className="block text-sm font-semibold text-[#0e0f0c] mb-3 text-right">الحالة</label>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => setFormData({ ...formData, condition: "new" })}
              className={`py-3 px-4 rounded-[10px] font-medium transition-all ${
                formData.condition === "new"
                  ? "bg-[#163300] text-white"
                  : "bg-[rgba(22,51,0,0.07843)] text-[#0e0f0c] border border-[rgba(14,15,12,0.12157)]"
              }`}
            >
              جديد
            </button>
            <button
              onClick={() => setFormData({ ...formData, condition: "used" })}
              className={`py-3 px-4 rounded-[10px] font-medium transition-all ${
                formData.condition === "used"
                  ? "bg-[#163300] text-white"
                  : "bg-[rgba(22,51,0,0.07843)] text-[#0e0f0c] border border-[rgba(14,15,12,0.12157)]"
              }`}
            >
              مستعمل
            </button>
          </div>
        </div>

        {/* City */}
        <div>
          <label className="block text-sm font-semibold text-[#0e0f0c] mb-2 text-right">المدينة</label>
          <select
            value={formData.city}
            onChange={(e) => setFormData({ ...formData, city: e.target.value })}
            className="w-full px-4 py-3 rounded-[10px] border border-[rgba(14,15,12,0.12157)] text-right focus:outline-none focus:border-[#163300] bg-white"
          >
            <option value="">اختر المدينة</option>
            <option value="الرياض">الرياض</option>
            <option value="جدة">جدة</option>
            <option value="الدمام">الدمام</option>
            <option value="مكة">مكة</option>
            <option value="المدينة">المدينة</option>
          </select>
        </div>

        {/* Description */}
        <div>
          <label className="block text-sm font-semibold text-[#0e0f0c] mb-2 text-right">الوصف</label>
          <textarea
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            placeholder="اكتب وصفاً تفصيلياً للمنتج..."
            rows={5}
            className="w-full px-4 py-3 rounded-[10px] border border-[rgba(14,15,12,0.12157)] text-right focus:outline-none focus:border-[#163300] resize-none"
          />
        </div>
      </div>

      {/* Fixed Bottom Button */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-[rgba(14,15,12,0.12157)] px-6 py-4 max-w-[430px] mx-auto">
        <WiseButton
          onClick={handleUpdate}
          variant="primary"
          fullWidth
          loading={isLoading}
          disabled={isLoading}
        >
          {isLoading ? "جاري التحديث..." : "حفظ التعديلات"}
        </WiseButton>
      </div>
    </div>
  );
}