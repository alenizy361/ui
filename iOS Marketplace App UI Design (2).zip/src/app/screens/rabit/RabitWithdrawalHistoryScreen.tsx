import { motion } from "motion/react";
import { ChevronRight, DollarSign, Calendar, CheckCircle2, Clock, X } from "lucide-react";
import { useState } from "react";
import { useLanguage } from "../../contexts/LanguageContext";

interface Withdrawal {
  id: string;
  amount: number;
  date: string;
  status: "completed" | "pending" | "failed";
  iban: string;
  transactionId?: string;
}

interface RabitWithdrawalHistoryScreenProps {
  onBack: () => void;
}

export function RabitWithdrawalHistoryScreen({ onBack }: RabitWithdrawalHistoryScreenProps) {
  const { language, isRTL } = useLanguage();
  const [filter, setFilter] = useState<"all" | "completed" | "pending" | "failed">("all");

  const content = {
    ar: {
      withdrawalHistory: "سجل السحوبات",
      all: "الكل",
      completed: "مكتمل",
      pending: "قيد المعالجة",
      failed: "فشل",
      noWithdrawals: "لا توجد سحوبات",
      noWithdrawalsDesc: "لم تقم بأي عمليات سحب حتى الآن",
      amount: "المبلغ",
      date: "التاريخ",
      iban: "IBAN",
      transactionId: "رقم العملية",
      totalWithdrawn: "إجمالي المسحوب",
      thisMonth: "هذا الشهر",
      statusCompleted: "تم التحويل بنجاح",
      statusPending: "قيد المعالجة",
      statusFailed: "فشلت العملية",
      viewDetails: "عرض التفاصيل",
    },
    en: {
      withdrawalHistory: "Withdrawal History",
      all: "All",
      completed: "Completed",
      pending: "Pending",
      failed: "Failed",
      noWithdrawals: "No Withdrawals",
      noWithdrawalsDesc: "You haven't made any withdrawals yet",
      amount: "Amount",
      date: "Date",
      iban: "IBAN",
      transactionId: "Transaction ID",
      totalWithdrawn: "Total Withdrawn",
      thisMonth: "This Month",
      statusCompleted: "Transfer completed",
      statusPending: "Processing",
      statusFailed: "Transfer failed",
      viewDetails: "View Details",
    },
  };
  const c = content[language];

  // Mock withdrawal data
  const mockWithdrawals: Withdrawal[] = [
    {
      id: "1",
      amount: 2500,
      date: "2025-12-20",
      status: "completed",
      iban: "SA03 8000 0000 6080 1016 7519",
      transactionId: "WD20251220001",
    },
    {
      id: "2",
      amount: 1800,
      date: "2025-12-15",
      status: "completed",
      iban: "SA03 8000 0000 6080 1016 7519",
      transactionId: "WD20251215001",
    },
    {
      id: "3",
      amount: 3200,
      date: "2025-12-10",
      status: "pending",
      iban: "SA03 8000 0000 6080 1016 7519",
    },
    {
      id: "4",
      amount: 1500,
      date: "2025-12-05",
      status: "completed",
      iban: "SA03 8000 0000 6080 1016 7519",
      transactionId: "WD20251205001",
    },
    {
      id: "5",
      amount: 950,
      date: "2025-11-28",
      status: "failed",
      iban: "SA03 8000 0000 6080 1016 7519",
    },
  ];

  const filteredWithdrawals =
    filter === "all"
      ? mockWithdrawals
      : mockWithdrawals.filter((w) => w.status === filter);

  const totalWithdrawn = mockWithdrawals
    .filter((w) => w.status === "completed")
    .reduce((sum, w) => sum + w.amount, 0);

  const thisMonthWithdrawn = mockWithdrawals
    .filter((w) => w.status === "completed" && new Date(w.date).getMonth() === 11) // December
    .reduce((sum, w) => sum + w.amount, 0);

  const getStatusIcon = (status: Withdrawal["status"]) => {
    if (status === "completed") return CheckCircle2;
    if (status === "pending") return Clock;
    return X;
  };

  const getStatusColor = (status: Withdrawal["status"]) => {
    if (status === "completed") return "text-[#008026]";
    if (status === "pending") return "text-[#ff9500]";
    return "text-[#cb272f]";
  };

  const getStatusBg = (status: Withdrawal["status"]) => {
    if (status === "completed") return "bg-[rgba(0,128,38,0.1)]";
    if (status === "pending") return "bg-[rgba(255,149,0,0.1)]";
    return "bg-[rgba(203,39,47,0.1)]";
  };

  const getStatusText = (status: Withdrawal["status"]) => {
    if (status === "completed") return c.statusCompleted;
    if (status === "pending") return c.statusPending;
    return c.statusFailed;
  };

  return (
    <div
      className="min-h-screen bg-[#fafafa] pb-6"
      style={{ fontFamily: language === "ar" ? "Cairo, sans-serif" : "system-ui, -apple-system, sans-serif" }}
      dir={isRTL ? "rtl" : "ltr"}
    >
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 z-10"
      >
        <div className="flex items-center justify-between">
          <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
            <ChevronRight className={`w-6 h-6 text-[#0e0f0c] ${isRTL ? "" : "rotate-180"}`} />
          </button>
          <h1 className="text-xl font-semibold text-[#0e0f0c]">{c.withdrawalHistory}</h1>
          <div className="w-10" />
        </div>
      </motion.div>

      <div className="p-6 space-y-6">
        {/* Summary Cards */}
        <div className="grid grid-cols-2 gap-3">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-gradient-to-br from-[#163300] to-[#1a3d00] rounded-[12px] p-4 text-white"
          >
            <DollarSign className="w-6 h-6 mb-2 opacity-80" />
            <p className="text-2xl font-bold mb-1">{totalWithdrawn.toLocaleString()}</p>
            <p className="text-xs opacity-80">{c.totalWithdrawn}</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.05 }}
            className="bg-white rounded-[12px] p-4 border border-[rgba(14,15,12,0.12157)]"
          >
            <Calendar className="w-6 h-6 mb-2 text-[#163300]" />
            <p className="text-2xl font-bold text-[#0e0f0c] mb-1">
              {thisMonthWithdrawn.toLocaleString()}
            </p>
            <p className="text-xs text-[#6a6c6a]">{c.thisMonth}</p>
          </motion.div>
        </div>

        {/* Filter Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="flex gap-2 overflow-x-auto pb-2"
        >
          {(["all", "completed", "pending", "failed"] as const).map((status) => (
            <button
              key={status}
              onClick={() => setFilter(status)}
              className={`px-4 py-2 rounded-[8px] text-sm font-medium whitespace-nowrap transition-colors ${
                filter === status
                  ? "bg-[#163300] text-white"
                  : "bg-white text-[#0e0f0c] border border-[rgba(14,15,12,0.12157)]"
              }`}
            >
              {c[status]}
            </button>
          ))}
        </motion.div>

        {/* Withdrawals List */}
        {filteredWithdrawals.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center justify-center py-20"
          >
            <DollarSign className="w-16 h-16 text-[#6a6c6a] mb-4" />
            <h3 className="text-lg font-semibold text-[#0e0f0c] mb-2">{c.noWithdrawals}</h3>
            <p className="text-sm text-[#6a6c6a] text-center">{c.noWithdrawalsDesc}</p>
          </motion.div>
        ) : (
          <div className="space-y-3">
            {filteredWithdrawals.map((withdrawal, index) => {
              const StatusIcon = getStatusIcon(withdrawal.status);
              return (
                <motion.div
                  key={withdrawal.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 + index * 0.05 }}
                  className="bg-white rounded-[12px] p-4"
                >
                  {/* Header */}
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <p className="text-2xl font-bold text-[#0e0f0c] mb-1">
                        {withdrawal.amount.toLocaleString()} ر.س
                      </p>
                      <p className="text-xs text-[#6a6c6a]">
                        {new Date(withdrawal.date).toLocaleDateString(
                          language === "ar" ? "ar-SA" : "en-US",
                          { year: "numeric", month: "long", day: "numeric" }
                        )}
                      </p>
                    </div>
                    <div
                      className={`flex items-center gap-1 px-3 py-1 rounded-full ${getStatusBg(
                        withdrawal.status
                      )}`}
                    >
                      <StatusIcon className={`w-4 h-4 ${getStatusColor(withdrawal.status)}`} />
                      <span className={`text-xs font-semibold ${getStatusColor(withdrawal.status)}`}>
                        {c[withdrawal.status]}
                      </span>
                    </div>
                  </div>

                  {/* Details */}
                  <div className="space-y-2 pt-3 border-t border-[rgba(14,15,12,0.12157)]">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-[#6a6c6a]">{c.iban}</span>
                      <span className="text-xs font-mono text-[#0e0f0c]" dir="ltr">
                        {withdrawal.iban}
                      </span>
                    </div>
                    {withdrawal.transactionId && (
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-[#6a6c6a]">{c.transactionId}</span>
                        <span className="text-xs font-mono text-[#0e0f0c]">
                          {withdrawal.transactionId}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Status Message */}
                  <div className={`mt-3 text-xs ${getStatusColor(withdrawal.status)}`}>
                    {getStatusText(withdrawal.status)}
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
