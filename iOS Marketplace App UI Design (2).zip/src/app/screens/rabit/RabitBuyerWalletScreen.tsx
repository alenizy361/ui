import { motion } from "motion/react";
import { ChevronRight, CreditCard, History, ShoppingBag } from "lucide-react";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";

/**
 * BUYER WALLET SCREEN
 * 
 * Shows:
 * - Available balance for purchases
 * - Payment methods
 * - Purchase history
 * - NO income/earnings
 * - NO withdrawal options
 */

interface RabitBuyerWalletScreenProps {
  onBack: () => void;
  onViewTransactions?: () => void;
  onPaymentMethods?: () => void;
}

export function RabitBuyerWalletScreen({ 
  onBack,
  onViewTransactions,
  onPaymentMethods,
}: RabitBuyerWalletScreenProps) {
  const { language, isRTL } = useLanguage();

  const content = {
    ar: {
      wallet: "المحفظة",
      availableBalance: "الرصيد المتاح",
      addBalance: "إضافة رصيد",
      paymentMethods: "طرق الدفع",
      purchaseHistory: "سجل المشتريات",
      recentPurchases: "المشتريات الأخيرة",
      note: "ملاحظة:",
      buyerProtectionNote: "جميع عمليات الشراء محمية بضمان رابط للمشتري",
    },
    en: {
      wallet: "Wallet",
      availableBalance: "Available Balance",
      addBalance: "Add Balance",
      paymentMethods: "Payment Methods",
      purchaseHistory: "Purchase History",
      recentPurchases: "Recent Purchases",
      note: "Note:",
      buyerProtectionNote: "All purchases are protected by Rabit buyer guarantee",
    },
  };
  const c = content[language];

  return (
    <div 
      className="min-h-screen bg-white" 
      style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }} 
        animate={{ opacity: 1, y: 0 }} 
        className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 flex items-center gap-4 z-10"
      >
        <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
          <ChevronRight className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-semibold text-[#0e0f0c]">{c.wallet}</h1>
      </motion.div>
      
      <div className="p-6">
        {/* Balance Card - For Buyers: Shows available credit/balance */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-gradient-to-br from-[#163300] to-[#0d1f00] rounded-[16px] p-6 text-white mb-6"
        >
          <p className="text-sm opacity-80 mb-2">{c.availableBalance}</p>
          <h2 className="text-4xl font-bold mb-4">٥٠٠ ر.س</h2>
          <div className="flex items-center gap-2 text-sm opacity-90">
            <CreditCard className="w-4 h-4" />
            <span>{c.addBalance}</span>
          </div>
        </motion.div>

        {/* Action Buttons - BUYER SPECIFIC */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          <button
            onClick={onPaymentMethods}
            className="flex items-center justify-center gap-2 py-4 px-4 bg-[#163300] text-white rounded-[10px] font-medium hover:bg-[#1a3d00] transition-colors"
          >
            <CreditCard className="w-5 h-5" />
            <span>{c.paymentMethods}</span>
          </button>
          <button
            onClick={onViewTransactions}
            className="flex items-center justify-center gap-2 py-4 px-4 bg-[rgba(22,51,0,0.1)] text-[#163300] rounded-[10px] font-medium hover:bg-[rgba(22,51,0,0.15)] transition-colors"
          >
            <History className="w-5 h-5" />
            <span>{c.purchaseHistory}</span>
          </button>
        </div>
        
        {/* Recent Purchases */}
        <div>
          <h3 className={`font-semibold text-[#0e0f0c] mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>{c.recentPurchases}</h3>
          <div className="space-y-3">
            {[
              { id: 1, titleAr: "آيفون ٢٠٢٣ برو", titleEn: "iPhone 2023 Pro", amount: 4500, days: 2 },
              { id: 2, titleAr: "ساعة أبل", titleEn: "Apple Watch", amount: 1800, days: 5 },
              { id: 3, titleAr: "سماعات AirPods", titleEn: "AirPods", amount: 650, days: 7 },
            ].map((purchase) => (
              <motion.div 
                key={purchase.id}
                initial={{ opacity: 0, x: isRTL ? 20 : -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: purchase.id * 0.1 }}
                className="flex justify-between items-center p-4 bg-[rgba(22,51,0,0.07843)] rounded-[10px] border border-[rgba(14,15,12,0.12157)]"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#163300]/10 flex items-center justify-center">
                    <ShoppingBag className="w-5 h-5 text-[#163300]" />
                  </div>
                  <div className={isRTL ? 'text-right' : 'text-left'}>
                    <p className="font-medium text-[#0e0f0c]">{language === 'ar' ? purchase.titleAr : purchase.titleEn}</p>
                    <p className="text-xs text-[#6a6c6a]">{language === 'ar' ? `منذ ${purchase.days} أيام` : `${purchase.days} days ago`}</p>
                  </div>
                </div>
                <span className="font-bold text-[#cb272f]">-{purchase.amount} ر.س</span>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Info Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mt-6 p-4 bg-[#e2f6d5] rounded-[10px] border border-[#163300]/20"
        >
          <p className={`text-sm text-[#163300] ${isRTL ? 'text-right' : 'text-left'}`}>
            💡 <strong>{c.note}</strong> {c.buyerProtectionNote}
          </p>
        </motion.div>
      </div>
    </div>
  );
}