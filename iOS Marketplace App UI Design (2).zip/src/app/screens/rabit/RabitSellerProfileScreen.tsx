import { motion } from "motion/react";
import { ChevronRight, Star, MapPin, Package, MessageCircle } from "lucide-react";
import { type RabitProduct } from "../../data/rabitProducts";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";
import { useState, useEffect } from "react";
import { getSellerProducts } from "../../services/products.service";

interface RabitSellerProfileScreenProps {
  sellerId: string;
  onBack: () => void;
  onProductClick: (product: RabitProduct) => void;
  onContactSeller: () => void;
}

export function RabitSellerProfileScreen({ sellerId, onBack, onProductClick, onContactSeller }: RabitSellerProfileScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);
  const [isLoadingProfile, setIsLoadingProfile] = useState(false);
  const [isLoadingListings, setIsLoadingListings] = useState(false);
  const [isLoadingReviews, setIsLoadingReviews] = useState(false);
  const [products, setProducts] = useState<RabitProduct[]>([]);

  // Fetch seller products
  useEffect(() => {
    const fetchSellerProducts = async () => {
      setIsLoadingListings(true);
      try {
        const result = await getSellerProducts(sellerId);
        if (result.success && result.products) {
          setProducts(result.products);
        } else {
          console.error('Failed to fetch seller products:', result.error);
          setProducts([]);
        }
      } catch (error) {
        console.error('Error fetching seller products:', error);
        setProducts([]);
      }
      setIsLoadingListings(false);
    };

    fetchSellerProducts();
  }, [sellerId]);

  // TODO: Connect to real backend when ready
  // Fetch seller profile on component mount:
  // useEffect(() => {
  //   const fetchSellerProfile = async () => {
  //     setIsLoadingProfile(true);
  //     const response = await sellersAPI.getSellerProfile(sellerId);
  //     if (response.success) {
  //       setSellerInfo(response.profile);
  //     }
  //     setIsLoadingProfile(false);
  //   };
  //   fetchSellerProfile();
  // }, [sellerId]);

  // TODO: Fetch seller's active listings:
  // useEffect(() => {
  //   const fetchListings = async () => {
  //     setIsLoadingListings(true);
  //     const response = await sellersAPI.getSellerListings(sellerId, {
  //       includeInactive: false,
  //       sortBy: 'newest',
  //       limit: 20
  //     });
  //     if (response.success) {
  //       setProducts(response.products);
  //     }
  //     setIsLoadingListings(false);
  //   };
  //   fetchListings();
  // }, [sellerId]);

  // TODO: Fetch seller reviews:
  // useEffect(() => {
  //   const fetchReviews = async () => {
  //     setIsLoadingReviews(true);
  //     const response = await sellersAPI.getSellerReviews(sellerId, {
  //       page: 1,
  //       limit: 5,
  //       sortBy: 'newest'
  //     });
  //     if (response.success) {
  //       setReviews(response.reviews);
  //       setAverageRating(response.averageRating);
  //     }
  //     setIsLoadingReviews(false);
  //   };
  //   fetchReviews();
  // }, [sellerId]);

  // Mock data for now
  const sellerInfo = {
    name: "متجر التقنية السعودية",
    rating: 4.9,
    reviewCount: 127,
    totalSales: 456,
    verified: true,
    joinDate: "يناير 2023",
  };

  const [products, setProducts] = useState<RabitProduct[]>([]);

  useEffect(() => {
    const fetchProducts = async () => {
      setIsLoadingListings(true);
      const response = await getSellerProducts(sellerId);
      if (response.success) {
        setProducts(response.products);
      }
      setIsLoadingListings(false);
    };
    fetchProducts();
  }, [sellerId]);

  return (
    <div className="min-h-screen bg-white pb-24" style={{ fontFamily: 'Cairo, sans-serif' }}>
      <motion.div 
        initial={{ opacity: 0, y: -20 }} 
        animate={{ opacity: 1, y: 0 }} 
        className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 flex items-center gap-4 z-10"
      >
        <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center text-[#0e0f0c]">
          <ChevronRight className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-semibold text-[#0e0f0c]">ملف البائع</h1>
      </motion.div>
      
      <div className="p-6">
        {/* Seller Header */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-6"
        >
          <div className="w-24 h-24 bg-[#163300] rounded-full mx-auto mb-4 flex items-center justify-center text-white text-3xl font-bold relative">
            A
            {sellerInfo.verified && (
              <div className="absolute -bottom-1 -right-1 w-8 h-8 bg-[#008026] rounded-full flex items-center justify-center border-2 border-white">
                <Star className="w-5 h-5 text-white" />
              </div>
            )}
          </div>
          <h2 className="text-xl font-bold text-[#0e0f0c] mb-2">{sellerInfo.name}</h2>
          <div className="flex items-center justify-center gap-2 mb-3">
            <span className="flex items-center gap-1 text-[#df8700]">
              <Star className="w-4 h-4 fill-current" />
              <span className="font-bold">{sellerInfo.rating}</span>
            </span>
            <span className="text-[#6a6c6a]">({sellerInfo.reviewCount} تقييم)</span>
          </div>
          
          {/* Stats */}
          <div className="flex justify-center gap-6 mb-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-[#163300]">{sellerInfo.totalSales}</p>
              <p className="text-xs text-[#6a6c6a]">مبيعات</p>
            </div>
            <div className="h-10 w-px bg-[rgba(14,15,12,0.12157)]" />
            <div className="text-center">
              <p className="text-2xl font-bold text-[#163300]">{products.length}</p>
              <p className="text-xs text-[#6a6c6a]">منتجات</p>
            </div>
          </div>

          {/* Contact Button */}
          {onContactSeller && (
            <WiseButton
              onClick={onContactSeller}
              variant="primary"
              fullWidth
              className="flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-5 h-5" />
              <span>تواصل مع البائع</span>
            </WiseButton>
          )}
        </motion.div>
        
        {/* Products Section */}
        <div className="mb-6">
          <h3 className="text-lg font-bold text-[#0e0f0c] mb-4 text-right">منتجات البائع</h3>
          <div className="grid grid-cols-2 gap-4">
            {products.slice(0, 6).map((product, index) => (
              <motion.button 
                key={product.id} 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
                onClick={() => onProductClick(product)} 
                className="bg-white rounded-[12px] border border-[rgba(14,15,12,0.12157)] overflow-hidden hover:shadow-md transition-shadow"
              >
                <img src={product.image} alt={product.titleAr} className="w-full aspect-square object-cover" />
                <div className="p-3">
                  <p className="text-sm font-medium text-[#0e0f0c] truncate text-right">{product.titleAr}</p>
                  <p className="font-bold text-[#163300] text-right">{product.price} ر.س</p>
                </div>
              </motion.button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}