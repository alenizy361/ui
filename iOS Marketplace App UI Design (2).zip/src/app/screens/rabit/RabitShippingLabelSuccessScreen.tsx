import { motion } from "motion/react";
import { CheckCircle, Download, Printer, Package, ArrowRight } from "lucide-react";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";

interface ShippingLabelSuccessScreenProps {
  orderNumber: string;
  trackingNumber: string;
  shippingCost: number;
  paymentMethod: "wallet" | "card";
  onDownloadLabel: () => void;
  onContinue: () => void;
}

export function RabitShippingLabelSuccessScreen({
  orderNumber,
  trackingNumber,
  shippingCost,
  paymentMethod,
  onDownloadLabel,
  onContinue,
}: ShippingLabelSuccessScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);

  return (
    <div
      className="min-h-screen bg-[#f8f9fa] flex flex-col items-center justify-center px-6 relative overflow-hidden"
      style={{ fontFamily: language === "ar" ? "Cairo, sans-serif" : "SF Pro Display, sans-serif" }}
    >
      {/* Background Decoration */}
      <motion.div
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 0.05 }}
        transition={{ duration: 1 }}
        className="absolute w-[500px] h-[500px] rounded-full border-4 border-[#9fe870] pointer-events-none"
      />

      {/* Success Icon */}
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{
          type: "spring",
          stiffness: 200,
          damping: 15,
          delay: 0.2,
        }}
        className="relative mb-8 pointer-events-none"
      >
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="w-32 h-32 rounded-full bg-[#9fe870]/10 backdrop-blur-sm flex items-center justify-center shadow-xl"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{
              type: "spring",
              stiffness: 300,
              damping: 20,
              delay: 0.4,
            }}
            className="w-24 h-24 rounded-full bg-[#9fe870] flex items-center justify-center relative shadow-lg"
          >
            <motion.div
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{
                type: "spring",
                stiffness: 200,
                damping: 15,
                delay: 0.6,
              }}
            >
              <CheckCircle className="w-12 h-12 text-white" strokeWidth={2.5} />
            </motion.div>

            {/* Pulse Effect */}
            <motion.div
              initial={{ scale: 1, opacity: 0.5 }}
              animate={{ scale: 2, opacity: 0 }}
              transition={{
                duration: 1.5,
                repeat: Infinity,
                repeatDelay: 0.5,
              }}
              className="absolute inset-0 rounded-full bg-[#9fe870]"
            />
          </motion.div>
        </motion.div>

        {/* Package Icon Badge */}
        <motion.div
          initial={{ scale: 0, x: 20, y: 20 }}
          animate={{ scale: 1, x: 0, y: 0 }}
          transition={{
            type: "spring",
            stiffness: 300,
            damping: 20,
            delay: 0.8,
          }}
          className="absolute -bottom-2 -right-2 w-14 h-14 rounded-full bg-white flex items-center justify-center shadow-lg border-4 border-[#f8f9fa]"
        >
          <Package className="w-7 h-7 text-[#163300]" />
        </motion.div>
      </motion.div>

      {/* Title */}
      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8, duration: 0.5 }}
        className="text-3xl font-bold text-[#0e0f0c] mb-3 text-center"
      >
        {language === "ar" ? "تم الدفع بنجاح! 🎉" : "Payment Successful! 🎉"}
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.9, duration: 0.5 }}
        className="text-[#6a6c6a] text-center mb-8 max-w-sm"
      >
        {language === "ar"
          ? "تم إصدار بوليصة الشحن بنجاح. يمكنك الآن تحميلها وطباعتها"
          : "Shipping label issued successfully. You can now download and print it"}
      </motion.p>

      {/* Details Card */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1, duration: 0.5 }}
        className="bg-white rounded-[20px] p-6 w-full max-w-md mb-6 shadow-xl border border-[#e8e9ea] relative z-10"
      >
        {/* Order Number */}
        <div className="flex items-center justify-between mb-4 pb-4 border-b border-[#e8e9ea]">
          <span className="text-[#6a6c6a] text-sm">
            {language === "ar" ? "رقم الطلب" : "Order Number"}
          </span>
          <span className="text-[#0e0f0c] font-semibold">{orderNumber}</span>
        </div>

        {/* Tracking Number */}
        <div className="flex items-center justify-between mb-4 pb-4 border-b border-[#e8e9ea]">
          <span className="text-[#6a6c6a] text-sm">
            {language === "ar" ? "رقم التتبع" : "Tracking Number"}
          </span>
          <span className="text-[#163300] font-semibold font-mono">{trackingNumber}</span>
        </div>

        {/* Payment Amount */}
        <div className="flex items-center justify-between mb-4 pb-4 border-b border-[#e8e9ea]">
          <span className="text-[#6a6c6a] text-sm">
            {language === "ar" ? "المبلغ المدفوع" : "Amount Paid"}
          </span>
          <span className="text-[#0e0f0c] font-semibold">
            {shippingCost.toLocaleString(language === "ar" ? "ar-SA" : "en-US")} {t.sar}
          </span>
        </div>

        {/* Payment Method */}
        <div className="flex items-center justify-between">
          <span className="text-[#6a6c6a] text-sm">
            {language === "ar" ? "طريقة الدفع" : "Payment Method"}
          </span>
          <span className="text-[#0e0f0c] font-medium">
            {paymentMethod === "wallet" 
              ? (language === "ar" ? "المحفظة" : "Wallet")
              : (language === "ar" ? "بطاقة ائتمانية" : "Credit Card")}
          </span>
        </div>
      </motion.div>

      {/* Action Buttons */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.2, duration: 0.5 }}
        className="w-full max-w-md space-y-3 relative z-20"
      >
        {/* Download Button */}
        <button
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            onDownloadLabel();
          }}
          className="w-full bg-[#163300] text-white rounded-full py-4 px-6 font-semibold flex items-center justify-center gap-2 shadow-lg hover:shadow-xl transition-all active:scale-95"
        >
          <Download className="w-5 h-5" />
          <span>{language === "ar" ? "تحميل بوليصة الشحن" : "Download Shipping Label"}</span>
        </button>

        {/* Print Button */}
        <button
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            window.print();
          }}
          className="w-full bg-white text-[#163300] border-2 border-[#163300] rounded-full py-4 px-6 font-semibold flex items-center justify-center gap-2 hover:bg-[#163300] hover:text-white transition-all active:scale-95"
        >
          <Printer className="w-5 h-5" />
          <span>{language === "ar" ? "طباعة" : "Print"}</span>
        </button>

        {/* Continue Button */}
        <button
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            onContinue();
          }}
          className="w-full bg-white text-[#6a6c6a] border-2 border-[#e8e9ea] rounded-full py-4 px-6 font-semibold hover:bg-[#f8f9fa] transition-all active:scale-95 flex items-center justify-center gap-2"
        >
          <span>{language === "ar" ? "متابعة" : "Continue"}</span>
          <ArrowRight className={`w-5 h-5 ${isRTL ? "rotate-180" : ""}`} />
        </button>
      </motion.div>

      {/* Info Box */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.4 }}
        className="mt-6 bg-[#9fe870]/10 rounded-[16px] p-4 w-full max-w-md border border-[#9fe870]/20 relative z-10"
      >
        <p className="text-sm text-[#163300] text-center leading-relaxed">
          {language === "ar"
            ? "✅ تم إرسال رقم التتبع للمشتري. يمكنك الآن شحن المنتج"
            : "✅ Tracking number sent to buyer. You can now ship the product"}
        </p>
      </motion.div>
    </div>
  );
}
