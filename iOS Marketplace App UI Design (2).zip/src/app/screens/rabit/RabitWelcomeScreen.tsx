import { motion } from "motion/react";
import { WiseButton } from "../../components/WiseButton";
import { ShoppingBag, Shield, Zap, TrendingUp, Store, Heart, Sparkles, Globe } from "lucide-react";
import { triggerHaptic } from "../../utils/haptics";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";

interface RabitWelcomeScreenProps {
  onRegister: () => void;
  onLogin: () => void;
  onTerms?: () => void;
  onPrivacy?: () => void;
}

export function RabitWelcomeScreen({ onRegister, onLogin, onTerms, onPrivacy }: RabitWelcomeScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);

  return (
    <div 
      className="min-h-screen bg-gradient-to-br from-[#fafafa] via-white to-[#f0fde8]/30 flex flex-col relative overflow-hidden" 
      style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Premium Gradient Orbs */}
      <motion.div
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.15, 0.25, 0.15],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute -top-40 -right-40 w-96 h-96 bg-gradient-to-br from-[#9fe870] to-[#163300] rounded-full blur-3xl"
      />
      <motion.div
        animate={{
          scale: [1.2, 1, 1.2],
          opacity: [0.1, 0.2, 0.1],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute -bottom-32 -left-32 w-80 h-80 bg-gradient-to-tr from-[#163300] to-[#9fe870] rounded-full blur-3xl"
      />

      <div className="flex-1 flex flex-col px-6 pt-12 pb-8 relative z-10">
        {/* Hero Section with Logo */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: -30 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ 
            delay: 0.1,
            type: "spring",
            stiffness: 200,
            damping: 20,
          }}
          className="text-center mb-12"
        >
          {/* Floating Logo Container */}
          <div className="relative inline-block mb-6">
            {/* Animated Glow */}
            <motion.div
              animate={{
                scale: [1, 1.3, 1],
                opacity: [0.2, 0.4, 0.2],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut",
              }}
              className="absolute inset-0 bg-gradient-to-br from-[#9fe870] to-[#163300] rounded-[32px] blur-3xl"
              style={{ transform: 'scale(1.5)' }}
            />
            
            {/* Logo Badge */}
            <motion.div
              animate={{
                y: [0, -10, 0],
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut",
              }}
              className="relative w-28 h-28 bg-white rounded-[32px] flex items-center justify-center shadow-2xl border border-white/20"
            >
              {/* Logo Image */}
              <img 
                src="https://rabit.sa/logo.svg" 
                alt="Rabit Logo" 
                className="w-20 h-20 object-contain relative z-10"
              />
              
              {/* Corner Sparkle */}
              <motion.div
                animate={{
                  scale: [0, 1, 0],
                  rotate: [0, 180, 360],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  repeatDelay: 3,
                }}
                className="absolute -top-2 -right-2"
              >
                <Sparkles className="w-6 h-6 text-[#9fe870]" fill="#9fe870" />
              </motion.div>
            </motion.div>
          </div>

          {/* Welcome Text */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <h1 className="text-5xl font-black mb-4 leading-tight">
              <span className="bg-gradient-to-l from-[#163300] via-[#1a4000] to-[#0a0b09] bg-clip-text text-transparent">
                {t.welcomeTitle}
              </span>
              <br />
              <span className="bg-gradient-to-r from-[#163300] to-[#9fe870] bg-clip-text text-transparent">
                {t.welcomeSubtitle}
              </span>
            </h1>
            <p className="text-lg text-[#6a6c6a] leading-relaxed max-w-sm mx-auto">
              {t.welcomeDescription}
            </p>
          </motion.div>
        </motion.div>

        {/* Value Propositions - Modern Cards */}
        <div className="space-y-4 mb-10">
          {/* Buy Card */}
          <motion.div
            initial={{ opacity: 0, x: isRTL ? 50 : -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4, type: "spring", stiffness: 100 }}
            whileHover={{ scale: 1.02, y: -2 }}
            className="relative group"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-[#9fe870]/20 to-[#163300]/20 rounded-3xl blur-xl group-hover:blur-2xl transition-all duration-300 opacity-0 group-hover:opacity-100" />
            <div className="relative bg-white/80 backdrop-blur-xl rounded-3xl p-6 border border-white/60 shadow-lg hover:shadow-2xl transition-all duration-300">
              <div className={`flex items-start gap-4 ${isRTL ? 'flex-row' : 'flex-row-reverse'}`}>
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#9fe870] to-[#b5ff8a] flex items-center justify-center shadow-lg flex-shrink-0">
                  <ShoppingBag className="w-8 h-8 text-[#163300]" strokeWidth={2.5} />
                </div>
                <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                  <h3 className={`text-xl font-black text-[#0a0b09] mb-2 flex items-center gap-2 ${isRTL ? 'justify-end' : 'justify-start'}`}>
                    {t.buyWithConfidenceTitle}
                    <Heart className="w-5 h-5 text-[#9fe870]" />
                  </h3>
                  <p className="text-sm text-[#6a6c6a] leading-relaxed">
                    {t.buyWithConfidenceDesc}
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Sell Card */}
          <motion.div
            initial={{ opacity: 0, x: isRTL ? -50 : 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5, type: "spring", stiffness: 100 }}
            whileHover={{ scale: 1.02, y: -2 }}
            className="relative group"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-[#163300]/20 to-[#9fe870]/20 rounded-3xl blur-xl group-hover:blur-2xl transition-all duration-300 opacity-0 group-hover:opacity-100" />
            <div className="relative bg-white/80 backdrop-blur-xl rounded-3xl p-6 border border-white/60 shadow-lg hover:shadow-2xl transition-all duration-300">
              <div className={`flex items-start gap-4 ${isRTL ? 'flex-row' : 'flex-row-reverse'}`}>
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#163300] to-[#0f2409] flex items-center justify-center shadow-lg flex-shrink-0">
                  <Store className="w-8 h-8 text-[#9fe870]" strokeWidth={2.5} />
                </div>
                <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                  <h3 className={`text-xl font-black text-[#0a0b09] mb-2 flex items-center gap-2 ${isRTL ? 'justify-end' : 'justify-start'}`}>
                    {t.startSellingTitle}
                    <TrendingUp className="w-5 h-5 text-[#9fe870]" />
                  </h3>
                  <p className="text-sm text-[#6a6c6a] leading-relaxed">
                    {t.startSellingDesc}
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Trust Card */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, type: "spring", stiffness: 100 }}
            whileHover={{ scale: 1.02, y: -2 }}
            className="relative group"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-[#9fe870]/10 to-[#163300]/10 rounded-3xl blur-xl group-hover:blur-2xl transition-all duration-300 opacity-0 group-hover:opacity-100" />
            <div className="relative bg-gradient-to-br from-white/60 to-[#f0fde8]/40 backdrop-blur-xl rounded-3xl p-5 border border-white/60 shadow-md hover:shadow-xl transition-all duration-300">
              <div className="flex items-center justify-center gap-6 text-center">
                <div className="flex items-center gap-2">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#163300]/10 to-[#9fe870]/10 flex items-center justify-center">
                    <Shield className="w-6 h-6 text-[#163300]" strokeWidth={2.5} />
                  </div>
                  <div className={isRTL ? 'text-right' : 'text-left'}>
                    <p className="text-xs text-[#6a6c6a]">{t.transactionsLabel}</p>
                    <p className="text-sm font-black text-[#163300]">{t.transactionsValue}</p>
                  </div>
                </div>
                
                <div className="w-px h-12 bg-gradient-to-b from-transparent via-[#163300]/20 to-transparent" />
                
                <div className="flex items-center gap-2">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#163300]/10 to-[#9fe870]/10 flex items-center justify-center">
                    <Zap className="w-6 h-6 text-[#9fe870]" strokeWidth={2.5} />
                  </div>
                  <div className={isRTL ? 'text-right' : 'text-left'}>
                    <p className="text-xs text-[#6a6c6a]">{t.deliveryLabel}</p>
                    <p className="text-sm font-black text-[#163300]">{t.deliveryValue}</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7, duration: 0.5 }}
          className="space-y-3 mt-auto"
        >
          <WiseButton 
            onClick={() => { onRegister(); triggerHaptic(); }} 
            variant="primary" 
            fullWidth 
            size="lg"
          >
            <span className="flex items-center justify-center gap-2">
              {t.createAccount}
              <Sparkles className="w-4 h-4" />
            </span>
          </WiseButton>
          
          <WiseButton 
            onClick={() => { onLogin(); triggerHaptic(); }} 
            variant="secondary" 
            fullWidth 
            size="lg"
          >
            {t.login}
          </WiseButton>
          
          <motion.p 
            className="text-center text-xs text-[#6a6c6a] mt-4 leading-relaxed px-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.9 }}
          >
            {t.termsPrefix}{" "}
            <button 
              onClick={() => { onTerms?.(); triggerHaptic('light'); }}
              className="text-[#163300] font-bold hover:underline"
            >
              {t.terms}
            </button>
            {" "}{t.and}{" "}
            <button 
              onClick={() => { onPrivacy?.(); triggerHaptic('light'); }}
              className="text-[#163300] font-bold hover:underline"
            >
              {t.privacy}
            </button>
          </motion.p>
        </motion.div>
      </div>
    </div>
  );
}