import { motion } from "motion/react";
import { WiseButton } from "../../components/WiseButton";
import { ChevronRight, DollarSign, Building, AlertCircle, Banknote } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { useLanguage } from "../../contexts/LanguageContext";

interface RabitWithdrawalScreenProps {
  availableBalance: number;
  onBack: () => void;
  onWithdrawalSuccess: () => void;
}

export function RabitWithdrawalScreen({
  availableBalance,
  onBack,
  onWithdrawalSuccess,
}: RabitWithdrawalScreenProps) {
  const { language, isRTL } = useLanguage();
  const [amount, setAmount] = useState("");
  const [iban, setIban] = useState("");
  const [accountName, setAccountName] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [showSuccess, setShowSuccess] = useState(false);

  const minWithdrawal = 100;
  const fee = 0; // No fee for demo

  const content = {
    ar: {
      enterAmount: "الرجاء إدخال المبلغ",
      minAmount: "الحد الأدنى للسحب",
      amountExceedsBalance: "المبلغ يتجاوز الرصيد المتاح",
      ibanRequired: "رقم IBAN مطلوب",
      invalidIban: "رقم IBAN غير صحيح (يجب أن يكون 24 رقماً)",
      accountNameRequired: "اسم صاحب الحساب مطلوب",
      successMessage: "تم إرسال طلب السحب بنجاح",
      confirmationMessage: "تم تأكيد طلب السحب",
      transferTime: "سيتم تحويل المبلغ خلال 1-3 أيام عمل",
      withdraw: "سحب الرصيد",
      availableForWithdrawal: "الرصيد المتاح للسحب",
      minWithdrawalAmount: "الحد الأدنى للسحب",
      withdrawAmount: "مبلغ السحب (ر.س)",
      ibanNumber: "رقم IBAN",
      accountHolderName: "اسم صاحب الحساب",
      asRegisteredInBank: "كما هو مسجل في البنك",
      requestedAmount: "المبلغ المطلوب",
      withdrawalFees: "رسوم السحب",
      free: "مجاناً",
      netAmount: "المبلغ الصافي",
      amount: "المبلغ",
      all: "الكل",
      importantInfo: "معلومات مهمة:",
      info1: "سيتم تحويل المبلغ خلال 1-3 أيام عمل",
      info2: "تأكد من صحة رقم IBAN",
      info3: "لا يمكن إلغاء طلب السحب بعد التأكيد",
      processing: "جاري المعالجة...",
      confirmWithdrawal: "تأكيد السحب",
    },
    en: {
      enterAmount: "Please enter amount",
      minAmount: "Minimum withdrawal",
      amountExceedsBalance: "Amount exceeds available balance",
      ibanRequired: "IBAN number is required",
      invalidIban: "Invalid IBAN (must be 24 characters)",
      accountNameRequired: "Account holder name is required",
      successMessage: "Withdrawal request sent successfully",
      confirmationMessage: "Withdrawal Request Confirmed",
      transferTime: "Amount will be transferred within 1-3 business days",
      withdraw: "Withdraw",
      availableForWithdrawal: "Available for Withdrawal",
      minWithdrawalAmount: "Minimum withdrawal",
      withdrawAmount: "Withdrawal Amount (SAR)",
      ibanNumber: "IBAN Number",
      accountHolderName: "Account Holder Name",
      asRegisteredInBank: "As registered in bank",
      requestedAmount: "Requested Amount",
      withdrawalFees: "Withdrawal Fees",
      free: "Free",
      netAmount: "Net Amount",
      amount: "Amount",
      all: "All",
      importantInfo: "Important Information:",
      info1: "Amount will be transferred within 1-3 business days",
      info2: "Verify IBAN number is correct",
      info3: "Withdrawal request cannot be cancelled after confirmation",
      processing: "Processing...",
      confirmWithdrawal: "Confirm Withdrawal",
    },
  };
  const c = content[language];

  const validate = () => {
    const newErrors: Record<string, string> = {};
    const withdrawAmount = parseFloat(amount);
    
    if (!amount || withdrawAmount <= 0) newErrors.amount = c.enterAmount;
    else if (withdrawAmount < minWithdrawal) newErrors.amount = `${c.minAmount} ${minWithdrawal} ر.س`;
    else if (withdrawAmount > availableBalance) newErrors.amount = c.amountExceedsBalance;
    
    if (!iban.trim()) newErrors.iban = c.ibanRequired;
    else {
      const cleanIban = iban.replace(/\s/g, "");
      // Saudi IBAN: SA followed by 22 digits = 24 characters total
      if (cleanIban.length !== 24 || !cleanIban.startsWith("SA")) {
        newErrors.iban = c.invalidIban;
      }
    }
    
    if (!accountName.trim()) newErrors.accountName = c.accountNameRequired;
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleWithdraw = () => {
    if (!validate()) return;
    
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setShowSuccess(true);
      toast.success(c.successMessage + " 💰");
      setTimeout(() => {
        onWithdrawalSuccess();
      }, 2000);
    }, 2000);
  };

  const formatIBAN = (value: string) => {
    const cleaned = value.replace(/\s/g, "").toUpperCase();
    const formatted = cleaned.match(/.{1,4}/g)?.join(" ") || cleaned;
    return formatted.substring(0, 29); // Max 24 chars + 5 spaces
  };

  const netAmount = amount ? parseFloat(amount) - fee : 0;

  if (showSuccess) {
    return (
      <div 
        className="min-h-screen bg-white flex flex-col items-center justify-center p-6" 
        style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
        dir={isRTL ? 'rtl' : 'ltr'}
      >
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 200, damping: 15 }}
          className="w-24 h-24 bg-[#163300] rounded-full flex items-center justify-center mb-6"
        >
          <motion.svg
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="w-12 h-12 text-white"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
          >
            <motion.path
              d="M5 13l4 4L19 7"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </motion.svg>
        </motion.div>
        
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-2xl font-bold text-[#163300] mb-2 text-center"
        >
          {c.confirmationMessage} ✓
        </motion.h2>
        
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="text-[#6a6c6a] text-center mb-6"
        >
          {c.transferTime}
        </motion.p>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5 }}
          className="bg-[rgba(22,51,0,0.07843)] rounded-[12px] p-4 w-full max-w-sm"
        >
          <div className="text-center">
            <p className="text-sm text-[#6a6c6a] mb-1">{c.amount}</p>
            <p className="text-3xl font-bold text-[#163300]">
              {parseFloat(amount).toLocaleString('ar-SA')} ر.س
            </p>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div 
      className="min-h-screen bg-white pb-32" 
      style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 flex items-center justify-between z-10"
      >
        <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
          <ChevronRight className="w-6 h-6 text-[#0e0f0c]" />
        </button>
        <h1 className="text-xl font-semibold text-[#0e0f0c]">{c.withdraw}</h1>
        <div className="w-10" />
      </motion.div>

      <div className="p-6 space-y-6">
        {/* Available Balance */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-br from-[#163300] to-[#1a3d00] rounded-[16px] p-6 text-white"
        >
          <div className="flex items-center justify-between mb-2">
            <Banknote className="w-8 h-8" />
            <p className="text-sm opacity-80">{c.availableForWithdrawal}</p>
          </div>
          <p className={`text-3xl font-bold ${isRTL ? 'text-right' : 'text-left'}`}>
            {availableBalance.toLocaleString('ar-SA')} ر.س
          </p>
          <p className={`text-xs opacity-60 mt-2 ${isRTL ? 'text-right' : 'text-left'}`}>
            {c.minWithdrawalAmount}: {minWithdrawal} ر.س
          </p>
        </motion.div>

        {/* Amount */}
        <div>
          <label className={`block text-sm font-semibold text-[#0e0f0c] mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
            {c.withdrawAmount}
          </label>
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="0.00"
            className={`w-full px-4 py-3 rounded-[10px] border border-[rgba(14,15,12,0.12157)] ${isRTL ? 'text-right' : 'text-left'} focus:outline-none focus:border-[#163300] text-2xl font-bold`}
          />
          {errors.amount && (
            <div className="flex items-center gap-2 mt-2 text-[#cb272f] text-sm">
              <AlertCircle className="w-4 h-4" />
              <span>{errors.amount}</span>
            </div>
          )}
          <div className="flex gap-2 mt-2">
            {[500, 1000, 2000].map((quickAmount) => (
              <button
                key={quickAmount}
                onClick={() => setAmount(quickAmount.toString())}
                className="flex-1 py-2 px-3 bg-[rgba(22,51,0,0.07843)] rounded-[8px] text-sm font-medium text-[#163300] hover:bg-[rgba(22,51,0,0.12)] transition-colors"
              >
                {quickAmount}
              </button>
            ))}
            <button
              onClick={() => setAmount(availableBalance.toString())}
              className="flex-1 py-2 px-3 bg-[rgba(22,51,0,0.07843)] rounded-[8px] text-sm font-medium text-[#163300] hover:bg-[rgba(22,51,0,0.12)] transition-colors"
            >
              {c.all}
            </button>
          </div>
        </div>

        {/* IBAN */}
        <div>
          <label className={`block text-sm font-semibold text-[#0e0f0c] mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
            {c.ibanNumber}
          </label>
          <input
            type="text"
            value={iban}
            onChange={(e) => setIban(formatIBAN(e.target.value))}
            placeholder="SA00 0000 0000 0000 0000 0000"
            dir="ltr"
            className="w-full px-4 py-3 rounded-[10px] border border-[rgba(14,15,12,0.12157)] text-center focus:outline-none focus:border-[#163300] font-mono"
          />
          {errors.iban && (
            <div className="flex items-center gap-2 mt-2 text-[#cb272f] text-sm">
              <AlertCircle className="w-4 h-4" />
              <span>{errors.iban}</span>
            </div>
          )}
        </div>

        {/* Account Name */}
        <div>
          <label className={`block text-sm font-semibold text-[#0e0f0c] mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
            {c.accountHolderName}
          </label>
          <input
            type="text"
            value={accountName}
            onChange={(e) => setAccountName(e.target.value)}
            placeholder={c.asRegisteredInBank}
            className={`w-full px-4 py-3 rounded-[10px] border border-[rgba(14,15,12,0.12157)] ${isRTL ? 'text-right' : 'text-left'} focus:outline-none focus:border-[#163300]`}
          />
          {errors.accountName && (
            <div className="flex items-center gap-2 mt-2 text-[#cb272f] text-sm">
              <AlertCircle className="w-4 h-4" />
              <span>{errors.accountName}</span>
            </div>
          )}
        </div>

        {/* Summary */}
        {amount && parseFloat(amount) > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            className="bg-[rgba(22,51,0,0.07843)] rounded-[12px] p-4 space-y-3"
          >
            <div className="flex items-center justify-between">
              <span className="text-sm text-[#6a6c6a]">{c.requestedAmount}</span>
              <span className="text-sm font-semibold text-[#0e0f0c]">
                {parseFloat(amount).toLocaleString('ar-SA')} ر.س
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-[#6a6c6a]">{c.withdrawalFees}</span>
              <span className="text-sm font-semibold text-[#008026]">
                {fee === 0 ? c.free : `${fee} ر.س`}
              </span>
            </div>
            <div className="border-t border-[rgba(14,15,12,0.12157)] pt-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-[#0e0f0c]">{c.netAmount}</span>
                <span className="text-lg font-bold text-[#163300]">
                  {netAmount.toLocaleString('ar-SA')} ر.س
                </span>
              </div>
            </div>
          </motion.div>
        )}

        {/* Info */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="bg-[rgba(159,232,112,0.1)] rounded-[12px] p-4"
        >
          <p className={`text-sm font-semibold text-[#163300] mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>ℹ️ {c.importantInfo}</p>
          <ul className={`text-xs text-[#6a6c6a] space-y-1 list-disc list-inside ${isRTL ? 'text-right' : 'text-left'}`}>
            <li>{c.info1}</li>
            <li>{c.info2}</li>
            <li>{c.info3}</li>
          </ul>
        </motion.div>
      </div>

      {/* Fixed Bottom Button */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-[rgba(14,15,12,0.12157)] px-6 py-4 max-w-[430px] mx-auto">
        <WiseButton
          onClick={handleWithdraw}
          variant="primary"
          fullWidth
          loading={isLoading}
          disabled={isLoading || !amount}
        >
          {isLoading ? c.processing : c.confirmWithdrawal}
        </WiseButton>
      </div>
    </div>
  );
}