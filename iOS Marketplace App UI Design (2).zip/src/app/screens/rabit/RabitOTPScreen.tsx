import { motion } from "motion/react";
import { ModernButton } from "../../components/design-system";
import { ChevronRight, Shield, CheckCircle2 } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";
import { triggerHaptic } from "../../utils/haptics";
import { toast } from "sonner";
import { verifyOTP, sendOTP, getMockOTP } from "../../utils/auth";

interface RabitOTPScreenProps {
  onBack: () => void;
  onVerify: () => void;
  email: string;
}

export function RabitOTPScreen({ onBack, onVerify, email }: RabitOTPScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [loading, setLoading] = useState(false);
  const [resendCooldown, setResendCooldown] = useState(0);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Auto-focus first input on mount
  useEffect(() => {
    inputRefs.current[0]?.focus();
  }, []);

  // Countdown timer for resend
  useEffect(() => {
    if (resendCooldown > 0) {
      const timer = setTimeout(() => setResendCooldown(resendCooldown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [resendCooldown]);

  const handleChange = (index: number, value: string) => {
    // Only allow numbers
    if (value && !/^\d$/.test(value)) return;

    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    // Auto-focus next input
    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }

    // Auto-verify when all 6 digits entered
    if (newOtp.every((digit) => digit !== "") && index === 5) {
      handleVerify(newOtp.join(''));
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handleVerify = async (codeToVerify?: string) => {
    if (otp.every((digit) => digit !== "")) {
      triggerHaptic('medium');
      setLoading(true);
      
      try {
        const result = await verifyOTP(email, otp.join(''));
        
        if (result.success) {
          triggerHaptic('success');
          toast.success(language === 'ar' ? 'تم التحقق بنجاح ✓' : 'Verified successfully ✓');
          onVerify();
        } else {
          setLoading(false);
          triggerHaptic('error');
          
          // Show user-friendly error message
          const errorMsg = result.error || 'Invalid verification code';
          console.warn('⚠️ OTP verification failed:', errorMsg);
          
          toast.error(
            language === 'ar' 
              ? result.errorAr || 'رمز التحقق غير صحيح' 
              : errorMsg,
            { duration: 4000 }
          );
          
          // Clear OTP on error and stay on this screen
          setOtp(["", "", "", "", "", ""]);
          inputRefs.current[0]?.focus();
          
          // ❌ DO NOT logout, DO NOT navigate away
          // User can retry OTP entry
        }
      } catch (error) {
        setLoading(false);
        triggerHaptic('error');
        console.error('❌ Exception during OTP verification:', error);
        toast.error(language === 'ar' ? 'حدث خطأ في التحقق' : 'Verification error occurred');
        
        // Clear OTP and let user retry
        setOtp(["", "", "", "", "", ""]);
        inputRefs.current[0]?.focus();
      }
    }
  };

  const handleResend = async () => {
    if (resendCooldown > 0) return;

    triggerHaptic('light');
    setResendCooldown(60);

    try {
      const result = await sendOTP(email);
      if (result.success) {
        toast.success(language === 'ar' ? 'تم إعادة إرسال الرمز' : 'Code resent successfully');
      }
    } catch (error) {
      toast.error(language === 'ar' ? 'فشل إعادة الإرسال' : 'Failed to resend');
    }
  };

  return (
    <div 
      className="min-h-screen bg-white flex flex-col p-6" 
      style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      <motion.button
        initial={{ opacity: 0, x: isRTL ? 20 : -20 }}
        animate={{ opacity: 1, x: 0 }}
        onClick={onBack}
        className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center mb-8 text-[#0e0f0c]"
        whileTap={{ scale: 0.95 }}
      >
        <ChevronRight className={`w-6 h-6 ${isRTL ? '' : 'rotate-180'}`} />
      </motion.button>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="mb-8"
      >
        <h1 className={`text-3xl font-bold mb-3 text-[#0e0f0c] ${isRTL ? 'text-right' : 'text-left'}`}>{t.otpTitle}</h1>
        <p className={`text-[#6a6c6a] ${isRTL ? 'text-right' : 'text-left'}`}>
          {t.otpSentTo} {email}
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="flex-1"
      >
        <div className="flex gap-2 justify-center mb-8" dir="ltr">
          {otp.map((digit, index) => (
            <motion.input
              key={index}
              ref={(el) => (inputRefs.current[index] = el)}
              type="text"
              inputMode="numeric"
              value={digit}
              onChange={(e) => handleChange(index, e.target.value)}
              onKeyDown={(e) => handleKeyDown(index, e)}
              className="w-12 h-14 bg-[rgba(22,51,0,0.07843)] rounded-[10px] text-center text-xl font-semibold outline-none focus:ring-2 focus:ring-[#163300] transition-all text-[#0e0f0c] border border-transparent focus:bg-white"
              maxLength={1}
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: index * 0.05 }}
            />
          ))}
        </div>

        <div className="text-center">
          <button 
            onClick={handleResend}
            className="text-sm text-[#6a6c6a] hover:text-[#163300] transition-colors"
            disabled={resendCooldown > 0}
          >
            {t.didntReceive}{" "}
            <span className="text-[#163300] font-medium hover:underline">{t.resendCode}</span>
            {resendCooldown > 0 && ` (${resendCooldown}s)`}
          </button>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <ModernButton
          onClick={handleVerify}
          variant="primary"
          fullWidth
          size="lg"
          loading={loading}
          disabled={otp.some((digit) => digit === "")}
        >
          {t.verify}
        </ModernButton>
      </motion.div>
    </div>
  );
}