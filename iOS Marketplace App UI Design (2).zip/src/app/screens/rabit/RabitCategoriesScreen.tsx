import { motion } from "motion/react";
import { ChevronRight } from "lucide-react";
import { useState, useEffect } from "react";
import { type RabitProduct } from "../../data/rabitProducts";
import { ModernCard } from "../../components/design-system";
import { PullToRefresh } from "../../components/PullToRefresh";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";
import { getCategories, getCategoryProducts, type Category } from "../../services/categories.service";

interface RabitCategoriesScreenProps {
  onBack: () => void;
  onProductClick: (product: RabitProduct) => void;
}

export function RabitCategoriesScreen({ onBack, onProductClick }: RabitCategoriesScreenProps) {
  const { language, isRTL } = useLanguage();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [isLoadingProducts, setIsLoadingProducts] = useState(false);
  const [categories, setCategories] = useState<Category[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const content = {
    ar: { categories: "الفئات" },
    en: { categories: "Categories" },
  };
  const c = content[language];

  // Fetch categories on mount
  useEffect(() => {
    fetchCategories();
  }, []);

  // Fetch products when category changes
  useEffect(() => {
    if (selectedCategory) {
      fetchCategoryProducts(selectedCategory);
    } else {
      setFilteredProducts([]);
    }
  }, [selectedCategory]);

  const fetchCategories = async () => {
    setLoading(true);
    const result = await getCategories();
    if (result.success && result.categories) {
      console.log('✅ Loaded categories:', result.categories.length);
      setCategories(result.categories);
    } else {
      console.error('❌ Failed to load categories:', result.error);
    }
    setLoading(false);
  };

  const fetchCategoryProducts = async (categoryName: string) => {
    setIsLoadingProducts(true);
    const result = await getCategoryProducts(categoryName);
    if (result.success && result.products) {
      console.log('✅ Loaded products for category:', result.products.length);
      setFilteredProducts(result.products);
    } else {
      console.error('❌ Failed to load products:', result.error);
      setFilteredProducts([]);
    }
    setIsLoadingProducts(false);
  };

  const handleRefresh = async () => {
    console.log("Refreshing categories data...");
    await fetchCategories();
    if (selectedCategory) {
      await fetchCategoryProducts(selectedCategory);
    }
  };

  const handleCategoryClick = async (categoryName: string) => {
    if (selectedCategory === categoryName) {
      setSelectedCategory(null);
    } else {
      setSelectedCategory(categoryName);
    }
  };

  return (
    <PullToRefresh onRefresh={handleRefresh}>
      <div 
        className="min-h-screen bg-[#fafafa]" 
        style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
        dir={isRTL ? 'rtl' : 'ltr'}
      >
        {/* Modern Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="sticky top-0 bg-white/95 backdrop-blur-lg border-b border-[rgba(0,0,0,0.06)] px-6 py-4 flex items-center gap-4 z-10"
          style={{ boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04)' }}
        >
          <button 
            onClick={onBack} 
            className="w-11 h-11 rounded-2xl bg-[#f0fde8] border border-[rgba(22,51,0,0.1)] flex items-center justify-center text-[#163300] transition-all duration-200 hover:bg-[#e2fad5] active:scale-95"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-semibold text-[#0a0b09] text-right flex-1">{c.categories}</h1>
        </motion.div>
        
        {/* Categories Grid - Modern Cards */}
        <div className="p-6 grid grid-cols-2 gap-4">
          {categories.map((cat, i) => (
            <motion.button
              key={cat.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.05 }}
              whileTap={{ scale: 0.97 }}
              className="bg-white rounded-2xl p-6 text-center border border-[rgba(0,0,0,0.08)] transition-all duration-200 hover:border-[rgba(22,51,0,0.2)]"
              style={{ boxShadow: 'var(--shadow-card)' }}
              onMouseEnter={(e) => e.currentTarget.style.boxShadow = 'var(--shadow-card-hover)'}
              onMouseLeave={(e) => e.currentTarget.style.boxShadow = 'var(--shadow-card)'}
              onClick={() => handleCategoryClick(language === 'ar' ? cat.name_ar : cat.name)}
            >
              <div className="w-16 h-16 mx-auto mb-3 rounded-2xl bg-gradient-to-br from-[#f0fde8] to-[#e2fad5] flex items-center justify-center text-4xl">
                {cat.icon}
              </div>
              <p className="font-semibold text-[#0a0b09] mb-1">{language === 'ar' ? cat.name_ar : cat.name}</p>
              <p className="text-xs text-[#6a6c6a]">{cat.product_count} {language === 'ar' ? 'منتج' : 'products'}</p>
            </motion.button>
          ))}
        </div>

        {/* Products Grid - Modern Cards */}
        {selectedCategory && (
          <div className="px-6 pb-6">
            <div className="flex items-center justify-between mb-4">
              <button
                onClick={() => setSelectedCategory(null)}
                className="text-sm text-[#163300] hover:underline"
              >
                إلغاء
              </button>
              <h2 className="font-semibold text-[#0a0b09]">{selectedCategory}</h2>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {filteredProducts.map((product, i) => (
                <motion.button
                  key={product.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => onProductClick(product)}
                  className="bg-white rounded-2xl overflow-hidden border border-[rgba(0,0,0,0.08)] hover:border-[rgba(22,51,0,0.2)] transition-all duration-200 group"
                  style={{ boxShadow: 'var(--shadow-card)' }}
                  onMouseEnter={(e) => e.currentTarget.style.boxShadow = 'var(--shadow-card-hover)'}
                  onMouseLeave={(e) => e.currentTarget.style.boxShadow = 'var(--shadow-card)'}
                >
                  <div className="aspect-square bg-[#fafafa] relative overflow-hidden">
                    <img
                      src={product.image}
                      alt={product.titleAr}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                    {product.verified && (
                      <div className="absolute top-2 left-2 w-7 h-7 bg-[#163300] rounded-xl flex items-center justify-center shadow-md">
                        <span className="text-white text-xs font-bold">✓</span>
                      </div>
                    )}
                  </div>
                  <div className="p-3.5 text-right">
                    <p className="text-sm font-semibold text-[#0a0b09] mb-1 truncate">
                      {product.titleAr}
                    </p>
                    <p className="text-xs text-[#6a6c6a] mb-2.5">{product.sellerAr}</p>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs text-[#6a6c6a] flex items-center gap-1">
                        <span className="text-[#f59e0b]">★</span>
                        {product.rating}
                      </span>
                      <span className="font-bold text-[#163300] text-base">{product.price} ر.س</span>
                    </div>
                    
                    {/* Payment Options */}
                    <div className="flex items-center gap-1.5 pt-2 border-t border-[rgba(0,0,0,0.06)]">
                      <span className="text-[9px] text-[#6a6c6a]">أو قسمها</span>
                      <div className="flex items-center gap-1">
                        {/* Tabby Logo */}
                        <div className="h-3.5 px-1.5 bg-[#3AFFA3] rounded flex items-center justify-center">
                          <span className="text-[8px] font-bold text-black" style={{ fontFamily: 'system-ui, sans-serif' }}>tabby</span>
                        </div>
                        {/* Tamara Logo */}
                        <div className="h-3.5 px-1.5 bg-black rounded flex items-center justify-center">
                          <span className="text-[8px] font-bold text-white" style={{ fontFamily: 'system-ui, sans-serif' }}>tamara</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.button>
              ))}
            </div>
          </div>
        )}
      </div>
    </PullToRefresh>
  );
}