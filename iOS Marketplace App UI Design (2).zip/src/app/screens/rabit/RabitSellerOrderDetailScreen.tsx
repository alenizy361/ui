import { motion } from "motion/react";
import { ChevronRight, ChevronLeft, Package, MapPin, Phone, MessageCircle, CheckCircle, Truck, Clock, User, DollarSign } from "lucide-react";
import { useState } from "react";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";
import { toast } from "sonner";
import { triggerHaptic } from "../../utils/haptics";

interface SellerOrderDetailProps {
  orderId: string;
  orderNumber: string;
  productTitle: string;
  productTitleAr: string;
  productImage: string;
  price: number;
  platformFee: number;
  buyerName: string;
  buyerNameAr: string;
  buyerPhone: string;
  status: "pending" | "shipped" | "delivered" | "cancelled";
  orderDate: string;
  shippingAddress: {
    name: string;
    phone: string;
    city: string;
    district: string;
    street: string;
    building: string;
  };
  onBack: () => void;
  onMarkAsShipped: () => void;
  onChatBuyer: () => void;
  onIssueShippingLabel?: () => void;
  onViewShippingLabel?: () => void;
  hasShippingLabel?: boolean; // Track if label already issued
}

export function RabitSellerOrderDetailScreen({
  orderId,
  orderNumber,
  productTitle,
  productTitleAr,
  productImage,
  price,
  platformFee,
  buyerName,
  buyerNameAr,
  buyerPhone,
  status,
  orderDate,
  shippingAddress,
  onBack,
  onMarkAsShipped,
  onChatBuyer,
  onIssueShippingLabel,
  onViewShippingLabel,
  hasShippingLabel,
}: SellerOrderDetailProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);
  const [localStatus, setLocalStatus] = useState(status);

  const getStatusColor = (currentStatus: string) => {
    switch (currentStatus) {
      case "pending":
        return "bg-[#df8700] text-white";
      case "shipped":
        return "bg-[#0066ff] text-white";
      case "delivered":
        return "bg-[#008026] text-white";
      case "cancelled":
        return "bg-[#cb272f] text-white";
      default:
        return "bg-[rgba(22,51,0,0.07843)] text-[#0e0f0c]";
    }
  };

  const getStatusText = (currentStatus: string) => {
    switch (currentStatus) {
      case "pending":
        return t.pending;
      case "shipped":
        return t.shipped;
      case "delivered":
        return t.delivered;
      case "cancelled":
        return t.cancelled;
      default:
        return currentStatus;
    }
  };

  const getStatusIcon = (currentStatus: string) => {
    switch (currentStatus) {
      case "pending":
        return <Clock className="w-5 h-5" />;
      case "shipped":
        return <Truck className="w-5 h-5" />;
      case "delivered":
        return <CheckCircle className="w-5 h-5" />;
      default:
        return <Package className="w-5 h-5" />;
    }
  };

  const handleMarkAsShipped = () => {
    setLocalStatus("shipped");
    toast.success(
      language === 'ar' ? 'تم تحديث حالة الطلب إلى "تم الشحن"' : 'Order status updated to "Shipped"'
    );
    triggerHaptic('success');
    onMarkAsShipped();
  };

  const sellerEarnings = price - platformFee;

  return (
    <div 
      className="min-h-screen bg-[#fafafa]"
      style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }} 
        animate={{ opacity: 1, y: 0 }} 
        className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 flex items-center gap-4 z-10"
      >
        <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
          {isRTL ? <ChevronRight className="w-6 h-6 text-[#0e0f0c]" /> : <ChevronLeft className="w-6 h-6 text-[#0e0f0c]" />}
        </button>
        <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
          <h1 className="text-xl font-semibold text-[#0e0f0c]">{language === 'ar' ? 'تفاصيل الطلب' : 'Order Details'}</h1>
          <p className="text-sm text-[#6a6c6a]">{orderNumber}</p>
        </div>
      </motion.div>

      <div className="px-6 py-6 space-y-4">
        {/* Status Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl border border-[rgba(14,15,12,0.12157)] p-5"
        >
          <div className={`flex items-center justify-between mb-4 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
            <span className={`px-4 py-2 rounded-full text-sm font-medium flex items-center gap-2 ${getStatusColor(localStatus)}`}>
              {getStatusIcon(localStatus)}
              {getStatusText(localStatus)}
            </span>
            <span className="text-sm text-[#6a6c6a]">{orderDate}</span>
          </div>

          {/* Timeline */}
          <div className={`space-y-3 ${isRTL ? 'pr-2' : 'pl-2'}`}>
            <div className={`flex items-start gap-3 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${localStatus !== 'pending' ? 'bg-[#008026]' : 'bg-[rgba(22,51,0,0.07843)]'}`}>
                <CheckCircle className={`w-4 h-4 ${localStatus !== 'pending' ? 'text-white' : 'text-[#6a6c6a]'}`} />
              </div>
              <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                <p className="text-sm font-medium text-[#0e0f0c]">{language === 'ar' ? 'تم استلام الطلب' : 'Order Received'}</p>
                <p className="text-xs text-[#6a6c6a]">{orderDate}</p>
              </div>
            </div>

            <div className={`flex items-start gap-3 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${localStatus === 'shipped' || localStatus === 'delivered' ? 'bg-[#008026]' : 'bg-[rgba(22,51,0,0.07843)]'}`}>
                <Truck className={`w-4 h-4 ${localStatus === 'shipped' || localStatus === 'delivered' ? 'text-white' : 'text-[#6a6c6a]'}`} />
              </div>
              <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                <p className="text-sm font-medium text-[#0e0f0c]">{language === 'ar' ? 'تم الشحن' : 'Shipped'}</p>
                <p className="text-xs text-[#6a6c6a]">
                  {localStatus === 'shipped' || localStatus === 'delivered' 
                    ? language === 'ar' ? 'قيد التوصيل' : 'In transit' 
                    : language === 'ar' ? 'في انتظار الشحن' : 'Awaiting shipment'}
                </p>
              </div>
            </div>

            <div className={`flex items-start gap-3 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${localStatus === 'delivered' ? 'bg-[#008026]' : 'bg-[rgba(22,51,0,0.07843)]'}`}>
                <Package className={`w-4 h-4 ${localStatus === 'delivered' ? 'text-white' : 'text-[#6a6c6a]'}`} />
              </div>
              <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                <p className="text-sm font-medium text-[#0e0f0c]">{language === 'ar' ? 'تم التسليم' : 'Delivered'}</p>
                <p className="text-xs text-[#6a6c6a]">
                  {localStatus === 'delivered' 
                    ? language === 'ar' ? 'تم التسليم بنجاح' : 'Successfully delivered'
                    : language === 'ar' ? 'لم يتم التسليم بعد' : 'Not delivered yet'}
                </p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Product Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-2xl border border-[rgba(14,15,12,0.12157)] p-5"
        >
          <h3 className={`text-sm font-semibold text-[#6a6c6a] mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
            {language === 'ar' ? 'تفاصيل المنتج' : 'Product Details'}
          </h3>
          <div className={`flex gap-4 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
            <div className="w-20 h-20 bg-[rgba(22,51,0,0.07843)] rounded-xl flex-shrink-0 overflow-hidden">
              <img
                src={productImage}
                alt={language === 'ar' ? productTitleAr : productTitle}
                className="w-full h-full object-cover"
              />
            </div>
            <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
              <p className="font-semibold text-[#0e0f0c] mb-2">
                {language === 'ar' ? productTitleAr : productTitle}
              </p>
              <p className="text-lg font-bold text-[#163300]">{price.toLocaleString()} {t.sar}</p>
            </div>
          </div>
        </motion.div>

        {/* Earnings Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="bg-gradient-to-br from-[#163300] to-[#1a3d00] rounded-2xl p-5 text-white"
        >
          <div className={`flex items-center gap-2 mb-4 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
            <DollarSign className="w-5 h-5 text-[#9fe870]" />
            <h3 className="text-sm font-semibold opacity-90">{language === 'ar' ? 'أرباحك' : 'Your Earnings'}</h3>
          </div>

          <div className="space-y-2">
            <div className={`flex justify-between items-center ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
              <span className="text-sm opacity-80">{language === 'ar' ? 'سعر المنتج' : 'Product Price'}</span>
              <span className="text-sm font-medium">{price.toLocaleString()} {t.sar}</span>
            </div>
            <div className={`flex justify-between items-center ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
              <span className="text-sm opacity-80">{language === 'ar' ? 'رسوم المنصة (5%)' : 'Platform Fee (5%)'}</span>
              <span className="text-sm font-medium text-[#ef4444]">-{platformFee.toLocaleString()} {t.sar}</span>
            </div>
            <div className={`h-px bg-white/20 my-3`}></div>
            <div className={`flex justify-between items-center ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
              <span className="font-semibold">{language === 'ar' ? 'صافي الأرباح' : 'Net Earnings'}</span>
              <span className="text-xl font-bold text-[#9fe870]">{sellerEarnings.toLocaleString()} {t.sar}</span>
            </div>
          </div>
        </motion.div>

        {/* Buyer Information */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-2xl border border-[rgba(14,15,12,0.12157)] p-5"
        >
          <h3 className={`text-sm font-semibold text-[#6a6c6a] mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
            {language === 'ar' ? 'معلومات المشتري' : 'Buyer Information'}
          </h3>
          
          <div className="space-y-3">
            <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
              <div className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
                <User className="w-5 h-5 text-[#163300]" />
              </div>
              <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                <p className="text-xs text-[#6a6c6a]">{language === 'ar' ? 'اسم المشتري' : 'Buyer Name'}</p>
                <p className="text-sm font-medium text-[#0e0f0c]">
                  {language === 'ar' ? buyerNameAr : buyerName}
                </p>
              </div>
            </div>

            <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
              <div className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
                <Phone className="w-5 h-5 text-[#163300]" />
              </div>
              <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                <p className="text-xs text-[#6a6c6a]">{language === 'ar' ? 'رقم الهاتف' : 'Phone Number'}</p>
                <p className="text-sm font-medium text-[#0e0f0c]" dir="ltr">
                  {buyerPhone}
                </p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Shipping Address */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="bg-white rounded-2xl border border-[rgba(14,15,12,0.12157)] p-5"
        >
          <div className={`flex items-center gap-3 mb-4 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
            <MapPin className="w-5 h-5 text-[#163300]" />
            <h3 className="text-sm font-semibold text-[#6a6c6a]">
              {language === 'ar' ? 'عنوان الشحن' : 'Shipping Address'}
            </h3>
          </div>

          <div className={`space-y-2 ${isRTL ? 'text-right' : 'text-left'}`}>
            <p className="text-sm font-medium text-[#0e0f0c]">{shippingAddress.name}</p>
            <p className="text-sm text-[#6a6c6a]" dir="ltr">{shippingAddress.phone}</p>
            <p className="text-sm text-[#6a6c6a]">
              {shippingAddress.city}, {shippingAddress.district}
            </p>
            <p className="text-sm text-[#6a6c6a]">{shippingAddress.street}</p>
            <p className="text-sm text-[#6a6c6a]">{shippingAddress.building}</p>
          </div>
        </motion.div>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="space-y-3 pb-6"
        >
          {localStatus === "pending" && onIssueShippingLabel && !hasShippingLabel && (
            <button
              onClick={onIssueShippingLabel}
              className={`w-full h-12 bg-[#9fe870] rounded-2xl font-semibold text-[#163300] flex items-center justify-center gap-2 transition-all duration-200 hover:bg-[#8ed65f] active:scale-98 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}
            >
              <Package className="w-5 h-5" />
              <span>{language === 'ar' ? 'إصدار بوليصة شحن' : 'Issue Shipping Label'}</span>
            </button>
          )}

          {localStatus === "pending" && hasShippingLabel && onViewShippingLabel && (
            <button
              onClick={onViewShippingLabel}
              className={`w-full h-12 bg-[#9fe870] rounded-2xl font-semibold text-[#163300] flex items-center justify-center gap-2 transition-all duration-200 hover:bg-[#8ed65f] active:scale-98 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}
            >
              <Package className="w-5 h-5" />
              <span>{language === 'ar' ? 'عرض بوليصة الشحن' : 'View Shipping Label'}</span>
            </button>
          )}

          {localStatus === "pending" && (
            <button
              onClick={handleMarkAsShipped}
              className={`w-full h-12 bg-[#163300] rounded-2xl font-semibold text-white flex items-center justify-center gap-2 transition-all duration-200 hover:bg-[#0f2409] active:scale-98 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}
            >
              <Truck className="w-5 h-5" />
              <span>{language === 'ar' ? 'تأكيد الشحن' : 'Mark as Shipped'}</span>
            </button>
          )}

          <button
            onClick={onChatBuyer}
            className={`w-full h-12 bg-[#fafafa] border border-[rgba(14,15,12,0.12157)] rounded-2xl font-medium text-[#163300] flex items-center justify-center gap-2 transition-all duration-200 hover:bg-[#f0fde8] active:scale-98 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}
          >
            <MessageCircle className="w-5 h-5" />
            <span>{language === 'ar' ? 'مراسلة المشتري' : 'Chat with Buyer'}</span>
          </button>
        </motion.div>
      </div>
    </div>
  );
}