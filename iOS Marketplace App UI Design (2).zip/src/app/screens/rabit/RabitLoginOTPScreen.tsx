import { motion } from "motion/react";
import { ModernButton } from "../../components/design-system";
import { ChevronRight, Mail, Shield } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import { toast } from "sonner";
import { triggerHaptic } from "../../utils/haptics";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";
import { verifyOTP, sendOTP, loginWithOTP } from "../../utils/auth";

interface RabitLoginOTPScreenProps {
  email: string;
  onBack: () => void;
  onVerified: (user: any) => void;
}

export function RabitLoginOTPScreen({ email, onBack, onVerified }: RabitLoginOTPScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [loading, setLoading] = useState(false);
  const [resendCooldown, setResendCooldown] = useState(0);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Auto-focus first input on mount
  useEffect(() => {
    inputRefs.current[0]?.focus();
  }, []);

  // Countdown timer for resend
  useEffect(() => {
    if (resendCooldown > 0) {
      const timer = setTimeout(() => setResendCooldown(resendCooldown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [resendCooldown]);

  const handleChange = (index: number, value: string) => {
    // Only allow numbers
    if (value && !/^\d$/.test(value)) return;

    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    // Auto-focus next input
    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }

    // Auto-verify when all 6 digits entered
    if (newOtp.every((digit) => digit !== "") && index === 5) {
      handleVerify(newOtp.join(''));
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData("text").slice(0, 6);
    if (/^\d+$/.test(pastedData)) {
      const newOtp = pastedData.split("").concat(Array(6).fill("")).slice(0, 6);
      setOtp(newOtp);
      // Focus last filled input or last input
      const lastIndex = Math.min(pastedData.length - 1, 5);
      inputRefs.current[lastIndex]?.focus();
      
      // Auto-verify if 6 digits pasted
      if (pastedData.length === 6) {
        handleVerify(pastedData);
      }
    }
  };

  const handleVerify = async (codeToVerify?: string) => {
    const code = codeToVerify || otp.join('');
    
    if (code.length !== 6) {
      toast.error(language === 'ar' ? 'الرجاء إدخال الرمز كاملاً' : 'Please enter the complete code');
      triggerHaptic('error');
      return;
    }

    triggerHaptic('medium');
    setLoading(true);

    try {
      console.log('🔐 Step 1: Verifying OTP for:', email);
      
      // Verify OTP
      const verifyResult = await verifyOTP(email, codeToVerify || otp.join(''));
      
      console.log('🔐 Step 1 Result:', verifyResult);
      
      if (!verifyResult.success) {
        setLoading(false);
        triggerHaptic('error');
        
        // Show user-friendly error message
        const errorMsg = verifyResult.error || 'Invalid code';
        console.warn('⚠️ OTP verification failed:', errorMsg);
        
        toast.error(
          language === 'ar' 
            ? verifyResult.errorAr || 'رمز التحقق غير صحيح' 
            : errorMsg,
          { duration: 4000 }
        );
        
        // Clear OTP on error and stay on this screen
        setOtp(["", "", "", "", "", ""]);
        inputRefs.current[0]?.focus();
        
        // ❌ DO NOT logout, DO NOT navigate away
        // User can retry OTP entry
        return;
      }

      console.log('🔐 Step 2: OTP verified, completing login for:', email);

      // OTP verified, now complete login
      const loginResult = await loginWithOTP(email);
      
      console.log('🔐 Step 2 Result:', {
        success: loginResult.success,
        hasUser: !!loginResult.user,
        userId: loginResult.user?.id,
        error: loginResult.error
      });
      
      if (loginResult.success && loginResult.user) {
        triggerHaptic('success');
        toast.success(language === 'ar' ? '✅ تم تسجيل الدخول بنجاح' : '✅ Login successful');
        console.log('🔐 Step 3: Calling onVerified with user:', loginResult.user.id);
        onVerified(loginResult.user);
      } else {
        setLoading(false);
        triggerHaptic('error');
        const errorMsg = loginResult.error || 'Login failed';
        console.error('❌ Login failed:', errorMsg);
        
        // Check if it's a "user not found" error
        if (errorMsg.includes('not found') || errorMsg.includes('غير موجود')) {
          toast.error(
            language === 'ar' 
              ? '❌ لا يوجد حساب بهذا البريد. يرجى إنشاء حساب جديد أولاً' 
              : '❌ No account found. Please create an account first',
            { duration: 5000 }
          );
        } else if (errorMsg.includes('not verified') || errorMsg.includes('غير موثق')) {
          toast.error(
            language === 'ar' 
              ? '❌ الحساب غير موثق. يرجى إكمال عملية التسجيل أولاً' 
              : '❌ Account not verified. Please complete registration first',
            { duration: 5000 }
          );
        } else {
          toast.error(language === 'ar' ? loginResult.errorAr || 'فشل تسجيل الدخول' : errorMsg);
        }
      }
    } catch (error) {
      setLoading(false);
      triggerHaptic('error');
      console.error('❌ Exception during login:', error);
      toast.error(language === 'ar' ? 'حدث خطأ' : 'An error occurred');
    }
  };

  const handleResend = async () => {
    if (resendCooldown > 0) return;

    triggerHaptic('light');
    setResendCooldown(60);

    try {
      const result = await sendOTP(email);
      if (result.success) {
        toast.success(language === 'ar' ? 'تم إعادة إرسال الرمز' : 'Code resent successfully');
      }
    } catch (error) {
      toast.error(language === 'ar' ? 'فشل إعادة الإرسال' : 'Failed to resend');
    }
  };

  return (
    <div 
      className="min-h-screen bg-gradient-to-br from-[#fafafa] via-white to-[#f0fde8]/20 flex flex-col relative overflow-hidden" 
      style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Animated Background Orbs */}
      <motion.div
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.1, 0.2, 0.1],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute -top-40 -right-40 w-96 h-96 bg-gradient-to-br from-[#9fe870] to-[#163300] rounded-full blur-3xl"
      />

      <div className="flex-1 flex flex-col p-6 relative z-10">
        {/* Back Button */}
        <motion.button
          initial={{ opacity: 0, x: isRTL ? 20 : -20 }}
          animate={{ opacity: 1, x: 0 }}
          onClick={onBack}
          whileTap={{ scale: 0.95 }}
          className="w-11 h-11 rounded-2xl bg-white/80 backdrop-blur-sm border border-white/60 flex items-center justify-center mb-8 text-[#163300] shadow-lg hover:shadow-xl transition-all duration-200 active:scale-95"
        >
          <ChevronRight className={`w-6 h-6 ${isRTL ? '' : 'rotate-180'}`} strokeWidth={2.5} />
        </motion.button>

        {/* Header Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-10 text-center"
        >
          {/* Shield Icon */}
          <motion.div
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
            className="inline-flex mb-6 relative"
          >
            <motion.div
              animate={{
                scale: [1, 1.2, 1],
                opacity: [0.3, 0.5, 0.3],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut",
              }}
              className="absolute inset-0 bg-[#9fe870] rounded-2xl blur-2xl"
            />
            <div className="w-20 h-20 bg-gradient-to-br from-[#163300] to-[#0f2409] rounded-3xl flex items-center justify-center shadow-2xl relative z-10 border border-white/20">
              <Shield className="w-10 h-10 text-[#9fe870]" strokeWidth={2.5} />
            </div>
          </motion.div>

          {/* Title */}
          <motion.h1 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="text-3xl font-black mb-3"
          >
            <span className="bg-gradient-to-l from-[#163300] to-[#0a0b09] bg-clip-text text-transparent">
              {t.verifyPhone}
            </span>
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="text-[#6a6c6a] text-sm px-4"
          >
            {language === 'ar' 
              ? `أدخل الرمز المرسل إلى ${email}`
              : `Enter the code sent to ${email}`
            }
          </motion.p>
        </motion.div>

        {/* OTP Input Section */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5 }}
          className="flex justify-center gap-2 mb-8"
        >
          {otp.map((digit, index) => (
            <input
              key={index}
              ref={(el) => (inputRefs.current[index] = el)}
              type="tel"
              inputMode="numeric"
              maxLength={1}
              value={digit}
              onChange={(e) => handleChange(index, e.target.value)}
              onKeyDown={(e) => handleKeyDown(index, e)}
              onPaste={handlePaste}
              className="w-14 h-16 text-2xl font-black text-center bg-white border-2 border-[#e5e5e5] rounded-2xl focus:border-[#9fe870] focus:ring-4 focus:ring-[#9fe870]/20 outline-none transition-all duration-200 shadow-sm"
              disabled={loading}
            />
          ))}
        </motion.div>

        {/* Resend Section */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="text-center mb-auto"
        >
          <p className="text-sm text-[#6a6c6a] mb-2">
            {language === 'ar' ? 'لم تستلم الرمز؟' : "Didn't receive the code?"}
          </p>
          {resendCooldown > 0 ? (
            <p className="text-sm text-[#163300] font-bold">
              {language === 'ar' 
                ? `أعد المحاولة بعد ${resendCooldown}ث`
                : `Resend in ${resendCooldown}s`
              }
            </p>
          ) : (
            <button
              onClick={handleResend}
              className="text-sm text-[#163300] font-black hover:underline px-4 py-2 rounded-xl hover:bg-[#f0fde8]/50 active:scale-95 transition-all duration-200"
            >
              {language === 'ar' ? 'إعادة الإرسال' : 'Resend Code'}
            </button>
          )}
        </motion.div>

        {/* Verify Button */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="mt-auto"
        >
          <ModernButton
            onClick={() => handleVerify()}
            variant="primary"
            fullWidth
            size="lg"
            disabled={otp.some(digit => !digit) || loading}
          >
            {loading ? (
              <div className="flex items-center justify-center gap-2">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full"
                />
                {language === 'ar' ? 'جاري التحقق...' : 'Verifying...'}
              </div>
            ) : (
              <span className="flex items-center justify-center gap-2">
                {t.verify || (language === 'ar' ? 'تحقق' : 'Verify')}
                <Shield className="w-5 h-5" strokeWidth={2.5} />
              </span>
            )}
          </ModernButton>

          {/* Dev Note */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
            className="mt-4 text-center bg-gradient-to-br from-[#f0fde8]/40 to-white/40 backdrop-blur-sm rounded-2xl p-3 border border-[#9fe870]/30"
          >
            <p className="text-xs text-[#163300]">
              {language === 'ar' 
                ? '🔐 رمز التطوير: 123456'
                : '🔐 Dev code: 123456'
              }
            </p>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}