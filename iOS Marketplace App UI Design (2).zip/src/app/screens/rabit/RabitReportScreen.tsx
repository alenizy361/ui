import { motion } from "motion/react";
import { WiseButton } from "../../components/WiseButton";
import { ChevronRight, AlertCircle } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";

interface RabitReportScreenProps {
  itemType: "product" | "seller" | "buyer";
  itemId: string;
  itemName: string;
  onBack: () => void;
  onReportSubmitted: () => void;
}

export function RabitReportScreen({
  itemType,
  itemId,
  itemName,
  onBack,
  onReportSubmitted,
}: RabitReportScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);
  const [selectedReason, setSelectedReason] = useState("");
  const [details, setDetails] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const reasons = {
    product: [
      { id: "fake", label: "منتج مزيف أو مقلد" },
      { id: "misleading", label: "وصف مضلل" },
      { id: "prohibited", label: "سلعة محظورة" },
      { id: "price", label: "سعر غير عادل" },
      { id: "spam", label: "إعلان متكرر" },
      { id: "other", label: "سبب آخر" },
    ],
    seller: [
      { id: "fraud", label: "احتيال أو نصب" },
      { id: "no_delivery", label: "عدم التسليم" },
      { id: "fake_products", label: "بيع منتجات مزيفة" },
      { id: "harassment", label: "تحرش أو إزعاج" },
      { id: "poor_service", label: "خدمة سيئة" },
      { id: "other", label: "سبب آخر" },
    ],
    buyer: [
      { id: "no_payment", label: "عدم الدفع" },
      { id: "harassment", label: "تحرش أو إزعاج" },
      { id: "false_claim", label: "ادعاءات كاذبة" },
      { id: "abuse", label: "إساءة استخدام المنصة" },
      { id: "other", label: "سبب آخر" },
    ],
  };

  const handleSubmit = () => {
    if (!selectedReason) return;
    
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setShowSuccess(true);
      toast.success("تم إرسال البلاغ، شكراً لمساعدتك 🛡️");
      setTimeout(() => {
        onReportSubmitted();
      }, 2000);
    }, 1500);
  };

  const getItemTypeAr = () => {
    switch (itemType) {
      case "product":
        return "المنتج";
      case "seller":
        return "البائع";
      case "buyer":
        return "المشتري";
      default:
        return "";
    }
  };

  if (showSuccess) {
    return (
      <div className="min-h-screen bg-white flex flex-col items-center justify-center p-6" style={{ fontFamily: 'Cairo, sans-serif' }}>
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 200, damping: 15 }}
          className="w-24 h-24 bg-[#163300] rounded-full flex items-center justify-center mb-6"
        >
          <motion.svg
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="w-12 h-12 text-white"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
          >
            <motion.path
              d="M5 13l4 4L19 7"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </motion.svg>
        </motion.div>
        
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-2xl font-bold text-[#163300] mb-2 text-center"
        >
          تم إرسال البلاغ ✓
        </motion.h2>
        
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="text-[#6a6c6a] text-center"
        >
          سيتم مراجعة البلاغ من قبل فريقنا
        </motion.p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white pb-32" style={{ fontFamily: 'Cairo, sans-serif' }}>
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 flex items-center justify-between z-10"
      >
        <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
          <ChevronRight className="w-6 h-6 text-[#0e0f0c]" />
        </button>
        <h1 className="text-xl font-semibold text-[#0e0f0c]">الإبلاغ</h1>
        <div className="w-10" />
      </motion.div>

      <div className="p-6 space-y-6">
        {/* Item Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[rgba(203,39,47,0.1)] rounded-[12px] p-4 flex items-start gap-3"
        >
          <AlertCircle className="w-6 h-6 text-[#cb272f] flex-shrink-0 mt-0.5" />
          <div className="flex-1 text-right">
            <p className="text-sm font-semibold text-[#0e0f0c] mb-1">
              الإبلاغ عن {getItemTypeAr()}
            </p>
            <p className="text-sm text-[#6a6c6a]">{itemName}</p>
          </div>
        </motion.div>

        {/* Reason Selection */}
        <div>
          <label className="block text-sm font-semibold text-[#0e0f0c] mb-3 text-right">
            سبب الإبلاغ
          </label>
          <div className="space-y-2">
            {reasons[itemType].map((reason, index) => (
              <motion.button
                key={reason.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                onClick={() => setSelectedReason(reason.id)}
                className={`w-full p-4 rounded-[10px] border-2 text-right transition-all ${
                  selectedReason === reason.id
                    ? "border-[#cb272f] bg-[rgba(203,39,47,0.05)]"
                    : "border-[rgba(14,15,12,0.12157)] bg-white"
                }`}
              >
                <div className="flex items-center justify-between">
                  <div
                    className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors ${
                      selectedReason === reason.id
                        ? "border-[#cb272f] bg-[#cb272f]"
                        : "border-[rgba(14,15,12,0.12157)]"
                    }`}
                  >
                    {selectedReason === reason.id && (
                      <span className="w-2 h-2 bg-white rounded-full" />
                    )}
                  </div>
                  <span className="font-medium text-[#0e0f0c]">{reason.label}</span>
                </div>
              </motion.button>
            ))}
          </div>
        </div>

        {/* Details */}
        <div>
          <label className="block text-sm font-semibold text-[#0e0f0c] mb-2 text-right">
            تفاصيل إضافية (اختياري)
          </label>
          <textarea
            value={details}
            onChange={(e) => setDetails(e.target.value)}
            placeholder="اكتب أي تفاصيل إضافية تساعدنا في المراجعة..."
            rows={5}
            className="w-full px-4 py-3 rounded-[10px] border border-[rgba(14,15,12,0.12157)] text-right focus:outline-none focus:border-[#163300] resize-none"
          />
          <p className="text-xs text-[#6a6c6a] mt-2 text-right">
            {details.length}/500 حرف
          </p>
        </div>

        {/* Info */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="bg-[rgba(159,232,112,0.1)] rounded-[12px] p-4"
        >
          <p className="text-sm font-semibold text-[#163300] mb-2">ℹ️ ماذا سيحدث بعد الإبلاغ؟</p>
          <ul className="text-xs text-[#6a6c6a] space-y-1 list-disc list-inside text-right">
            <li>سيتم مراجعة البلاغ من قبل فريقنا خلال 24 ساعة</li>
            <li>سنتواصل معك إذا احتجنا لمزيد من المعلومات</li>
            <li>ستظل هويتك سرية</li>
            <li>سنتخذ الإجراء المناسب حسب سياساتنا</li>
          </ul>
        </motion.div>
      </div>

      {/* Fixed Bottom Button */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-[rgba(14,15,12,0.12157)] px-6 py-4 max-w-[430px] mx-auto">
        <WiseButton
          onClick={handleSubmit}
          variant="danger"
          fullWidth
          loading={isLoading}
          disabled={!selectedReason || isLoading}
        >
          {isLoading ? "جاري الإرسال..." : "إرسال البلاغ"}
        </WiseButton>
      </div>
    </div>
  );
}