import { motion } from "motion/react";
import { Check, Package, TrendingUp, ArrowRight } from "lucide-react";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";
import { useEffect } from "react";

interface OrderShippedSuccessScreenProps {
  orderNumber: string;
  productTitle: string;
  productTitleAr: string;
  earnings: number;
  onContinue: () => void;
  onViewOrder: () => void;
}

export function RabitOrderShippedSuccessScreen({
  orderNumber,
  productTitle,
  productTitleAr,
  earnings,
  onContinue,
  onViewOrder,
}: OrderShippedSuccessScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);

  // Confetti particle effect
  const confettiColors = ["#9fe870", "#163300", "#b8f092", "#FFD700"];
  const confettiParticles = Array.from({ length: 30 }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    color: confettiColors[Math.floor(Math.random() * confettiColors.length)],
    delay: Math.random() * 0.5,
    duration: 2 + Math.random() * 2,
  }));

  return (
    <div
      className="min-h-screen bg-[#f8f9fa] flex flex-col items-center justify-center px-6 relative overflow-hidden"
      style={{ fontFamily: "Cairo, sans-serif" }}
    >
      {/* Confetti Animation */}
      {confettiParticles.map((particle) => (
        <motion.div
          key={particle.id}
          initial={{ y: -20, x: `${particle.x}vw`, opacity: 1, rotate: 0 }}
          animate={{
            y: "110vh",
            rotate: 360,
            opacity: [1, 1, 0],
          }}
          transition={{
            duration: particle.duration,
            delay: particle.delay,
            ease: "easeIn",
          }}
          className="absolute w-3 h-3 rounded-full pointer-events-none"
          style={{ backgroundColor: particle.color }}
        />
      ))}

      {/* Background Circles */}
      <motion.div
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 0.05 }}
        transition={{ duration: 1.2, ease: "easeOut" }}
        className="absolute w-[500px] h-[500px] rounded-full border-4 border-[#9fe870] pointer-events-none"
      />
      <motion.div
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 0.03 }}
        transition={{ duration: 1.4, delay: 0.2, ease: "easeOut" }}
        className="absolute w-[700px] h-[700px] rounded-full border-4 border-[#9fe870] pointer-events-none"
      />

      {/* Success Icon with Animation */}
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{
          type: "spring",
          stiffness: 200,
          damping: 15,
          delay: 0.2,
        }}
        className="relative mb-8 z-10 pointer-events-none"
      >
        {/* Outer Circle */}
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="w-32 h-32 rounded-full bg-[#9fe870]/10 backdrop-blur-sm flex items-center justify-center shadow-xl"
        >
          {/* Inner Circle */}
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{
              type: "spring",
              stiffness: 300,
              damping: 20,
              delay: 0.4,
            }}
            className="w-24 h-24 rounded-full bg-[#9fe870] flex items-center justify-center relative shadow-lg"
          >
            {/* Checkmark Animation */}
            <motion.div
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{
                type: "spring",
                stiffness: 200,
                damping: 15,
                delay: 0.6,
              }}
            >
              <Check className="w-12 h-12 text-white" strokeWidth={3} />
            </motion.div>

            {/* Pulse Effect */}
            <motion.div
              initial={{ scale: 1, opacity: 0.5 }}
              animate={{ scale: 2, opacity: 0 }}
              transition={{
                duration: 1.5,
                repeat: Infinity,
                repeatDelay: 0.5,
              }}
              className="absolute inset-0 rounded-full bg-[#9fe870]"
            />
          </motion.div>
        </motion.div>

        {/* Package Icon Badge */}
        <motion.div
          initial={{ scale: 0, x: 20, y: 20 }}
          animate={{ scale: 1, x: 0, y: 0 }}
          transition={{
            type: "spring",
            stiffness: 300,
            damping: 20,
            delay: 0.8,
          }}
          className="absolute -bottom-2 -right-2 w-14 h-14 rounded-full bg-white flex items-center justify-center shadow-lg border-4 border-[#f8f9fa]"
        >
          <Package className="w-7 h-7 text-[#163300]" />
        </motion.div>
      </motion.div>

      {/* Title */}
      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8, duration: 0.5 }}
        className="text-3xl font-bold text-[#0e0f0c] mb-3 text-center"
      >
        {language === "ar" ? "تم الشحن بنجاح! 🎉" : "Order Shipped! 🎉"}
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.9, duration: 0.5 }}
        className="text-[#6a6c6a] text-center mb-8 max-w-sm"
      >
        {language === "ar"
          ? "تم تحديث حالة الطلب بنجاح. سيتم إشعار المشتري بشحن المنتج"
          : "Order status updated successfully. The buyer will be notified that the product has been shipped"}
      </motion.p>

      {/* Order Details Card */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1, duration: 0.5 }}
        className="bg-white rounded-[20px] p-6 w-full max-w-md mb-6 shadow-xl border border-[#e8e9ea]"
      >
        {/* Order Number */}
        <div className="flex items-center justify-between mb-4 pb-4 border-b border-[#e8e9ea]">
          <span className="text-[#6a6c6a] text-sm">
            {language === "ar" ? "رقم الطلب" : "Order Number"}
          </span>
          <span className="text-[#0e0f0c] font-semibold">{orderNumber}</span>
        </div>

        {/* Product Title */}
        <div className="flex items-center justify-between mb-4 pb-4 border-b border-[#e8e9ea]">
          <span className="text-[#6a6c6a] text-sm">
            {language === "ar" ? "المنتج" : "Product"}
          </span>
          <span className="text-[#0e0f0c] font-medium text-right max-w-[60%]">
            {language === "ar" ? productTitleAr : productTitle}
          </span>
        </div>

        {/* Earnings with Animation */}
        <motion.div
          initial={{ scale: 0.9 }}
          animate={{ scale: 1 }}
          transition={{
            delay: 1.2,
            type: "spring",
            stiffness: 200,
            damping: 15,
          }}
          className="bg-[#9fe870]/10 rounded-[16px] p-4 flex items-center justify-between"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#9fe870] flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-[#6a6c6a] text-xs mb-1">
                {language === "ar" ? "أرباحك" : "Your Earnings"}
              </p>
              <motion.p
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 1.3, duration: 0.5 }}
                className="text-[#163300] text-2xl font-bold"
              >
                {earnings.toLocaleString(language === "ar" ? "ar-SA" : "en-US")}{" "}
                <span className="text-lg">{t.sar}</span>
              </motion.p>
            </div>
          </div>
        </motion.div>
      </motion.div>

      {/* Action Buttons */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.2, duration: 0.5 }}
        className="w-full max-w-md space-y-3 relative z-20"
      >
        {/* View Order Button */}
        <button
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            console.log("View Order clicked!"); // Debug log
            onViewOrder();
          }}
          className="w-full bg-[#163300] text-white rounded-full py-4 px-6 font-semibold flex items-center justify-center gap-2 shadow-lg hover:shadow-xl transition-all active:scale-95 cursor-pointer"
        >
          <span>{language === "ar" ? "عرض تفاصيل الطلب" : "View Order Details"}</span>
          <ArrowRight
            className={`w-5 h-5 ${isRTL ? "rotate-180" : ""}`}
          />
        </button>

        {/* Continue to Sales Button */}
        <button
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            console.log("Back to Sales clicked!"); // Debug log
            onContinue();
          }}
          className="w-full bg-white text-[#163300] border-2 border-[#e8e9ea] rounded-full py-4 px-6 font-semibold hover:bg-[#f8f9fa] transition-all active:scale-95 cursor-pointer"
        >
          {language === "ar" ? "العودة إلى المبيعات" : "Back to Sales"}
        </button>
      </motion.div>

      {/* Bottom Decoration - Remove dark overlay */}
    </div>
  );
}