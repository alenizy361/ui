import { motion } from "motion/react";
import { ChevronRight, Phone, Mail } from "lucide-react";
import { useState } from "react";
import { triggerHaptic } from "../../utils/haptics";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";

interface RabitForgotPasswordScreenProps {
  onBack: () => void;
  onContinue: (phoneOrEmail: string, method: "phone" | "email") => void;
}

export function RabitForgotPasswordScreen({
  onBack,
  onContinue,
}: RabitForgotPasswordScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);
  const [method, setMethod] = useState<"phone" | "email">("phone");
  const [phoneOrEmail, setPhoneOrEmail] = useState("");
  const [error, setError] = useState("");

  const validateAndContinue = () => {
    setError("");

    if (method === "phone") {
      // Saudi phone validation
      const phoneRegex = /^(5[0-9]{8})$/;
      if (!phoneRegex.test(phoneOrEmail.replace(/\s/g, ""))) {
        setError(
          language === "ar"
            ? "رقم الجوال غير صحيح"
            : "Invalid phone number"
        );
        triggerHaptic("error");
        return;
      }
    } else {
      // Email validation
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(phoneOrEmail)) {
        setError(
          language === "ar"
            ? "البريد الإلكتروني غير صحيح"
            : "Invalid email address"
        );
        triggerHaptic("error");
        return;
      }
    }

    triggerHaptic("light");
    onContinue(phoneOrEmail, method);
  };

  return (
    <div
      className="min-h-screen bg-gradient-to-b from-[#fafafa] to-white"
      style={{
        fontFamily:
          language === "ar"
            ? "Cairo, sans-serif"
            : "system-ui, -apple-system, sans-serif",
      }}
      dir={isRTL ? "rtl" : "ltr"}
    >
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white/95 backdrop-blur-lg border-b border-[rgba(0,0,0,0.06)] px-6 py-4 z-10"
      >
        <div className="flex items-center justify-between">
          <button
            onClick={() => {
              triggerHaptic("light");
              onBack();
            }}
            className="w-11 h-11 rounded-2xl bg-[#f0fde8] border border-[rgba(22,51,0,0.1)] flex items-center justify-center text-[#163300] transition-all duration-200 hover:bg-[#e2fad5] active:scale-95"
          >
            <ChevronRight className={`w-6 h-6 ${isRTL ? '' : 'rotate-180'}`} />
          </button>
          <h1 className="text-xl font-semibold text-[#0a0b09]">
            {language === 'ar' ? 'استعادة كلمة المرور' : 'Reset Password'}
          </h1>
          <div className="w-11" /> {/* Spacer */}
        </div>
      </motion.div>

      {/* Content */}
      <div className="p-6 space-y-8">
        {/* Illustration */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="flex justify-center pt-8"
        >
          <div className="w-32 h-32 rounded-3xl bg-gradient-to-br from-[#f0fde8] to-[#e2fad5] flex items-center justify-center shadow-lg">
            <svg
              className="w-16 h-16 text-[#163300]"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
              />
            </svg>
          </div>
        </motion.div>

        {/* Description */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-center space-y-2"
        >
          <h2 className="text-2xl font-bold text-[#0a0b09]">
            {t.forgotPassword}
          </h2>
          <p className="text-[#6a6c6a] text-sm leading-relaxed">
            {language === 'ar' ? 'أدخل رقم جوالك أو بريدك الإلكتروني وسنرسل لك رمز التحقق لإعادة تعيين كلمة المرور' : 'Enter your phone number or email and we\'ll send you a verification code to reset your password'}
          </p>
        </motion.div>

        {/* Method Selection */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="space-y-3"
        >
          <label className={`text-sm font-medium text-[#0a0b09] block ${isRTL ? 'text-right' : 'text-left'}`}>
            {language === 'ar' ? 'طريقة الاستعادة' : 'Recovery Method'}
          </label>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => {
                triggerHaptic("selection");
                setMethod("phone");
                setPhoneOrEmail("");
                setError("");
              }}
              className={`p-4 rounded-2xl border-2 transition-all duration-200 flex flex-col items-center gap-2 ${
                method === "phone"
                  ? "border-[#163300] bg-[#f0fde8] shadow-md"
                  : "border-[rgba(0,0,0,0.1)] bg-white"
              }`}
            >
              <Phone
                className={`w-6 h-6 ${
                  method === "phone" ? "text-[#163300]" : "text-[#6a6c6a]"
                }`}
              />
              <span
                className={`text-sm font-medium ${
                  method === "phone" ? "text-[#163300]" : "text-[#6a6c6a]"
                }`}
              >
                {t.phoneNumber}
              </span>
            </button>

            <button
              onClick={() => {
                triggerHaptic("selection");
                setMethod("email");
                setPhoneOrEmail("");
                setError("");
              }}
              className={`p-4 rounded-2xl border-2 transition-all duration-200 flex flex-col items-center gap-2 ${
                method === "email"
                  ? "border-[#163300] bg-[#f0fde8] shadow-md"
                  : "border-[rgba(0,0,0,0.1)] bg-white"
              }`}
            >
              <Mail
                className={`w-6 h-6 ${
                  method === "email" ? "text-[#163300]" : "text-[#6a6c6a]"
                }`}
              />
              <span
                className={`text-sm font-medium ${
                  method === "email" ? "text-[#163300]" : "text-[#6a6c6a]"
                }`}
              >
                {t.email}
              </span>
            </button>
          </div>
        </motion.div>

        {/* Input Field */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="space-y-2"
        >
          <label className={`text-sm font-medium text-[#0a0b09] block ${isRTL ? 'text-right' : 'text-left'}`}>
            {method === "phone" ? t.phoneNumber : t.email}
          </label>
          <div className="relative">
            {method === "phone" && (
              <div className={`absolute ${isRTL ? 'right-4' : 'left-4'} top-1/2 -translate-y-1/2 flex items-center gap-2 text-[#6a6c6a] ${isRTL ? 'border-l' : 'border-r'} border-[rgba(0,0,0,0.1)] ${isRTL ? 'pl-3' : 'pr-3'}`}>
                <span className="text-sm">+966</span>
              </div>
            )}
            <input
              type={method === "phone" ? "tel" : "email"}
              value={phoneOrEmail}
              onChange={(e) => {
                setPhoneOrEmail(e.target.value);
                setError("");
              }}
              placeholder={
                method === "phone" ? "5XXXXXXXX" : "example@email.com"
              }
              dir="ltr"
              className={`w-full px-4 py-4 ${
                method === "phone" ? (isRTL ? 'pr-20' : 'pl-20') : ""
              } bg-white border-2 rounded-2xl ${isRTL ? 'text-right' : 'text-left'} transition-all duration-200 ${
                error
                  ? "border-red-500"
                  : "border-[rgba(0,0,0,0.1)] focus:border-[#163300]"
              } focus:outline-none focus:shadow-md`}
            />
          </div>
          {error && (
            <motion.p
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`text-red-500 text-sm ${isRTL ? 'text-right' : 'text-left'}`}
            >
              {error}
            </motion.p>
          )}
        </motion.div>

        {/* Continue Button */}
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          whileTap={{ scale: 0.98 }}
          onClick={validateAndContinue}
          disabled={!phoneOrEmail}
          className={`w-full py-4 rounded-2xl font-semibold transition-all duration-200 ${
            phoneOrEmail
              ? "bg-gradient-to-br from-[#163300] to-[#0f2409] text-white shadow-lg hover:shadow-xl active:scale-98"
              : "bg-[#e5e5e5] text-[#a3a3a3] cursor-not-allowed"
          }`}
        >
          {language === 'ar' ? 'إرسال رمز التحقق' : 'Send Verification Code'}
        </motion.button>

        {/* Help Text */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="text-center"
        >
          <p className="text-[#6a6c6a] text-sm">
            {language === 'ar' ? 'تذكرت كلمة المرور؟' : 'Remember your password?'}{" "}
            <button
              onClick={() => {
                triggerHaptic("light");
                onBack();
              }}
              className="text-[#163300] font-semibold hover:underline"
            >
              {t.login}
            </button>
          </p>
        </motion.div>
      </div>
    </div>
  );
}