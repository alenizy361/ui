import { motion } from "motion/react";
import { ChevronRight, Star, ThumbsUp, Filter, User } from "lucide-react";
import { useState } from "react";
import { useLanguage } from "../../contexts/LanguageContext";

interface Review {
  id: string;
  userName: string;
  userAvatar?: string;
  rating: number;
  date: string;
  comment: string;
  images?: string[];
  helpful: number;
  verified: boolean;
}

interface RabitProductReviewsScreenProps {
  productName: string;
  averageRating: number;
  totalReviews: number;
  onBack: () => void;
}

export function RabitProductReviewsScreen({
  productName,
  averageRating,
  totalReviews,
  onBack,
}: RabitProductReviewsScreenProps) {
  const { language, isRTL } = useLanguage();
  const [filterRating, setFilterRating] = useState<number | null>(null);
  const [sortBy, setSortBy] = useState<"recent" | "helpful">("recent");

  const content = {
    ar: {
      reviews: "التقييمات",
      allReviews: "جميع التقييمات",
      verified: "تم التحقق من الشراء",
      helpful: "مفيد",
      sortBy: "ترتيب حسب",
      recent: "الأحدث",
      mostHelpful: "الأكثر إفادة",
      filterByRating: "تصفية حسب التقييم",
      allRatings: "جميع التقييمات",
      stars: "نجوم",
      noReviews: "لا توجد تقييمات",
      noReviewsDesc: "كن أول من يقيم هذا المنتج",
      writeReview: "اكتب تقييم",
      ratingBreakdown: "توزيع التقييمات",
      outOf5: "من 5",
    },
    en: {
      reviews: "Reviews",
      allReviews: "All Reviews",
      verified: "Verified Purchase",
      helpful: "Helpful",
      sortBy: "Sort by",
      recent: "Most Recent",
      mostHelpful: "Most Helpful",
      filterByRating: "Filter by Rating",
      allRatings: "All Ratings",
      stars: "stars",
      noReviews: "No reviews yet",
      noReviewsDesc: "Be the first to review this product",
      writeReview: "Write Review",
      ratingBreakdown: "Rating Breakdown",
      outOf5: "out of 5",
    },
  };
  const c = content[language];

  // Mock reviews data
  const mockReviews: Review[] = [
    {
      id: "1",
      userName: "أحمد محمد",
      rating: 5,
      date: "2025-12-20",
      comment: "منتج ممتاز جداً! الجودة عالية والتوصيل كان سريع. أنصح بالشراء بشدة.",
      images: [
        "https://images.unsplash.com/photo-1592286927505-2fd7d4f114f0?w=200",
        "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=200",
      ],
      helpful: 12,
      verified: true,
    },
    {
      id: "2",
      userName: "سارة أحمد",
      rating: 4,
      date: "2025-12-18",
      comment: "جيد جداً، لكن التغليف كان يحتاج لمزيد من الحماية.",
      helpful: 8,
      verified: true,
    },
    {
      id: "3",
      userName: "محمد علي",
      rating: 5,
      date: "2025-12-15",
      comment: "أفضل عملية شراء قمت بها! المنتج يطابق الوصف تماماً.",
      helpful: 15,
      verified: true,
    },
    {
      id: "4",
      userName: "فاطمة خالد",
      rating: 3,
      date: "2025-12-10",
      comment: "المنتج جيد لكن التوصيل تأخر قليلاً.",
      helpful: 3,
      verified: false,
    },
    {
      id: "5",
      userName: "عبدالله سعيد",
      rating: 5,
      date: "2025-12-05",
      comment: "ممتاز! سعيد جداً بالشراء.",
      helpful: 7,
      verified: true,
    },
  ];

  // Calculate rating distribution
  const ratingDistribution = [5, 4, 3, 2, 1].map((rating) => {
    const count = mockReviews.filter((r) => r.rating === rating).length;
    const percentage = (count / mockReviews.length) * 100;
    return { rating, count, percentage };
  });

  const filteredReviews = filterRating
    ? mockReviews.filter((r) => r.rating === filterRating)
    : mockReviews;

  const sortedReviews = [...filteredReviews].sort((a, b) => {
    if (sortBy === "helpful") return b.helpful - a.helpful;
    return new Date(b.date).getTime() - new Date(a.date).getTime();
  });

  return (
    <div
      className="min-h-screen bg-[#fafafa] pb-6"
      style={{ fontFamily: language === "ar" ? "Cairo, sans-serif" : "system-ui, -apple-system, sans-serif" }}
      dir={isRTL ? "rtl" : "ltr"}
    >
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 z-10"
      >
        <div className="flex items-center justify-between">
          <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
            <ChevronRight className={`w-6 h-6 text-[#0e0f0c] ${isRTL ? "" : "rotate-180"}`} />
          </button>
          <h1 className="text-xl font-semibold text-[#0e0f0c]">{c.reviews}</h1>
          <div className="w-10" />
        </div>
      </motion.div>

      <div className="p-6 space-y-6">
        {/* Rating Summary */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-[16px] p-6"
        >
          <div className="text-center mb-6">
            <div className="text-5xl font-bold text-[#163300] mb-2">{averageRating.toFixed(1)}</div>
            <div className="flex items-center justify-center gap-1 mb-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star
                  key={star}
                  className={`w-5 h-5 ${
                    star <= averageRating
                      ? "fill-[#fbbf24] text-[#fbbf24]"
                      : "fill-[rgba(14,15,12,0.12157)] text-[rgba(14,15,12,0.12157)]"
                  }`}
                />
              ))}
            </div>
            <p className="text-sm text-[#6a6c6a]">
              {totalReviews} {language === "ar" ? "تقييم" : "reviews"}
            </p>
          </div>

          {/* Rating Distribution */}
          <div className="space-y-2">
            {ratingDistribution.map(({ rating, count, percentage }) => (
              <button
                key={rating}
                onClick={() => setFilterRating(filterRating === rating ? null : rating)}
                className={`w-full flex items-center gap-3 py-2 px-3 rounded-[8px] transition-colors ${
                  filterRating === rating ? "bg-[rgba(22,51,0,0.12157)]" : "hover:bg-[rgba(22,51,0,0.07843)]"
                }`}
              >
                <span className="text-sm font-medium text-[#0e0f0c] w-8">{rating} ⭐</span>
                <div className="flex-1 h-2 bg-[rgba(14,15,12,0.12157)] rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#fbbf24] transition-all"
                    style={{ width: `${percentage}%` }}
                  />
                </div>
                <span className="text-sm text-[#6a6c6a] w-8 text-right">{count}</span>
              </button>
            ))}
          </div>
        </motion.div>

        {/* Sort Controls */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="flex gap-2"
        >
          <button
            onClick={() => setSortBy("recent")}
            className={`flex-1 py-2 px-4 rounded-[10px] text-sm font-medium transition-colors ${
              sortBy === "recent"
                ? "bg-[#163300] text-white"
                : "bg-white text-[#0e0f0c] border border-[rgba(14,15,12,0.12157)]"
            }`}
          >
            {c.recent}
          </button>
          <button
            onClick={() => setSortBy("helpful")}
            className={`flex-1 py-2 px-4 rounded-[10px] text-sm font-medium transition-colors ${
              sortBy === "helpful"
                ? "bg-[#163300] text-white"
                : "bg-white text-[#0e0f0c] border border-[rgba(14,15,12,0.12157)]"
            }`}
          >
            {c.mostHelpful}
          </button>
        </motion.div>

        {/* Reviews List */}
        <div className="space-y-4">
          {sortedReviews.map((review, index) => (
            <motion.div
              key={review.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + index * 0.05 }}
              className="bg-white rounded-[12px] p-4"
            >
              {/* User Info */}
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.12157)] flex items-center justify-center">
                    {review.userAvatar ? (
                      <img src={review.userAvatar} alt={review.userName} className="w-full h-full rounded-full object-cover" />
                    ) : (
                      <User className="w-5 h-5 text-[#163300]" />
                    )}
                  </div>
                  <div>
                    <h3 className={`font-semibold text-[#0e0f0c] ${isRTL ? "text-right" : "text-left"}`}>
                      {review.userName}
                    </h3>
                    {review.verified && (
                      <span className="text-xs text-[#008026]">✓ {c.verified}</span>
                    )}
                  </div>
                </div>
                <span className="text-xs text-[#6a6c6a]">
                  {new Date(review.date).toLocaleDateString(language === "ar" ? "ar-SA" : "en-US")}
                </span>
              </div>

              {/* Rating */}
              <div className="flex items-center gap-1 mb-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    className={`w-4 h-4 ${
                      star <= review.rating
                        ? "fill-[#fbbf24] text-[#fbbf24]"
                        : "fill-[rgba(14,15,12,0.12157)] text-[rgba(14,15,12,0.12157)]"
                    }`}
                  />
                ))}
              </div>

              {/* Comment */}
              <p className={`text-sm text-[#0e0f0c] mb-3 ${isRTL ? "text-right" : "text-left"}`}>
                {review.comment}
              </p>

              {/* Images */}
              {review.images && review.images.length > 0 && (
                <div className="flex gap-2 mb-3 overflow-x-auto">
                  {review.images.map((img, idx) => (
                    <img
                      key={idx}
                      src={img}
                      alt={`Review ${idx + 1}`}
                      className="w-20 h-20 rounded-[8px] object-cover"
                    />
                  ))}
                </div>
              )}

              {/* Helpful */}
              <button className="flex items-center gap-2 text-sm text-[#6a6c6a] hover:text-[#163300] transition-colors">
                <ThumbsUp className="w-4 h-4" />
                <span>
                  {c.helpful} ({review.helpful})
                </span>
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
