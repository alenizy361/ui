import { useState, useRef, useEffect } from "react";
import { motion } from "motion/react";
import { ChevronRight, Send, Paperclip, MoreVertical, Phone } from "lucide-react";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";
import { useAuth } from "../../contexts/AuthContext";
import { uploadProductImage } from "../../services/storage.service";
import { type RabitProduct } from "../../data/rabitProducts";
import { ImageZoomModal } from "../../components/ImageZoomModal";
import { triggerHaptic } from "../../utils/haptics";
import { toast } from "sonner";

interface ChatMessage {
  id: string;
  text?: string;
  image?: string;
  sender: "user" | "other";
  time: string;
  status?: "sent" | "delivered" | "read";
}

interface ChatScreenProps {
  product?: RabitProduct;
  chatWith?: {
    id?: string; // User ID we're chatting with
    name: string;
    nameAr: string;
    role?: "buyer" | "seller";
  };
  onBack: () => void;
}

export function RabitChatScreen({ product, chatWith, onBack }: ChatScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);
  const { user } = useAuth();
  const [message, setMessage] = useState("");
  const [isZoomModalOpen, setIsZoomModalOpen] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string>("");
  const [isLoadingMessages, setIsLoadingMessages] = useState(false);
  const [isSendingMessage, setIsSendingMessage] = useState(false);
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Safe fallbacks for potentially missing fields
  const chatPersonName = chatWith 
    ? (language === 'ar' ? (chatWith.nameAr || 'مستخدم') : (chatWith.name || 'User'))
    : (product 
        ? (language === 'ar' ? (product.sellerAr || 'بائع') : (product.seller || 'Seller'))
        : (language === 'ar' ? 'مستخدم' : 'User'));
  
  const chatPersonNameAr = chatWith?.nameAr || product?.sellerAr || 'مستخدم';
  const chatPersonInitial = chatPersonNameAr[0] || 'U';

  // TODO: Connect to real backend when ready
  // Fetch conversation on component mount:
  useEffect(() => {
    const fetchConversation = async () => {
      if (!chatWith?.id) return;
      
      setIsLoadingMessages(true);
      const response = await messagingAPI.getConversation(
        chatWith.id,
        product?.id,
        user.accessToken
      );
      
      if (response.success && response.conversation) {
        // Convert backend messages to ChatMessage format
        const backendMessages = response.conversation.messages.map((msg: any) => ({
          id: msg.id,
          text: msg.text,
          image: msg.image,
          sender: msg.senderId === user.id ? 'user' : 'other',
          time: formatTime(msg.createdAt),
          status: msg.read ? 'read' : 'sent'
        }));
        setMessages(backendMessages);
        
        // Mark as read
        if (response.conversation.id) {
          await messagingAPI.markConversationAsRead(response.conversation.id, user.accessToken);
        }
      }
      setIsLoadingMessages(false);
    };
    
    fetchConversation();
  }, [chatWith?.id, product?.id]);

  // TODO: Handle send message:
  const handleSendMessageBackend = async () => {
    if (!message.trim() || !chatWith?.id) return;
    
    setIsSendingMessage(true);
    const response = await messagingAPI.sendMessage(
      {
        recipientId: chatWith.id,
        productId: product?.id,
        text: message.trim(),
        messageType: 'text'
      },
      user.accessToken
    );
    
    if (response.success) {
      // Add message to UI
      const newMessage = {
        id: response.message.id,
        text: message.trim(),
        sender: 'user' as const,
        time: formatTime(new Date().toISOString()),
        status: 'sent' as const
      };
      setMessages(prev => [...prev, newMessage]);
      setMessage('');
      
      // Scroll to bottom
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
    setIsSendingMessage(false);
  };

  // TODO: Auto-refresh messages every 3 seconds:
  useEffect(() => {
    const interval = setInterval(async () => {
      if (!chatWith?.id) return;
      const response = await messagingAPI.getConversation(chatWith.id, product?.id, user.accessToken);
      if (response.success && response.conversation) {
        const backendMessages = response.conversation.messages.map((msg: any) => ({
          id: msg.id,
          text: msg.text,
          sender: msg.senderId === user.id ? 'user' : 'other',
          time: formatTime(msg.createdAt),
          status: msg.read ? 'read' : 'sent'
        }));
        setMessages(backendMessages);
      }
    }, 3000); // Refresh every 3 seconds
    
    return () => clearInterval(interval);
  }, [chatWith?.id]);

  // Determine who we're chatting with
  const isBuyerChat = chatWith && chatWith.role === "buyer";

  // Messages from backend - no mock data
  const [messages, setMessages] = useState<ChatMessage[]>([]);

  const handleSendMessage = () => {
    if (message.trim()) {
      const newMessage: ChatMessage = {
        id: Date.now().toString(),
        text: message,
        sender: "user",
        time: new Date().toLocaleTimeString("ar-SA", { hour: "2-digit", minute: "2-digit" }),
        status: "sent",
      };
      setMessages([...messages, newMessage]);
      setMessage("");

      // Simulate response
      setTimeout(() => {
        const autoReply: ChatMessage = {
          id: (Date.now() + 1).toString(),
          text: "شكراً لك! سأرد عليك قريباً 😊",
          sender: "other",
          time: new Date().toLocaleTimeString("ar-SA", { hour: "2-digit", minute: "2-digit" }),
        };
        setMessages((prev) => [...prev, autoReply]);
      }, 2000);
    }
  };

  const handleImageClick = (imageUrl: string) => {
    setSelectedImage(imageUrl);
    setIsZoomModalOpen(true);
  };

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Check file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      toast.error(language === 'ar' ? 'حجم الملف كبير جداً (الحد الأقصى 10 ميجابايت)' : 'File size too large (max 10MB)');
      return;
    }

    setIsUploadingImage(true);
    toast.loading(language === 'ar' ? 'جاري تحميل الصورة...' : 'Uploading image...');

    try {
      const response = await uploadProductImage(file);
      
      if (response.success && response.url) {
        const newMessage: ChatMessage = {
          id: Date.now().toString(),
          image: response.url,
          sender: "user",
          time: new Date().toLocaleTimeString("ar-SA", { hour: "2-digit", minute: "2-digit" }),
          status: "sent",
        };
        setMessages([...messages, newMessage]);
        toast.dismiss();
        toast.success(language === 'ar' ? 'تم إرسال الصورة بنجاح' : 'Image sent successfully');

        // Scroll to bottom
        setTimeout(() => {
          messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
        }, 100);
      } else {
        toast.dismiss();
        toast.error(language === 'ar' ? (response.error || 'فشل تحميل الصورة') : (response.error || 'Failed to upload image'));
      }
    } catch (error) {
      toast.dismiss();
      toast.error(language === 'ar' ? 'حدث خطأ أثناء تحميل الصورة' : 'Error uploading image');
      console.error('Image upload error:', error);
    }
    
    setIsUploadingImage(false);
    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const formatTime = (isoTime: string) => {
    const date = new Date(isoTime);
    return date.toLocaleTimeString(language === 'ar' ? 'ar-SA' : 'en-US', { hour: "2-digit", minute: "2-digit" });
  };

  return (
    <div className="min-h-screen bg-[#f5f5f5] flex flex-col" style={{ fontFamily: 'Cairo, sans-serif' }}>
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }} 
        animate={{ opacity: 1, y: 0 }} 
        className="bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4"
      >
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => console.log("More options clicked")}
              className="w-8 h-8 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center hover:bg-[rgba(22,51,0,0.12)] transition-colors"
              aria-label={t.moreOptions}
            >
              <MoreVertical className="w-4 h-4 text-[#0e0f0c]" />
            </button>
            <button 
              onClick={() => console.log("Call clicked")}
              className="w-8 h-8 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center hover:bg-[rgba(22,51,0,0.12)] transition-colors"
              aria-label={t.call}
            >
              <Phone className="w-4 h-4 text-[#0e0f0c]" />
            </button>
          </div>
          <div className={`flex items-center gap-3 ${isRTL ? '' : 'flex-row-reverse'}`}>
            <div className={isRTL ? "text-right" : "text-left"}>
              <h1 className="text-base font-semibold text-[#0e0f0c]">
                {chatPersonName}
              </h1>
              <p className="text-xs text-[#6a6c6a]">{t.online}</p>
            </div>
            <div className="w-10 h-10 rounded-full bg-[#163300] flex items-center justify-center text-white font-bold">
              {chatPersonInitial}
            </div>
          </div>
          <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>

        {/* Product Card */}
        <div className="bg-[rgba(22,51,0,0.07843)] rounded-[10px] p-3 flex gap-3 items-center">
          <div className={`flex-1 ${isRTL ? "text-right" : "text-left"}`}>
            <p className="text-sm font-medium text-[#0e0f0c] mb-1">
              {product ? (language === 'ar' ? product.titleAr : product.title) : (language === 'ar' ? "منتج غير محدد" : "Product not specified")}
            </p>
            <p className="text-xs text-[#163300] font-bold">
              {product ? `${product.price.toLocaleString(language === 'ar' ? 'ar-SA' : 'en-US')} ${t.sar}` : (language === 'ar' ? "غير محدد" : "Not specified")}
            </p>
          </div>
          <div className="w-16 h-16 bg-white rounded-[8px] flex items-center justify-center overflow-hidden flex-shrink-0">
            <Paperclip className="w-8 h-8 text-[#6a6c6a]" />
          </div>
        </div>
      </motion.div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg, index) => (
          <motion.div
            key={msg.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className={`flex ${msg.sender === "user" ? "justify-start" : "justify-end"}`}
          >
            <div className={`max-w-[75%] ${msg.sender === "user" ? "items-start" : "items-end"} flex flex-col gap-1`}>
              {msg.image ? (
                <motion.div
                  whileTap={{ scale: 0.95 }}
                  onClick={() => handleImageClick(msg.image!)}
                  className={`rounded-[16px] overflow-hidden cursor-pointer ${
                    msg.sender === "user"
                      ? "border border-[rgba(14,15,12,0.12157)]"
                      : ""
                  }`}
                >
                  <img
                    src={msg.image}
                    alt="Shared image"
                    className="w-64 h-64 object-cover"
                  />
                </motion.div>
              ) : (
                <div
                  className={`px-4 py-3 rounded-[16px] ${
                    msg.sender === "user"
                      ? "bg-white border border-[rgba(14,15,12,0.12157)] text-[#0e0f0c]"
                      : "bg-[#163300] text-white"
                  }`}
                >
                  <p className="text-sm leading-relaxed">{msg.text}</p>
                </div>
              )}
              <div className="flex items-center gap-2 px-2">
                <span className="text-xs text-[#6a6c6a]">{msg.time}</span>
                {msg.sender === "user" && msg.status && (
                  <span className="text-xs text-[#6a6c6a]">
                    {msg.status === "sent" && "✓"}
                    {msg.status === "delivered" && "✓✓"}
                    {msg.status === "read" && <span className="text-[#163300]">✓✓</span>}
                  </span>
                )}
              </div>
            </div>
          </motion.div>
        ))}

        {/* Typing Indicator */}
        {messages.length > 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.5 }}
            className="flex justify-end"
          >
            <div className="bg-white border border-[rgba(14,15,12,0.12157)] px-4 py-3 rounded-[16px]">
              <div className="flex gap-1">
                <motion.div
                  animate={{ opacity: [0.3, 1, 0.3] }}
                  transition={{ duration: 1.5, repeat: Infinity, delay: 0 }}
                  className="w-2 h-2 bg-[#6a6c6a] rounded-full"
                />
                <motion.div
                  animate={{ opacity: [0.3, 1, 0.3] }}
                  transition={{ duration: 1.5, repeat: Infinity, delay: 0.2 }}
                  className="w-2 h-2 bg-[#6a6c6a] rounded-full"
                />
                <motion.div
                  animate={{ opacity: [0.3, 1, 0.3] }}
                  transition={{ duration: 1.5, repeat: Infinity, delay: 0.4 }}
                  className="w-2 h-2 bg-[#6a6c6a] rounded-full"
                />
              </div>
            </div>
          </motion.div>
        )}
      </div>

      {/* Input */}
      <div className="bg-white border-t border-[rgba(14,15,12,0.12157)] p-4">
        <div className={`flex gap-3 items-end ${isRTL ? '' : 'flex-row-reverse'}`}>
          <button 
            className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center text-[#163300] flex-shrink-0"
            aria-label={t.attach}
            onClick={() => fileInputRef.current?.click()}
          >
            <Paperclip className="w-5 h-5" />
          </button>
          <button
            onClick={handleSendMessage}
            disabled={!message.trim()}
            className="w-10 h-10 rounded-full bg-[#163300] flex items-center justify-center text-white disabled:opacity-50 disabled:cursor-not-allowed flex-shrink-0"
            aria-label={language === 'ar' ? 'إرسال' : 'Send'}
          >
            <Send className="w-5 h-5" />
          </button>
          <div className="flex-1 relative">
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyPress={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              placeholder={t.typeMessage}
              dir={isRTL ? 'rtl' : 'ltr'}
              className={`w-full px-4 py-3 ${isRTL ? 'pr-12' : 'pl-12'} rounded-[20px] bg-[rgba(22,51,0,0.07843)] border border-transparent text-[#0e0f0c] placeholder:text-[#6a6c6a] focus:outline-none focus:ring-2 focus:ring-[#163300] focus:bg-white transition-all resize-none ${isRTL ? 'text-right' : 'text-left'} max-h-24`}
              style={{ fontFamily: 'Cairo, sans-serif' }}
              rows={1}
            />
            <button 
              className={`absolute ${isRTL ? 'left-3' : 'right-3'} top-1/2 -translate-y-1/2 w-8 h-8 rounded-full hover:bg-[rgba(22,51,0,0.12)] flex items-center justify-center text-[#6a6c6a] transition-colors`}
              aria-label={t.attach}
              onClick={() => fileInputRef.current?.click()}
            >
              <Paperclip className="w-5 h-5" />
            </button>
          </div>
        </div>
        <input
          type="file"
          ref={fileInputRef}
          className="hidden"
          onChange={handleFileChange}
          accept="image/*"
        />
      </div>

      {/* Image Zoom Modal */}
      <ImageZoomModal
        images={selectedImage ? [selectedImage] : []}
        initialIndex={0}
        isOpen={isZoomModalOpen}
        onClose={() => setIsZoomModalOpen(false)}
      />
    </div>
  );
}