import { motion } from "motion/react";
import { ChevronRight, TrendingUp, DollarSign, Calendar, Eye } from "lucide-react";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";

/**
 * SELLER WALLET SCREEN
 * 
 * Shows:
 * - Total earnings
 * - Available for withdrawal
 * - Sales statistics
 * - Withdrawal options
 * - Earnings history
 */

interface RabitSellerWalletScreenProps {
  onBack: () => void;
  onWithdraw?: () => void;
  onViewTransactions?: () => void;
}

export function RabitSellerWalletScreen({ 
  onBack,
  onWithdraw,
  onViewTransactions,
}: RabitSellerWalletScreenProps) {
  const { language, isRTL } = useLanguage();

  const content = {
    ar: {
      sellerWallet: "محفظة البائع",
      availableForWithdrawal: "متاح للسحب",
      totalEarnings: "إجمالي الأرباح",
      fees: "الرسوم",
      withdraw: "سحب",
      earningsHistory: "سجل الأرباح",
      recentSales: "المبيعات الأخيرة",
      completed: "مكتمل",
      pending: "قيد المعالجة",
      day: "يوم",
      days: "أيام",
      note: "ملاحظة:",
      holdNote: "يتم احتجاز المبلغ حتى تأكيد استلام المشتري للمنتج (٣-٥ أيام)",
    },
    en: {
      sellerWallet: "Seller Wallet",
      availableForWithdrawal: "Available for Withdrawal",
      totalEarnings: "Total Earnings",
      fees: "Fees",
      withdraw: "Withdraw",
      earningsHistory: "Earnings History",
      recentSales: "Recent Sales",
      completed: "Completed",
      pending: "Pending",
      day: "day",
      days: "days",
      note: "Note:",
      holdNote: "Amount is held until buyer confirms receipt (3-5 days)",
    },
  };
  const c = content[language];

  return (
    <div 
      className="min-h-screen bg-white" 
      style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }} 
        animate={{ opacity: 1, y: 0 }} 
        className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 flex items-center gap-4 z-10"
      >
        <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
          <ChevronRight className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-semibold text-[#0e0f0c]">{c.sellerWallet}</h1>
      </motion.div>
      
      <div className="p-6">
        {/* Balance Card - SELLER: Shows earnings */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-gradient-to-br from-[#163300] to-[#0d1f00] rounded-[16px] p-6 text-white mb-6"
        >
          <p className="text-sm opacity-80 mb-2">{c.availableForWithdrawal}</p>
          <h2 className="text-4xl font-bold mb-4">٢٬٣٥٠ ر.س</h2>
          
          {/* Earnings vs Expenses */}
          <div className="flex gap-4">
            <div className="flex-1 bg-white/10 rounded-[10px] p-3 text-center">
              <TrendingUp className="w-5 h-5 mx-auto mb-1" />
              <p className="text-xs">{c.totalEarnings}</p>
              <p className="font-semibold">٣٬٨٠٠ ر.س</p>
            </div>
            <div className="flex-1 bg-white/10 rounded-[10px] p-3 text-center">
              <DollarSign className="w-5 h-5 mx-auto mb-1" />
              <p className="text-xs">{c.fees}</p>
              <p className="font-semibold">٢٬٣٥٠ ر.س</p>
            </div>
          </div>
        </motion.div>

        {/* Action Buttons - SELLER SPECIFIC */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          <motion.button
            initial={{ opacity: 0, x: isRTL ? 20 : -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            onClick={onWithdraw}
            className="flex items-center justify-center gap-2 py-4 px-4 bg-[#163300] text-white rounded-[10px] font-medium hover:bg-[#1a3d00] transition-colors"
          >
            <DollarSign className="w-5 h-5" />
            <span>{c.withdraw}</span>
          </motion.button>
          <motion.button
            initial={{ opacity: 0, x: isRTL ? -20 : 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            onClick={onViewTransactions}
            className="flex items-center justify-center gap-2 py-4 px-4 bg-[rgba(22,51,0,0.1)] text-[#163300] rounded-[10px] font-medium hover:bg-[rgba(22,51,0,0.15)] transition-colors"
          >
            <Eye className="w-5 h-5" />
            <span>{c.earningsHistory}</span>
          </motion.button>
        </div>
        
        {/* Recent Sales */}
        <div>
          <h3 className={`font-semibold text-[#0e0f0c] mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>{c.recentSales}</h3>
          <div className="space-y-3">
            {[
              { id: 1, titleAr: "آيفون ١٤ برو ماكس", titleEn: "iPhone 14 Pro Max", amount: 4500, days: 1, status: "completed" },
              { id: 2, titleAr: "ساعة أبل Series 8", titleEn: "Apple Watch Series 8", amount: 1800, days: 3, status: "pending" },
              { id: 3, titleAr: "سماعات AirPods Pro", titleEn: "AirPods Pro", amount: 650, days: 5, status: "completed" },
            ].map((sale) => (
              <motion.div 
                key={sale.id}
                initial={{ opacity: 0, x: isRTL ? 20 : -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: sale.id * 0.1 }}
                className="flex justify-between items-center p-4 bg-[rgba(22,51,0,0.07843)] rounded-[10px] border border-[rgba(14,15,12,0.12157)]"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#163300]/10 flex items-center justify-center">
                    <Calendar className="w-5 h-5 text-[#163300]" />
                  </div>
                  <div className={isRTL ? 'text-right' : 'text-left'}>
                    <p className="font-medium text-[#0e0f0c]">{language === 'ar' ? sale.titleAr : sale.titleEn}</p>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-[#6a6c6a]">
                        {language === 'ar' 
                          ? `منذ ${sale.days} ${sale.days === 1 ? c.day : c.days}`
                          : `${sale.days} ${sale.days === 1 ? c.day : c.days} ago`
                        }
                      </span>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${
                        sale.status === "completed" 
                          ? "bg-[#008026]/10 text-[#008026]" 
                          : "bg-[#df8700]/10 text-[#df8700]"
                      }`}>
                        {sale.status === "completed" ? c.completed : c.pending}
                      </span>
                    </div>
                  </div>
                </div>
                <span className="font-bold text-[#008026]">+{sale.amount} ر.س</span>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Info Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mt-6 p-4 bg-[#e2f6d5] rounded-[10px] border border-[#163300]/20"
        >
          <p className={`text-sm text-[#163300] ${isRTL ? 'text-right' : 'text-left'}`}>
            💰 <strong>{c.note}</strong> {c.holdNote}
          </p>
        </motion.div>
      </div>
    </div>
  );
}