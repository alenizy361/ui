import { motion } from "motion/react";
import { ChevronRight, Shield, AlertTriangle, Database, Lock, Eye, Share2, FileText } from "lucide-react";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";

interface RabitPrivacyPolicyScreenProps {
  onBack: () => void;
}

export function RabitPrivacyPolicyScreen({ onBack }: RabitPrivacyPolicyScreenProps) {
  const { language, isRTL } = useLanguage();

  const content = {
    ar: {
      title: 'سياسة الخصوصية',
      heroTitle: 'خصوصيتك مهمة بالنسبة لنا',
      lastUpdated: 'آخر تحديث',
      importantNotice: 'ملاحظة مهمة',
      noticeText: 'نحن نحترم خصوصيتك ونلتزم بحماية بياناتك الشخصية وفقًا لأنظمة حماية البيانات في المملكة العربية السعودية.',
      dataWeCollect: 'البيانات التي نجمعها',
      personalInfo: 'المعلومات الشخصية:',
      fullName: 'الاسم الكامل',
      phoneNumber: 'رقم الجوال',
      email: 'البريد الإلكتروني',
      address: 'العنوان البريدي',
      city: 'المدينة',
      transactionData: 'بيانات المعاملات:',
      purchaseDates: 'تواريخ الشراء والبيع',
      orderDetails: 'تفاصيل الطلبات',
      paymentInfo: 'معلومات الدفع (مشفرة)',
      reviews: 'التقييمات والمراجعات',
      usageData: 'بيانات الاستخدام:',
      browsingHistory: 'سجل التصفح داخل المنصة',
      favorites: 'المنتجات المفضلة',
      searchOps: 'عمليات البحث',
      ipDevice: 'عنوان IP ونوع الجهاز',
      howWeUse: 'كيف نستخدم بياناتك',
      useIntro: 'نستخدم معلوماتك للأغراض التالية:',
      completeTrans: 'إتمام عمليات البيع والشراء',
      sendNotif: 'إرسال إشعارات حالة الطلب',
      improveExp: 'تحسين تجربة المستخدم',
      preventFraud: 'منع الاحتيال والأنشطة المشبوهة',
      techSupport: 'الدعم الفني',
      marketing: 'إرسال عروض تسويقية (يمكن إلغاء الاشتراك)',
      legalComp: 'الامتثال للقوانين والأنظمة',
      dataSharing: 'مشاركة البيانات',
      noSell: 'نحن لا نبيع بياناتك الشخصية لأي طرف ثالث.',
      buyersSellers: 'بين المشترين والبائعين:',
      orderComplete: 'عند إتمام الطلب، يتم مشاركة الاسم ورقم الجوال والعنوان',
      serviceProviders: 'مزودي الخدمات:',
      paymentGateways: 'بوابات الدفع (معلومات مشفرة)',
      shipping: 'شركات الشحن',
      analytics: 'خدمات التحليلات',
      security: 'خدمات الأمان',
      govEntities: 'الجهات الحكومية:',
      whenRequired: 'عند الطلب من الجهات المختصة',
      dataSecurity: 'أمان البيانات',
      securityMeasures: 'نتخذ إجراءات أمنية صارمة لحماية بياناتك:',
      sslEncryption: 'تشفير SSL/TLS لجميع الاتصالات',
      twoFactor: 'المصادقة الثنائية',
      firewalls: 'جدران حماية متقدمة',
      monitoring: 'مراقبة مستمرة للأنشطة المشبوهة',
      backups: 'نسخ احتياطية يومية',
      accessControl: 'قيود صارمة على الوصول الداخلي',
      yourRights: 'حقوقك',
      rightsIntro: 'لديك الحق في:',
      accessData: 'الوصول إلى بياناتك الشخصية',
      updateInfo: 'تحديث معلوماتك',
      deleteAccount: 'حذف حسابك',
      unsubscribe: 'إلغاء الاشتراك من الرسائل التسويقية',
      exportData: 'تصدير نسخة من بياناتك',
      objectProcessing: 'الاعتراض على معالجة البيانات',
      exerciseRights: 'لممارسة حقوقك، يرجى التواصل معنا على: privacy@rabit.sa',
      cookies: 'ملفات تعريف الارتباط (Cookies)',
      cookiesIntro: 'نستخدم ملفات تعريف الارتباط لـ:',
      rememberLogin: 'تذكر تسجيل دخولك',
      savePreferences: 'حفظ تفضيلاتك',
      analyzePlatform: 'تحليل أداء المنصة',
      personalizedAds: 'عرض إعلانات مخصصة',
      disableCookies: 'يمكنك تعطيل ملفات تعريف الارتباط من إعدادات المتصفح، لكن قد يؤثر ذلك على بعض الوظائف.',
      childrenPrivacy: 'خصوصية الأطفال',
      notForChildren: 'منصة رابِت غير مخصصة للأطفال دون سن 18 عامًا. إذا كنت تحت 18 عامًا، يجب عليك استخدام المنصة تحت إشراف ولي الأمر.',
      noChildData: 'نحن لا نجمع بيانات الأطفال عن قصد. إذا اكتشفنا أننا جمعنا بيانات طفل، سنقوم بحذفها فورًا.',
      changesToPolicy: 'التغييرات على السياسة',
      policyUpdates: 'قد نقوم بتحديث هذه السياسة من وقت لآخر. سنخطرك بأي تغييرات عبر:',
      emailNotif: 'البريد الإلكتروني',
      inAppNotif: 'إشعار داخل المنصة',
      updateDate: 'تحديث تاريخ "آخر تحديث"',
      contactUs: 'اتصل بنا',
      questionsText: 'لديك أسئلة حول خصوصيتك؟ تواصل معنا:',
    },
    en: {
      title: 'Privacy Policy',
      heroTitle: 'Your Privacy is Important to Us',
      lastUpdated: 'Last Updated',
      importantNotice: 'Important Notice',
      noticeText: 'We respect your privacy and are committed to protecting your personal data in accordance with Saudi Arabia data protection regulations.',
      dataWeCollect: 'Data We Collect',
      personalInfo: 'Personal Information:',
      fullName: 'Full Name',
      phoneNumber: 'Phone Number',
      email: 'Email',
      address: 'Postal Address',
      city: 'City',
      transactionData: 'Transaction Data:',
      purchaseDates: 'Purchase and sale dates',
      orderDetails: 'Order details',
      paymentInfo: 'Payment information (encrypted)',
      reviews: 'Reviews and ratings',
      usageData: 'Usage Data:',
      browsingHistory: 'Browsing history within platform',
      favorites: 'Favorite products',
      searchOps: 'Search operations',
      ipDevice: 'IP address and device type',
      howWeUse: 'How We Use Your Data',
      useIntro: 'We use your information for the following purposes:',
      completeTrans: 'Completing buy and sell transactions',
      sendNotif: 'Sending order status notifications',
      improveExp: 'Improving user experience',
      preventFraud: 'Preventing fraud and suspicious activities',
      techSupport: 'Technical support',
      marketing: 'Sending marketing offers (you can unsubscribe)',
      legalComp: 'Compliance with laws and regulations',
      dataSharing: 'Data Sharing',
      noSell: 'We do not sell your personal data to any third party.',
      buyersSellers: 'Between Buyers and Sellers:',
      orderComplete: 'When an order is completed, name, phone number, and address are shared',
      serviceProviders: 'Service Providers:',
      paymentGateways: 'Payment gateways (encrypted information)',
      shipping: 'Shipping companies',
      analytics: 'Analytics services',
      security: 'Security services',
      govEntities: 'Government Entities:',
      whenRequired: 'When requested by relevant authorities',
      dataSecurity: 'Data Security',
      securityMeasures: 'We take strict security measures to protect your data:',
      sslEncryption: 'SSL/TLS encryption for all communications',
      twoFactor: 'Two-factor authentication',
      firewalls: 'Advanced firewalls',
      monitoring: 'Continuous monitoring for suspicious activities',
      backups: 'Daily backups',
      accessControl: 'Strict internal access controls',
      yourRights: 'Your Rights',
      rightsIntro: 'You have the right to:',
      accessData: 'Access your personal data',
      updateInfo: 'Update your information',
      deleteAccount: 'Delete your account',
      unsubscribe: 'Unsubscribe from marketing messages',
      exportData: 'Export a copy of your data',
      objectProcessing: 'Object to data processing',
      exerciseRights: 'To exercise your rights, please contact us at: privacy@rabit.sa',
      cookies: 'Cookies',
      cookiesIntro: 'We use cookies to:',
      rememberLogin: 'Remember your login',
      savePreferences: 'Save your preferences',
      analyzePlatform: 'Analyze platform performance',
      personalizedAds: 'Display personalized ads',
      disableCookies: 'You can disable cookies from your browser settings, but this may affect some functionality.',
      childrenPrivacy: 'Children\'s Privacy',
      notForChildren: 'Rabit Platform is not intended for children under 18 years old. If you are under 18, you must use the platform under parental supervision.',
      noChildData: 'We do not intentionally collect children\'s data. If we discover we have collected a child\'s data, we will delete it immediately.',
      changesToPolicy: 'Changes to Policy',
      policyUpdates: 'We may update this policy from time to time. We will notify you of any changes via:',
      emailNotif: 'Email',
      inAppNotif: 'In-platform notification',
      updateDate: 'Updating the "Last Updated" date',
      contactUs: 'Contact Us',
      questionsText: 'Have questions about your privacy? Contact us:',
    },
  };

  const c = content[language];

  return (
    <div
      className="min-h-screen bg-white"
      style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white/95 backdrop-blur-lg border-b border-[rgba(0,0,0,0.06)] px-6 py-4 z-10 shadow-sm"
      >
        <div className="flex items-center justify-between">
          <button
            onClick={onBack}
            className="w-11 h-11 rounded-2xl bg-[#f0fde8] border border-[rgba(22,51,0,0.1)] flex items-center justify-center text-[#163300] transition-all duration-200 hover:bg-[#e2fad5] active:scale-95"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-semibold text-[#0a0b09]">{c.title}</h1>
          <div className="w-11" /> {/* Spacer */}
        </div>
      </motion.div>

      {/* Content */}
      <div className="p-6 space-y-6">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="bg-gradient-to-br from-[#163300] to-[#0f2409] rounded-3xl p-8 text-center shadow-xl"
        >
          <div className="w-20 h-20 rounded-3xl bg-[#9fe870] flex items-center justify-center mx-auto mb-4">
            <Shield className="w-10 h-10 text-[#163300]" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">{c.heroTitle}</h2>
          <p className="text-white/80 text-sm">
            {c.lastUpdated}: 26 ديسمبر 2024
          </p>
        </motion.div>

        {/* Important Notice */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-blue-50 border border-blue-200 rounded-2xl p-6"
        >
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-6 h-6 text-blue-600 flex-shrink-0 mt-1" />
            <div className="text-sm text-blue-900 leading-relaxed">
              <p className="font-semibold mb-2">{c.importantNotice}</p>
              <p>
                {c.noticeText}
              </p>
            </div>
          </div>
        </motion.div>

        {/* Section 1: Data Collection */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white rounded-2xl border border-[rgba(0,0,0,0.06)] p-6 shadow-card"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-2xl bg-[#f0fde8] flex items-center justify-center">
              <Database className="w-6 h-6 text-[#163300]" />
            </div>
            <h3 className="text-lg font-bold text-[#0a0b09]">{c.dataWeCollect}</h3>
          </div>
          <div className="space-y-3 text-[#6a6c6a] text-sm leading-relaxed">
            <p className="font-semibold text-[#0a0b09]">{c.personalInfo}</p>
            <ul className="list-disc list-inside space-y-2 pr-4">
              <li>{c.fullName}</li>
              <li>{c.phoneNumber}</li>
              <li>{c.email}</li>
              <li>{c.address}</li>
              <li>{c.city}</li>
            </ul>

            <p className="font-semibold text-[#0a0b09] pt-3">{c.transactionData}</p>
            <ul className="list-disc list-inside space-y-2 pr-4">
              <li>{c.purchaseDates}</li>
              <li>{c.orderDetails}</li>
              <li>{c.paymentInfo}</li>
              <li>{c.reviews}</li>
            </ul>

            <p className="font-semibold text-[#0a0b09] pt-3">{c.usageData}</p>
            <ul className="list-disc list-inside space-y-2 pr-4">
              <li>{c.browsingHistory}</li>
              <li>{c.favorites}</li>
              <li>{c.searchOps}</li>
              <li>{c.ipDevice}</li>
            </ul>
          </div>
        </motion.div>

        {/* Section 2: How We Use Data */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-white rounded-2xl border border-[rgba(0,0,0,0.06)] p-6 shadow-card"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-2xl bg-[#f0fde8] flex items-center justify-center">
              <Eye className="w-6 h-6 text-[#163300]" />
            </div>
            <h3 className="text-lg font-bold text-[#0a0b09]">{c.howWeUse}</h3>
          </div>
          <div className="space-y-3 text-[#6a6c6a] text-sm leading-relaxed">
            <p>{c.useIntro}</p>
            <ul className="list-disc list-inside space-y-2 pr-4">
              <li>{c.completeTrans}</li>
              <li>{c.sendNotif}</li>
              <li>{c.improveExp}</li>
              <li>{c.preventFraud}</li>
              <li>{c.techSupport}</li>
              <li>{c.marketing}</li>
              <li>{c.legalComp}</li>
            </ul>
          </div>
        </motion.div>

        {/* Section 3: Data Sharing */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-white rounded-2xl border border-[rgba(0,0,0,0.06)] p-6 shadow-card"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-2xl bg-[#f0fde8] flex items-center justify-center">
              <Share2 className="w-6 h-6 text-[#163300]" />
            </div>
            <h3 className="text-lg font-bold text-[#0a0b09]">{c.dataSharing}</h3>
          </div>
          <div className="space-y-3 text-[#6a6c6a] text-sm leading-relaxed">
            <p>{c.noSell}</p>
            
            <p className="font-semibold text-[#0a0b09]">{c.buyersSellers}</p>
            <ul className="list-disc list-inside space-y-2 pr-4">
              <li>{c.orderComplete}</li>
              <li>{c.fullName}, {c.phoneNumber}, {c.address}</li>
            </ul>

            <p className="font-semibold text-[#0a0b09] pt-3">{c.serviceProviders}</p>
            <ul className="list-disc list-inside space-y-2 pr-4">
              <li>{c.paymentGateways}</li>
              <li>{c.shipping}</li>
              <li>{c.analytics}</li>
              <li>{c.security}</li>
            </ul>

            <p className="font-semibold text-[#0a0b09] pt-3">{c.govEntities}</p>
            <ul className="list-disc list-inside space-y-2 pr-4">
              <li>{c.whenRequired}</li>
              <li>{c.legalComp}</li>
            </ul>
          </div>
        </motion.div>

        {/* Section 4: Data Security */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="bg-white rounded-2xl border border-[rgba(0,0,0,0.06)] p-6 shadow-card"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-2xl bg-[#f0fde8] flex items-center justify-center">
              <Lock className="w-6 h-6 text-[#163300]" />
            </div>
            <h3 className="text-lg font-bold text-[#0a0b09]">{c.dataSecurity}</h3>
          </div>
          <div className="space-y-3 text-[#6a6c6a] text-sm leading-relaxed">
            <p>{c.securityMeasures}</p>
            <ul className="list-disc list-inside space-y-2 pr-4">
              <li>{c.sslEncryption}</li>
              <li>{c.paymentInfo}</li>
              <li>{c.twoFactor}</li>
              <li>{c.firewalls}</li>
              <li>{c.monitoring}</li>
              <li>{c.backups}</li>
              <li>{c.accessControl}</li>
            </ul>
          </div>
        </motion.div>

        {/* Section 5: Your Rights */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="bg-gradient-to-br from-[#f0fde8] to-[#e2fad5] rounded-2xl p-6"
        >
          <h3 className="text-lg font-bold text-[#163300] mb-4">{c.yourRights}</h3>
          <div className="space-y-2 text-[#163300] text-sm">
            <p>{c.rightsIntro}</p>
            <ul className="list-disc list-inside space-y-2 pr-4">
              <li>{c.accessData}</li>
              <li>{c.updateInfo}</li>
              <li>{c.deleteAccount}</li>
              <li>{c.unsubscribe}</li>
              <li>{c.exportData}</li>
              <li>{c.objectProcessing}</li>
            </ul>
            <p className="pt-3 font-semibold">
              {c.exerciseRights}
            </p>
          </div>
        </motion.div>

        {/* Section 6: Cookies */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="bg-white rounded-2xl border border-[rgba(0,0,0,0.06)] p-6 shadow-card"
        >
          <h3 className="text-lg font-bold text-[#0a0b09] mb-4">{c.cookies}</h3>
          <div className="space-y-3 text-[#6a6c6a] text-sm leading-relaxed">
            <p>{c.cookiesIntro}</p>
            <ul className="list-disc list-inside space-y-2 pr-4">
              <li>{c.rememberLogin}</li>
              <li>{c.savePreferences}</li>
              <li>{c.analyzePlatform}</li>
              <li>{c.personalizedAds}</li>
            </ul>
            <p>{c.disableCookies}</p>
          </div>
        </motion.div>

        {/* Section 7: Children */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9 }}
          className="bg-white rounded-2xl border border-[rgba(0,0,0,0.06)] p-6 shadow-card"
        >
          <h3 className="text-lg font-bold text-[#0a0b09] mb-4">{c.childrenPrivacy}</h3>
          <div className="space-y-3 text-[#6a6c6a] text-sm leading-relaxed">
            <p>
              {c.notForChildren}
            </p>
            <p>
              {c.noChildData}
            </p>
          </div>
        </motion.div>

        {/* Section 8: Changes */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.0 }}
          className="bg-white rounded-2xl border border-[rgba(0,0,0,0.06)] p-6 shadow-card"
        >
          <h3 className="text-lg font-bold text-[#0a0b09] mb-4">{c.changesToPolicy}</h3>
          <div className="space-y-3 text-[#6a6c6a] text-sm leading-relaxed">
            <p>
              {c.policyUpdates}
            </p>
            <ul className="list-disc list-inside space-y-2 pr-4">
              <li>{c.emailNotif}</li>
              <li>{c.inAppNotif}</li>
              <li>{c.updateDate}</li>
            </ul>
          </div>
        </motion.div>

        {/* Contact Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.1 }}
          className="bg-gradient-to-br from-[#163300] to-[#0f2409] rounded-2xl p-6 text-center"
        >
          <h3 className="text-lg font-bold text-white mb-2">{c.contactUs}</h3>
          <p className="text-white/80 text-sm mb-4">
            {c.questionsText}
          </p>
          <div className="space-y-2 text-sm text-white">
            <p>📧 privacy@rabit.sa</p>
            <p>📱 +966 50 123 4567</p>
            <p>📍 الرياض، المملكة العربية السعودية</p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}