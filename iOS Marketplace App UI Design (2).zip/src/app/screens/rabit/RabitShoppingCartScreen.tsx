import { motion, AnimatePresence } from "motion/react";
import { ChevronRight, Trash2, Plus, Minus, ShoppingBag, Tag } from "lucide-react";
import { useLanguage } from "../../contexts/LanguageContext";
import { WiseButton } from "../../components/WiseButton";
import { toast } from "sonner";
import { useApp } from "../../contexts/AppContext";
import { triggerHaptic } from "../../utils/haptics";

interface RabitShoppingCartScreenProps {
  onBack: () => void;
  onCheckout: (items: any[]) => void;
  onProductClick: (productId: string) => void;
}

export function RabitShoppingCartScreen({
  onBack,
  onCheckout,
  onProductClick,
}: RabitShoppingCartScreenProps) {
  const { language, isRTL } = useLanguage();
  const { cart, removeFromCart, updateQuantity, clearCart, cartTotal, cartItemCount } = useApp();

  const content = {
    ar: {
      cart: "السلة",
      emptyCart: "السلة فارغة",
      emptyCartDesc: "ابدأ بإضافة منتجات إلى سلتك",
      continueShopping: "تابع التسوق",
      remove: "حذف",
      subtotal: "المجموع الفرعي",
      platformFee: "رسوم المنصة",
      shipping: "الشحن",
      total: "الإجمالي",
      checkout: "إتمام الشراء",
      items: "منتجات",
      item: "منتج",
      free: "مجاناً",
      seller: "البائع",
      qty: "الكمية",
      removeItem: "تم حذف المنتج",
      sar: "ر.س",
    },
    en: {
      cart: "Cart",
      emptyCart: "Cart is Empty",
      emptyCartDesc: "Start adding products to your cart",
      continueShopping: "Continue Shopping",
      remove: "Remove",
      subtotal: "Subtotal",
      platformFee: "Platform Fee",
      shipping: "Shipping",
      total: "Total",
      checkout: "Checkout",
      items: "items",
      item: "item",
      free: "Free",
      seller: "Seller",
      qty: "Qty",
      removeItem: "Item removed",
      sar: "SAR",
    },
  };
  const c = content[language];

  const handleRemoveItem = (productId: string) => {
    triggerHaptic("medium");
    removeFromCart(productId);
    toast.success(c.removeItem, {
      duration: 2000,
      position: isRTL ? "top-left" : "top-right",
    });
  };

  const handleUpdateQuantity = (productId: string, newQuantity: number) => {
    triggerHaptic("light");
    updateQuantity(productId, newQuantity);
  };

  // Calculate totals
  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const platformFee = subtotal * 0.025; // 2.5% platform fee
  const shipping = 0; // Free shipping
  const total = subtotal + platformFee + shipping;

  if (cartItemCount === 0) {
    return (
      <div
        className="min-h-screen bg-[#fafafa] flex flex-col"
        style={{ fontFamily: language === "ar" ? "Cairo, sans-serif" : "system-ui, -apple-system, sans-serif" }}
        dir={isRTL ? "rtl" : "ltr"}
      >
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 z-10"
        >
          <div className="flex items-center justify-between">
            <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
              <ChevronRight className={`w-6 h-6 text-[#0e0f0c] ${isRTL ? "" : "rotate-180"}`} />
            </button>
            <h1 className="text-xl font-semibold text-[#0e0f0c]">{c.cart}</h1>
            <div className="w-10" />
          </div>
        </motion.div>

        <div className="flex-1 flex flex-col items-center justify-center p-6">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 200, damping: 15 }}
            className="w-24 h-24 bg-[rgba(22,51,0,0.12157)] rounded-full flex items-center justify-center mb-6"
          >
            <ShoppingBag className="w-12 h-12 text-[#163300]" />
          </motion.div>
          <h3 className="text-xl font-bold text-[#0e0f0c] mb-2">{c.emptyCart}</h3>
          <p className="text-sm text-[#6a6c6a] text-center mb-6">{c.emptyCartDesc}</p>
          <WiseButton onClick={onBack} variant="primary">
            {c.continueShopping}
          </WiseButton>
        </div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen bg-[#fafafa] pb-64"
      style={{ fontFamily: language === "ar" ? "Cairo, sans-serif" : "system-ui, -apple-system, sans-serif" }}
      dir={isRTL ? "rtl" : "ltr"}
    >
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 z-10"
      >
        <div className="flex items-center justify-between">
          <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
            <ChevronRight className={`w-6 h-6 text-[#0e0f0c] ${isRTL ? "" : "rotate-180"}`} />
          </button>
          <h1 className="text-xl font-semibold text-[#0e0f0c]">
            {c.cart} ({cartItemCount} {cartItemCount === 1 ? c.item : c.items})
          </h1>
          <div className="w-10" />
        </div>
      </motion.div>

      <div className="p-6 space-y-4">
        {/* Cart Items */}
        <AnimatePresence>
          {cart.map((item, index) => (
            <motion.div
              key={item.productId}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, x: isRTL ? 100 : -100 }}
              transition={{ delay: index * 0.05 }}
              className="bg-white rounded-[12px] p-4"
            >
              <div className="flex gap-3 mb-3">
                {/* Image */}
                <button
                  onClick={() => onProductClick(item.productId)}
                  className="w-20 h-20 rounded-[8px] overflow-hidden flex-shrink-0"
                >
                  <img src={item.image} alt={language === 'ar' ? item.titleAr : item.title} className="w-full h-full object-cover" />
                </button>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <button
                    onClick={() => onProductClick(item.productId)}
                    className={`font-semibold text-[#0e0f0c] mb-1 line-clamp-2 hover:text-[#163300] transition-colors ${
                      isRTL ? "text-right" : "text-left"
                    }`}
                  >
                    {language === 'ar' ? item.titleAr : item.title}
                  </button>
                  <p className="text-xs text-[#6a6c6a] mb-2">
                    {c.seller}: {language === 'ar' ? item.sellerAr : item.seller}
                  </p>
                  <p className="font-bold text-[#163300]">
                    {item.price.toLocaleString()} {c.sar}
                  </p>
                </div>
              </div>

              {/* Quantity & Remove */}
              <div className="flex items-center justify-between pt-3 border-t border-[rgba(14,15,12,0.12157)]">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleUpdateQuantity(item.productId, item.quantity - 1)}
                    disabled={item.quantity <= 1}
                    className="w-8 h-8 rounded-full bg-[rgba(22,51,0,0.12157)] flex items-center justify-center disabled:opacity-50"
                  >
                    <Minus className="w-4 h-4 text-[#163300]" />
                  </button>
                  <span className="w-8 text-center font-semibold text-[#0e0f0c]">
                    {item.quantity}
                  </span>
                  <button
                    onClick={() => handleUpdateQuantity(item.productId, item.quantity + 1)}
                    className="w-8 h-8 rounded-full bg-[rgba(22,51,0,0.12157)] flex items-center justify-center"
                  >
                    <Plus className="w-4 h-4 text-[#163300]" />
                  </button>
                </div>

                <button
                  onClick={() => handleRemoveItem(item.productId)}
                  className="flex items-center gap-2 text-[#cb272f] text-sm font-medium hover:text-[#a01f26] transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>{c.remove}</span>
                </button>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Fixed Bottom Summary */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-[rgba(14,15,12,0.12157)] px-6 py-4 max-w-[430px] mx-auto">
        {/* Summary */}
        <div className="space-y-2 mb-4">
          <div className="flex items-center justify-between text-sm">
            <span className="text-[#6a6c6a]">{c.subtotal}</span>
            <span className="font-semibold text-[#0e0f0c]">
              {subtotal.toLocaleString()} {c.sar}
            </span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-[#6a6c6a]">{c.platformFee} (2.5%)</span>
            <span className="font-semibold text-[#0e0f0c]">
              {platformFee.toFixed(2)} {c.sar}
            </span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-[#6a6c6a]">{c.shipping}</span>
            <span className="font-semibold text-[#008026]">{c.free}</span>
          </div>
          <div className="flex items-center justify-between pt-2 border-t border-[rgba(14,15,12,0.12157)]">
            <span className="font-bold text-[#0e0f0c]">{c.total}</span>
            <span className="text-xl font-bold text-[#163300]">
              {total.toLocaleString()} {c.sar}
            </span>
          </div>
        </div>

        <WiseButton onClick={() => onCheckout(cart)} variant="primary" fullWidth>
          {c.checkout}
        </WiseButton>
      </div>
    </div>
  );
}