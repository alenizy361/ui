import { motion } from "motion/react";
import { ChevronRight, TrendingUp, Package, Clock, Edit, Trash2, Eye, EyeOff, Star, MessageCircle, DollarSign, Edit2 } from "lucide-react";
import { useState, useEffect } from "react";
import { useLanguage } from "../../contexts/LanguageContext";
import { WiseButton } from "../../components/WiseButton";
import { QuantityManager } from "../../components/QuantityManager";
import { DeleteConfirmationDialog } from "../../components/DeleteConfirmationDialog";
import { getProducts, deleteProduct, updateProduct } from "../../services/products.service";
import { useAuth } from "../../contexts/AuthContext";
import { type RabitProduct } from "../../data/rabitProducts";
import { toast } from "sonner";

interface RabitSellerDashboardScreenProps {
  onBack: () => void;
  onOrdersClick: () => void;
  onProductsClick: () => void;
  onEarningsClick: () => void;
  onShipNow?: () => void;
  onEditProduct?: (product: any) => void;
  onDeleteProduct?: (id: string) => void;
}

// Skeleton component for loading state
function ProductCardSkeleton() {
  return (
    <div className="bg-white border border-[rgba(14,15,12,0.12157)] rounded-[12px] p-4 animate-pulse">
      <div className="h-4 bg-gray-200 rounded w-3/4 mb-3"></div>
      <div className="h-16 bg-gray-200 rounded mb-3"></div>
      <div className="flex gap-2">
        <div className="h-10 bg-gray-200 rounded flex-1"></div>
        <div className="h-10 bg-gray-200 rounded flex-1"></div>
      </div>
    </div>
  );
}

export function RabitSellerDashboardScreen({ 
  onBack,
  onOrdersClick,
  onProductsClick,
  onEarningsClick,
  onShipNow,
  onEditProduct,
  onDeleteProduct,
}: RabitSellerDashboardScreenProps) {
  const { language, isRTL } = useLanguage();
  const [activeTab, setActiveTab] = useState<"overview" | "sales" | "products">("overview");
  const [loading, setLoading] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [productToDelete, setProductToDelete] = useState<any>(null);
  const [sellerProducts, setSellerProducts] = useState<any[]>([]);
  const { accessToken } = useAuth();

  // Handle quantity update
  const handleQuantityUpdate = async (productId: string, newQuantity: number) => {
    // TODO: Connect to real backend when ready
    // - Pass user's accessToken
    // - Fetch real products from backend instead of rabitProducts mock data
    // - Update local state after successful API call
    // - Add error handling
    
    // DEMO MODE: Currently working with mock data
    // await productsAPI.updateQuantity(productId, newQuantity, accessToken);
    
    // Show success toast
    toast.success(
      language === 'ar' 
        ? `تم تحديث الكمية إلى ${newQuantity}` 
        : `Quantity updated to ${newQuantity}`,
      {
        duration: 2000,
      }
    );
    
    // If quantity is 0, show out of stock message
    if (newQuantity === 0) {
      toast.warning(
        language === 'ar'
          ? '⚠️ المنتج الآن غير متاح وسيتم إخفاؤه من النتائج'
          : '⚠️ Product is now out of stock and will be hidden from search',
        {
          duration: 3000,
        }
      );
    }
  };

  const content = {
    ar: {
      sellerDashboard: "لوحة البائع",
      overview: "نظرة عامة",
      sales: "المبيعات",
      products: "المنتجات",
      totalSales: "إجالي المبيعات",
      activeListings: "المنتجات النشطة",
      rating: "التقييم",
      messages: "الرسائل",
      revenue: "الإيرادات",
      platformFees: "رسوم المنصة",
      netRevenue: "صافي الإيرادات",
      quickActions: "إجراءات سريعة",
      manageProducts: "إدارة المنتجات",
      productPrice: "سعر المنتج",
      netProfit: "صافي الربح",
      availableQuantity: "الكمية المتاحة",
      edit: "تعديل",
      delete: "حذف",
    },
    en: {
      sellerDashboard: "Seller Dashboard",
      overview: "Overview",
      sales: "Sales",
      products: "Products",
      totalSales: "Total Sales",
      activeListings: "Active Listings",
      rating: "Rating",
      messages: "Messages",
      revenue: "Revenue",
      platformFees: "Platform Fees",
      netRevenue: "Net Revenue",
      quickActions: "Quick Actions",
      manageProducts: "Manage Products",
      productPrice: "Product Price",
      netProfit: "Net Profit",
      availableQuantity: "Available Quantity",
      edit: "Edit",
      delete: "Delete",
    },
  };
  const c = content[language];

  // Mock stats data
  const stats = {
    totalSales: 156,
    activeListings: 12,
    rating: 4.8,
    reviews: 89,
    revenue: 45600,
    platformFees: 2280,
    netRevenue: 43320,
  };

  // Mock sales data
  const sales = [
    {
      id: "ORD-001",
      productAr: "ساعة ذكية",
      orderNumber: "#12345",
      price: 1200,
      platformFee: 60,
      netAmount: 1140,
      status: "ready_to_ship",
      date: "منذ ساعة",
    },
    {
      id: "ORD-002",
      productAr: "سماعات لاسلكية",
      orderNumber: "#12346",
      price: 450,
      platformFee: 22.5,
      netAmount: 427.5,
      status: "shipped",
      date: "منذ 3 ساعات",
    },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "ready_to_ship":
        return "bg-[#9fe870] text-[#163300]";
      case "shipped":
        return "bg-blue-100 text-blue-800";
      case "delivered":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusTextAr = (status: string) => {
    switch (status) {
      case "ready_to_ship":
        return "جاهز للشحن";
      case "shipped":
        return "تم الشحن";
      case "delivered":
        return "تم التسليم";
      default:
        return status;
    }
  };

  useEffect(() => {
    const fetchProducts = async () => {
      setLoading(true);
      try {
        const result = await getProducts();
        if (result.success && result.products) {
          setSellerProducts(result.products);
        } else {
          console.error("Error fetching products:", result.error);
          toast.error(language === 'ar' ? 'فشل تحميل المنتجات' : 'Failed to load products');
          setSellerProducts([]);
        }
      } catch (error) {
        console.error("Error fetching products:", error);
        toast.error(language === 'ar' ? 'حدث خطأ أثناء تحميل المنتجات' : 'Error loading products');
        setSellerProducts([]);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  return (
    <div 
      className="min-h-screen bg-white" 
      style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      <motion.div 
        initial={{ opacity: 0, y: -20 }} 
        animate={{ opacity: 1, y: 0 }} 
        className="sticky top-0 bg-white/95 backdrop-blur-lg border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 z-10"
      >
        <div className="flex items-center gap-4 mb-4">
          <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
            <ChevronRight className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-semibold text-[#0e0f0c]">{c.sellerDashboard}</h1>
        </div>

        {/* Tabs */}
        <div className="flex gap-2">
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => {
              setActiveTab("overview");
              onEarningsClick();
            }}
            className={`flex-1 py-2 px-4 rounded-full text-sm font-medium transition-all ${
              activeTab === "overview"
                ? "bg-[#163300] text-white"
                : "bg-[rgba(22,51,0,0.07843)] text-[#6a6c6a]"
            }`}
          >
            {c.overview}
          </motion.button>
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => {
              setActiveTab("sales");
              onOrdersClick();
            }}
            className={`flex-1 py-2 px-4 rounded-full text-sm font-medium transition-all ${
              activeTab === "sales"
                ? "bg-[#163300] text-white"
                : "bg-[rgba(22,51,0,0.07843)] text-[#6a6c6a]"
            }`}
          >
            {c.sales}
          </motion.button>
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => {
              setActiveTab("products");
              onProductsClick();
            }}
            className={`flex-1 py-2 px-4 rounded-full text-sm font-medium transition-all ${
              activeTab === "products"
                ? "bg-[#163300] text-white"
                : "bg-[rgba(22,51,0,0.07843)] text-[#6a6c6a]"
            }`}
          >
            {c.products}
          </motion.button>
        </div>
      </motion.div>

      {/* Overview Tab */}
      {activeTab === "overview" && (
        <div className="p-6 space-y-6">
          {/* Stats Grid */}
          <div className="grid grid-cols-2 gap-3">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-[#163300] text-white rounded-[12px] p-4"
            >
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-5 h-5 text-[#9fe870]" />
                <p className="text-sm opacity-90">{c.totalSales}</p>
              </div>
              <p className="text-2xl font-bold">{stats.totalSales}</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 }}
              className="bg-[rgba(22,51,0,0.07843)] rounded-[12px] p-4"
            >
              <div className="flex items-center gap-2 mb-2">
                <Package className="w-5 h-5 text-[#163300]" />
                <p className="text-sm text-[#6a6c6a]">{c.activeListings}</p>
              </div>
              <p className="text-2xl font-bold text-[#163300]">{stats.activeListings}</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-[rgba(22,51,0,0.07843)] rounded-[12px] p-4"
            >
              <div className="flex items-center gap-2 mb-2">
                <Star className="w-5 h-5 text-[#df8700]" />
                <p className="text-sm text-[#6a6c6a]">{c.rating}</p>
              </div>
              <p className="text-2xl font-bold text-[#0e0f0c]">
                {stats.rating} <span className="text-sm text-[#6a6c6a]">({stats.reviews})</span>
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.25 }}
              className="bg-[rgba(22,51,0,0.07843)] rounded-[12px] p-4"
            >
              <div className="flex items-center gap-2 mb-2">
                <MessageCircle className="w-5 h-5 text-[#163300]" />
                <p className="text-sm text-[#6a6c6a]">{c.messages}</p>
              </div>
              <p className="text-2xl font-bold text-[#0e0f0c]">8</p>
            </motion.div>
          </div>

          {/* Revenue Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-gradient-to-br from-[#163300] to-[#0d1f00] text-white rounded-[12px] p-6"
          >
            <div className="flex items-center gap-2 mb-4">
              <DollarSign className="w-6 h-6 text-[#9fe870]" />
              <h3 className="text-lg font-semibold">{c.revenue}</h3>
            </div>
            
            <div className="space-y-3">
              <div className={`flex ${isRTL ? 'justify-between' : 'justify-between'} items-center`}>
                <p className="text-3xl font-bold">{stats.revenue.toLocaleString('ar-SA')} ر.س</p>
                <span className="text-sm opacity-75">{c.totalSales}</span>
              </div>
              
              <div className="h-px bg-white/20" />
              
              <div className={`flex ${isRTL ? 'justify-between' : 'justify-between'} items-center`}>
                <p className="text-xl font-bold text-[#cb272f]">- {stats.platformFees.toLocaleString('ar-SA')} ر.س</p>
                <span className="text-sm opacity-75">{c.platformFees} (5%)</span>
              </div>
              
              <div className="h-px bg-white/20" />
              
              <div className={`flex ${isRTL ? 'justify-between' : 'justify-between'} items-center`}>
                <p className="text-3xl font-bold text-[#9fe870]">{stats.netRevenue.toLocaleString('ar-SA')} ر.س</p>
                <span className="text-sm opacity-75">{c.netRevenue}</span>
              </div>
            </div>
          </motion.div>

          {/* Quick Actions */}
          <div className="space-y-3">
            <h3 className={`text-sm font-semibold text-[#0e0f0c] ${isRTL ? 'text-right' : 'text-left'}`}>{c.quickActions}</h3>
            <div className="grid grid-cols-2 gap-3">
              <button 
                onClick={() => console.log("Manage products clicked")}
                className={`py-3 px-4 bg-[rgba(22,51,0,0.07843)] rounded-[10px] text-sm font-medium text-[#0e0f0c] hover:bg-[rgba(22,51,0,0.12)] transition-colors ${isRTL ? 'text-right' : 'text-left'} flex items-center gap-2`}
              >
                <Package className="w-4 h-4 text-[#163300]" />
                <span>{c.manageProducts}</span>
              </button>
              <button 
                onClick={() => console.log("Messages clicked")}
                className={`py-3 px-4 bg-[rgba(22,51,0,0.07843)] rounded-[10px] text-sm font-medium text-[#0e0f0c] hover:bg-[rgba(22,51,0,0.12)] transition-colors ${isRTL ? 'text-right' : 'text-left'} flex items-center gap-2`}
              >
                <MessageCircle className="w-4 h-4 text-[#163300]" />
                <span>{c.messages}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Sales Tab */}
      {activeTab === "sales" && (
        <div className="p-6 space-y-4">
          {sales.map((sale, index) => (
            <motion.div
              key={sale.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="bg-white border border-[rgba(14,15,12,0.12157)] rounded-[12px] p-4"
            >
              <div className="flex justify-between items-start mb-3">
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(sale.status)}`}>
                  {getStatusTextAr(sale.status)}
                </span>
                <div className={`${isRTL ? 'text-right' : 'text-left'} flex-1 ${isRTL ? 'mr-3' : 'ml-3'}`}>
                  <p className="font-semibold text-[#0e0f0c] mb-1">{sale.productAr}</p>
                  <p className="text-xs text-[#6a6c6a]">{sale.orderNumber}</p>
                </div>
              </div>

              <div className="bg-[rgba(22,51,0,0.07843)] rounded-[8px] p-3 space-y-2 mb-3">
                <div className="flex justify-between text-sm">
                  <span className="font-bold text-[#163300]">{sale.price.toLocaleString('ar-SA')} ر.س</span>
                  <span className="text-[#6a6c6a]">{c.productPrice}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="font-medium text-[#cb272f]">- {sale.platformFee.toLocaleString('ar-SA')} ر.س</span>
                  <span className="text-[#6a6c6a]">{c.platformFees}</span>
                </div>
                <div className="h-px bg-[rgba(14,15,12,0.12157)]" />
                <div className="flex justify-between">
                  <span className="font-bold text-[#163300]">{sale.netAmount.toLocaleString('ar-SA')} ر.س</span>
                  <span className="text-sm text-[#6a6c6a]">{c.netProfit}</span>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  {sale.status === "ready_to_ship" && onShipNow && (
                    <WiseButton
                      onClick={onShipNow}
                      variant="primary"
                      size="sm"
                    >
                      شحن الآن
                    </WiseButton>
                  )}
                </div>
                <span className="text-xs text-[#6a6c6a]">{sale.date}</span>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {/* Products Tab */}
      {activeTab === "products" && (
        <div className="p-6 space-y-4">
          {loading ? (
            // Show skeleton while loading
            Array.from({ length: 4 }).map((_, index) => (
              <ProductCardSkeleton key={index} />
            ))
          ) : (
            sellerProducts.slice(0, 5).map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="bg-white border border-[rgba(14,15,12,0.12157)] rounded-[12px] p-4"
              >
                <div className="flex justify-between items-start mb-3">
                  <div className={`${isRTL ? 'text-right' : 'text-left'} flex-1 ${isRTL ? 'mr-3' : 'ml-3'}`}>
                    <p className="font-semibold text-[#0e0f0c] mb-1">{product.title || product.titleAr || product.titleEn || 'Untitled'}</p>
                    <p className="text-xs text-[#6a6c6a]">{product.id}</p>
                  </div>
                </div>

                <div className="bg-[rgba(22,51,0,0.07843)] rounded-[8px] p-3 space-y-2 mb-3">
                  <div className="flex justify-between text-sm">
                    <span className="font-bold text-[#163300]">{product.price.toLocaleString('ar-SA')} ر.س</span>
                    <span className="text-[#6a6c6a]">{c.productPrice}</span>
                  </div>
                  <div className="h-px bg-[rgba(14,15,12,0.12157)]" />
                  
                  {/* Quantity Manager - Interactive Stock Control */}
                  <div className={`flex ${isRTL ? 'justify-between' : 'justify-between'} items-center`}>
                    <QuantityManager
                      productId={product.id}
                      currentQuantity={product.quantity || product.stock || 0}
                      productName={product.title || product.titleAr || product.titleEn || 'Untitled'}
                      onQuantityChange={handleQuantityUpdate}
                      variant="compact"
                    />
                    <span className="text-sm text-[#6a6c6a]">{c.availableQuantity}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onEditProduct?.(product)}
                    className="flex-1 py-2 px-4 bg-[#163300] text-white rounded-[10px] text-sm font-medium hover:bg-[#1a3d00] transition-colors flex items-center justify-center gap-2"
                  >
                    <Edit2 className="w-4 h-4" />
                    <span>{c.edit}</span>
                  </button>
                  <button
                    onClick={() => {
                      setProductToDelete(product);
                      setDeleteDialogOpen(true);
                    }}
                    className="flex-1 py-2 px-4 bg-[#cb272f] text-white rounded-[10px] text-sm font-medium hover:bg-[#b02329] transition-colors flex items-center justify-center gap-2"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>{c.delete}</span>
                  </button>
                </div>
              </motion.div>
            ))
          )}
        </div>
      )}

      {/* Delete Confirmation Dialog */}
      <DeleteConfirmationDialog
        isOpen={deleteDialogOpen}
        onClose={() => setDeleteDialogOpen(false)}
        onConfirm={() => {
          if (productToDelete) {
            onDeleteProduct?.(productToDelete.id);
            setDeleteDialogOpen(false);
          }
        }}
        productName={productToDelete ? (language === 'ar' ? productToDelete.titleAr : productToDelete.titleEn || productToDelete.titleAr) : ''}
      />
    </div>
  );
}