import { motion } from "motion/react";
import { ChevronRight, Search, X, Clock } from "lucide-react";
import { useState, useEffect } from "react";
import { type RabitProduct } from "../../data/rabitProducts";
import { ProductCard } from "../../components/design-system";
import { useSearchHistory } from "../../hooks/useLocalStorage";
import { triggerHaptic } from "../../utils/haptics";
import { PullToRefresh } from "../../components/PullToRefresh";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";
import { searchProducts } from "../../services/products.service";
import { toast } from "sonner";

interface RabitSearchScreenProps {
  onBack: () => void;
  onProductClick: (product: RabitProduct) => void;
}

export function RabitSearchScreen({ onBack, onProductClick }: RabitSearchScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);
  const [search, setSearch] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [products, setProducts] = useState<RabitProduct[]>([]);
  const { history, addSearch, removeSearch, clearHistory } = useSearchHistory();

  const handleSearch = async (query: string) => {
    setSearch(query);
    if (query.trim()) {
      addSearch(query.trim());
      setIsSearching(true);
      
      try {
        const result = await searchProducts(query.trim());
        if (result.success && result.products) {
          setProducts(result.products);
        } else {
          toast.error(language === 'ar' ? 'فشل البحث عن المنتجات' : 'Failed to search products');
          setProducts([]);
        }
      } catch (error) {
        console.error('Search error:', error);
        toast.error(language === 'ar' ? 'حدث خطأ أثناء البحث' : 'Error searching products');
        setProducts([]);
      }
      
      setIsSearching(false);
    } else {
      setProducts([]);
    }
  };

  const handleHistoryClick = (query: string) => {
    triggerHaptic('selection');
    setSearch(query);
    addSearch(query);
  };

  const handleRemoveHistory = (query: string, e: React.MouseEvent) => {
    e.stopPropagation();
    triggerHaptic('light');
    removeSearch(query);
  };

  const handleClearHistory = () => {
    triggerHaptic('warning');
    clearHistory();
  };
  
  return (
    <div className="min-h-screen bg-[#fafafa]" style={{ fontFamily: 'Cairo, sans-serif' }}>
      {/* Modern Header with Glassmorphism */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white/95 backdrop-blur-lg border-b border-[rgba(0,0,0,0.06)] px-6 py-4 flex items-center gap-4 z-10"
        style={{ boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04)' }}
      >
        <button 
          onClick={onBack} 
          className="w-11 h-11 rounded-2xl bg-[#f0fde8] border border-[rgba(22,51,0,0.1)] flex items-center justify-center text-[#163300] transition-all duration-200 hover:bg-[#e2fad5] active:scale-95"
        >
          <ChevronRight className="w-6 h-6" />
        </button>
        <motion.div 
          className="flex-1 relative"
          initial={{ scale: 0.95 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.1 }}
        >
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#6a6c6a] pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => handleSearch(e.target.value)}
            placeholder="ابحث عن منتجات..."
            className="w-full h-14 bg-white border border-[rgba(0,0,0,0.1)] rounded-2xl pr-12 pl-4 text-right outline-none transition-all duration-200"
            style={{ 
              boxShadow: 'var(--shadow-card)',
            }}
            onFocus={(e) => {
              e.currentTarget.style.boxShadow = '0 0 0 3px rgba(159, 232, 112, 0.15)';
              e.currentTarget.style.borderColor = 'rgba(22, 51, 0, 0.3)';
            }}
            onBlur={(e) => {
              e.currentTarget.style.boxShadow = 'var(--shadow-card)';
              e.currentTarget.style.borderColor = 'rgba(0, 0, 0, 0.1)';
            }}
            autoFocus
          />
        </motion.div>
      </motion.div>
      
      <div className="p-6">
        {search.trim() === "" ? (
          <>
            {/* Search History */}
            {history.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="mb-8"
              >
                <div className="flex items-center justify-between mb-4">
                  <button
                    onClick={handleClearHistory}
                    className="text-sm text-[#ef4444] hover:underline"
                  >
                    مسح الكل
                  </button>
                  <h3 className="font-semibold text-[#0a0b09]">عمليات البحث الأخيرة</h3>
                </div>
                <div className="space-y-2">
                  {history.slice(0, 10).map((query, index) => (
                    <motion.button
                      key={query}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.05 }}
                      onClick={() => handleHistoryClick(query)}
                      className="w-full bg-white rounded-2xl p-4 flex items-center gap-3 text-right border border-[rgba(0,0,0,0.08)] hover:border-[#163300] transition-all duration-200 group"
                    >
                      <button
                        onClick={(e) => handleRemoveHistory(query, e)}
                        className="w-8 h-8 rounded-xl bg-[#f0fde8] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <X className="w-4 h-4 text-[#6a6c6a]" />
                      </button>
                      <span className="flex-1 text-[#0a0b09]">{query}</span>
                      <Clock className="w-5 h-5 text-[#6a6c6a]" />
                    </motion.button>
                  ))}
                </div>
              </motion.div>
            )}
            
            {/* Empty State */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-center mt-20"
            >
              <div className="w-20 h-20 mx-auto mb-4 rounded-2xl bg-[#f0fde8] flex items-center justify-center">
                <Search className="w-10 h-10 text-[#163300]" />
              </div>
              <h3 className="font-semibold text-[#0a0b09] mb-2">ابحث عن منتجات</h3>
              <p className="text-sm text-[#6a6c6a]">ابدأ البحث للعثور على ما تريد</p>
            </motion.div>
          </>
        ) : products.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.1 }}
            className="text-center mt-20"
          >
            <div className="w-20 h-20 mx-auto mb-4 rounded-2xl bg-[#f0fde8] flex items-center justify-center">
              <Search className="w-10 h-10 text-[#6a6c6a]" />
            </div>
            <h3 className="font-semibold text-[#0a0b09] mb-2">لا توجد نتائج</h3>
            <p className="text-sm text-[#6a6c6a]">جرب كلمات بحث أخرى</p>
          </motion.div>
        ) : (
          <>
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-sm text-[#6a6c6a] mb-4 text-right"
            >
              {products.length} نتيجة
            </motion.p>
            <div className="grid grid-cols-2 gap-4">
              {products.map((product, index) => (
                <ProductCard
                  key={product.id}
                  {...product}
                  onClick={() => onProductClick(product)}
                  delay={index * 0.05}
                />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}