import { motion } from "motion/react";
import { ChevronRight, Lock, Eye, EyeOff, CheckCircle } from "lucide-react";
import { useState } from "react";
import { triggerHaptic } from "../../utils/haptics";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";

interface RabitNewPasswordScreenProps {
  onBack: () => void;
  onSuccess: () => void;
}

export function RabitNewPasswordScreen({
  onBack,
  onSuccess,
}: RabitNewPasswordScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [errors, setErrors] = useState({ password: "", confirmPassword: "" });

  const passwordRequirements = [
    {
      labelAr: "8 أحرف على الأقل",
      labelEn: "At least 8 characters",
      test: (p: string) => p.length >= 8,
    },
    {
      labelAr: "حرف كبير واحد على الأقل",
      labelEn: "At least one uppercase letter",
      test: (p: string) => /[A-Z]/.test(p),
    },
    {
      labelAr: "حرف صغير واحد على الأقل",
      labelEn: "At least one lowercase letter",
      test: (p: string) => /[a-z]/.test(p),
    },
    {
      labelAr: "رقم واحد على الأقل",
      labelEn: "At least one number",
      test: (p: string) => /[0-9]/.test(p),
    },
  ];

  const validatePassword = (value: string) => {
    const allValid = passwordRequirements.every((req) => req.test(value));
    if (!value) {
      return language === "ar"
        ? "كلمة المرور مطلوبة"
        : "Password required";
    }
    if (!allValid) {
      return language === "ar"
        ? "كلمة المرور لا تستوفي جميع المتطلبات"
        : "Password doesn't meet requirements";
    }
    return "";
  };

  const handleSubmit = () => {
    const passwordError = validatePassword(password);
    const confirmError =
      password !== confirmPassword
        ? (language === "ar" ? "كلمتا المرور غير متطابقتين" : "Passwords don't match")
        : "";

    setErrors({
      password: passwordError,
      confirmPassword: confirmError,
    });

    if (!passwordError && !confirmError) {
      triggerHaptic("success");
      onSuccess();
    } else {
      triggerHaptic("error");
    }
  };

  return (
    <div
      className="min-h-screen bg-gradient-to-b from-[#fafafa] to-white"
      style={{
        fontFamily:
          language === "ar"
            ? "Cairo, sans-serif"
            : "system-ui, -apple-system, sans-serif",
      }}
      dir={isRTL ? "rtl" : "ltr"}
    >
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white/95 backdrop-blur-lg border-b border-[rgba(0,0,0,0.06)] px-6 py-4 z-10"
      >
        <div className="flex items-center justify-between">
          <button
            onClick={() => {
              triggerHaptic("light");
              onBack();
            }}
            className="w-11 h-11 rounded-2xl bg-[#f0fde8] border border-[rgba(22,51,0,0.1)] flex items-center justify-center text-[#163300] transition-all duration-200 hover:bg-[#e2fad5] active:scale-95"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-semibold text-[#0a0b09]">
            كلمة مرور جديدة
          </h1>
          <div className="w-11" /> {/* Spacer */}
        </div>
      </motion.div>

      {/* Content */}
      <div className="p-6 space-y-6">
        {/* Illustration */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="flex justify-center pt-4"
        >
          <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-[#f0fde8] to-[#e2fad5] flex items-center justify-center shadow-lg">
            <Lock className="w-12 h-12 text-[#163300]" />
          </div>
        </motion.div>

        {/* Description */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-center space-y-2"
        >
          <h2 className="text-xl font-bold text-[#0a0b09]">
            إنشاء كلمة مرور جديدة
          </h2>
          <p className="text-[#6a6c6a] text-sm leading-relaxed">
            اختر كلمة مرور قوية وآمنة لحسابك
          </p>
        </motion.div>

        {/* New Password Field */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="space-y-2"
        >
          <label className="text-sm font-medium text-[#0a0b09] block text-right">
            كلمة المرور الجديدة
          </label>
          <div className="relative">
            <input
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                setErrors({ ...errors, password: "" });
              }}
              placeholder="أدخل كلمة المرور"
              className={`w-full px-4 py-4 pr-12 bg-white border-2 rounded-2xl text-right transition-all duration-200 ${
                errors.password
                  ? "border-red-500"
                  : "border-[rgba(0,0,0,0.1)] focus:border-[#163300]"
              } focus:outline-none focus:shadow-md`}
            />
            <button
              onClick={() => {
                triggerHaptic("light");
                setShowPassword(!showPassword);
              }}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-[#6a6c6a] hover:text-[#163300] transition-colors"
            >
              {showPassword ? (
                <EyeOff className="w-5 h-5" />
              ) : (
                <Eye className="w-5 h-5" />
              )}
            </button>
          </div>
          {errors.password && (
            <motion.p
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-red-500 text-sm text-right"
            >
              {errors.password}
            </motion.p>
          )}
        </motion.div>

        {/* Password Requirements */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-[#fafafa] border border-[rgba(0,0,0,0.06)] rounded-2xl p-4 space-y-2"
        >
          <p className="text-sm font-medium text-[#0a0b09] text-right mb-3">
            متطلبات كلمة المرور:
          </p>
          {passwordRequirements.map((req, index) => {
            const isValid = password && req.test(password);
            return (
              <div key={index} className="flex items-center gap-2 justify-end">
                <span
                  className={`text-xs ${
                    isValid ? "text-[#008026]" : "text-[#6a6c6a]"
                  }`}
                >
                  {language === "ar" ? req.labelAr : req.labelEn}
                </span>
                <CheckCircle
                  className={`w-4 h-4 ${
                    isValid ? "text-[#008026]" : "text-[#d4d4d4]"
                  }`}
                />
              </div>
            );
          })}
        </motion.div>

        {/* Confirm Password Field */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="space-y-2"
        >
          <label className="text-sm font-medium text-[#0a0b09] block text-right">
            تأكيد كلمة المرور
          </label>
          <div className="relative">
            <input
              type={showConfirmPassword ? "text" : "password"}
              value={confirmPassword}
              onChange={(e) => {
                setConfirmPassword(e.target.value);
                setErrors({ ...errors, confirmPassword: "" });
              }}
              placeholder="أعد إدخال كلمة المرور"
              className={`w-full px-4 py-4 pr-12 bg-white border-2 rounded-2xl text-right transition-all duration-200 ${
                errors.confirmPassword
                  ? "border-red-500"
                  : "border-[rgba(0,0,0,0.1)] focus:border-[#163300]"
              } focus:outline-none focus:shadow-md`}
            />
            <button
              onClick={() => {
                triggerHaptic("light");
                setShowConfirmPassword(!showConfirmPassword);
              }}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-[#6a6c6a] hover:text-[#163300] transition-colors"
            >
              {showConfirmPassword ? (
                <EyeOff className="w-5 h-5" />
              ) : (
                <Eye className="w-5 h-5" />
              )}
            </button>
          </div>
          {errors.confirmPassword && (
            <motion.p
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-red-500 text-sm text-right"
            >
              {errors.confirmPassword}
            </motion.p>
          )}
        </motion.div>

        {/* Submit Button */}
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          whileTap={{ scale: 0.98 }}
          onClick={handleSubmit}
          disabled={!password || !confirmPassword}
          className={`w-full py-4 rounded-2xl font-semibold transition-all duration-200 ${
            password && confirmPassword
              ? "bg-gradient-to-br from-[#163300] to-[#0f2409] text-white shadow-lg hover:shadow-xl active:scale-98"
              : "bg-[#e5e5e5] text-[#a3a3a3] cursor-not-allowed"
          }`}
        >
          تأكيد وحفظ
        </motion.button>
      </div>
    </div>
  );
}