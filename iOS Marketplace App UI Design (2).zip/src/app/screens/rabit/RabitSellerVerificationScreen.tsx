import { motion } from "motion/react";
import { ChevronRight, Camera, Upload, CheckCircle2, AlertCircle, User } from "lucide-react";
import { useState } from "react";
import { useLanguage } from "../../contexts/LanguageContext";
import { WiseButton } from "../../components/WiseButton";
import { toast } from "sonner";

interface RabitSellerVerificationScreenProps {
  onBack: () => void;
  onVerificationSuccess: () => void;
}

export function RabitSellerVerificationScreen({
  onBack,
  onVerificationSuccess,
}: RabitSellerVerificationScreenProps) {
  const { language, isRTL } = useLanguage();
  const [step, setStep] = useState<"info" | "upload" | "review" | "success">("info");
  const [idFrontImage, setIdFrontImage] = useState<string | null>(null);
  const [idBackImage, setIdBackImage] = useState<string | null>(null);
  const [selfieImage, setSelfieImage] = useState<string | null>(null);
  const [fullName, setFullName] = useState("");
  const [idNumber, setIdNumber] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const content = {
    ar: {
      verification: "التحقق من الهوية",
      whyVerify: "لماذا نحتاج التحقق؟",
      whyVerifyDesc: "للحفاظ على أمان المنصة وبناء الثقة بين المستخدمين، نحتاج للتحقق من هوية البائعين.",
      benefits: "مزايا التحقق:",
      benefit1: "شارة التحقق على حسابك",
      benefit2: "زيادة ثقة المشترين",
      benefit3: "إمكانية رفع حدود البيع",
      benefit4: "أولوية في الدعم الفني",
      getStarted: "ابدأ التحقق",
      
      // Upload step
      uploadDocuments: "إرفاق المستندات",
      idFront: "الهوية الوطنية (الوجه الأمامي)",
      idBack: "الهوية الوطنية (الوجه الخلفي)",
      selfie: "صورة سيلفي",
      fullName: "الاسم الكامل",
      fullNamePlaceholder: "كما هو مكتوب في الهوية",
      idNumber: "رقم الهوية",
      idNumberPlaceholder: "10 أرقام",
      uploadPhoto: "رفع صورة",
      takePhoto: "التقاط صورة",
      requirements: "المتطلبات:",
      req1: "صورة واضحة للهوية الوطنية",
      req2: "الهوية يجب أن تكون سارية المفعول",
      req3: "صورة سيلفي واضحة للوجه",
      req4: "البيانات يجب أن تطابق الهوية",
      continue: "متابعة",
      
      // Review step
      reviewInfo: "مراجعة البيانات",
      reviewDesc: "تأكد من صحة جميع البيانات قبل الإرسال",
      frontID: "الهوية (أمامي)",
      backID: "الهوية (خلفي)",
      selfiePhoto: "صورة السيلفي",
      personalInfo: "المعلومات الشخصية",
      submit: "إرسال للمراجعة",
      
      // Success
      submitted: "تم إرسال الطلب!",
      successDesc: "سيتم مراجعة طلبك خلال 24-48 ساعة",
      whatNext: "ماذا بعد؟",
      next1: "سنقوم بمراجعة مستنداتك",
      next2: "ستصلك رسالة عند اكتمال المراجعة",
      next3: "بعد الموافقة، ستحصل على شارة التحقق",
      backToHome: "العودة للرئيسية",
      
      processing: "جاري المعالجة...",
      fillAllFields: "الرجاء إكمال جميع الحقول",
      uploadAllPhotos: "الرجاء رفع جميع الصور المطلوبة",
      invalidIdNumber: "رقم الهوية يجب أن يكون 10 أرقام",
    },
    en: {
      verification: "Identity Verification",
      whyVerify: "Why do we need verification?",
      whyVerifyDesc: "To maintain platform security and build trust among users, we need to verify seller identities.",
      benefits: "Verification Benefits:",
      benefit1: "Verified badge on your account",
      benefit2: "Increased buyer trust",
      benefit3: "Higher selling limits",
      benefit4: "Priority support",
      getStarted: "Get Started",
      
      // Upload step
      uploadDocuments: "Upload Documents",
      idFront: "National ID (Front)",
      idBack: "National ID (Back)",
      selfie: "Selfie Photo",
      fullName: "Full Name",
      fullNamePlaceholder: "As written on ID",
      idNumber: "ID Number",
      idNumberPlaceholder: "10 digits",
      uploadPhoto: "Upload Photo",
      takePhoto: "Take Photo",
      requirements: "Requirements:",
      req1: "Clear photo of National ID",
      req2: "ID must be valid",
      req3: "Clear selfie photo",
      req4: "Information must match ID",
      continue: "Continue",
      
      // Review step
      reviewInfo: "Review Information",
      reviewDesc: "Verify all information before submitting",
      frontID: "Front ID",
      backID: "Back ID",
      selfiePhoto: "Selfie Photo",
      personalInfo: "Personal Information",
      submit: "Submit for Review",
      
      // Success
      submitted: "Request Submitted!",
      successDesc: "Your request will be reviewed within 24-48 hours",
      whatNext: "What's Next?",
      next1: "We will review your documents",
      next2: "You'll receive a notification when review is complete",
      next3: "After approval, you'll get a verified badge",
      backToHome: "Back to Home",
      
      processing: "Processing...",
      fillAllFields: "Please fill all fields",
      uploadAllPhotos: "Please upload all required photos",
      invalidIdNumber: "ID number must be 10 digits",
    },
  };
  const c = content[language];

  const handleMockUpload = (type: "front" | "back" | "selfie") => {
    const mockImage = `https://images.unsplash.com/photo-${Date.now() % 1000000000000}?w=400`;
    if (type === "front") setIdFrontImage(mockImage);
    else if (type === "back") setIdBackImage(mockImage);
    else setSelfieImage(mockImage);
  };

  const handleContinue = () => {
    if (!idFrontImage || !idBackImage || !selfieImage) {
      toast.error(c.uploadAllPhotos);
      return;
    }
    if (!fullName.trim() || !idNumber.trim()) {
      toast.error(c.fillAllFields);
      return;
    }
    if (idNumber.length !== 10) {
      toast.error(c.invalidIdNumber);
      return;
    }
    setStep("review");
  };

  const handleSubmit = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setStep("success");
      toast.success(c.submitted + " ✓");
    }, 2000);
  };

  // Info Step
  if (step === "info") {
    return (
      <div
        className="min-h-screen bg-[#fafafa]"
        style={{ fontFamily: language === "ar" ? "Cairo, sans-serif" : "system-ui, -apple-system, sans-serif" }}
        dir={isRTL ? "rtl" : "ltr"}
      >
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 z-10"
        >
          <div className="flex items-center justify-between">
            <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
              <ChevronRight className={`w-6 h-6 text-[#0e0f0c] ${isRTL ? "" : "rotate-180"}`} />
            </button>
            <h1 className="text-xl font-semibold text-[#0e0f0c]">{c.verification}</h1>
            <div className="w-10" />
          </div>
        </motion.div>

        <div className="p-6 space-y-6">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-gradient-to-br from-[#163300] to-[#1a3d00] rounded-[20px] p-8 text-white text-center"
          >
            <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h2 className="text-2xl font-bold mb-2">{c.whyVerify}</h2>
            <p className="text-sm opacity-90">{c.whyVerifyDesc}</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white rounded-[16px] p-6"
          >
            <h3 className={`font-bold text-[#0e0f0c] mb-4 ${isRTL ? "text-right" : "text-left"}`}>
              {c.benefits}
            </h3>
            <div className="space-y-3">
              {[c.benefit1, c.benefit2, c.benefit3, c.benefit4].map((benefit, index) => (
                <div key={index} className="flex items-center gap-3">
                  <div className="w-6 h-6 rounded-full bg-[rgba(22,51,0,0.12157)] flex items-center justify-center flex-shrink-0">
                    <CheckCircle2 className="w-4 h-4 text-[#163300]" />
                  </div>
                  <p className={`text-sm text-[#0e0f0c] ${isRTL ? "text-right" : "text-left"}`}>{benefit}</p>
                </div>
              ))}
            </div>
          </motion.div>

          <WiseButton onClick={() => setStep("upload")} variant="primary" fullWidth>
            {c.getStarted}
          </WiseButton>
        </div>
      </div>
    );
  }

  // Upload Step
  if (step === "upload") {
    return (
      <div
        className="min-h-screen bg-[#fafafa] pb-32"
        style={{ fontFamily: language === "ar" ? "Cairo, sans-serif" : "system-ui, -apple-system, sans-serif" }}
        dir={isRTL ? "rtl" : "ltr"}
      >
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 z-10"
        >
          <div className="flex items-center justify-between">
            <button onClick={() => setStep("info")} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
              <ChevronRight className={`w-6 h-6 text-[#0e0f0c] ${isRTL ? "" : "rotate-180"}`} />
            </button>
            <h1 className="text-xl font-semibold text-[#0e0f0c]">{c.uploadDocuments}</h1>
            <div className="w-10" />
          </div>
        </motion.div>

        <div className="p-6 space-y-6">
          {/* ID Front */}
          <div>
            <label className={`block text-sm font-semibold text-[#0e0f0c] mb-2 ${isRTL ? "text-right" : "text-left"}`}>
              {c.idFront}
            </label>
            {idFrontImage ? (
              <div className="relative">
                <img src={idFrontImage} alt="ID Front" className="w-full h-48 object-cover rounded-[12px]" />
                <button
                  onClick={() => setIdFrontImage(null)}
                  className="absolute top-2 right-2 w-8 h-8 bg-[#cb272f] text-white rounded-full"
                >
                  ×
                </button>
              </div>
            ) : (
              <button
                onClick={() => handleMockUpload("front")}
                className="w-full h-48 border-2 border-dashed border-[rgba(14,15,12,0.12157)] rounded-[12px] flex flex-col items-center justify-center gap-2 hover:border-[#163300] transition-colors"
              >
                <Camera className="w-8 h-8 text-[#6a6c6a]" />
                <span className="text-sm font-medium text-[#6a6c6a]">{c.uploadPhoto}</span>
              </button>
            )}
          </div>

          {/* ID Back */}
          <div>
            <label className={`block text-sm font-semibold text-[#0e0f0c] mb-2 ${isRTL ? "text-right" : "text-left"}`}>
              {c.idBack}
            </label>
            {idBackImage ? (
              <div className="relative">
                <img src={idBackImage} alt="ID Back" className="w-full h-48 object-cover rounded-[12px]" />
                <button
                  onClick={() => setIdBackImage(null)}
                  className="absolute top-2 right-2 w-8 h-8 bg-[#cb272f] text-white rounded-full"
                >
                  ×
                </button>
              </div>
            ) : (
              <button
                onClick={() => handleMockUpload("back")}
                className="w-full h-48 border-2 border-dashed border-[rgba(14,15,12,0.12157)] rounded-[12px] flex flex-col items-center justify-center gap-2 hover:border-[#163300] transition-colors"
              >
                <Camera className="w-8 h-8 text-[#6a6c6a]" />
                <span className="text-sm font-medium text-[#6a6c6a]">{c.uploadPhoto}</span>
              </button>
            )}
          </div>

          {/* Selfie */}
          <div>
            <label className={`block text-sm font-semibold text-[#0e0f0c] mb-2 ${isRTL ? "text-right" : "text-left"}`}>
              {c.selfie}
            </label>
            {selfieImage ? (
              <div className="relative">
                <img src={selfieImage} alt="Selfie" className="w-full h-48 object-cover rounded-[12px]" />
                <button
                  onClick={() => setSelfieImage(null)}
                  className="absolute top-2 right-2 w-8 h-8 bg-[#cb272f] text-white rounded-full"
                >
                  ×
                </button>
              </div>
            ) : (
              <button
                onClick={() => handleMockUpload("selfie")}
                className="w-full h-48 border-2 border-dashed border-[rgba(14,15,12,0.12157)] rounded-[12px] flex flex-col items-center justify-center gap-2 hover:border-[#163300] transition-colors"
              >
                <User className="w-8 h-8 text-[#6a6c6a]" />
                <span className="text-sm font-medium text-[#6a6c6a]">{c.takePhoto}</span>
              </button>
            )}
          </div>

          {/* Full Name */}
          <div>
            <label className={`block text-sm font-semibold text-[#0e0f0c] mb-2 ${isRTL ? "text-right" : "text-left"}`}>
              {c.fullName}
            </label>
            <input
              type="text"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder={c.fullNamePlaceholder}
              className={`w-full px-4 py-3 rounded-[10px] border border-[rgba(14,15,12,0.12157)] ${isRTL ? "text-right" : "text-left"} focus:outline-none focus:border-[#163300]`}
            />
          </div>

          {/* ID Number */}
          <div>
            <label className={`block text-sm font-semibold text-[#0e0f0c] mb-2 ${isRTL ? "text-right" : "text-left"}`}>
              {c.idNumber}
            </label>
            <input
              type="text"
              value={idNumber}
              onChange={(e) => setIdNumber(e.target.value.replace(/\D/g, "").slice(0, 10))}
              placeholder={c.idNumberPlaceholder}
              className={`w-full px-4 py-3 rounded-[10px] border border-[rgba(14,15,12,0.12157)] ${isRTL ? "text-right" : "text-left"} focus:outline-none focus:border-[#163300]`}
              dir="ltr"
            />
          </div>

          {/* Requirements */}
          <div className="bg-[rgba(159,232,112,0.1)] rounded-[12px] p-4">
            <div className="flex items-start gap-2 mb-2">
              <AlertCircle className="w-5 h-5 text-[#163300] flex-shrink-0 mt-0.5" />
              <p className={`text-sm font-semibold text-[#163300] ${isRTL ? "text-right" : "text-left"}`}>
                {c.requirements}
              </p>
            </div>
            <ul className={`text-xs text-[#6a6c6a] space-y-1 ${isRTL ? "pr-7 text-right" : "pl-7 text-left"} list-disc`}>
              <li>{c.req1}</li>
              <li>{c.req2}</li>
              <li>{c.req3}</li>
              <li>{c.req4}</li>
            </ul>
          </div>
        </div>

        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-[rgba(14,15,12,0.12157)] px-6 py-4 max-w-[430px] mx-auto">
          <WiseButton onClick={handleContinue} variant="primary" fullWidth>
            {c.continue}
          </WiseButton>
        </div>
      </div>
    );
  }

  // Review Step
  if (step === "review") {
    return (
      <div
        className="min-h-screen bg-[#fafafa] pb-32"
        style={{ fontFamily: language === "ar" ? "Cairo, sans-serif" : "system-ui, -apple-system, sans-serif" }}
        dir={isRTL ? "rtl" : "ltr"}
      >
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 z-10"
        >
          <div className="flex items-center justify-between">
            <button onClick={() => setStep("upload")} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
              <ChevronRight className={`w-6 h-6 text-[#0e0f0c] ${isRTL ? "" : "rotate-180"}`} />
            </button>
            <h1 className="text-xl font-semibold text-[#0e0f0c]">{c.reviewInfo}</h1>
            <div className="w-10" />
          </div>
        </motion.div>

        <div className="p-6 space-y-6">
          <p className={`text-sm text-[#6a6c6a] text-center`}>{c.reviewDesc}</p>

          {/* Photos Preview */}
          <div className="bg-white rounded-[16px] p-4 space-y-3">
            <div>
              <p className={`text-sm font-semibold text-[#0e0f0c] mb-2 ${isRTL ? "text-right" : "text-left"}`}>
                {c.frontID}
              </p>
              <img src={idFrontImage!} alt="ID Front" className="w-full h-40 object-cover rounded-[8px]" />
            </div>
            <div>
              <p className={`text-sm font-semibold text-[#0e0f0c] mb-2 ${isRTL ? "text-right" : "text-left"}`}>
                {c.backID}
              </p>
              <img src={idBackImage!} alt="ID Back" className="w-full h-40 object-cover rounded-[8px]" />
            </div>
            <div>
              <p className={`text-sm font-semibold text-[#0e0f0c] mb-2 ${isRTL ? "text-right" : "text-left"}`}>
                {c.selfiePhoto}
              </p>
              <img src={selfieImage!} alt="Selfie" className="w-full h-40 object-cover rounded-[8px]" />
            </div>
          </div>

          {/* Personal Info */}
          <div className="bg-white rounded-[16px] p-4">
            <h3 className={`font-bold text-[#0e0f0c] mb-3 ${isRTL ? "text-right" : "text-left"}`}>
              {c.personalInfo}
            </h3>
            <div className="space-y-2">
              <div className="flex items-center justify-between py-2 border-b border-[rgba(14,15,12,0.12157)]">
                <span className="text-sm text-[#6a6c6a]">{c.fullName}</span>
                <span className="text-sm font-semibold text-[#0e0f0c]">{fullName}</span>
              </div>
              <div className="flex items-center justify-between py-2">
                <span className="text-sm text-[#6a6c6a]">{c.idNumber}</span>
                <span className="text-sm font-semibold text-[#0e0f0c]" dir="ltr">{idNumber}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-[rgba(14,15,12,0.12157)] px-6 py-4 max-w-[430px] mx-auto">
          <WiseButton onClick={handleSubmit} variant="primary" fullWidth loading={isLoading}>
            {isLoading ? c.processing : c.submit}
          </WiseButton>
        </div>
      </div>
    );
  }

  // Success Step
  return (
    <div
      className="min-h-screen bg-white flex flex-col items-center justify-center p-6"
      style={{ fontFamily: language === "ar" ? "Cairo, sans-serif" : "system-ui, -apple-system, sans-serif" }}
      dir={isRTL ? "rtl" : "ltr"}
    >
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: "spring", stiffness: 200, damping: 15 }}
        className="w-24 h-24 bg-[#163300] rounded-full flex items-center justify-center mb-6"
      >
        <motion.svg
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="w-12 h-12 text-white"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="3"
        >
          <motion.path
            d="M5 13l4 4L19 7"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </motion.svg>
      </motion.div>

      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="text-2xl font-bold text-[#163300] mb-2 text-center"
      >
        {c.submitted} ✓
      </motion.h2>

      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="text-[#6a6c6a] text-center mb-8"
      >
        {c.successDesc}
      </motion.p>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="bg-[rgba(22,51,0,0.07843)] rounded-[16px] p-6 w-full max-w-sm mb-8"
      >
        <h3 className={`font-bold text-[#163300] mb-3 ${isRTL ? "text-right" : "text-left"}`}>
          {c.whatNext}
        </h3>
        <div className="space-y-2">
          {[c.next1, c.next2, c.next3].map((text, index) => (
            <div key={index} className="flex items-start gap-2">
              <div className="w-5 h-5 rounded-full bg-[#163300] flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-xs text-white font-bold">{index + 1}</span>
              </div>
              <p className={`text-sm text-[#0e0f0c] ${isRTL ? "text-right" : "text-left"}`}>{text}</p>
            </div>
          ))}
        </div>
      </motion.div>

      <WiseButton onClick={onVerificationSuccess} variant="primary" fullWidth>
        {c.backToHome}
      </WiseButton>
    </div>
  );
}
