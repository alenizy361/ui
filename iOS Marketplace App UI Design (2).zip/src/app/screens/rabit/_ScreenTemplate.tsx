import { motion } from "motion/react";
import { WiseButton } from "../../components/WiseButton";
import { ChevronRight } from "lucide-react";

// This is a template for creating new Rabit screens
// Copy this file and customize for each screen

interface ScreenProps {
  onBack?: () => void;
  [key: string]: any;
}

export function ScreenTemplate({ onBack, ...props }: ScreenProps) {
  return (
    <div className="min-h-screen bg-white flex flex-col" style={{ fontFamily: 'Cairo, sans-serif' }}>
      {/* Header with Back Button */}
      {onBack && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="sticky top-0 bg-white/95 backdrop-blur-lg border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 flex items-center gap-4 z-10"
        >
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center text-[#0e0f0c]"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-semibold text-[#0e0f0c]">عنوان الشاشة</h1>
        </motion.div>
      )}

      {/* Content */}
      <div className="flex-1 p-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <p className="text-center text-[#6a6c6a]">محتوى الشاشة هنا</p>
        </motion.div>
      </div>

      {/* Bottom CTA (if needed) */}
      <motion.div
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        transition={{ delay: 0.3 }}
        className="sticky bottom-0 bg-white border-t border-[rgba(14,15,12,0.12157)] p-6"
      >
        <WiseButton variant="primary" fullWidth size="lg">
          زر الإجراء
        </WiseButton>
      </motion.div>
    </div>
  );
}
