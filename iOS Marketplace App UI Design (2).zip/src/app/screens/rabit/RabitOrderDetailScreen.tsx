import { motion } from "motion/react";
import { ChevronRight, Package, MapPin, Phone, MessageCircle, Star, CheckCircle, Truck, Home } from "lucide-react";
import { WiseButton } from "../../components/WiseButton";
import { useState } from "react";
import { useLanguage } from "../../contexts/LanguageContext";

interface RabitOrderDetailScreenProps {
  orderNumber: string;
  productTitle: string;
  productImage: string;
  price: number;
  platformFee: number;
  deliveryFee: number;
  sellerName: string;
  status: "pending" | "shipped" | "delivered" | "cancelled";
  orderDate: string;
  estimatedDelivery: string;
  shippingAddress: {
    name: string;
    phone: string;
    city: string;
    district: string;
    street: string;
    building: string;
  };
  onBack: () => void;
  onChatSeller: () => void;
  onWriteReview?: () => void;
  onReportIssue?: () => void;
  onTrackOrder?: () => void;
  onRequestReturn?: () => void;
}

export function RabitOrderDetailScreen({
  orderNumber,
  productTitle,
  productImage,
  price,
  platformFee,
  deliveryFee,
  sellerName,
  status,
  orderDate,
  estimatedDelivery,
  shippingAddress,
  onBack,
  onChatSeller,
  onWriteReview,
  onReportIssue,
  onTrackOrder,
  onRequestReturn,
}: RabitOrderDetailScreenProps) {
  const { language, isRTL } = useLanguage();
  const [activeTab, setActiveTab] = useState<"tracking" | "details">("tracking");

  const getStatusBadge = () => {
    const statusConfig = {
      pending: { bg: "bg-[#df8700]", text: "في الانتظار" },
      shipped: { bg: "bg-[#9c27b0]", text: "قيد الشحن" },
      delivered: { bg: "bg-[#008026]", text: "تم التوصيل" },
      cancelled: { bg: "bg-[#cb272f]", text: "ملغي" },
    };
    return statusConfig[status];
  };

  const statusBadge = getStatusBadge();
  const total = price + platformFee + deliveryFee;

  const trackingSteps = [
    {
      id: 1,
      icon: CheckCircle,
      titleAr: "تم تأكيد الطلب",
      descriptionAr: "تم استلام طلبك وجاري التجهيز",
      date: orderDate,
      completed: true,
    },
    {
      id: 2,
      icon: Package,
      titleAr: "جاري التغليف",
      descriptionAr: "البائع يقوم بتغليف المنتج",
      date: status === "shipped" || status === "delivered" ? "منذ ساعتين" : undefined,
      completed: status === "shipped" || status === "delivered",
    },
    {
      id: 3,
      icon: Truck,
      titleAr: "قيد التوصيل",
      descriptionAr: "الطلب مع مندوب التوصيل",
      date: status === "delivered" ? "منذ ساعة" : undefined,
      completed: status === "delivered",
    },
    {
      id: 4,
      icon: Home,
      titleAr: "تم التوصيل",
      descriptionAr: "تم تسليم الطلب بنجاح",
      date: status === "delivered" ? orderDate : undefined,
      completed: status === "delivered",
    },
  ];

  return (
    <div className="min-h-screen bg-white pb-24" style={{ fontFamily: 'Cairo, sans-serif' }}>
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 flex items-center justify-between z-10"
      >
        <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
          <ChevronRight className="w-6 h-6 text-[#0e0f0c]" />
        </button>
        <h1 className="text-xl font-semibold text-[#0e0f0c]">تفاصيل الطلب</h1>
        <div className="w-10" />
      </motion.div>

      <div className="p-6 space-y-6">
        {/* Order Status Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[rgba(22,51,0,0.07843)] rounded-[16px] p-5 border border-[rgba(14,15,12,0.12157)]"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="text-right">
              <p className="text-sm text-[#6a6c6a] mb-1">رقم الطلب</p>
              <p className="font-bold text-[#0e0f0c]" dir="ltr">#{orderNumber}</p>
            </div>
            <span className={`${statusBadge.bg} text-white px-4 py-1.5 rounded-full text-sm font-medium`}>
              {statusBadge.text}
            </span>
          </div>
          <div className="flex items-center gap-3">
            <img 
              src={productImage} 
              alt={productTitle} 
              className="w-20 h-20 rounded-[12px] object-cover border border-[rgba(14,15,12,0.12157)]"
            />
            <div className="flex-1 text-right">
              <p className="font-semibold text-[#0e0f0c] mb-1">{productTitle}</p>
              <p className="text-sm text-[#6a6c6a] mb-2">البائع: {sellerName}</p>
              <p className="text-lg font-bold text-[#163300]">{total.toLocaleString('ar-SA')} ر.س</p>
            </div>
          </div>
        </motion.div>

        {/* Tabs */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="flex gap-3 bg-[rgba(22,51,0,0.07843)] p-1.5 rounded-[12px]"
        >
          <button
            onClick={() => setActiveTab("tracking")}
            className={`flex-1 py-2.5 rounded-[8px] font-medium text-sm transition-all ${
              activeTab === "tracking"
                ? "bg-white text-[#163300] shadow-sm"
                : "text-[#6a6c6a]"
            }`}
          >
            تتبع الطلب
          </button>
          <button
            onClick={() => setActiveTab("details")}
            className={`flex-1 py-2.5 rounded-[8px] font-medium text-sm transition-all ${
              activeTab === "details"
                ? "bg-white text-[#163300] shadow-sm"
                : "text-[#6a6c6a]"
            }`}
          >
            التفاصيل
          </button>
        </motion.div>

        {/* Tracking Tab */}
        {activeTab === "tracking" && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            {/* Timeline */}
            <div className="bg-white rounded-[16px] border border-[rgba(14,15,12,0.12157)] p-6">
              <h3 className="font-bold text-[#0e0f0c] mb-6 text-right">مراحل الشحن</h3>
              <div className="space-y-6">
                {trackingSteps.map((step, index) => {
                  const StepIcon = step.icon;
                  const isLast = index === trackingSteps.length - 1;

                  return (
                    <motion.div
                      key={step.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="flex gap-4 relative"
                    >
                      {/* Timeline Line */}
                      {!isLast && (
                        <div
                          className={`absolute right-6 top-12 w-0.5 h-full transition-all ${
                            step.completed ? "bg-[#163300]" : "bg-[rgba(14,15,12,0.12157)]"
                          }`}
                        />
                      )}

                      {/* Icon */}
                      <div
                        className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 relative z-10 transition-all ${
                          step.completed
                            ? "bg-[#163300] text-white"
                            : "bg-[rgba(22,51,0,0.07843)] text-[#6a6c6a]"
                        }`}
                      >
                        <StepIcon className="w-6 h-6" />
                      </div>

                      {/* Content */}
                      <div className="flex-1 pt-2 text-right">
                        <h4
                          className={`font-semibold mb-1 ${
                            step.completed ? "text-[#0e0f0c]" : "text-[#6a6c6a]"
                          }`}
                        >
                          {step.titleAr}
                        </h4>
                        <p
                          className={`text-sm mb-1 ${
                            step.completed ? "text-[#6a6c6a]" : "text-[#b0b3b0]"
                          }`}
                        >
                          {step.descriptionAr}
                        </p>
                        {step.date && (
                          <p
                            className={`text-xs ${
                              step.completed ? "text-[#163300]" : "text-[#b0b3b0]"
                            }`}
                          >
                            {step.date}
                          </p>
                        )}
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </div>

            {/* Shipping Address */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="bg-white rounded-[16px] border border-[rgba(14,15,12,0.12157)] p-5"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-[rgba(22,51,0,0.07843)] rounded-full flex items-center justify-center">
                  <MapPin className="w-5 h-5 text-[#163300]" />
                </div>
                <h3 className="font-bold text-[#0e0f0c]">عنوان التوصيل</h3>
              </div>
              <div className="bg-[rgba(22,51,0,0.07843)] rounded-[12px] p-4 text-right">
                <p className="font-semibold text-[#0e0f0c] mb-2">{shippingAddress.name}</p>
                <p className="text-sm text-[#6a6c6a] mb-1">{shippingAddress.street}</p>
                <p className="text-sm text-[#6a6c6a] mb-1">{shippingAddress.building}</p>
                <p className="text-sm text-[#6a6c6a] mb-1">{shippingAddress.district}، {shippingAddress.city}</p>
                <div className="flex items-center gap-2 pt-3 border-t border-[rgba(14,15,12,0.12157)] mt-3">
                  <Phone className="w-4 h-4 text-[#163300]" />
                  <p className="text-sm text-[#0e0f0c]" dir="ltr">{shippingAddress.phone}</p>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}

        {/* Details Tab */}
        {activeTab === "details" && (
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-4"
          >
            {/* Price Breakdown */}
            <div className="bg-white rounded-[16px] border border-[rgba(14,15,12,0.12157)] p-5">
              <h3 className="font-bold text-[#0e0f0c] mb-4 text-right">تفاصيل السعر</h3>
              <div className="space-y-3">
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.1 }}
                  className="flex items-center justify-between"
                >
                  <span className="text-sm text-[#6a6c6a]">سعر المنتج</span>
                  <span className="text-sm font-semibold text-[#0e0f0c]">
                    {price.toLocaleString('ar-SA')} ر.س
                  </span>
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 }}
                  className="flex items-center justify-between"
                >
                  <span className="text-sm text-[#6a6c6a]">رسوم المنصة (5%)</span>
                  <span className="text-sm font-semibold text-[#0e0f0c]">
                    {platformFee.toLocaleString('ar-SA')} ر.س
                  </span>
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 }}
                  className="flex items-center justify-between"
                >
                  <span className="text-sm text-[#6a6c6a]">رسوم التوصيل</span>
                  <span className="text-sm font-semibold text-[#008026]">
                    {deliveryFee === 0 ? "مجاناً" : `${deliveryFee.toLocaleString('ar-SA')} ر.س`}
                  </span>
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, scaleX: 0 }}
                  animate={{ opacity: 1, scaleX: 1 }}
                  transition={{ delay: 0.4 }}
                  className="border-t border-[rgba(14,15,12,0.12157)] pt-3 mt-3"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-[#0e0f0c]">المجموع الكلي</span>
                    <span className="text-xl font-bold text-[#163300]">
                      {total.toLocaleString('ar-SA')} ر.س
                    </span>
                  </div>
                </motion.div>
              </div>
            </div>

            {/* Order Info */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-white rounded-[16px] border border-[rgba(14,15,12,0.12157)] p-5"
            >
              <h3 className="font-bold text-[#0e0f0c] mb-4 text-right">معلومات الطلب</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-[#6a6c6a]">تاريخ الطلب</span>
                  <span className="text-sm font-medium text-[#0e0f0c]">{orderDate}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-[#6a6c6a]">البائع</span>
                  <span className="text-sm font-medium text-[#0e0f0c]">{sellerName}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-[#6a6c6a]">طريقة الدفع</span>
                  <span className="text-sm font-medium text-[#0e0f0c]">بطاقة ائتمانية</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-[#6a6c6a]">التوصيل المتوقع</span>
                  <span className="text-sm font-medium text-[#163300]">{estimatedDelivery}</span>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}

        {/* Action Buttons */}
        {status === "delivered" && onWriteReview && (
          <motion.button
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={onWriteReview}
            className="w-full py-4 px-6 bg-[#163300] text-white rounded-[12px] font-semibold flex items-center justify-center gap-3 shadow-lg"
          >
            <Star className="w-5 h-5" />
            <span>كتابة تقييم للمنتج</span>
          </motion.button>
        )}
      </div>

      {/* Fixed Bottom Actions */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-[rgba(14,15,12,0.12157)] px-6 py-4 max-w-[430px] mx-auto">
        <div className="flex gap-3">
          {onReportIssue && (
            <button
              onClick={onReportIssue}
              className="flex-1 py-3 px-4 bg-[rgba(203,39,47,0.1)] text-[#cb272f] rounded-[10px] font-medium text-sm"
            >
              الإبلاغ عن مشكلة
            </button>
          )}
          <button
            onClick={onChatSeller}
            className="flex-1 py-3 px-4 bg-[#163300] text-white rounded-[10px] font-medium text-sm flex items-center justify-center gap-2"
          >
            <MessageCircle className="w-4 h-4" />
            <span>تواصل مع البائع</span>
          </button>
        </div>
      </div>
    </div>
  );
}