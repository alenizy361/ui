import { motion } from "motion/react";
import { Package, Wallet, CreditCard, MapPin, ArrowRight, ChevronLeft, Truck, CheckCircle } from "lucide-react";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";
import { useState } from "react";

interface ShippingLabelScreenProps {
  orderNumber: string;
  productTitle: string;
  productTitleAr: string;
  shippingAddress: {
    name: string;
    phone: string;
    city: string;
    district: string;
    street: string;
    building: string;
  };
  shippingCost: number;
  walletBalance: number;
  onBack: () => void;
  onPaymentComplete: () => void;
}

export function RabitIssueShippingLabelScreen({
  orderNumber,
  productTitle,
  productTitleAr,
  shippingAddress,
  shippingCost,
  walletBalance,
  onBack,
  onPaymentComplete,
}: ShippingLabelScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);
  const [selectedPayment, setSelectedPayment] = useState<"wallet" | "card" | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const hasEnoughBalance = walletBalance >= shippingCost;

  const handlePayment = () => {
    if (!selectedPayment) return;
    
    setIsProcessing(true);
    
    // Simulate payment processing with haptic feedback
    if (navigator.vibrate) {
      navigator.vibrate([50, 100, 50]);
    }

    setTimeout(() => {
      setIsProcessing(false);
      onPaymentComplete();
    }, 2000);
  };

  return (
    <div 
      className="min-h-screen bg-[#f8f9fa]"
      style={{ fontFamily: language === "ar" ? "Cairo, sans-serif" : "SF Pro Display, sans-serif" }}
    >
      {/* Header */}
      <div className="bg-white border-b border-[#e8e9ea] sticky top-0 z-50">
        <div className="px-4 py-4 flex items-center gap-4">
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-[#f8f9fa] flex items-center justify-center active:scale-95 transition-transform"
          >
            <ChevronLeft className={`w-5 h-5 text-[#0e0f0c] ${isRTL ? "rotate-180" : ""}`} />
          </button>
          <div className="flex-1">
            <h1 className="font-bold text-[#0e0f0c]">
              {language === "ar" ? "إصدار بوليصة شحن" : "Issue Shipping Label"}
            </h1>
            <p className="text-sm text-[#6a6c6a]">{orderNumber}</p>
          </div>
        </div>
      </div>

      <div className="px-4 py-6 space-y-4 pb-32">
        {/* Order Info Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-[20px] p-5 border border-[#e8e9ea]"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-full bg-[#9fe870]/10 flex items-center justify-center">
              <Package className="w-6 h-6 text-[#163300]" />
            </div>
            <div className="flex-1">
              <p className="text-sm text-[#6a6c6a] mb-1">
                {language === "ar" ? "المنتج" : "Product"}
              </p>
              <p className="font-semibold text-[#0e0f0c]">
                {language === "ar" ? productTitleAr : productTitle}
              </p>
            </div>
          </div>

          {/* Shipping Address */}
          <div className="pt-4 border-t border-[#e8e9ea]">
            <div className="flex items-start gap-3">
              <MapPin className="w-5 h-5 text-[#6a6c6a] mt-1 flex-shrink-0" />
              <div className="flex-1">
                <p className="text-sm text-[#6a6c6a] mb-2">
                  {language === "ar" ? "عنوان الشحن" : "Shipping Address"}
                </p>
                <p className="text-[#0e0f0c] font-medium mb-1">{shippingAddress.name}</p>
                <p className="text-sm text-[#6a6c6a] leading-relaxed">
                  {shippingAddress.city}, {shippingAddress.district}
                  <br />
                  {shippingAddress.street}
                  <br />
                  {shippingAddress.building}
                </p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Shipping Cost Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-gradient-to-br from-[#163300] to-[#1e4500] rounded-[20px] p-5 text-white"
        >
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
              <Truck className="w-5 h-5 text-white" />
            </div>
            <p className="font-semibold">
              {language === "ar" ? "تكلفة بوليصة الشحن" : "Shipping Label Cost"}
            </p>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold">
              {shippingCost.toLocaleString(language === "ar" ? "ar-SA" : "en-US")}
            </span>
            <span className="text-lg opacity-80">{t.sar}</span>
          </div>
          <p className="text-sm opacity-70 mt-2">
            {language === "ar" 
              ? "شامل التأمين والتتبع"
              : "Including insurance and tracking"}
          </p>
        </motion.div>

        {/* Payment Methods */}
        <div className="space-y-3">
          <h2 className="font-semibold text-[#0e0f0c] px-1">
            {language === "ar" ? "طريقة الدفع" : "Payment Method"}
          </h2>

          {/* Wallet Option */}
          <motion.button
            initial={{ opacity: 0, x: isRTL ? 20 : -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            onClick={() => setSelectedPayment("wallet")}
            disabled={!hasEnoughBalance}
            className={`w-full bg-white rounded-[20px] p-5 border-2 transition-all active:scale-98 ${
              selectedPayment === "wallet"
                ? "border-[#163300] shadow-lg"
                : "border-[#e8e9ea]"
            } ${!hasEnoughBalance ? "opacity-50" : ""}`}
          >
            <div className="flex items-center gap-4">
              <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                selectedPayment === "wallet" ? "bg-[#9fe870]" : "bg-[#f8f9fa]"
              }`}>
                <Wallet className={`w-6 h-6 ${
                  selectedPayment === "wallet" ? "text-white" : "text-[#6a6c6a]"
                }`} />
              </div>
              <div className="flex-1 text-right" dir={isRTL ? "rtl" : "ltr"}>
                <p className="font-semibold text-[#0e0f0c] mb-1">
                  {language === "ar" ? "المحفظة" : "Wallet"}
                </p>
                <p className={`text-sm ${
                  hasEnoughBalance ? "text-[#163300]" : "text-red-500"
                }`}>
                  {language === "ar" ? "الرصيد: " : "Balance: "}
                  {walletBalance.toLocaleString(language === "ar" ? "ar-SA" : "en-US")} {t.sar}
                </p>
              </div>
              {selectedPayment === "wallet" && (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", stiffness: 500 }}
                >
                  <CheckCircle className="w-6 h-6 text-[#163300]" />
                </motion.div>
              )}
            </div>
            {!hasEnoughBalance && (
              <div className="mt-3 pt-3 border-t border-[#e8e9ea]">
                <p className="text-sm text-red-500 text-center">
                  {language === "ar" 
                    ? "رصيد غير كافٍ. الرجاء شحن المحفظة أو استخدام البطاقة"
                    : "Insufficient balance. Please top up wallet or use card"}
                </p>
              </div>
            )}
          </motion.button>

          {/* Card Payment Option */}
          <motion.button
            initial={{ opacity: 0, x: isRTL ? 20 : -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            onClick={() => setSelectedPayment("card")}
            className={`w-full bg-white rounded-[20px] p-5 border-2 transition-all active:scale-98 ${
              selectedPayment === "card"
                ? "border-[#163300] shadow-lg"
                : "border-[#e8e9ea]"
            }`}
          >
            <div className="flex items-center gap-4">
              <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                selectedPayment === "card" ? "bg-[#9fe870]" : "bg-[#f8f9fa]"
              }`}>
                <CreditCard className={`w-6 h-6 ${
                  selectedPayment === "card" ? "text-white" : "text-[#6a6c6a]"
                }`} />
              </div>
              <div className="flex-1 text-right" dir={isRTL ? "rtl" : "ltr"}>
                <p className="font-semibold text-[#0e0f0c] mb-1">
                  {language === "ar" ? "بطاقة ائتمانية" : "Credit Card"}
                </p>
                <p className="text-sm text-[#6a6c6a]">
                  {language === "ar" ? "الدفع ببطاقة ائتمانية" : "Pay with credit card"}
                </p>
              </div>
              {selectedPayment === "card" && (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", stiffness: 500 }}
                >
                  <CheckCircle className="w-6 h-6 text-[#163300]" />
                </motion.div>
              )}
            </div>
          </motion.button>
        </div>

        {/* Info Box */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="bg-[#9fe870]/10 rounded-[16px] p-4 border border-[#9fe870]/20"
        >
          <p className="text-sm text-[#163300] leading-relaxed">
            {language === "ar"
              ? "💡 بعد إصدار بوليصة الشحن، ستتمكن من طباعتها ولصقها على الطرد. سيتم إرسال رقم التتبع إلى المشتري تلقائياً"
              : "💡 After issuing the shipping label, you'll be able to print it and attach it to the package. The tracking number will be sent to the buyer automatically"}
          </p>
        </motion.div>
      </div>

      {/* Fixed Bottom Button */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-[#e8e9ea] px-4 py-4 safe-area-bottom">
        <motion.button
          whileTap={{ scale: 0.98 }}
          onClick={handlePayment}
          disabled={!selectedPayment || isProcessing}
          className={`w-full rounded-full py-4 px-6 font-semibold flex items-center justify-center gap-2 transition-all ${
            selectedPayment && !isProcessing
              ? "bg-[#163300] text-white shadow-lg"
              : "bg-[#e8e9ea] text-[#6a6c6a]"
          }`}
        >
          {isProcessing ? (
            <>
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                className="w-5 h-5 border-2 border-white border-t-transparent rounded-full"
              />
              <span>
                {language === "ar" ? "جاري المعالجة..." : "Processing..."}
              </span>
            </>
          ) : (
            <>
              <span>
                {language === "ar" ? "إصدار ودفع" : "Issue & Pay"}
                {selectedPayment && ` ${shippingCost.toLocaleString(language === "ar" ? "ar-SA" : "en-US")} ${t.sar}`}
              </span>
              <ArrowRight className={`w-5 h-5 ${isRTL ? "rotate-180" : ""}`} />
            </>
          )}
        </motion.button>
      </div>
    </div>
  );
}
