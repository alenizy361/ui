import { motion } from "motion/react";
import { ChevronRight, FileText, Shield, AlertCircle, CheckCircle } from "lucide-react";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";

interface RabitTermsAndConditionsScreenProps {
  onBack: () => void;
}

export function RabitTermsAndConditionsScreen({ onBack }: RabitTermsAndConditionsScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);

  const content = {
    heroTitle: { ar: 'شروط الاستخدام', en: 'Terms of Use' },
    lastUpdated: { ar: 'آخر تحديث: 26 ديسمبر 2024', en: 'Last Updated: December 26, 2024' },
    
    // Section 1
    section1Title: { ar: '1. مقدمة', en: '1. Introduction' },
    section1P1: {
      ar: 'مرحباً بك في منصة رابط. باستخدامك لهذه المنصة، فإنك توافق على الالتزام بهذه الشروط والأحكام.',
      en: 'Welcome to Rabit Platform. By using this platform, you agree to comply with these terms and conditions.'
    },
    section1P2: {
      ar: 'منصة رابط هي منصة إلكترونية تربط بين المشترين والبائعين في المملكة العربية السعودية، وتوفر بيئة آمنة وموثوقة للتجارة الإلكترونية.',
      en: 'Rabit Platform is an electronic platform that connects buyers and sellers in Saudi Arabia, providing a safe and reliable environment for e-commerce.'
    },

    // Section 2
    section2Title: { ar: '2. الحسابات', en: '2. Accounts' },
    section2SubTitle1: { ar: '2.1 التسجيل', en: '2.1 Registration' },
    section2List1: {
      ar: [
        'يجب أن تكون فوق 18 عاماً لاستخدام المنصة',
        'يجب تقديم معلومات صحيحة ودقيقة',
        'أنت مسؤول عن الحفاظ على سرية حسابك',
        'حساب واحد فقط لكل مستخدم'
      ],
      en: [
        'You must be over 18 years old to use the platform',
        'You must provide accurate and correct information',
        'You are responsible for maintaining the confidentiality of your account',
        'Only one account per user'
      ]
    },
    section2SubTitle2: { ar: '2.2 أنواع الحسابات', en: '2.2 Account Types' },
    section2List2: {
      ar: [
        { label: 'مشتري:', text: 'يمكنه شراء المنتجات فقط' },
        { label: 'بائع:', text: 'يمكنه بيع المنتجات فقط' },
        { label: 'كلاهما:', text: 'يمكنه البيع والشراء' }
      ],
      en: [
        { label: 'Buyer:', text: 'Can purchase products only' },
        { label: 'Seller:', text: 'Can sell products only' },
        { label: 'Both:', text: 'Can buy and sell' }
      ]
    },

    // Section 3
    section3Title: { ar: '3. المعاملات', en: '3. Transactions' },
    section3SubTitle1: { ar: '3.1 رسوم المنصة', en: '3.1 Platform Fees' },
    section3List1: {
      ar: [
        'رسوم المنصة: 5% من قيمة المنتج',
        'الحد الأدنى للرسوم: 5 ريال',
        'الحد الأقصى للرسوم: 500 ريال',
        'يتحمل البائع رسوم المنصة'
      ],
      en: [
        'Platform fee: 5% of product value',
        'Minimum fee: 5 SAR',
        'Maximum fee: 500 SAR',
        'Seller bears the platform fees'
      ]
    },
    section3SubTitle2: { ar: '3.2 الدفع', en: '3.2 Payment' },
    section3List2: {
      ar: [
        'جميع المدفوعات تتم عبر المنصة',
        'لا يجوز التعامل المباشر خارج المنصة',
        'يتم حجز المبلغ حتى تأكيد استلام المشتري',
        'يتم تحويل المبلغ للبائع بعد 24 ساعة من التسليم'
      ],
      en: [
        'All payments are made through the platform',
        'Direct transactions outside the platform are not allowed',
        'Amount is held until buyer confirms receipt',
        'Amount is transferred to seller 24 hours after delivery'
      ]
    },
    section3SubTitle3: { ar: '3.3 الشحن', en: '3.3 Shipping' },
    section3List3: {
      ar: [
        'البائع مسؤول عن شحن المنتج',
        'يجب شحن المنتج خلال 3 أيام من الطلب',
        'يجب تغليف المنتج بشكل آمن'
      ],
      en: [
        'Seller is responsible for shipping the product',
        'Product must be shipped within 3 days of order',
        'Product must be packaged securely'
      ]
    },

    // Section 4
    section4Title: { ar: '4. المنتجات المحظورة', en: '4. Prohibited Items' },
    section4Intro: {
      ar: 'يُحظر بيع أو شراء المنتجات التالية:',
      en: 'The following products are prohibited from being sold or purchased:'
    },
    section4List: {
      ar: [
        'الأسلحة والذخائر',
        'المواد المخدرة والممنوعات',
        'المنتجات المقلدة أو المزورة',
        'المنتجات المسروقة',
        'الحيوانات الحية',
        'المواد الإباحية',
        'أي منتجات مخالفة للقانون السعودي'
      ],
      en: [
        'Weapons and ammunition',
        'Drugs and prohibited substances',
        'Counterfeit or forged products',
        'Stolen products',
        'Live animals',
        'Pornographic materials',
        'Any products violating Saudi law'
      ]
    },

    // Section 5
    section5Title: { ar: '5. النزاعات', en: '5. Disputes' },
    section5Intro: {
      ar: 'في حالة حدوث نزاع بين المشتري والبائع:',
      en: 'In case of a dispute between buyer and seller:'
    },
    section5List: {
      ar: [
        'يمكن للطرفين فتح نزاع عبر المنصة',
        'يجب تقديم أدلة (صور، فيديو، رسائل)',
        'فريق الدعم يراجع النزاع خلال 3-5 أيام',
        'قرار المنصة نهائي وملزم للطرفين',
        'يمكن إعادة المنتج في حالة عدم المطابقة'
      ],
      en: [
        'Both parties can open a dispute through the platform',
        'Evidence must be provided (photos, videos, messages)',
        'Support team reviews the dispute within 3-5 days',
        'Platform decision is final and binding for both parties',
        'Product can be returned if not as described'
      ]
    },

    // Section 6
    section6Title: { ar: '6. المسؤولية', en: '6. Liability' },
    section6Intro: {
      ar: 'منصة رابط هي وسيط بين المشترين والبائعين فقط. نحن لسنا مسؤولين عن:',
      en: 'Rabit Platform is only an intermediary between buyers and sellers. We are not responsible for:'
    },
    section6List: {
      ar: [
        'جودة المنتجات المعروضة',
        'صحة أوصاف المنتجات',
        'تأخير الشحن من قبل البائع',
        'تلف المنتج أثناء الشحن',
        'الاحتيال بين المستخدمين'
      ],
      en: [
        'Quality of listed products',
        'Accuracy of product descriptions',
        'Shipping delays by the seller',
        'Product damage during shipping',
        'Fraud between users'
      ]
    },
    section6Outro: {
      ar: 'ومع ذلك، نعمل جاهدين على توفير بيئة آمنة وموثوقة.',
      en: 'However, we strive to provide a safe and reliable environment.'
    },

    // Section 7
    section7Title: { ar: '7. التعديلات', en: '7. Amendments' },
    section7P1: {
      ar: 'نحتفظ بالحق في تعديل هذه الشروط في أي وقت. سيتم إشعارك بأي تغييرات مهمة عبر البريد الإلكتروني أو الإشعارات.',
      en: 'We reserve the right to modify these terms at any time. You will be notified of any important changes via email or notifications.'
    },
    section7P2: {
      ar: 'استمرارك في استخدام المنصة بعد التعديلات يعني موافقتك على الشروط الجديدة.',
      en: 'Your continued use of the platform after amendments means your acceptance of the new terms.'
    },

    // Contact
    contactTitle: { ar: 'تواصل معنا', en: 'Contact Us' },
    contactSubtitle: {
      ar: 'لديك أسئلة حول الشروط والأحكام؟',
      en: 'Have questions about the terms and conditions?'
    }
  };

  return (
    <div
      className="min-h-screen bg-gradient-to-b from-[#fafafa] to-white"
      style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white/95 backdrop-blur-lg border-b border-[rgba(0,0,0,0.06)] px-6 py-4 z-10 shadow-sm"
      >
        <div className="flex items-center justify-between">
          <button
            onClick={onBack}
            className="w-11 h-11 rounded-2xl bg-[#f0fde8] border border-[rgba(22,51,0,0.1)] flex items-center justify-center text-[#163300] transition-all duration-200 hover:bg-[#e2fad5] active:scale-95"
          >
            <ChevronRight className={`w-6 h-6 ${isRTL ? '' : 'rotate-180'}`} />
          </button>
          <h1 className="text-xl font-semibold text-[#0a0b09]">{t.terms}</h1>
          <div className="w-11" /> {/* Spacer */}
        </div>
      </motion.div>

      {/* Content */}
      <div className="p-6 space-y-6">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="bg-gradient-to-br from-[#163300] to-[#0f2409] rounded-3xl p-8 text-center shadow-xl"
        >
          <div className="w-20 h-20 rounded-3xl bg-[#9fe870] flex items-center justify-center mx-auto mb-4">
            <FileText className="w-10 h-10 text-[#163300]" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">
            {content.heroTitle[language]}
          </h2>
          <p className="text-white/80 text-sm">
            {content.lastUpdated[language]}
          </p>
        </motion.div>

        {/* Section 1: Introduction */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-2xl border border-[rgba(0,0,0,0.06)] p-6 shadow-card"
        >
          <div className="flex items-center gap-3 mb-4" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
            <div className="w-12 h-12 rounded-2xl bg-[#f0fde8] flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-[#163300]" />
            </div>
            <h3 className="text-lg font-bold text-[#0a0b09]">{content.section1Title[language]}</h3>
          </div>
          <div className="space-y-3 text-[#6a6c6a] text-sm leading-relaxed" style={{ textAlign: isRTL ? 'right' : 'left' }}>
            <p>{content.section1P1[language]}</p>
            <p>{content.section1P2[language]}</p>
          </div>
        </motion.div>

        {/* Section 2: User Accounts */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white rounded-2xl border border-[rgba(0,0,0,0.06)] p-6 shadow-card"
        >
          <div className="flex items-center gap-3 mb-4" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
            <div className="w-12 h-12 rounded-2xl bg-[#f0fde8] flex items-center justify-center">
              <Shield className="w-6 h-6 text-[#163300]" />
            </div>
            <h3 className="text-lg font-bold text-[#0a0b09]">{content.section2Title[language]}</h3>
          </div>
          <div className="space-y-3 text-[#6a6c6a] text-sm leading-relaxed" style={{ textAlign: isRTL ? 'right' : 'left' }}>
            <p className="font-semibold text-[#0a0b09]">{content.section2SubTitle1[language]}</p>
            <ul className={`list-disc space-y-2 ${isRTL ? 'list-inside pr-4' : 'list-inside pl-4'}`}>
              {content.section2List1[language].map((item, index) => (
                <li key={index}>{item}</li>
              ))}
            </ul>

            <p className="font-semibold text-[#0a0b09] pt-3">{content.section2SubTitle2[language]}</p>
            <ul className={`list-disc space-y-2 ${isRTL ? 'list-inside pr-4' : 'list-inside pl-4'}`}>
              {content.section2List2[language].map((item, index) => (
                <li key={index}>
                  <strong>{item.label}</strong> {item.text}
                </li>
              ))}
            </ul>
          </div>
        </motion.div>

        {/* Section 3: Transactions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-white rounded-2xl border border-[rgba(0,0,0,0.06)] p-6 shadow-card"
        >
          <div className="flex items-center gap-3 mb-4" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
            <div className="w-12 h-12 rounded-2xl bg-[#f0fde8] flex items-center justify-center">
              <AlertCircle className="w-6 h-6 text-[#163300]" />
            </div>
            <h3 className="text-lg font-bold text-[#0a0b09]">{content.section3Title[language]}</h3>
          </div>
          <div className="space-y-3 text-[#6a6c6a] text-sm leading-relaxed" style={{ textAlign: isRTL ? 'right' : 'left' }}>
            <p className="font-semibold text-[#0a0b09]">{content.section3SubTitle1[language]}</p>
            <ul className={`list-disc space-y-2 ${isRTL ? 'list-inside pr-4' : 'list-inside pl-4'}`}>
              {content.section3List1[language].map((item, index) => (
                <li key={index}>{item}</li>
              ))}
            </ul>

            <p className="font-semibold text-[#0a0b09] pt-3">{content.section3SubTitle2[language]}</p>
            <ul className={`list-disc space-y-2 ${isRTL ? 'list-inside pr-4' : 'list-inside pl-4'}`}>
              {content.section3List2[language].map((item, index) => (
                <li key={index}>{item}</li>
              ))}
            </ul>

            <p className="font-semibold text-[#0a0b09] pt-3">{content.section3SubTitle3[language]}</p>
            <ul className={`list-disc space-y-2 ${isRTL ? 'list-inside pr-4' : 'list-inside pl-4'}`}>
              {content.section3List3[language].map((item, index) => (
                <li key={index}>{item}</li>
              ))}
            </ul>
          </div>
        </motion.div>

        {/* Section 4: Prohibited Items */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-red-50 border border-red-200 rounded-2xl p-6"
        >
          <h3 className="text-lg font-bold text-red-900 mb-4" style={{ textAlign: isRTL ? 'right' : 'left' }}>
            {content.section4Title[language]}
          </h3>
          <div className="space-y-2 text-red-800 text-sm" style={{ textAlign: isRTL ? 'right' : 'left' }}>
            <p>{content.section4Intro[language]}</p>
            <ul className={`list-disc space-y-1 ${isRTL ? 'list-inside pr-4' : 'list-inside pl-4'}`}>
              {content.section4List[language].map((item, index) => (
                <li key={index}>{item}</li>
              ))}
            </ul>
          </div>
        </motion.div>

        {/* Section 5: Disputes */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="bg-white rounded-2xl border border-[rgba(0,0,0,0.06)] p-6 shadow-card"
        >
          <h3 className="text-lg font-bold text-[#0a0b09] mb-4" style={{ textAlign: isRTL ? 'right' : 'left' }}>
            {content.section5Title[language]}
          </h3>
          <div className="space-y-3 text-[#6a6c6a] text-sm leading-relaxed" style={{ textAlign: isRTL ? 'right' : 'left' }}>
            <p>{content.section5Intro[language]}</p>
            <ul className={`list-disc space-y-2 ${isRTL ? 'list-inside pr-4' : 'list-inside pl-4'}`}>
              {content.section5List[language].map((item, index) => (
                <li key={index}>{item}</li>
              ))}
            </ul>
          </div>
        </motion.div>

        {/* Section 6: Liability */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="bg-white rounded-2xl border border-[rgba(0,0,0,0.06)] p-6 shadow-card"
        >
          <h3 className="text-lg font-bold text-[#0a0b09] mb-4" style={{ textAlign: isRTL ? 'right' : 'left' }}>
            {content.section6Title[language]}
          </h3>
          <div className="space-y-3 text-[#6a6c6a] text-sm leading-relaxed" style={{ textAlign: isRTL ? 'right' : 'left' }}>
            <p>{content.section6Intro[language]}</p>
            <ul className={`list-disc space-y-2 ${isRTL ? 'list-inside pr-4' : 'list-inside pl-4'}`}>
              {content.section6List[language].map((item, index) => (
                <li key={index}>{item}</li>
              ))}
            </ul>
            <p className="pt-3">{content.section6Outro[language]}</p>
          </div>
        </motion.div>

        {/* Section 7: Changes */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="bg-white rounded-2xl border border-[rgba(0,0,0,0.06)] p-6 shadow-card"
        >
          <h3 className="text-lg font-bold text-[#0a0b09] mb-4" style={{ textAlign: isRTL ? 'right' : 'left' }}>
            {content.section7Title[language]}
          </h3>
          <div className="space-y-3 text-[#6a6c6a] text-sm leading-relaxed" style={{ textAlign: isRTL ? 'right' : 'left' }}>
            <p>{content.section7P1[language]}</p>
            <p>{content.section7P2[language]}</p>
          </div>
        </motion.div>

        {/* Contact Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9 }}
          className="bg-gradient-to-br from-[#f0fde8] to-[#e2fad5] rounded-2xl p-6 text-center"
        >
          <h3 className="text-lg font-bold text-[#163300] mb-2">
            {content.contactTitle[language]}
          </h3>
          <p className="text-[#163300]/80 text-sm mb-4">
            {content.contactSubtitle[language]}
          </p>
          <div className="space-y-2 text-sm text-[#163300]">
            <p>📧 support@rabit.sa</p>
            <p>📱 +966 50 123 4567</p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
