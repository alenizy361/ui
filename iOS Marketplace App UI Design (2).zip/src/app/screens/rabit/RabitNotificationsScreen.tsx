import { motion, AnimatePresence } from "motion/react";
import { ChevronRight, Bell, Package, DollarSign, MessageCircle, Tag, Trash2, BellOff, CheckCheck, ShoppingCart, TrendingUp, AlertCircle } from "lucide-react";
import { useState, useEffect } from "react";
import { PullToRefresh } from "../../components/PullToRefresh";
import { SwipeableNotification } from "../../components/SwipeableNotification";
import { LanguageSwitcher } from "../../components/LanguageSwitcher";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";
import { notificationsAPI } from "../../utils/api";
import { useAuth } from "../../contexts/AuthContext";
import { toast } from "sonner";

interface Notification {
  id: string;
  type: "order" | "message" | "payment" | "offer" | "newOrder" | "shipping" | "review";
  titleAr: string;
  titleEn: string;
  messageAr: string;
  messageEn: string;
  time: string;
  timeEn: string;
  read: boolean;
  isToday: boolean;
  orderId?: string; // For navigation
  actionUrl?: string;
  createdAt?: string;
}

interface RabitNotificationsScreenProps {
  onBack: () => void;
  userRole?: "buyer" | "seller" | "both";
  onNavigateToOrders?: () => void;
  onNavigateToShipping?: (orderId: string) => void;
  onNavigateToChat?: () => void;
  onNavigateToWallet?: () => void;
  onNavigateToReviews?: () => void;
}

export function RabitNotificationsScreen({ onBack, userRole = "buyer", onNavigateToOrders, onNavigateToShipping, onNavigateToChat, onNavigateToWallet, onNavigateToReviews }: RabitNotificationsScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);
  const { user } = useAuth();

  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);

  // Helper function to format time ago
  const formatTimeAgo = (createdAt: string) => {
    const now = new Date();
    const created = new Date(createdAt);
    const diffMs = now.getTime() - created.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (language === 'ar') {
      if (diffMins < 1) return 'الآن';
      if (diffMins < 60) return `منذ ${diffMins} دقيقة`;
      if (diffHours < 24) return `منذ ${diffHours} ساعة`;
      if (diffDays === 1) return 'أمس';
      return `منذ ${diffDays} يوم`;
    } else {
      if (diffMins < 1) return 'Just now';
      if (diffMins < 60) return `${diffMins} min ago`;
      if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
      if (diffDays === 1) return 'Yesterday';
      return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
    }
  };

  // Helper function to check if notification is from today
  const isToday = (createdAt: string) => {
    const now = new Date();
    const created = new Date(createdAt);
    return (
      now.getDate() === created.getDate() &&
      now.getMonth() === created.getMonth() &&
      now.getFullYear() === created.getFullYear()
    );
  };

  // Convert backend notification to UI format
  const convertNotification = (backendNotif: any): Notification => {
    return {
      id: backendNotif.id,
      type: backendNotif.category === 'order' ? 'order' : 
            backendNotif.category === 'message' ? 'message' : 
            backendNotif.category === 'social' ? 'review' : 'offer',
      titleAr: backendNotif.titleAr,
      titleEn: backendNotif.title,
      messageAr: backendNotif.messageAr,
      messageEn: backendNotif.message,
      time: formatTimeAgo(backendNotif.createdAt),
      timeEn: formatTimeAgo(backendNotif.createdAt),
      read: backendNotif.read,
      isToday: isToday(backendNotif.createdAt),
      orderId: backendNotif.orderId,
      actionUrl: backendNotif.actionUrl,
      createdAt: backendNotif.createdAt,
    };
  };

  // Fetch notifications from backend
  const fetchNotifications = async () => {
    if (!user?.accessToken) {
      setLoading(false);
      return;
    }

    try {
      const response = await notificationsAPI.getNotifications(
        user.accessToken,
        { page: 1, limit: 50 }
      );

      if (response.success && response.notifications) {
        const converted = response.notifications.map(convertNotification);
        setNotifications(converted);
      }
    } catch (error) {
      console.error('Error fetching notifications:', error);
      toast.error(language === 'ar' ? 'فشل تحميل الإشعارات' : 'Failed to load notifications');
    } finally {
      setLoading(false);
    }
  };

  // Initial fetch
  useEffect(() => {
    fetchNotifications();
  }, [user?.accessToken]);

  const unreadCount = notifications.filter((n) => !n.read).length;

  const handleRefresh = async () => {
    await fetchNotifications();
  };

  const markAllAsRead = async () => {
    if (!user?.accessToken) return;

    try {
      const response = await notificationsAPI.markAllNotificationsAsRead(user.accessToken);
      
      if (response.success) {
        setNotifications(notifications.map(n => ({ ...n, read: true })));
        toast.success(language === 'ar' ? 'تم تعليم الكل كمقروء' : 'All marked as read');
      }
    } catch (error) {
      console.error('Error marking all as read:', error);
      toast.error(language === 'ar' ? 'حدث خطأ' : 'An error occurred');
    }
  };

  const deleteNotification = async (id: string) => {
    if (!user?.accessToken) return;

    try {
      const response = await notificationsAPI.deleteNotification(id, user.accessToken);
      
      if (response.success) {
        setNotifications(notifications.filter(n => n.id !== id));
        toast.success(language === 'ar' ? 'تم حذف الإشعار' : 'Notification deleted');
      }
    } catch (error) {
      console.error('Error deleting notification:', error);
      toast.error(language === 'ar' ? 'فشل الحذف' : 'Failed to delete');
    }
  };

  const markAsRead = async (id: string) => {
    if (!user?.accessToken) return;

    try {
      const response = await notificationsAPI.markNotificationAsRead(id, user.accessToken);
      
      if (response.success) {
        setNotifications(notifications.map(n => 
          n.id === id ? { ...n, read: true } : n
        ));
      }
    } catch (error) {
      console.error('Error marking as read:', error);
    }
  };

  // Handle notification click with navigation
  const handleNotificationClick = (notification: Notification) => {
    // Mark as read
    markAsRead(notification.id);
    
    // Navigate based on type
    switch (notification.type) {
      case "order":
        // Navigate to orders for buyer
        onNavigateToOrders?.();
        break;
      case "newOrder":
        // Navigate to orders for seller
        onNavigateToOrders?.();
        break;
      case "shipping":
        // Navigate to shipping screen
        onNavigateToShipping?.(notification.orderId || "RBT-2024-1234");
        break;
      case "message":
        // Navigate to chat
        onNavigateToChat?.();
        break;
      case "payment":
        // Navigate to wallet
        onNavigateToWallet?.();
        break;
      case "review":
        // Navigate to reviews or seller dashboard
        onNavigateToOrders?.();
        break;
      case "offer":
        // Stay on notifications for offers
        break;
      default:
        break;
    }
  };

  const getIcon = (type: string) => {
    switch (type) {
      case "order":
        return Package;
      case "message":
        return MessageCircle;
      case "payment":
        return DollarSign;
      case "offer":
        return Tag;
      case "newOrder":
        return ShoppingCart;
      case "shipping":
        return TrendingUp;
      case "review":
        return AlertCircle;
      default:
        return Bell;
    }
  };

  const getIconColor = (type: string) => {
    switch (type) {
      case "order":
        return "from-green-500 to-emerald-600";
      case "message":
        return "from-blue-500 to-cyan-600";
      case "payment":
        return "from-purple-500 to-pink-600";
      case "offer":
        return "from-orange-500 to-amber-600";
      case "newOrder":
        return "from-blue-500 to-cyan-600";
      case "shipping":
        return "from-blue-500 to-cyan-600";
      case "review":
        return "from-yellow-500 to-amber-600";
      default:
        return "from-gray-500 to-slate-600";
    }
  };

  // Group notifications by today/earlier
  const todayNotifications = notifications.filter((n) => n.isToday);
  const earlierNotifications = notifications.filter((n) => !n.isToday);

  return (
    <PullToRefresh onRefresh={handleRefresh}>
      <div 
        className="min-h-screen bg-gradient-to-b from-[#fafafa] to-[#f0fde8]/20" 
        style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
        dir={isRTL ? 'rtl' : 'ltr'}
      >
        {/* Premium Modern Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="sticky top-0 bg-white/80 backdrop-blur-2xl border-b border-white/50 px-5 py-5 z-10"
          style={{ 
            boxShadow: '0 8px 32px rgba(22, 51, 0, 0.04)',
            backgroundImage: 'linear-gradient(to bottom, rgba(255,255,255,0.9), rgba(255,255,255,0.7))'
          }}
        >
          <div className="flex items-center justify-between mb-4">
            <motion.button
              whileTap={{ scale: 0.92 }}
              onClick={onBack}
              className="w-11 h-11 rounded-2xl bg-gradient-to-br from-[#f8f8f8] to-[#f0f0f0] flex items-center justify-center text-[#163300] shadow-sm border border-white/60 transition-all duration-200 hover:shadow-md active:scale-95"
            >
              <ChevronRight className={`w-5 h-5 ${isRTL ? '' : 'rotate-180'}`} strokeWidth={2.5} />
            </motion.button>
            
            <div className="flex items-center gap-2.5">
              <h1 className="text-2xl font-bold bg-gradient-to-l from-[#163300] to-[#0a0b09] bg-clip-text text-transparent">
                {t.notificationsTitle}
              </h1>
              {unreadCount > 0 && (
                <motion.div
                  initial={{ scale: 0, rotate: -180 }}
                  animate={{ scale: 1, rotate: 0 }}
                  className="relative"
                >
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#163300] to-[#0a3d0a] flex items-center justify-center shadow-lg">
                    <span className="text-white text-xs font-black">{unreadCount}</span>
                  </div>
                  <motion.div
                    animate={{
                      scale: [1, 1.3, 1],
                      opacity: [0.5, 0, 0.5],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: "easeInOut",
                    }}
                    className="absolute inset-0 bg-[#9fe870] rounded-xl blur-md"
                  />
                </motion.div>
              )}
            </div>

            <LanguageSwitcher variant="compact" />
          </div>

          {/* Modern Action Bar */}
          {unreadCount > 0 && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden"
            >
              <motion.button
                whileTap={{ scale: 0.97 }}
                onClick={markAllAsRead}
                className="w-full h-11 rounded-2xl bg-gradient-to-r from-[#f0fde8] via-[#e8fcd4] to-[#f0fde8] border border-[#9fe870]/20 flex items-center justify-center gap-2.5 text-[#163300] font-bold text-sm shadow-sm hover:shadow-md transition-all duration-300 hover:border-[#9fe870]/40"
              >
                <CheckCheck className="w-4.5 h-4.5" strokeWidth={2.5} />
                <span>{t.markAllRead}</span>
              </motion.button>
            </motion.div>
          )}
        </motion.div>

        {/* Notifications Content */}
        <div className="px-4 py-5">
          {notifications.length === 0 ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.1 }}
              className="flex flex-col items-center justify-center p-12 text-center mt-24"
            >
              <motion.div
                animate={{
                  y: [0, -15, 0],
                }}
                transition={{
                  duration: 4,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
                className="relative mb-8"
              >
                <div className="w-32 h-32 rounded-[32px] bg-gradient-to-br from-white via-[#f0fde8] to-[#e2fad5] flex items-center justify-center shadow-2xl border border-white/60">
                  <BellOff className="w-16 h-16 text-[#6a6c6a]" strokeWidth={1.5} />
                </div>
                <motion.div
                  animate={{
                    scale: [1, 1.4, 1],
                    opacity: [0.2, 0, 0.2],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                  className="absolute inset-0 bg-gradient-to-br from-[#9fe870] to-[#163300] rounded-[32px] blur-3xl -z-10"
                />
              </motion.div>
              <h3 className="text-2xl font-black text-[#0a0b09] mb-3">
                {language === 'ar' ? 'لا توجد إشعارات' : 'No Notifications'}
              </h3>
              <p className="text-sm text-[#6a6c6a] max-w-[280px] leading-relaxed">
                {language === 'ar' 
                  ? 'سنرسل لك إشعاراً فورياً عند حدوث أي تحديثات مهمة على حسابك'
                  : 'We will send you a notification instantly when any important updates occur on your account'
                }
              </p>
            </motion.div>
          ) : (
            <div className="space-y-7">
              {/* Today Section */}
              {todayNotifications.length > 0 && (
                <div>
                  <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="flex items-center gap-2 mb-4 px-1"
                  >
                    <div className="w-1.5 h-6 rounded-full bg-gradient-to-b from-[#163300] to-[#9fe870]" />
                    <h2 className="text-sm font-black text-[#163300] tracking-wide uppercase">
                      اليوم
                    </h2>
                  </motion.div>
                  <div className="space-y-3">
                    {todayNotifications.map((notification, index) => {
                      const Icon = getIcon(notification.type);
                      const gradient = getIconColor(notification.type);

                      return (
                        <motion.div
                          key={notification.id}
                          initial={{ opacity: 0, x: 50, scale: 0.95 }}
                          animate={{ opacity: 1, x: 0, scale: 1 }}
                          transition={{ 
                            delay: index * 0.05,
                            type: "spring",
                            stiffness: 260,
                            damping: 20
                          }}
                        >
                          <SwipeableNotification
                            id={notification.id}
                            onDelete={() => deleteNotification(notification.id)}
                            onTap={() => handleNotificationClick(notification)}
                          >
                            {/* Main Card */}
                            <div className={`relative overflow-hidden rounded-3xl transition-all duration-500 ${
                              !notification.read 
                                ? "bg-gradient-to-br from-white via-[#f0fde8]/30 to-white shadow-xl border-2 border-[#9fe870]/40" 
                                : "bg-white/70 backdrop-blur-sm shadow-md border border-[rgba(0,0,0,0.04)] hover:shadow-xl hover:border-[rgba(0,0,0,0.08)]"
                            }`}>
                              <div className="p-5">
                                <div className="flex gap-4">
                                  {/* Premium Icon Badge */}
                                  <div className="relative flex-shrink-0">
                                    <motion.div 
                                      whileHover={{ rotate: [0, -10, 10, 0] }}
                                      transition={{ duration: 0.5 }}
                                      className={`w-16 h-16 rounded-[20px] bg-gradient-to-br ${gradient} flex items-center justify-center shadow-lg relative overflow-hidden`}
                                    >
                                      <Icon className="w-8 h-8 text-white relative z-10" strokeWidth={2.5} />
                                      {/* Shine effect */}
                                      <motion.div
                                        animate={{
                                          x: ['-100%', '200%'],
                                        }}
                                        transition={{
                                          duration: 3,
                                          repeat: Infinity,
                                          repeatDelay: 2,
                                          ease: "easeInOut",
                                        }}
                                        className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
                                      />
                                    </motion.div>
                                    {!notification.read && (
                                      <motion.div
                                        initial={{ scale: 0 }}
                                        animate={{ scale: 1 }}
                                        className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-gradient-to-br from-[#163300] to-[#0a3d0a] rounded-full border-[3px] border-white shadow-lg flex items-center justify-center"
                                      >
                                        <motion.div
                                          animate={{
                                            scale: [1, 1.2, 1],
                                          }}
                                          transition={{
                                            duration: 1.5,
                                            repeat: Infinity,
                                          }}
                                          className="w-2 h-2 bg-[#9fe870] rounded-full"
                                        />
                                      </motion.div>
                                    )}
                                  </div>

                                  {/* Content */}
                                  <div className="flex-1 min-w-0 text-right">
                                    <div className="flex items-start justify-between gap-3 mb-2">
                                      <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#fafafa] to-[#f5f5f5] border border-[rgba(0,0,0,0.04)]">
                                        <div className="w-1 h-1 rounded-full bg-[#9fe870]" />
                                        <span className="text-[11px] text-[#6a6c6a] font-bold">
                                          {language === "ar" ? notification.time : notification.timeEn}
                                        </span>
                                      </div>
                                      <h3 className={`font-black text-base leading-tight ${
                                        !notification.read ? "text-[#163300]" : "text-[#0a0b09]"
                                      }`}>
                                        {language === "ar" ? notification.titleAr : notification.titleEn}
                                      </h3>
                                    </div>
                                    <p className={`text-[13px] leading-relaxed ${
                                      !notification.read ? "text-[#2a2c2a] font-medium" : "text-[#6a6c6a]"
                                    }`}>
                                      {language === "ar" ? notification.messageAr : notification.messageEn}
                                    </p>
                                  </div>
                                </div>
                              </div>

                              {/* Gradient Bottom Border for Unread */}
                              {!notification.read && (
                                <div className="h-1 bg-gradient-to-r from-transparent via-[#9fe870] to-transparent" />
                              )}
                            </div>
                          </SwipeableNotification>
                        </motion.div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Earlier Section */}
              {earlierNotifications.length > 0 && (
                <div>
                  <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.2 }}
                    className="flex items-center gap-2 mb-4 px-1"
                  >
                    <div className="w-1.5 h-6 rounded-full bg-gradient-to-b from-[#6a6c6a] to-[#9a9c9a]" />
                    <h2 className="text-sm font-black text-[#6a6c6a] tracking-wide uppercase">
                      سابقاً
                    </h2>
                  </motion.div>
                  <div className="space-y-3">
                    {earlierNotifications.map((notification, index) => {
                      const Icon = getIcon(notification.type);
                      const gradient = getIconColor(notification.type);

                      return (
                        <motion.div
                          key={notification.id}
                          initial={{ opacity: 0, x: 50, scale: 0.95 }}
                          animate={{ opacity: 1, x: 0, scale: 1 }}
                          transition={{ 
                            delay: 0.2 + index * 0.05,
                            type: "spring",
                            stiffness: 260,
                            damping: 20
                          }}
                        >
                          <SwipeableNotification
                            id={notification.id}
                            onDelete={() => deleteNotification(notification.id)}
                            onTap={() => handleNotificationClick(notification)}
                          >
                            <div className="bg-white/60 backdrop-blur-md rounded-3xl shadow-sm border border-[rgba(0,0,0,0.04)] hover:shadow-lg hover:bg-white/80 transition-all duration-500 overflow-hidden">
                              <div className="p-5">
                                <div className="flex gap-4">
                                  {/* Muted Icon for Read */}
                                  <div className={`w-16 h-16 rounded-[20px] bg-gradient-to-br ${gradient} opacity-60 flex items-center justify-center shadow-md`}>
                                    <Icon className="w-8 h-8 text-white" strokeWidth={2} />
                                  </div>

                                  {/* Content */}
                                  <div className="flex-1 min-w-0 text-right">
                                    <div className="flex items-start justify-between gap-3 mb-2">
                                      <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#fafafa]/50 border border-[rgba(0,0,0,0.03)]">
                                        <div className="w-1 h-1 rounded-full bg-[#9a9c9a]" />
                                        <span className="text-[11px] text-[#9a9c9a] font-bold">
                                          {language === "ar" ? notification.time : notification.timeEn}
                                        </span>
                                      </div>
                                      <h3 className="font-bold text-base text-[#4a4c4a] leading-tight">
                                        {language === "ar" ? notification.titleAr : notification.titleEn}
                                      </h3>
                                    </div>
                                    <p className="text-[13px] text-[#6a6c6a] leading-relaxed">
                                      {language === "ar" ? notification.messageAr : notification.messageEn}
                                    </p>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </SwipeableNotification>
                        </motion.div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </PullToRefresh>
  );
}