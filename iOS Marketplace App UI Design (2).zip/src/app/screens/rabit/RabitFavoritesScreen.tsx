import { motion } from "motion/react";
import { ChevronRight, Heart, Trash2 } from "lucide-react";
import { type RabitProduct } from "../../data/rabitProducts";
import { useFavorites } from "../../hooks/useLocalStorage";
import { PullToRefresh } from "../../components/PullToRefresh";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";
import { useState, useEffect } from "react";
import { getProducts } from "../../services/products.service";
import { toast } from "sonner";

interface RabitFavoritesScreenProps {
  onBack: () => void;
  onProductClick: (product: RabitProduct) => void;
}

export function RabitFavoritesScreen({ onBack, onProductClick }: RabitFavoritesScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);
  const { favorites, toggleFavorite } = useFavorites();
  const [isLoadingFavorites, setIsLoadingFavorites] = useState(false);
  const [favoritesStats, setFavoritesStats] = useState<any>(null);
  const [favoriteProducts, setFavoriteProducts] = useState<RabitProduct[]>([]);
  
  // Fetch products and filter by favorites
  useEffect(() => {
    const fetchFavoriteProducts = async () => {
      setIsLoadingFavorites(true);
      try {
        const result = await getProducts();
        if (result.success && result.products) {
          // Filter products by favorite IDs
          const filtered = result.products.filter((p: RabitProduct) => favorites.includes(p.id));
          setFavoriteProducts(filtered);
        } else {
          toast.error(language === 'ar' ? 'فشل تحميل المفضلة' : 'Failed to load favorites');
          setFavoriteProducts([]);
        }
      } catch (error) {
        console.error('Error fetching favorite products:', error);
        toast.error(language === 'ar' ? 'حدث خطأ أثناء تحميل المفضلة' : 'Error loading favorites');
        setFavoriteProducts([]);
      }
      setIsLoadingFavorites(false);
    };

    fetchFavoriteProducts();
  }, [favorites, language]);

  const handleRefresh = async () => {
    await new Promise(resolve => setTimeout(resolve, 1500));
    console.log("Refreshing favorites data...");
    
    // Refetch products
    try {
      const result = await getProducts();
      if (result.success && result.products) {
        const filtered = result.products.filter((p: RabitProduct) => favorites.includes(p.id));
        setFavoriteProducts(filtered);
        toast.success(language === 'ar' ? 'تم تحديث المفضلة!' : 'Favorites refreshed!');
      }
    } catch (error) {
      console.error('Error refreshing favorites:', error);
    }
  };

  return (
    <PullToRefresh onRefresh={handleRefresh}>
      <div className="min-h-screen bg-[#fafafa]" style={{ fontFamily: 'Cairo, sans-serif' }}>
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 flex items-center justify-between z-10"
        >
          <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
            <ChevronRight className="w-6 h-6 text-[#0e0f0c]" />
          </button>
          <div className="flex items-center gap-2">
            <span className="text-sm text-[#6a6c6a]">({favorites.length})</span>
            <h1 className="text-xl font-semibold text-[#0e0f0c]">المفضلة</h1>
          </div>
          <div className="w-10" />
        </motion.div>

        {favoriteProducts.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center justify-center py-20 px-6"
          >
            <div className="w-20 h-20 rounded-full bg-[rgba(106,108,106,0.1)] flex items-center justify-center mb-4">
              <Heart className="w-10 h-10 text-[#6a6c6a]" />
            </div>
            <h2 className="text-xl font-bold text-[#0e0f0c] mb-2 text-center">لا توجد منتجات مفضلة</h2>
            <p className="text-sm text-[#6a6c6a] text-center leading-relaxed max-w-xs">
              ابدأ بإضافة منتجات إلى المفضلة لتسهيل الوصول إليها لاحقاً
            </p>
          </motion.div>
        ) : (
          <div className="p-6 space-y-4">
            {favoriteProducts.map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="bg-white rounded-[12px] border border-[rgba(14,15,12,0.12157)] overflow-hidden shadow-sm"
              >
                <div className="flex gap-4 p-4">
                  <button
                    onClick={() => onProductClick(product)}
                    className="w-24 h-24 bg-[rgba(22,51,0,0.07843)] rounded-[8px] flex-shrink-0 overflow-hidden"
                  >
                    <img
                      src={product.image}
                      alt={product.titleAr}
                      className="w-full h-full object-cover"
                    />
                  </button>
                  <div className="flex-1 text-right">
                    <button
                      onClick={() => onProductClick(product)}
                      className="text-left w-full"
                    >
                      <h3 className="font-semibold text-[#0e0f0c] mb-1 text-right">
                        {product.titleAr}
                      </h3>
                      <p className="text-sm text-[#6a6c6a] mb-2">{product.sellerAr}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-[#6a6c6a]">⭐ {product.rating}</span>
                        <span className="text-lg font-bold text-[#163300]">
                          {product.price} ر.س
                        </span>
                      </div>
                    </button>
                  </div>
                  <button
                    onClick={() => toggleFavorite(product.id)}
                    className="w-10 h-10 rounded-full bg-[rgba(203,39,47,0.1)] flex items-center justify-center self-start"
                  >
                    <Trash2 className="w-5 h-5 text-[#cb272f]" />
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </PullToRefresh>
  );
}