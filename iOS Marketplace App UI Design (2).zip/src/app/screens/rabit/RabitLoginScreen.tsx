import { motion } from "motion/react";
import { ModernButton } from "../../components/design-system";
import { WiseInput } from "../../components/WiseInput";
import { ChevronRight, Mail, Lock, Eye, EyeOff, LogIn, Sparkles } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { triggerHaptic } from "../../utils/haptics";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";
import { useAuth } from "../../contexts/AuthContext";

interface RabitLoginScreenProps {
  onBack: () => void;
  onRegister: () => void;
  onSuccess: () => void;
}

export function RabitLoginScreen({ onBack, onRegister, onSuccess }: RabitLoginScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);
  const { signIn } = useAuth();
  
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleContinue = async () => {
    // Validation
    if (!email.trim() || !password.trim()) {
      toast.error(language === 'ar' ? 'الرجاء إدخال البريد الإلكتروني وكلمة المرور' : 'Please enter email and password');
      triggerHaptic('error');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      toast.error(language === 'ar' ? 'البريد الإلكتروني غير صالح' : 'Invalid email address');
      triggerHaptic('error');
      return;
    }

    // Sign in
    triggerHaptic('medium');
    setLoading(true);

    const result = await signIn(email.trim(), password.trim());

    if (!result.success) {
      triggerHaptic('error');
      const errorMsg = language === 'ar'
        ? (result.error?.includes('Invalid') ? 'البريد الإلكتروني أو كلمة المرور غير صحيحة' : result.error || 'فشل تسجيل الدخول')
        : result.error || 'Login failed';
      toast.error(errorMsg);
      setLoading(false);
      return;
    }

    // Success
    triggerHaptic('success');
    toast.success(language === 'ar' ? 'مرحباً بعودتك! ✓' : 'Welcome back! ✓');
    
    setTimeout(() => {
      onSuccess();
    }, 300);
  };

  return (
    <div 
      className="min-h-screen bg-gradient-to-br from-[#fafafa] via-white to-[#f0fde8]/20 flex flex-col relative overflow-hidden" 
      style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Animated Background */}
      <motion.div
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.1, 0.2, 0.1],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute -top-40 -right-40 w-96 h-96 bg-gradient-to-br from-[#9fe870] to-[#163300] rounded-full blur-3xl"
      />
      <motion.div
        animate={{
          scale: [1.2, 1, 1.2],
          opacity: [0.1, 0.15, 0.1],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute -bottom-40 -left-40 w-96 h-96 bg-gradient-to-tr from-[#163300] to-[#9fe870] rounded-full blur-3xl"
      />

      {/* Header */}
      <div className="relative z-10 pt-6 px-6">
        <button
          onClick={() => {
            triggerHaptic('light');
            onBack();
          }}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
        >
          <ChevronRight className={`w-5 h-5 ${isRTL ? '' : 'rotate-180'}`} />
          <span>{language === 'ar' ? 'رجوع' : 'Back'}</span>
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md"
        >
          {/* Icon */}
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 200, damping: 15 }}
            className="w-20 h-20 bg-gradient-to-br from-[#163300] to-[#1e4400] rounded-3xl flex items-center justify-center mb-8 mx-auto shadow-lg"
          >
            <LogIn className="w-10 h-10 text-[#9fe870]" />
          </motion.div>

          {/* Title */}
          <h1 className="text-4xl font-bold text-center mb-3 bg-gradient-to-r from-[#163300] to-[#1e4400] bg-clip-text text-transparent">
            {language === 'ar' ? 'مرحباً بعودتك' : 'Welcome Back'}
          </h1>
          <p className="text-center text-gray-600 mb-8">
            {language === 'ar' ? 'سجّل الدخول للمتابعة' : 'Sign in to continue'}
          </p>

          {/* Form */}
          <div className="space-y-4">
            <WiseInput
              leftIcon={<Mail />}
              placeholder={language === 'ar' ? 'البريد الإلكتروني' : 'Email'}
              value={email}
              onChange={setEmail}
              type="email"
              autoComplete="email"
            />

            <WiseInput
              leftIcon={<Lock />}
              placeholder={language === 'ar' ? 'كلمة المرور' : 'Password'}
              value={password}
              onChange={setPassword}
              type={showPassword ? 'text' : 'password'}
              autoComplete="current-password"
              rightIcon={
                <button
                  onClick={() => setShowPassword(!showPassword)}
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              }
            />
          </div>

          {/* Forgot Password */}
          <div className="mt-4 text-center">
            <button className="text-sm text-[#163300] hover:text-[#1e4400] font-medium transition-colors">
              {language === 'ar' ? 'نسيت كلمة المرور؟' : 'Forgot password?'}
            </button>
          </div>

          {/* Sign In Button */}
          <div className="mt-8">
            <ModernButton
              onClick={handleContinue}
              loading={loading}
              disabled={loading}
              fullWidth
            >
              {language === 'ar' ? 'تسجيل الدخول' : 'Sign In'}
            </ModernButton>
          </div>

          {/* Register Link */}
          <div className="mt-6 text-center">
            <span className="text-gray-600">
              {language === 'ar' ? 'لا تملك حساب؟ ' : "Don't have an account? "}
            </span>
            <button
              onClick={() => {
                triggerHaptic('light');
                onRegister();
              }}
              className="text-[#163300] hover:text-[#1e4400] font-semibold transition-colors"
            >
              {language === 'ar' ? 'إنشاء حساب' : 'Sign Up'}
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}