import { motion } from "motion/react";
import { ChevronRight, ShoppingBag, X, RotateCcw, Calendar, ArrowDownLeft, ArrowUpRight } from "lucide-react";
import { useState } from "react";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";

interface RabitBuyerTransactionHistoryScreenProps {
  onBack: () => void;
}

export function RabitBuyerTransactionHistoryScreen({ onBack }: RabitBuyerTransactionHistoryScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);
  const [filter, setFilter] = useState<"all" | "purchase" | "refund">("all");

  const transactions: Transaction[] = [
    {
      id: "1",
      type: "purchase",
      amount: -4500,
      description: "آيفون 14 برو ماكس",
      date: "2024-12-24",
      status: "completed",
      orderId: "RBT-2024-5678",
    },
    {
      id: "2",
      type: "purchase",
      amount: -1800,
      description: "ساعة أبل Series 8",
      date: "2024-12-21",
      status: "completed",
      orderId: "RBT-2024-5544",
    },
    {
      id: "3",
      type: "refund",
      amount: 950,
      description: "استرجاع مبلغ - طلب ملغي",
      date: "2024-12-18",
      status: "completed",
      orderId: "RBT-2024-5432",
    },
    {
      id: "4",
      type: "purchase",
      amount: -650,
      description: "سماعات AirPods Pro",
      date: "2024-12-15",
      status: "completed",
      orderId: "RBT-2024-5321",
    },
    {
      id: "5",
      type: "purchase",
      amount: -2300,
      description: "لاب توب Dell XPS",
      date: "2024-12-10",
      status: "pending",
      orderId: "RBT-2024-5210",
    },
  ];

  const filteredTransactions = transactions.filter((t) => {
    if (filter === "all") return true;
    return t.type === filter;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "text-[#008026] bg-[#008026]/10";
      case "pending":
        return "text-[#df8700] bg-[#df8700]/10";
      case "failed":
        return "text-[#cb272f] bg-[#cb272f]/10";
      default:
        return "text-[#6a6c6a] bg-[#6a6c6a]/10";
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "completed":
        return "مكتمل";
      case "pending":
        return "قيد المعالجة";
      case "failed":
        return "فشل";
      default:
        return status;
    }
  };

  return (
    <div className="min-h-screen bg-white" style={{ fontFamily: 'Cairo, sans-serif' }}>
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 flex items-center justify-between z-10"
      >
        <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
          <ChevronRight className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-semibold text-[#0e0f0c]">سجل المشتريات</h1>
        <div className="w-10" />
      </motion.div>

      <div className="p-6">
        {/* Filter Chips */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {[
            { value: "all", label: "الكل" },
            { value: "purchase", label: "مشتريات" },
            { value: "refund", label: "استرجاع" },
          ].map((filterOption) => (
            <button
              key={filterOption.value}
              onClick={() => setFilter(filterOption.value as any)}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                filter === filterOption.value
                  ? "bg-[#163300] text-white"
                  : "bg-[rgba(22,51,0,0.07843)] text-[#163300] hover:bg-[rgba(22,51,0,0.12)]"
              }`}
            >
              {filterOption.label}
            </button>
          ))}
        </div>

        {/* Summary Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[rgba(22,51,0,0.07843)] rounded-[12px] p-4 mb-6 border border-[rgba(14,15,12,0.12157)]"
        >
          <p className="text-sm text-[#6a6c6a] mb-1 text-right">إجمالي المشتريات هذا الشهر</p>
          <p className="text-2xl font-bold text-[#163300] text-right">٩٬٢٥٠ ر.س</p>
        </motion.div>

        {/* Transactions List */}
        <div className="space-y-3">
          {filteredTransactions.map((transaction, index) => (
            <motion.div
              key={transaction.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
              className="bg-white border border-[rgba(14,15,12,0.12157)] rounded-[12px] p-4"
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-start gap-3 flex-1">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    transaction.type === "refund" ? "bg-[#008026]/10" : "bg-[#163300]/10"
                  }`}>
                    {transaction.type === "refund" ? (
                      <ArrowDownLeft className="w-5 h-5 text-[#008026] rotate-180" />
                    ) : (
                      <ShoppingBag className="w-5 h-5 text-[#163300]" />
                    )}
                  </div>
                  <div className="flex-1 text-right">
                    <p className="font-semibold text-[#0e0f0c] mb-1">{transaction.description}</p>
                    <p className="text-xs text-[#6a6c6a] mb-2">
                      {transaction.orderId} • {transaction.date}
                    </p>
                    <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(transaction.status)}`}>
                      {getStatusText(transaction.status)}
                    </span>
                  </div>
                </div>
                <span
                  className={`text-lg font-bold ${
                    transaction.amount > 0 ? "text-[#008026]" : "text-[#cb272f]"
                  }`}
                >
                  {transaction.amount > 0 ? "+" : ""}{transaction.amount} ر.س
                </span>
              </div>
            </motion.div>
          ))}
        </div>

        {filteredTransactions.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <Filter className="w-12 h-12 text-[#6a6c6a] mx-auto mb-3 opacity-50" />
            <p className="text-[#6a6c6a]">لا توجد معاملات</p>
          </motion.div>
        )}
      </div>
    </div>
  );
}