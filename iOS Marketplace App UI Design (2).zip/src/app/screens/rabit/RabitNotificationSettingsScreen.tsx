import { motion } from "motion/react";
import { ChevronRight, Bell, Mail, MessageCircle, Package, DollarSign, Tag } from "lucide-react";
import { useState, useEffect } from "react";
import { useLanguage } from "../../contexts/LanguageContext";
import { notificationsAPI } from "../../utils/api";
import { useAuth } from "../../contexts/AuthContext";
import { toast } from "sonner";

interface RabitNotificationSettingsScreenProps {
  onBack: () => void;
  onSaveSuccess: () => void;
}

export function RabitNotificationSettingsScreen({
  onBack,
  onSaveSuccess,
}: RabitNotificationSettingsScreenProps) {
  const { language, isRTL } = useLanguage();
  const { user } = useAuth();

  const [settings, setSettings] = useState({
    // Push Notifications
    pushOrders: true,
    pushMessages: true,
    pushPromotions: false,
    pushPayments: true,
    pushShipping: true,
    
    // Email Notifications
    emailOrders: true,
    emailMessages: false,
    emailPromotions: false,
    emailWeeklyReport: true,
    
    // SMS Notifications
    smsOrders: false,
    smsPayments: true,
    smsShipping: false,
  });

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // Load preferences from backend
  useEffect(() => {
    const loadPreferences = async () => {
      if (!user?.accessToken) {
        setLoading(false);
        return;
      }

      try {
        const response = await notificationsAPI.getNotificationPreferences(user.accessToken);
        
        if (response.success && response.preferences) {
          // Map backend preferences to UI settings
          setSettings({
            pushOrders: response.preferences.order_created ?? true,
            pushMessages: response.preferences.message_received ?? true,
            pushPromotions: response.preferences.promotion ?? false,
            pushPayments: response.preferences.payment_received ?? true,
            pushShipping: response.preferences.order_shipped ?? true,
            emailOrders: response.preferences.order_created ?? true,
            emailMessages: response.preferences.message_received ?? false,
            emailPromotions: response.preferences.promotion ?? false,
            emailWeeklyReport: true,
            smsOrders: false,
            smsPayments: response.preferences.payment_received ?? true,
            smsShipping: response.preferences.order_shipped ?? false,
          });
        }
      } catch (error) {
        console.error('Error loading preferences:', error);
        toast.error(language === 'ar' ? 'فشل تحميل الإعدادات' : 'Failed to load settings');
      } finally {
        setLoading(false);
      }
    };

    loadPreferences();
  }, [user?.accessToken]);

  const content = {
    ar: {
      notificationSettings: "إعدادات الإشعارات",
      pushNotifications: "إشعارات التطبيق",
      emailNotifications: "إشعارات البريد الإلكتروني",
      smsNotifications: "إشعارات الرسائل النصية",
      
      orders: "الطلبات",
      ordersDesc: "تحديثات الطلبات الجديدة وحالتها",
      messages: "الرسائل",
      messagesDesc: "رسائل جديدة من البائعين والمشترين",
      promotions: "العروض الترويجية",
      promotionsDesc: "عروض خاصة وخصومات",
      payments: "المدفوعات",
      paymentsDesc: "تأكيدات الدفع والاستلام",
      shipping: "الشحن",
      shippingDesc: "تحديثات الشحن والتوصيل",
      weeklyReport: "التقرير الأسبوعي",
      weeklyReportDesc: "ملخص أسبوعي لنشاطك",
      
      saveSettings: "حفظ الإعدادات",
      settingsSaved: "تم حفظ الإعدادات بنجاح",
      managePreferences: "إدارة تفضيلاتك",
      managePreferencesDesc: "اختر الإشعارات التي تريد استلامها",
    },
    en: {
      notificationSettings: "Notification Settings",
      pushNotifications: "Push Notifications",
      emailNotifications: "Email Notifications",
      smsNotifications: "SMS Notifications",
      
      orders: "Orders",
      ordersDesc: "New orders and status updates",
      messages: "Messages",
      messagesDesc: "New messages from sellers and buyers",
      promotions: "Promotions",
      promotionsDesc: "Special offers and discounts",
      payments: "Payments",
      paymentsDesc: "Payment confirmations and receipts",
      shipping: "Shipping",
      shippingDesc: "Shipping and delivery updates",
      weeklyReport: "Weekly Report",
      weeklyReportDesc: "Weekly summary of your activity",
      
      saveSettings: "Save Settings",
      settingsSaved: "Settings saved successfully",
      managePreferences: "Manage Your Preferences",
      managePreferencesDesc: "Choose which notifications you want to receive",
    },
  };
  const c = content[language];

  const toggleSetting = (key: keyof typeof settings) => {
    setSettings((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const handleSave = async () => {
    if (!user?.accessToken) return;

    setSaving(true);

    try {
      // Map UI settings to backend preference format
      const preferences = {
        order_created: settings.pushOrders,
        order_shipped: settings.pushShipping,
        order_delivered: settings.pushShipping,
        message_received: settings.pushMessages,
        payment_received: settings.pushPayments,
        promotion: settings.pushPromotions,
        review_received: true,
        follow: true,
        like: false,
        comment: false,
        mention: false,
        system: true,
        account: true,
        security: true,
      };

      const response = await notificationsAPI.updateNotificationPreferences(
        preferences,
        user.accessToken
      );

      if (response.success) {
        toast.success(c.settingsSaved);
        onSaveSuccess();
      } else {
        toast.error(response.error || (language === 'ar' ? 'فشل حفظ الإعدادات' : 'Failed to save settings'));
      }
    } catch (error) {
      console.error('Error saving preferences:', error);
      toast.error(language === 'ar' ? 'حدث خطأ' : 'An error occurred');
    } finally {
      setSaving(false);
    }
  };

  const notificationGroups = [
    {
      title: c.pushNotifications,
      icon: Bell,
      items: [
        { key: "pushOrders" as const, label: c.orders, description: c.ordersDesc, icon: Package },
        { key: "pushMessages" as const, label: c.messages, description: c.messagesDesc, icon: MessageCircle },
        { key: "pushPromotions" as const, label: c.promotions, description: c.promotionsDesc, icon: Tag },
        { key: "pushPayments" as const, label: c.payments, description: c.paymentsDesc, icon: DollarSign },
        { key: "pushShipping" as const, label: c.shipping, description: c.shippingDesc, icon: Package },
      ],
    },
    {
      title: c.emailNotifications,
      icon: Mail,
      items: [
        { key: "emailOrders" as const, label: c.orders, description: c.ordersDesc, icon: Package },
        { key: "emailMessages" as const, label: c.messages, description: c.messagesDesc, icon: MessageCircle },
        { key: "emailPromotions" as const, label: c.promotions, description: c.promotionsDesc, icon: Tag },
        { key: "emailWeeklyReport" as const, label: c.weeklyReport, description: c.weeklyReportDesc, icon: Mail },
      ],
    },
    {
      title: c.smsNotifications,
      icon: MessageCircle,
      items: [
        { key: "smsOrders" as const, label: c.orders, description: c.ordersDesc, icon: Package },
        { key: "smsPayments" as const, label: c.payments, description: c.paymentsDesc, icon: DollarSign },
        { key: "smsShipping" as const, label: c.shipping, description: c.shippingDesc, icon: Package },
      ],
    },
  ];

  return (
    <div
      className="min-h-screen bg-[#fafafa] pb-32"
      style={{ fontFamily: language === "ar" ? "Cairo, sans-serif" : "system-ui, -apple-system, sans-serif" }}
      dir={isRTL ? "rtl" : "ltr"}
    >
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 z-10"
      >
        <div className="flex items-center justify-between">
          <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
            <ChevronRight className={`w-6 h-6 text-[#0e0f0c] ${isRTL ? "" : "rotate-180"}`} />
          </button>
          <h1 className="text-xl font-semibold text-[#0e0f0c]">{c.notificationSettings}</h1>
          <div className="w-10" />
        </div>
      </motion.div>

      <div className="p-6 space-y-6">
        {/* Header Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-br from-[#163300] to-[#1a3d00] rounded-[16px] p-6 text-white"
        >
          <Bell className="w-8 h-8 mb-3" />
          <h2 className={`text-lg font-bold mb-2 ${isRTL ? "text-right" : "text-left"}`}>
            {c.managePreferences}
          </h2>
          <p className={`text-sm opacity-90 ${isRTL ? "text-right" : "text-left"}`}>
            {c.managePreferencesDesc}
          </p>
        </motion.div>

        {/* Notification Groups */}
        {notificationGroups.map((group, groupIndex) => {
          const GroupIcon = group.icon;
          return (
            <motion.div
              key={group.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 + groupIndex * 0.1 }}
              className="bg-white rounded-[16px] p-6"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.12157)] flex items-center justify-center">
                  <GroupIcon className="w-5 h-5 text-[#163300]" />
                </div>
                <h3 className={`font-bold text-[#0e0f0c] ${isRTL ? "text-right" : "text-left"}`}>
                  {group.title}
                </h3>
              </div>

              <div className="space-y-4">
                {group.items.map((item) => {
                  const ItemIcon = item.icon;
                  return (
                    <div
                      key={item.key}
                      className="flex items-start justify-between py-3 border-b border-[rgba(14,15,12,0.12157)] last:border-0"
                    >
                      <div className="flex items-start gap-3 flex-1">
                        <div className="w-8 h-8 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center flex-shrink-0 mt-1">
                          <ItemIcon className="w-4 h-4 text-[#163300]" />
                        </div>
                        <div className="flex-1">
                          <p className={`font-semibold text-[#0e0f0c] text-sm mb-1 ${isRTL ? "text-right" : "text-left"}`}>
                            {item.label}
                          </p>
                          <p className={`text-xs text-[#6a6c6a] ${isRTL ? "text-right" : "text-left"}`}>
                            {item.description}
                          </p>
                        </div>
                      </div>

                      {/* Toggle Switch */}
                      <button
                        onClick={() => toggleSetting(item.key)}
                        className={`relative w-12 h-6 rounded-full transition-colors flex-shrink-0 ${
                          settings[item.key] ? "bg-[#163300]" : "bg-[rgba(14,15,12,0.12157)]"
                        }`}
                      >
                        <motion.div
                          animate={{
                            x: settings[item.key] ? (isRTL ? -24 : 24) : 0,
                          }}
                          transition={{ type: "spring", stiffness: 500, damping: 30 }}
                          className="absolute top-1 left-1 w-4 h-4 bg-white rounded-full"
                        />
                      </button>
                    </div>
                  );
                })}
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Fixed Bottom Button */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-[rgba(14,15,12,0.12157)] px-6 py-4 max-w-[430px] mx-auto">
        <button
          onClick={handleSave}
          className="w-full py-3 bg-[#163300] text-white font-semibold rounded-[12px] hover:bg-[#1a3d00] transition-colors"
        >
          {c.saveSettings}
        </button>
      </div>
    </div>
  );
}