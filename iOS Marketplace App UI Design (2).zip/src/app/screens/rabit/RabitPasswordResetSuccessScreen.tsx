import { motion } from "motion/react";
import { CheckCircle, Home } from "lucide-react";
import { useEffect } from "react";
import { triggerHaptic } from "../../utils/haptics";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";

interface RabitPasswordResetSuccessScreenProps {
  onContinue: () => void;
}

export function RabitPasswordResetSuccessScreen({
  onContinue,
}: RabitPasswordResetSuccessScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);

  useEffect(() => {
    triggerHaptic("success");
  }, []);

  return (
    <div
      className="min-h-screen bg-gradient-to-b from-[#f0fde8] to-white flex items-center justify-center p-6"
      style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-md w-full"
      >
        {/* Success Icon with Animation */}
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{
            type: "spring",
            stiffness: 200,
            damping: 15,
            delay: 0.2,
          }}
          className="flex justify-center mb-8"
        >
          <div className="relative">
            {/* Background Circle */}
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.1 }}
              className="w-32 h-32 rounded-full bg-gradient-to-br from-[#9fe870] to-[#7ec45a] flex items-center justify-center shadow-2xl"
            >
              <CheckCircle className="w-16 h-16 text-white" strokeWidth={2.5} />
            </motion.div>

            {/* Pulsing Ring */}
            <motion.div
              initial={{ scale: 1, opacity: 0.5 }}
              animate={{ scale: 1.5, opacity: 0 }}
              transition={{
                duration: 1.5,
                repeat: Infinity,
                ease: "easeOut",
              }}
              className="absolute inset-0 rounded-full bg-[#9fe870]"
            />
          </div>
        </motion.div>

        {/* Success Message */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="text-center space-y-4 mb-8"
        >
          <h1 className="text-3xl font-bold text-[#163300]">{language === 'ar' ? 'تم بنجاح! 🎉' : 'Success! 🎉'}</h1>
          <p className="text-[#6a6c6a] leading-relaxed">
            {language === 'ar' ? 'تم تغيير كلمة المرور بنجاح' : 'Password changed successfully'}
            <br />
            {language === 'ar' ? 'يمكنك الآن تسجيل الدخول باستخدام كلمة المرور الجديدة' : 'You can now sign in with your new password'}
          </p>
        </motion.div>

        {/* Success Details */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="bg-white rounded-2xl border border-[rgba(0,0,0,0.06)] p-6 mb-6 shadow-card"
        >
          <div className={`flex items-center gap-3 ${isRTL ? 'text-right' : 'text-left'}`}>
            <div className="flex-1">
              <p className="text-sm text-[#6a6c6a] mb-1">{language === 'ar' ? 'حالة العملية' : 'Status'}</p>
              <p className="font-semibold text-[#163300]">{language === 'ar' ? 'تم التحديث بنجاح' : 'Successfully Updated'}</p>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-[#f0fde8] flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-[#163300]" />
            </div>
          </div>
        </motion.div>

        {/* Continue Button */}
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => {
            triggerHaptic("light");
            onContinue();
          }}
          className="w-full py-4 bg-gradient-to-br from-[#163300] to-[#0f2409] text-white font-semibold rounded-2xl shadow-lg hover:shadow-xl transition-all duration-200 flex items-center justify-center gap-2"
        >
          <Home className="w-5 h-5" />
          {language === 'ar' ? 'الذهاب لتسجيل الدخول' : 'Go to Sign In'}
        </motion.button>

        {/* Decorative Elements */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="flex justify-center gap-2 mt-8"
        >
          {[0, 1, 2].map((i) => (
            <motion.div
              key={i}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 1 + i * 0.1 }}
              className="w-2 h-2 rounded-full bg-[#9fe870]"
            />
          ))}
        </motion.div>
      </motion.div>
    </div>
  );
}