import { motion } from "motion/react";
import { ChevronRight, Search, ChevronLeft, MessageCircle, HelpCircle, FileText, Shield, CreditCard, Users, Mail, Phone, AlertCircle } from "lucide-react";
import { useState } from "react";
import { useLanguage } from "../../contexts/LanguageContext";

interface RabitHelpCenterScreenProps {
  onBack: () => void;
}

interface FAQItem {
  question: string;
  answer: string;
  category: string;
  icon: any;
}

export function RabitHelpCenterScreen({ onBack }: RabitHelpCenterScreenProps) {
  const { language, isRTL } = useLanguage();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<number | null>(null);

  const content = {
    ar: {
      title: "مركز المساعدة",
      heroTitle: "كيف يمكننا مساعدتك؟",
      heroSubtitle: "ابحث عن إجابات لأسئلتك أو تواصل معنا",
      searchPlaceholder: "ابحث عن سؤالك...",
      faqsCount: "الأسئلة الشائعة",
      noResults: "لم نجد نتائج لبحثك",
      tryOtherKeywords: "جرب كلمات بحث أخرى",
      notFoundAnswer: "لم تجد إجابة لسؤالك؟",
      contactSupport: "تواصل مع فريق الدعم وسنساعدك خلال 24 ساعة",
      emailLabel: "البريد الإلكتروني",
      phoneLabel: "الهاتف",
      liveChatLabel: "الدردشة المباشرة",
      liveChatHours: "متاح من 9 ص - 10 م",
      // Categories
      all: "الكل",
      buying: "الشراء",
      selling: "البيع",
      payment: "الدفع",
      account: "الحساب",
      // FAQs
      howToBuy: "كيف أشتري منتج؟",
      howToBuyAnswer: "1. ابحث عن المنتج الذي تريده\n2. اضغط على المنتج لعرض التفاصيل\n3. اضغط \"اشتر الآن\"\n4. أدخل عنوان الشحن\n5. اختر طريقة الدفع\n6. أكمل الدفع\n\nسيتم توصيل المنتج خلال 3-7 أيام عمل",
      howToSell: "كيف أبيع منتج؟",
      howToSellAnswer: "1. قم بالتبديل إلى وضع البائع\n2. اضغط \"إضافة منتج\"\n3. أدخل تفاصيل المنتج (الاسم، السعر، الوصف)\n4. أضف صور المنتج (5 صور كحد أقصى)\n5. اختر الفئة والحالة\n6. اضغط \"نشر\"\n\nسيكون منتجك مرئيًا للمشترين فورًا",
      platformFees: "ما هي رسوم المنصة؟",
      platformFeesAnswer: "• رسوم البائع: 5% من قيمة المنتج\n• الحد الأدنى للرسوم: 5 ريال\n• الحد الأقصى للرسوم: 500 ريال\n\nلا توجد رسوم على المشترين\n\nمثال: سعر المنتج 100 ريال\nأرباح البائع: 95 ريال\nرسوم المنصة: 5 ريال",
      whenReceiveMoney: "متى أستلم المال؟",
      whenReceiveMoneyAnswer: "• بعد 24 ساعة من تأكيد المشتري استلام المنتج\n• أو بعد 7 أيام من الشحن (تلقائيًا)\n\nهذا لحماية الطرفين والتأكد من استلام المشتري للمنتج",
      switchToBuyer: "كيف أبدل من مشترٍ إلى بائع؟",
      switchToBuyerAnswer: "• إذا كان حسابك \"الاثنين معًا\":\n1. اذهب إلى الصفحة الرئيسية\n2. اضغط \"التبديل إلى وضع البائع\"\n3. سيتم توجيهك لواجهة البائع\n\n• إذا كان حسابك \"مشترٍ فقط\":\n1. اذهب إلى الإعدادات\n2. اضغط \"تغيير نوع الحساب\"\n3. اختر \"بائع\" أو \"الاثنين معًا\"",
      productNotReceived: "ماذا لو لم أستلم المنتج؟",
      productNotReceivedAnswer: "1. اضغط \"طلباتي\"\n2. اختر الطلب\n3. اضغط \"فتح نزاع\"\n4. اختر \"لم أستلم المنتج\"\n5. قدم الأدلة (صور، رسائل، إلخ)\n\nسنراجع النزاع وسنسترجع أموالك إذا كان البائع على خطأ",
      canReturn: "هل يمكنني إرجاع المنتج؟",
      canReturnAnswer: "• إذا كان المنتج لا يطابق الوصف\n• إذا كان المنتج معيبًا أو تالفًا\n• إذا كان المنتج مزيفًا\n\nخطوات الإرجاع:\n1. افتح نزاع خلال 3 أيام من الاستلام\n2. قدم صور المنتج\n3. أرجع المنتج للبائع\n4. سيتم استرجاع كامل المبلغ",
      withdrawMoney: "كيف أسحب الأموال من المحفظة؟",
      withdrawMoneyAnswer: "• للبائعين فقط:\n1. اذهب إلى المحفظة\n2. اضغط \"سحب\"\n3. أدخل المبلغ (الحد الأدنى 100 ريال)\n4. أدخل معلومات الحساب البنكي\n5. أكد السحب\n\nسيتم التحويل خلال 1-3 أيام عمل",
      addPaymentMethod: "كيف أضيف طريقة دفع؟",
      addPaymentMethodAnswer: "1. اذهب إلى الإعدادات\n2. اختر \"طرق الدفع\"\n3. اضغط \"إضافة بطاقة\"\n4. أدخل تفاصيل البطاقة\n5. احفظ\n\nندعم:\n• مدى\n• فيزا\n• ماستركارد\n• آبل باي",
      isDataSecure: "هل بياناتي آمنة؟",
      isDataSecureAnswer: "• نستخدم:\n• تشفير SSL/TLS لجميع البيانات\n• معايير PCI DSS للمدفوعات\n• المصادقة الثنائية\n• مراقبة أمنية 24/7\n\nبياناتك محمية بأعلى معايير الأمان",
      contactSeller: "كيف أتواصل مع البائع؟",
      contactSellerAnswer: "1. اذهب إلى صفحة المنتج\n2. اضغط \"تواصل مع البائع\"\n3. ابدأ المحادثة\n\nيمكنك:\n• طرح الأسئلة\n• طلب صور إضافية\n• التفاوض على السعر (إذا كان مسموحًا)\n\nتجنب:\n• التعامل خارج المنصة\n• إرسال الأموال مباشرة",
      shipProduct: "كيف أشحن المنتج للمشتري؟",
      shipProductAnswer: "• بعد استلام الطلب:\n1. قم بتعبئة المنتج بشكل آمن\n2. اذهب إلى \"طلباتي\" - تبويب \"بائع\"\n3. اضغط \"شحن الآن\"\n4. اختر شركة الشحن\n5. أدخل رقم التتبع\n6. أكد الشحن\n\nيجب شحن المنتج خلال 3 أيام من الطلب",
    },
    en: {
      title: "Help Center",
      heroTitle: "How can we help you?",
      heroSubtitle: "Find answers to your questions or contact us",
      searchPlaceholder: "Search for your question...",
      faqsCount: "Frequently Asked Questions",
      noResults: "No results found for your search",
      tryOtherKeywords: "Try different search keywords",
      notFoundAnswer: "Didn't find an answer?",
      contactSupport: "Contact our support team and we'll help you within 24 hours",
      emailLabel: "Email",
      phoneLabel: "Phone",
      liveChatLabel: "Live Chat",
      liveChatHours: "Available 9 AM - 10 PM",
      // Categories
      all: "All",
      buying: "Buying",
      selling: "Selling",
      payment: "Payment",
      account: "Account",
      // FAQs
      howToBuy: "How do I buy a product?",
      howToBuyAnswer: "1. Search for the product you want\n2. Click on the product to view details\n3. Click \"Buy Now\"\n4. Enter shipping address\n5. Choose payment method\n6. Complete payment\n\nThe product will be delivered within 3-7 business days",
      howToSell: "How do I sell a product?",
      howToSellAnswer: "1. Switch to Seller mode\n2. Click \"Add Product\"\n3. Enter product details (name, price, description)\n4. Add product images (max 5 photos)\n5. Choose category and condition\n6. Click \"Publish\"\n\nYour product will be visible to buyers immediately",
      platformFees: "What are the platform fees?",
      platformFeesAnswer: "• Seller fee: 5% of product value\n• Minimum fee: 5 SAR\n• Maximum fee: 500 SAR\n\nNo fees for buyers\n\nExample: Product price 100 SAR\nSeller earnings: 95 SAR\nPlatform fee: 5 SAR",
      whenReceiveMoney: "When do I receive the money?",
      whenReceiveMoneyAnswer: "• 24 hours after buyer confirms receipt\n• Or 7 days after shipment (automatically)\n\nThis is to protect both parties and ensure buyer receives the product",
      switchToBuyer: "How do I switch from Buyer to Seller?",
      switchToBuyerAnswer: "• If your account is \"Both\":\n1. Go to homepage\n2. Click \"Switch to Seller Mode\"\n3. You'll be redirected to seller interface\n\n• If your account is \"Buyer Only\":\n1. Go to Settings\n2. Click \"Change Account Type\"\n3. Choose \"Seller\" or \"Both\"",
      productNotReceived: "What if I didn't receive the product?",
      productNotReceivedAnswer: "1. Click \"My Orders\"\n2. Select the order\n3. Click \"Open Dispute\"\n4. Choose \"Product Not Received\"\n5. Provide evidence (photos, messages, etc.)\n\nWe'll review the dispute and refund your money if the seller is at fault",
      canReturn: "Can I return a product?",
      canReturnAnswer: "• If product doesn't match description\n• If product is defective or damaged\n• If product is counterfeit\n\nReturn steps:\n1. Open dispute within 3 days of receipt\n2. Provide product photos\n3. Return product to seller\n4. Full refund will be issued",
      withdrawMoney: "How do I withdraw money from wallet?",
      withdrawMoneyAnswer: "• For sellers only:\n1. Go to Wallet\n2. Click \"Withdraw\"\n3. Enter amount (minimum 100 SAR)\n4. Enter bank account information\n5. Confirm withdrawal\n\nTransfer will be made within 1-3 business days",
      addPaymentMethod: "How do I add a payment method?",
      addPaymentMethodAnswer: "1. Go to Settings\n2. Choose \"Payment Methods\"\n3. Click \"Add Card\"\n4. Enter card details\n5. Save\n\nWe support:\n• Mada\n• Visa\n• Mastercard\n• Apple Pay",
      isDataSecure: "Is my data secure?",
      isDataSecureAnswer: "• We use:\n• SSL/TLS encryption for all data\n• PCI DSS standards for payments\n• Two-factor authentication\n• 24/7 security monitoring\n\nYour data is protected by top security standards",
      contactSeller: "How do I contact the seller?",
      contactSellerAnswer: "1. Go to product page\n2. Click \"Contact Seller\"\n3. Start conversation\n\nYou can:\n• Ask questions\n• Request additional images\n• Negotiate price (if allowed)\n\nAvoid:\n• Dealing outside the platform\n• Sending money directly",
      shipProduct: "How do I ship the product to buyer?",
      shipProductAnswer: "• After receiving the order:\n1. Pack product safely\n2. Go to \"My Orders\" - \"Seller\" tab\n3. Click \"Ship Now\"\n4. Choose shipping company\n5. Enter tracking number\n6. Confirm shipment\n\nProduct must be shipped within 3 days of order",
    },
  };

  const c = content[language];

  const categories = [
    { id: "all", name: c.all, icon: HelpCircle },
    { id: "buying", name: c.buying, icon: FileText },
    { id: "selling", name: c.selling, icon: FileText },
    { id: "payment", name: c.payment, icon: CreditCard },
    { id: "account", name: c.account, icon: Users },
  ];

  const faqs: FAQItem[] = [
    { question: c.howToBuy, answer: c.howToBuyAnswer, category: "buying", icon: FileText },
    { question: c.howToSell, answer: c.howToSellAnswer, category: "selling", icon: FileText },
    { question: c.platformFees, answer: c.platformFeesAnswer, category: "payment", icon: CreditCard },
    { question: c.whenReceiveMoney, answer: c.whenReceiveMoneyAnswer, category: "payment", icon: CreditCard },
    { question: c.switchToBuyer, answer: c.switchToBuyerAnswer, category: "account", icon: Users },
    { question: c.productNotReceived, answer: c.productNotReceivedAnswer, category: "buying", icon: FileText },
    { question: c.canReturn, answer: c.canReturnAnswer, category: "buying", icon: FileText },
    { question: c.withdrawMoney, answer: c.withdrawMoneyAnswer, category: "payment", icon: CreditCard },
    { question: c.addPaymentMethod, answer: c.addPaymentMethodAnswer, category: "payment", icon: CreditCard },
    { question: c.isDataSecure, answer: c.isDataSecureAnswer, category: "account", icon: Users },
    { question: c.contactSeller, answer: c.contactSellerAnswer, category: "buying", icon: MessageCircle },
    { question: c.shipProduct, answer: c.shipProductAnswer, category: "selling", icon: FileText },
  ];

  const filteredFAQs = faqs.filter((faq) => {
    const matchesSearch = faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         faq.answer.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = !selectedCategory || selectedCategory === "all" || faq.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div
      className="min-h-screen bg-gradient-to-b from-[#fafafa] to-white pb-6"
      style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white/95 backdrop-blur-lg border-b border-[rgba(0,0,0,0.06)] px-6 py-4 z-10 shadow-sm"
      >
        <div className="flex items-center justify-between">
          <button
            onClick={onBack}
            className="w-11 h-11 rounded-2xl bg-[#f0fde8] border border-[rgba(22,51,0,0.1)] flex items-center justify-center text-[#163300] transition-all duration-200 hover:bg-[#e2fad5] active:scale-95"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-semibold text-[#0a0b09]">{c.title}</h1>
          <div className="w-11" /> {/* Spacer */}
        </div>
      </motion.div>

      <div className="px-6 space-y-6 mt-6">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="bg-gradient-to-br from-[#163300] to-[#0f2409] rounded-3xl p-8 text-center shadow-xl"
        >
          <div className="w-20 h-20 rounded-3xl bg-[#9fe870] flex items-center justify-center mx-auto mb-4">
            <HelpCircle className="w-10 h-10 text-[#163300]" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">{c.heroTitle}</h2>
          <p className="text-white/80 text-sm">
            {c.heroSubtitle}
          </p>
        </motion.div>

        {/* Search Bar */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="relative"
        >
          <Search className={`absolute ${isRTL ? 'right-4' : 'left-4'} top-1/2 -translate-y-1/2 w-5 h-5 text-[#6a6c6a]`} />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={c.searchPlaceholder}
            className={`w-full ${isRTL ? 'pr-12 pl-4' : 'pl-12 pr-4'} py-4 bg-white border-2 border-[rgba(0,0,0,0.1)] rounded-2xl ${isRTL ? 'text-right' : 'text-left'} focus:border-[#163300] focus:outline-none transition-all duration-200`}
          />
        </motion.div>

        {/* Categories */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="flex gap-2 overflow-x-auto pb-2 no-scrollbar"
        >
          {categories.map((cat) => {
            const Icon = cat.icon;
            const isSelected = selectedCategory === cat.id || (!selectedCategory && cat.id === "all");
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-medium text-sm whitespace-nowrap transition-all duration-200 ${
                  isSelected
                    ? "bg-[#163300] text-white shadow-md"
                    : "bg-white text-[#6a6c6a] border border-[rgba(0,0,0,0.1)] hover:border-[#163300]"
                }`}
              >
                <Icon className="w-4 h-4" />
                {cat.name}
              </button>
            );
          })}
        </motion.div>

        {/* FAQ List */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="space-y-3"
        >
          <h3 className="text-lg font-bold text-[#0a0b09] mb-4">
            {c.faqsCount} ({filteredFAQs.length})
          </h3>
          {filteredFAQs.map((faq, index) => {
            const Icon = faq.icon;
            const isExpanded = expandedId === index;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="bg-white rounded-2xl border border-[rgba(0,0,0,0.06)] overflow-hidden shadow-card"
              >
                <button
                  onClick={() => setExpandedId(isExpanded ? null : index)}
                  className={`w-full p-5 flex items-center gap-3 ${isRTL ? 'text-right' : 'text-left'} hover:bg-[#fafafa] transition-all duration-200`}
                >
                  <ChevronLeft
                    className={`w-5 h-5 text-[#6a6c6a] flex-shrink-0 transition-transform duration-200 ${
                      isExpanded ? "rotate-90" : ""
                    } ${isRTL ? 'order-first' : 'order-last'}`}
                  />
                  <div className="flex-1">
                    <div className={`flex items-center gap-2 ${isRTL ? 'justify-end' : 'justify-start'} mb-1`}>
                      {isRTL && <Icon className="w-5 h-5 text-[#163300] flex-shrink-0" />}
                      <p className="font-semibold text-[#0a0b09]">{faq.question}</p>
                      {!isRTL && <Icon className="w-5 h-5 text-[#163300] flex-shrink-0" />}
                    </div>
                  </div>
                </button>

                {isExpanded && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="px-5 pb-5 pt-0"
                  >
                    <div className={`bg-[#fafafa] rounded-xl p-4 ${isRTL ? 'border-r-4' : 'border-l-4'} border-[#163300]`}>
                      <p className="text-[#6a6c6a] text-sm leading-relaxed whitespace-pre-line">
                        {faq.answer}
                      </p>
                    </div>
                  </motion.div>
                )}
              </motion.div>
            );
          })}

          {filteredFAQs.length === 0 && (
            <div className="text-center py-12">
              <AlertCircle className="w-16 h-16 text-[#d4d4d4] mx-auto mb-4" />
              <p className="text-[#6a6c6a]">{c.noResults}</p>
              <p className="text-sm text-[#a3a3a3] mt-2">{c.tryOtherKeywords}</p>
            </div>
          )}
        </motion.div>

        {/* Contact Support */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-gradient-to-br from-[#f0fde8] to-[#e2fad5] rounded-2xl p-6"
        >
          <h3 className="text-lg font-bold text-[#163300] mb-2 text-center">
            {c.notFoundAnswer}
          </h3>
          <p className="text-[#163300]/80 text-sm text-center mb-4">
            {c.contactSupport}
          </p>
          <div className="space-y-3">
            <a
              href="mailto:support@rabit.sa"
              className="flex items-center gap-3 p-4 bg-white rounded-2xl hover:shadow-md transition-all duration-200"
            >
              <div className="w-12 h-12 rounded-2xl bg-[#163300] flex items-center justify-center flex-shrink-0">
                <Mail className="w-6 h-6 text-white" />
              </div>
              <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                <p className="font-semibold text-[#0a0b09]">{c.emailLabel}</p>
                <p className="text-sm text-[#6a6c6a]">support@rabit.sa</p>
              </div>
            </a>

            <a
              href="tel:+966501234567"
              className="flex items-center gap-3 p-4 bg-white rounded-2xl hover:shadow-md transition-all duration-200"
            >
              <div className="w-12 h-12 rounded-2xl bg-[#163300] flex items-center justify-center flex-shrink-0">
                <Phone className="w-6 h-6 text-white" />
              </div>
              <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                <p className="font-semibold text-[#0a0b09]">{c.phoneLabel}</p>
                <p className="text-sm text-[#6a6c6a]" dir="ltr">+966 50 123 4567</p>
              </div>
            </a>

            <button className="flex items-center gap-3 p-4 bg-white rounded-2xl hover:shadow-md transition-all duration-200 w-full">
              <div className="w-12 h-12 rounded-2xl bg-[#163300] flex items-center justify-center flex-shrink-0">
                <MessageCircle className="w-6 h-6 text-white" />
              </div>
              <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                <p className="font-semibold text-[#0a0b09]">{c.liveChatLabel}</p>
                <p className="text-sm text-[#6a6c6a]">{c.liveChatHours}</p>
              </div>
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
