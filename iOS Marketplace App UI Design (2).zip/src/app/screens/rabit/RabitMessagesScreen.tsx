import { motion } from "motion/react";
import { ChevronRight, Search, MessageCircle, User, Image as ImageIcon } from "lucide-react";
import { useState } from "react";
import { useLanguage } from "../../contexts/LanguageContext";

interface Message {
  id: string;
  userName: string;
  userAvatar?: string;
  lastMessage: string;
  timestamp: string;
  unreadCount: number;
  productImage?: string;
  productName: string;
  isOnline: boolean;
}

interface RabitMessagesScreenProps {
  onBack: () => void;
  onChatClick: (messageId: string) => void;
  userRole: "buyer" | "seller" | "both";
}

export function RabitMessagesScreen({ onBack, onChatClick, userRole }: RabitMessagesScreenProps) {
  const { language, isRTL } = useLanguage();
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState<"all" | "buying" | "selling">("all");

  const content = {
    ar: {
      messages: "الرسائل",
      search: "بحث في المحادثات...",
      all: "الكل",
      buying: "المشتريات",
      selling: "المبيعات",
      noMessages: "لا توجد رسائل",
      noMessagesDesc: "ابدأ محادثة مع البائعين أو المشترين",
      online: "متصل",
      now: "الآن",
      minsAgo: "منذ {mins} د",
      hoursAgo: "منذ {hours} س",
      daysAgo: "منذ {days} يوم",
      you: "أنت:",
      typing: "يكتب...",
    },
    en: {
      messages: "Messages",
      search: "Search conversations...",
      all: "All",
      buying: "Buying",
      selling: "Selling",
      noMessages: "No messages",
      noMessagesDesc: "Start a conversation with sellers or buyers",
      online: "Online",
      now: "Now",
      minsAgo: "{mins}m ago",
      hoursAgo: "{hours}h ago",
      daysAgo: "{days}d ago",
      you: "You:",
      typing: "Typing...",
    },
  };
  const c = content[language];

  // Mock messages data
  const mockMessages: Message[] = [
    {
      id: "1",
      userName: "أحمد محمد",
      lastMessage: "هل المنتج متوفر؟",
      timestamp: "2m",
      unreadCount: 2,
      productName: "آيفون 14 برو ماكس",
      productImage: "https://images.unsplash.com/photo-1592286927505-2fd7d4f114f0?w=100",
      isOnline: true,
    },
    {
      id: "2",
      userName: "سارة أحمد",
      lastMessage: "شكراً، وصلني الطلب",
      timestamp: "1h",
      unreadCount: 0,
      productName: "ساعة ذكية",
      productImage: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=100",
      isOnline: false,
    },
    {
      id: "3",
      userName: "محمد علي",
      lastMessage: "متى سيتم الشحن؟",
      timestamp: "3h",
      unreadCount: 1,
      productName: "لابتوب HP",
      productImage: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=100",
      isOnline: true,
    },
    {
      id: "4",
      userName: "فاطمة خالد",
      lastMessage: "ممتاز، سأشتريه",
      timestamp: "1d",
      unreadCount: 0,
      productName: "كاميرا كانون",
      productImage: "https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?w=100",
      isOnline: false,
    },
    {
      id: "5",
      userName: "عبدالله سعيد",
      lastMessage: "هل يمكن التفاوض على السعر؟",
      timestamp: "2d",
      unreadCount: 0,
      productName: "سماعات AirPods",
      productImage: "https://images.unsplash.com/photo-1572569511254-d8f925fe2cbb?w=100",
      isOnline: false,
    },
  ];

  const filteredMessages = mockMessages.filter((msg) =>
    msg.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    msg.productName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const formatTime = (time: string) => {
    if (time.includes("m")) return c.minsAgo.replace("{mins}", time.replace("m", ""));
    if (time.includes("h")) return c.hoursAgo.replace("{hours}", time.replace("h", ""));
    if (time.includes("d")) return c.daysAgo.replace("{days}", time.replace("d", ""));
    return time;
  };

  return (
    <div
      className="min-h-screen bg-[#fafafa]"
      style={{ fontFamily: language === "ar" ? "Cairo, sans-serif" : "system-ui, -apple-system, sans-serif" }}
      dir={isRTL ? "rtl" : "ltr"}
    >
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 z-10"
      >
        <div className="flex items-center justify-between mb-4">
          <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
            <ChevronRight className={`w-6 h-6 text-[#0e0f0c] ${isRTL ? "" : "rotate-180"}`} />
          </button>
          <h1 className="text-xl font-semibold text-[#0e0f0c]">{c.messages}</h1>
          <div className="w-10" />
        </div>

        {/* Search */}
        <div className="relative">
          <Search className={`absolute ${isRTL ? "right-3" : "left-3"} top-1/2 -translate-y-1/2 w-5 h-5 text-[#6a6c6a]`} />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={c.search}
            className={`w-full ${isRTL ? "pr-11 pl-4" : "pl-11 pr-4"} py-3 rounded-[10px] bg-[rgba(22,51,0,0.07843)] border-none focus:outline-none focus:ring-2 focus:ring-[#163300] ${isRTL ? "text-right" : "text-left"}`}
          />
        </div>

        {/* Tabs */}
        {userRole === "both" && (
          <div className="flex gap-2 mt-4">
            {(["all", "buying", "selling"] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`flex-1 py-2 px-4 rounded-[8px] text-sm font-medium transition-colors ${
                  activeTab === tab
                    ? "bg-[#163300] text-white"
                    : "bg-[rgba(22,51,0,0.07843)] text-[#0e0f0c]"
                }`}
              >
                {c[tab]}
              </button>
            ))}
          </div>
        )}
      </motion.div>

      {/* Messages List */}
      <div className="p-4">
        {filteredMessages.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center justify-center py-20"
          >
            <MessageCircle className="w-16 h-16 text-[#6a6c6a] mb-4" />
            <h3 className="text-lg font-semibold text-[#0e0f0c] mb-2">{c.noMessages}</h3>
            <p className="text-sm text-[#6a6c6a] text-center">{c.noMessagesDesc}</p>
          </motion.div>
        ) : (
          <div className="space-y-2">
            {filteredMessages.map((message, index) => (
              <motion.button
                key={message.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                onClick={() => onChatClick(message.id)}
                className="w-full bg-white rounded-[12px] p-4 flex items-center gap-3 hover:bg-[rgba(22,51,0,0.07843)] transition-colors"
              >
                {/* User Avatar */}
                <div className="relative">
                  <div className="w-14 h-14 rounded-full bg-[rgba(22,51,0,0.12157)] flex items-center justify-center overflow-hidden">
                    {message.userAvatar ? (
                      <img src={message.userAvatar} alt={message.userName} className="w-full h-full object-cover" />
                    ) : (
                      <User className="w-7 h-7 text-[#163300]" />
                    )}
                  </div>
                  {message.isOnline && (
                    <div className="absolute bottom-0 right-0 w-4 h-4 bg-[#008026] border-2 border-white rounded-full"></div>
                  )}
                </div>

                {/* Message Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between mb-1">
                    <h3 className={`font-semibold text-[#0e0f0c] ${isRTL ? "text-right" : "text-left"}`}>
                      {message.userName}
                    </h3>
                    <span className="text-xs text-[#6a6c6a] whitespace-nowrap">{formatTime(message.timestamp)}</span>
                  </div>
                  <p className={`text-sm text-[#6a6c6a] truncate mb-1 ${isRTL ? "text-right" : "text-left"}`}>
                    {message.lastMessage}
                  </p>
                  <div className="flex items-center gap-2">
                    {message.productImage && (
                      <img src={message.productImage} alt="" className="w-6 h-6 rounded object-cover" />
                    )}
                    <span className="text-xs text-[#6a6c6a] truncate">{message.productName}</span>
                  </div>
                </div>

                {/* Unread Badge */}
                {message.unreadCount > 0 && (
                  <div className="w-6 h-6 bg-[#163300] rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-xs font-bold text-white">{message.unreadCount}</span>
                  </div>
                )}
              </motion.button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
