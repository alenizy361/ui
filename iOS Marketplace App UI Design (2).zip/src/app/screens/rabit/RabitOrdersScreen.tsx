import { motion } from "motion/react";
import { ChevronRight, Package, Clock, CheckCircle, XCircle } from "lucide-react";
import { useState } from "react";
import { PullToRefresh } from "../../components/PullToRefresh";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";

interface RabitOrdersScreenProps {
  onBack: () => void;
  onOrderClick: (orderId: string) => void;
}

export function RabitOrdersScreen({ onBack, onOrderClick }: RabitOrdersScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);
  const [activeTab, setActiveTab] = useState<"all" | "pending" | "completed">("all");

  const handleRefresh = async () => {
    await new Promise(resolve => setTimeout(resolve, 1500));
    console.log("Refreshing orders data...");
  };

  return (
    <PullToRefresh onRefresh={handleRefresh}>
      <div 
        className="min-h-screen bg-[#fafafa]" 
        style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
        dir={isRTL ? 'rtl' : 'ltr'}
      >
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }} 
          animate={{ opacity: 1, y: 0 }} 
          className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 flex items-center justify-between z-10"
        >
          <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
            <ChevronRight className={`w-6 h-6 text-[#0e0f0c] ${isRTL ? '' : 'rotate-180'}`} />
          </button>
          <h1 className="text-xl font-semibold text-[#0e0f0c]">{t.ordersTitle}</h1>
          <div className="w-10" />
        </motion.div>

        {/* Filter Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="px-6 pt-4 pb-2"
        >
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            {[
              { id: "all", label: t.allOrders, count: 4 },
              { id: "pending", label: t.pending, count: 1 },
              { id: "completed", label: language === 'ar' ? 'مكتملة' : 'Completed', count: 3 },
            ].map((tab, index) => (
              <motion.button
                key={tab.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
                onClick={() => setActiveTab(tab.id as typeof activeTab)}
                className={`px-4 py-2.5 rounded-full whitespace-nowrap transition-all flex items-center gap-2 ${
                  activeTab === tab.id
                    ? "bg-[#163300] text-white"
                    : "bg-[rgba(22,51,0,0.07843)] text-[#6a6c6a] border border-[rgba(14,15,12,0.12157)]"
                }`}
              >
                <span className="text-sm font-medium">{tab.label}</span>
                <span className={`text-xs px-1.5 py-0.5 rounded-full ${
                  activeTab === tab.id ? "bg-white/20" : "bg-[rgba(22,51,0,0.12)]"
                }`}>
                  {tab.count}
                </span>
              </motion.button>
            ))}
          </div>
        </motion.div>

        {/* Orders List */}
        <div className="px-6 pt-4 space-y-4">
          {activeTab === "all" && (
            <>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.05 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => onOrderClick("1")}
                className="bg-white rounded-[16px] border border-[rgba(14,15,12,0.12157)] p-4 cursor-pointer hover:shadow-lg transition-all"
              >
                {/* Order Header */}
                <div className="flex items-center justify-between mb-3" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                  <div style={{ textAlign: isRTL ? 'right' : 'left' }}>
                    <p className="text-xs text-[#6a6c6a] mb-1">{language === 'ar' ? 'رقم الطلب' : 'Order Number'}</p>
                    <p className="font-bold text-[#0e0f0c] text-sm" dir="ltr">#RBT-2024-1234</p>
                  </div>
                  <span className="bg-[#008026] text-white px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1.5">
                    <Package className="w-3.5 h-3.5" />
                    {language === 'ar' ? 'تم التوصيل' : 'Delivered'}
                  </span>
                </div>

                {/* Product Info */}
                <div className="flex gap-3 mb-3" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                  <img 
                    src="https://images.unsplash.com/photo-1678685888221-cda773a3dcdb?w=400" 
                    alt={language === 'ar' ? 'آيفون 14 برو ماكس - 256 جيجا' : 'iPhone 14 Pro Max - 256GB'}
                    className="w-20 h-20 rounded-[12px] object-cover border border-[rgba(14,15,12,0.12157)]"
                  />
                  <div className="flex-1" style={{ textAlign: isRTL ? 'right' : 'left' }}>
                    <p className="font-semibold text-[#0e0f0c] mb-1 line-clamp-2">
                      {language === 'ar' ? 'آيفون 14 برو ماكس - 256 جيجا' : 'iPhone 14 Pro Max - 256GB'}
                    </p>
                    <p className="text-sm text-[#6a6c6a] mb-1">
                      {language === 'ar' ? 'البائع: أحمد التميمي' : 'Seller: Ahmed Al-Tamimi'}
                    </p>
                    <p className="font-bold text-[#163300]">
                      4500 {language === 'ar' ? 'ر.س' : 'SAR'}
                    </p>
                  </div>
                </div>

                {/* Order Date */}
                <div className="flex items-center justify-between pt-3 border-t border-[rgba(14,15,12,0.12157)]" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                  <p className="text-xs text-[#6a6c6a]">
                    {language === 'ar' ? 'اليوم، 10:30 ص' : 'Today, 10:30 AM'}
                  </p>
                  <ChevronRight className={`w-4 h-4 text-[#6a6c6a] ${isRTL ? 'rotate-180' : ''}`} />
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => onOrderClick("2")}
                className="bg-white rounded-[16px] border border-[rgba(14,15,12,0.12157)] p-4 cursor-pointer hover:shadow-lg transition-all"
              >
                {/* Order Header */}
                <div className="flex items-center justify-between mb-3" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                  <div style={{ textAlign: isRTL ? 'right' : 'left' }}>
                    <p className="text-xs text-[#6a6c6a] mb-1">{language === 'ar' ? 'رقم الطلب' : 'Order Number'}</p>
                    <p className="font-bold text-[#0e0f0c] text-sm" dir="ltr">#RBT-2024-5678</p>
                  </div>
                  <span className="bg-[#9c27b0] text-white px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1.5">
                    <Package className="w-3.5 h-3.5" />
                    {language === 'ar' ? 'قيد الشحن' : 'In Transit'}
                  </span>
                </div>

                {/* Product Info */}
                <div className="flex gap-3 mb-3" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                  <img 
                    src="https://images.unsplash.com/photo-1434493789847-2f02dc6ca35d?w=400" 
                    alt={language === 'ar' ? 'ساعة ابل الجيل الثامن' : 'Apple Watch Series 8'}
                    className="w-20 h-20 rounded-[12px] object-cover border border-[rgba(14,15,12,0.12157)]"
                  />
                  <div className="flex-1" style={{ textAlign: isRTL ? 'right' : 'left' }}>
                    <p className="font-semibold text-[#0e0f0c] mb-1 line-clamp-2">
                      {language === 'ar' ? 'ساعة ابل الجيل الثامن' : 'Apple Watch Series 8'}
                    </p>
                    <p className="text-sm text-[#6a6c6a] mb-1">
                      {language === 'ar' ? 'البائع: محمد العتيبي' : 'Seller: Mohammed Al-Otaibi'}
                    </p>
                    <p className="font-bold text-[#163300]">
                      1899 {language === 'ar' ? 'ر.س' : 'SAR'}
                    </p>
                  </div>
                </div>

                {/* Order Date */}
                <div className="flex items-center justify-between pt-3 border-t border-[rgba(14,15,12,0.12157)]" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                  <p className="text-xs text-[#6a6c6a]">
                    {language === 'ar' ? 'أمس، 3:45 م' : 'Yesterday, 3:45 PM'}
                  </p>
                  <ChevronRight className={`w-4 h-4 text-[#6a6c6a] ${isRTL ? 'rotate-180' : ''}`} />
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.15 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => onOrderClick("3")}
                className="bg-white rounded-[16px] border border-[rgba(14,15,12,0.12157)] p-4 cursor-pointer hover:shadow-lg transition-all"
              >
                {/* Order Header */}
                <div className="flex items-center justify-between mb-3" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                  <div style={{ textAlign: isRTL ? 'right' : 'left' }}>
                    <p className="text-xs text-[#6a6c6a] mb-1">{language === 'ar' ? 'رقم الطلب' : 'Order Number'}</p>
                    <p className="font-bold text-[#0e0f0c] text-sm" dir="ltr">#RBT-2024-9012</p>
                  </div>
                  <span className="bg-[#0091ea] text-white px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1.5">
                    <CheckCircle className="w-3.5 h-3.5" />
                    {language === 'ar' ? 'تم التأكيد' : 'Confirmed'}
                  </span>
                </div>

                {/* Product Info */}
                <div className="flex gap-3 mb-3" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                  <img 
                    src="https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400" 
                    alt={language === 'ar' ? 'ماك بوك برو M2 - 512 جيجا' : 'MacBook Pro M2 - 512GB'}
                    className="w-20 h-20 rounded-[12px] object-cover border border-[rgba(14,15,12,0.12157)]"
                  />
                  <div className="flex-1" style={{ textAlign: isRTL ? 'right' : 'left' }}>
                    <p className="font-semibold text-[#0e0f0c] mb-1 line-clamp-2">
                      {language === 'ar' ? 'ماك بوك برو M2 - 512 جيجا' : 'MacBook Pro M2 - 512GB'}
                    </p>
                    <p className="text-sm text-[#6a6c6a] mb-1">
                      {language === 'ar' ? 'البائع: خالد السعيد' : 'Seller: Khalid Al-Saeed'}
                    </p>
                    <p className="font-bold text-[#163300]">
                      8999 {language === 'ar' ? 'ر.س' : 'SAR'}
                    </p>
                  </div>
                </div>

                {/* Order Date */}
                <div className="flex items-center justify-between pt-3 border-t border-[rgba(14,15,12,0.12157)]" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                  <p className="text-xs text-[#6a6c6a]">
                    {language === 'ar' ? '3 ديسمبر' : 'Dec 3'}
                  </p>
                  <ChevronRight className={`w-4 h-4 text-[#6a6c6a] ${isRTL ? 'rotate-180' : ''}`} />
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => onOrderClick("4")}
                className="bg-white rounded-[16px] border border-[rgba(14,15,12,0.12157)] p-4 cursor-pointer hover:shadow-lg transition-all"
              >
                {/* Order Header */}
                <div className="flex items-center justify-between mb-3" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                  <div style={{ textAlign: isRTL ? 'right' : 'left' }}>
                    <p className="text-xs text-[#6a6c6a] mb-1">{language === 'ar' ? 'رقم الطلب' : 'Order Number'}</p>
                    <p className="font-bold text-[#0e0f0c] text-sm" dir="ltr">#RBT-2024-3456</p>
                  </div>
                  <span className="bg-[#df8700] text-white px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5" />
                    {language === 'ar' ? 'في الانتظار' : 'Pending'}
                  </span>
                </div>

                {/* Product Info */}
                <div className="flex gap-3 mb-3" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                  <img 
                    src="https://images.unsplash.com/photo-1572569511254-d8f925fe2cbb?w=400" 
                    alt={language === 'ar' ? 'سماعات AirPods Pro' : 'AirPods Pro'}
                    className="w-20 h-20 rounded-[12px] object-cover border border-[rgba(14,15,12,0.12157)]"
                  />
                  <div className="flex-1" style={{ textAlign: isRTL ? 'right' : 'left' }}>
                    <p className="font-semibold text-[#0e0f0c] mb-1 line-clamp-2">
                      {language === 'ar' ? 'سماعات AirPods Pro' : 'AirPods Pro'}
                    </p>
                    <p className="text-sm text-[#6a6c6a] mb-1">
                      {language === 'ar' ? 'البائع: فهد الدوسري' : 'Seller: Fahad Al-Dosari'}
                    </p>
                    <p className="font-bold text-[#163300]">
                      899 {language === 'ar' ? 'ر.س' : 'SAR'}
                    </p>
                  </div>
                </div>

                {/* Order Date */}
                <div className="flex items-center justify-between pt-3 border-t border-[rgba(14,15,12,0.12157)]" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                  <p className="text-xs text-[#6a6c6a]">
                    {language === 'ar' ? '1 ديسمبر' : 'Dec 1'}
                  </p>
                  <ChevronRight className={`w-4 h-4 text-[#6a6c6a] ${isRTL ? 'rotate-180' : ''}`} />
                </div>
              </motion.div>
            </>
          )}

          {activeTab === "pending" && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.05 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => onOrderClick("4")}
              className="bg-white rounded-[16px] border border-[rgba(14,15,12,0.12157)] p-4 cursor-pointer hover:shadow-lg transition-all"
            >
              {/* Order Header */}
              <div className="flex items-center justify-between mb-3" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                <div style={{ textAlign: isRTL ? 'right' : 'left' }}>
                  <p className="text-xs text-[#6a6c6a] mb-1">{language === 'ar' ? 'رقم الطلب' : 'Order Number'}</p>
                  <p className="font-bold text-[#0e0f0c] text-sm" dir="ltr">#RBT-2024-3456</p>
                </div>
                <span className="bg-[#df8700] text-white px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5" />
                  {language === 'ar' ? 'في الانتظار' : 'Pending'}
                </span>
              </div>

              {/* Product Info */}
              <div className="flex gap-3 mb-3" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                <img 
                  src="https://images.unsplash.com/photo-1572569511254-d8f925fe2cbb?w=400" 
                  alt={language === 'ar' ? 'سماعات AirPods Pro' : 'AirPods Pro'}
                  className="w-20 h-20 rounded-[12px] object-cover border border-[rgba(14,15,12,0.12157)]"
                />
                <div className="flex-1" style={{ textAlign: isRTL ? 'right' : 'left' }}>
                  <p className="font-semibold text-[#0e0f0c] mb-1 line-clamp-2">
                    {language === 'ar' ? 'سماعات AirPods Pro' : 'AirPods Pro'}
                  </p>
                  <p className="text-sm text-[#6a6c6a] mb-1">
                    {language === 'ar' ? 'البائع: فهد الدوسري' : 'Seller: Fahad Al-Dosari'}
                  </p>
                  <p className="font-bold text-[#163300]">
                    899 {language === 'ar' ? 'ر.س' : 'SAR'}
                  </p>
                </div>
              </div>

              {/* Order Date */}
              <div className="flex items-center justify-between pt-3 border-t border-[rgba(14,15,12,0.12157)]" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                <p className="text-xs text-[#6a6c6a]">
                  {language === 'ar' ? '1 ديسمبر' : 'Dec 1'}
                </p>
                <ChevronRight className={`w-4 h-4 text-[#6a6c6a] ${isRTL ? 'rotate-180' : ''}`} />
              </div>
            </motion.div>
          )}

          {activeTab === "completed" && (
            <>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.05 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => onOrderClick("1")}
                className="bg-white rounded-[16px] border border-[rgba(14,15,12,0.12157)] p-4 cursor-pointer hover:shadow-lg transition-all"
              >
                {/* Order Header */}
                <div className="flex items-center justify-between mb-3" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                  <div style={{ textAlign: isRTL ? 'right' : 'left' }}>
                    <p className="text-xs text-[#6a6c6a] mb-1">{language === 'ar' ? 'رقم الطلب' : 'Order Number'}</p>
                    <p className="font-bold text-[#0e0f0c] text-sm" dir="ltr">#RBT-2024-1234</p>
                  </div>
                  <span className="bg-[#008026] text-white px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1.5">
                    <Package className="w-3.5 h-3.5" />
                    {language === 'ar' ? 'تم التوصيل' : 'Delivered'}
                  </span>
                </div>

                {/* Product Info */}
                <div className="flex gap-3 mb-3" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                  <img 
                    src="https://images.unsplash.com/photo-1678685888221-cda773a3dcdb?w=400" 
                    alt={language === 'ar' ? 'آيفون 14 برو ماكس - 256 جيجا' : 'iPhone 14 Pro Max - 256GB'}
                    className="w-20 h-20 rounded-[12px] object-cover border border-[rgba(14,15,12,0.12157)]"
                  />
                  <div className="flex-1" style={{ textAlign: isRTL ? 'right' : 'left' }}>
                    <p className="font-semibold text-[#0e0f0c] mb-1 line-clamp-2">
                      {language === 'ar' ? 'آيفون 14 برو ماكس - 256 جيجا' : 'iPhone 14 Pro Max - 256GB'}
                    </p>
                    <p className="text-sm text-[#6a6c6a] mb-1">
                      {language === 'ar' ? 'البائع: أحمد التميمي' : 'Seller: Ahmed Al-Tamimi'}
                    </p>
                    <p className="font-bold text-[#163300]">
                      4500 {language === 'ar' ? 'ر.س' : 'SAR'}
                    </p>
                  </div>
                </div>

                {/* Order Date */}
                <div className="flex items-center justify-between pt-3 border-t border-[rgba(14,15,12,0.12157)]" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                  <p className="text-xs text-[#6a6c6a]">
                    {language === 'ar' ? 'اليوم، 10:30 ص' : 'Today, 10:30 AM'}
                  </p>
                  <ChevronRight className={`w-4 h-4 text-[#6a6c6a] ${isRTL ? 'rotate-180' : ''}`} />
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => onOrderClick("2")}
                className="bg-white rounded-[16px] border border-[rgba(14,15,12,0.12157)] p-4 cursor-pointer hover:shadow-lg transition-all"
              >
                {/* Order Header */}
                <div className="flex items-center justify-between mb-3" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                  <div style={{ textAlign: isRTL ? 'right' : 'left' }}>
                    <p className="text-xs text-[#6a6c6a] mb-1">{language === 'ar' ? 'رقم الطلب' : 'Order Number'}</p>
                    <p className="font-bold text-[#0e0f0c] text-sm" dir="ltr">#RBT-2024-5678</p>
                  </div>
                  <span className="bg-[#9c27b0] text-white px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1.5">
                    <Package className="w-3.5 h-3.5" />
                    {language === 'ar' ? 'قيد الشحن' : 'In Transit'}
                  </span>
                </div>

                {/* Product Info */}
                <div className="flex gap-3 mb-3" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                  <img 
                    src="https://images.unsplash.com/photo-1434493789847-2f02dc6ca35d?w=400" 
                    alt={language === 'ar' ? 'ساعة ابل الجيل الثامن' : 'Apple Watch Series 8'}
                    className="w-20 h-20 rounded-[12px] object-cover border border-[rgba(14,15,12,0.12157)]"
                  />
                  <div className="flex-1" style={{ textAlign: isRTL ? 'right' : 'left' }}>
                    <p className="font-semibold text-[#0e0f0c] mb-1 line-clamp-2">
                      {language === 'ar' ? 'ساعة ابل الجيل الثامن' : 'Apple Watch Series 8'}
                    </p>
                    <p className="text-sm text-[#6a6c6a] mb-1">
                      {language === 'ar' ? 'البائع: محمد العتيبي' : 'Seller: Mohammed Al-Otaibi'}
                    </p>
                    <p className="font-bold text-[#163300]">
                      1899 {language === 'ar' ? 'ر.س' : 'SAR'}
                    </p>
                  </div>
                </div>

                {/* Order Date */}
                <div className="flex items-center justify-between pt-3 border-t border-[rgba(14,15,12,0.12157)]" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                  <p className="text-xs text-[#6a6c6a]">
                    {language === 'ar' ? 'أمس، 3:45 م' : 'Yesterday, 3:45 PM'}
                  </p>
                  <ChevronRight className={`w-4 h-4 text-[#6a6c6a] ${isRTL ? 'rotate-180' : ''}`} />
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.15 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => onOrderClick("3")}
                className="bg-white rounded-[16px] border border-[rgba(14,15,12,0.12157)] p-4 cursor-pointer hover:shadow-lg transition-all"
              >
                {/* Order Header */}
                <div className="flex items-center justify-between mb-3" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                  <div style={{ textAlign: isRTL ? 'right' : 'left' }}>
                    <p className="text-xs text-[#6a6c6a] mb-1">{language === 'ar' ? 'رقم الطلب' : 'Order Number'}</p>
                    <p className="font-bold text-[#0e0f0c] text-sm" dir="ltr">#RBT-2024-9012</p>
                  </div>
                  <span className="bg-[#0091ea] text-white px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1.5">
                    <CheckCircle className="w-3.5 h-3.5" />
                    {language === 'ar' ? 'تم التأكيد' : 'Confirmed'}
                  </span>
                </div>

                {/* Product Info */}
                <div className="flex gap-3 mb-3" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                  <img 
                    src="https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400" 
                    alt={language === 'ar' ? 'ماك بوك برو M2 - 512 جيجا' : 'MacBook Pro M2 - 512GB'}
                    className="w-20 h-20 rounded-[12px] object-cover border border-[rgba(14,15,12,0.12157)]"
                  />
                  <div className="flex-1" style={{ textAlign: isRTL ? 'right' : 'left' }}>
                    <p className="font-semibold text-[#0e0f0c] mb-1 line-clamp-2">
                      {language === 'ar' ? 'ماك بوك برو M2 - 512 جيجا' : 'MacBook Pro M2 - 512GB'}
                    </p>
                    <p className="text-sm text-[#6a6c6a] mb-1">
                      {language === 'ar' ? 'البائع: خالد السعيد' : 'Seller: Khalid Al-Saeed'}
                    </p>
                    <p className="font-bold text-[#163300]">
                      8999 {language === 'ar' ? 'ر.س' : 'SAR'}
                    </p>
                  </div>
                </div>

                {/* Order Date */}
                <div className="flex items-center justify-between pt-3 border-t border-[rgba(14,15,12,0.12157)]" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                  <p className="text-xs text-[#6a6c6a]">
                    {language === 'ar' ? '3 ديسمبر' : 'Dec 3'}
                  </p>
                  <ChevronRight className={`w-4 h-4 text-[#6a6c6a] ${isRTL ? 'rotate-180' : ''}`} />
                </div>
              </motion.div>
            </>
          )}
        </div>

        {/* Summary Footer */}
        {activeTab === "all" && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="fixed bottom-0 left-0 right-0 bg-white border-t border-[rgba(14,15,12,0.12157)] px-6 py-4 max-w-[430px] mx-auto"
          >
            <div className="flex items-center justify-between" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
              <span className="text-sm text-[#6a6c6a]">
                {language === 'ar' ? 'إجمالي الطلبات' : 'Total Orders'}
              </span>
              <span className="font-bold text-[#163300]">
                4 {language === 'ar' ? 'طلب' : 'Orders'}
              </span>
            </div>
          </motion.div>
        )}

        {activeTab === "pending" && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="fixed bottom-0 left-0 right-0 bg-white border-t border-[rgba(14,15,12,0.12157)] px-6 py-4 max-w-[430px] mx-auto"
          >
            <div className="flex items-center justify-between" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
              <span className="text-sm text-[#6a6c6a]">
                {language === 'ar' ? 'إجمالي الطلبات' : 'Total Orders'}
              </span>
              <span className="font-bold text-[#163300]">
                1 {language === 'ar' ? 'طلب' : 'Order'}
              </span>
            </div>
          </motion.div>
        )}

        {activeTab === "completed" && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="fixed bottom-0 left-0 right-0 bg-white border-t border-[rgba(14,15,12,0.12157)] px-6 py-4 max-w-[430px] mx-auto"
          >
            <div className="flex items-center justify-between" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
              <span className="text-sm text-[#6a6c6a]">
                {language === 'ar' ? 'إجمالي الطلبات' : 'Total Orders'}
              </span>
              <span className="font-bold text-[#163300]">
                3 {language === 'ar' ? 'طلب' : 'Orders'}
              </span>
            </div>
          </motion.div>
        )}
      </div>
    </PullToRefresh>
  );
}