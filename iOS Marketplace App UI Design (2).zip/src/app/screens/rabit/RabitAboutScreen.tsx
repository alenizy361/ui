import { motion } from "motion/react";
import { ChevronRight, Heart, Users, ShieldCheck, Zap } from "lucide-react";
import { useLanguage } from "../../contexts/LanguageContext";

interface RabitAboutScreenProps {
  onBack: () => void;
}

export function RabitAboutScreen({ onBack }: RabitAboutScreenProps) {
  const { language, isRTL } = useLanguage();

  const content = {
    ar: {
      title: "عن التطبيق",
      appName: "منصة رابط",
      slogan: "اربط • اشتري • بِع",
      version: "الإصدار 1.0.0",
      ourVision: "رؤيتنا",
      visionText: "نسعى لأن نكون المنصة الأولى للتجارة الإلكترونية بين الأفراد في المملكة العربية السعودية، حيث نربط المشترين والبائعين في بيئة آمنة وموثوقة وسهلة الاستخدام.",
      activeUsers: "مستخدم نشط",
      productsListed: "منتج معروض",
      dailyTransactions: "معاملة يومية",
      citiesCovered: "مدينة",
      ourValues: "قيمنا",
      securityTrust: "الأمان والثقة",
      secureEnvironment: "نوفر بيئة آمنة ومحمية لجميع معاملاتك",
      userExperience: "تجربة المستخدم",
      smoothExperience: "واجهة سهلة وسلسة لتجربة تسوق ممتعة",
      activeCommunity: "مجتمع نشط",
      trustedCommunity: "آلاف المستخدمين الموثوقين في جميع أنحاء المملكة",
      transparency: "الشفافية",
      clearFees: "رسوم واضحة وبدون أي تكاليف خفية",
      whyRabit: "لماذا رابط؟",
      lowFees: "رسوم منخفضة",
      onlyForSellers: "فقط للبائعين",
      securePayments: "مدفوعات آمنة",
      fullPaymentProtection: "حماية كاملة للمدفوعات",
      fastShipping: "شحن سريع",
      deliveryIn3to7Days: "توصيل في 3-7 أيام",
      support247: "دعم 24/7",
      alwaysAvailable: "متاحون دائماً",
      ourTeam: "فريقنا",
      teamDescription: "فريق متحمس من المطورين والمصممين والمتخصصين في خدمة العملاء، نعمل على مدار الساعة لتوفير أفضل تجربة تسوق لك.",
      technology: "التقنية",
      techDescription: "مبني بأحدث التقنيات لضمان سرعة وأمان وموثوقية عالية",
      contactUs: "تواصل معنا",
      termsConditions: "الشروط والأحكام",
      privacyPolicy: "سياسة الخصوصية",
      copyright: "© 2024 منصة رابط. جميع الحقوق محفوظة.",
    },
    en: {
      title: "About",
      appName: "Rabit Platform",
      slogan: "Connect • Buy • Sell",
      version: "Version 1.0.0",
      ourVision: "Our Vision",
      visionText: "We strive to be the leading peer-to-peer e-commerce platform in Saudi Arabia, connecting buyers and sellers in a safe, reliable, and easy-to-use environment.",
      activeUsers: "Active Users",
      productsListed: "Products Listed",
      dailyTransactions: "Daily Transactions",
      citiesCovered: "Cities",
      ourValues: "Our Values",
      securityTrust: "Security & Trust",
      secureEnvironment: "We provide a safe and secure environment for all your transactions",
      userExperience: "User Experience",
      smoothExperience: "Easy and smooth interface for an enjoyable shopping experience",
      activeCommunity: "Active Community",
      trustedCommunity: "Thousands of trusted users across the Kingdom",
      transparency: "Transparency",
      clearFees: "Clear fees with no hidden costs",
      whyRabit: "Why Rabit?",
      lowFees: "Low Fees",
      onlyForSellers: "Only for sellers",
      securePayments: "Secure Payments",
      fullPaymentProtection: "Full payment protection",
      fastShipping: "Fast Shipping",
      deliveryIn3to7Days: "Delivery in 3-7 days",
      support247: "24/7 Support",
      alwaysAvailable: "Always available",
      ourTeam: "Our Team",
      teamDescription: "A passionate team of developers, designers, and customer service specialists, working around the clock to provide you with the best shopping experience.",
      technology: "Technology",
      techDescription: "Built with the latest technologies to ensure high speed, security, and reliability",
      contactUs: "Contact Us",
      termsConditions: "Terms & Conditions",
      privacyPolicy: "Privacy Policy",
      copyright: "© 2024 Rabit Platform. All rights reserved.",
    },
  };

  const c = content[language];
  
  const stats = [
    { label: c.activeUsers, value: "50K+", icon: Users },
    { label: c.productsListed, value: "100K+", icon: Zap },
    { label: c.dailyTransactions, value: "1K+", icon: Zap },
    { label: c.citiesCovered, value: "13", icon: ShieldCheck },
  ];

  const values = [
    {
      icon: ShieldCheck,
      title: c.securityTrust,
      description: c.secureEnvironment,
    },
    {
      icon: Heart,
      title: c.userExperience,
      description: c.smoothExperience,
    },
    {
      icon: Users,
      title: c.activeCommunity,
      description: c.trustedCommunity,
    },
    {
      icon: ShieldCheck,
      title: c.transparency,
      description: c.clearFees,
    },
  ];

  const features = [
    { title: c.lowFees, description: `5% ${c.onlyForSellers}` },
    { title: c.securePayments, description: c.fullPaymentProtection },
    { title: c.fastShipping, description: c.deliveryIn3to7Days },
    { title: c.support247, description: c.alwaysAvailable },
  ];

  return (
    <div
      className="min-h-screen bg-gradient-to-b from-[#fafafa] to-white"
      style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white/95 backdrop-blur-lg border-b border-[rgba(0,0,0,0.06)] px-6 py-4 z-10 shadow-sm"
      >
        <div className="flex items-center justify-between">
          <button
            onClick={onBack}
            className="w-11 h-11 rounded-2xl bg-[#f0fde8] border border-[rgba(22,51,0,0.1)] flex items-center justify-center text-[#163300] transition-all duration-200 hover:bg-[#e2fad5] active:scale-95"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-semibold text-[#0a0b09]">{c.title}</h1>
          <div className="w-11" /> {/* Spacer */}
        </div>
      </motion.div>

      {/* Content */}
      <div className="p-6 space-y-6">
        {/* Hero Section with Logo */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="bg-gradient-to-br from-[#163300] via-[#0f2409] to-[#163300] rounded-3xl p-8 text-center shadow-xl relative overflow-hidden"
        >
          {/* Decorative elements */}
          <div className="absolute top-0 right-0 w-40 h-40 bg-[#9fe870] opacity-10 rounded-full blur-3xl" />
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-[#9fe870] opacity-10 rounded-full blur-3xl" />

          <div className="relative z-10">
            {/* App Icon */}
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", delay: 0.2 }}
              className="w-24 h-24 rounded-3xl bg-[#9fe870] flex items-center justify-center mx-auto mb-4 shadow-2xl"
            >
              <span className="text-4xl font-bold text-[#163300]">R</span>
            </motion.div>

            <h2 className="text-3xl font-bold text-white mb-2">{c.appName}</h2>
            <p className="text-white/80 text-sm mb-4">{c.slogan}</p>
            <div className="inline-block px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full text-white text-sm">
              {c.version}
            </div>
          </div>
        </motion.div>

        {/* Mission Statement */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white rounded-2xl border border-[rgba(0,0,0,0.06)] p-6 shadow-card"
        >
          <h3 className="text-xl font-bold text-[#0a0b09] mb-3 text-center">{c.ourVision}</h3>
          <p className="text-[#6a6c6a] text-sm leading-relaxed text-center">
            {c.visionText}
          </p>
        </motion.div>

        {/* Stats Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="grid grid-cols-2 gap-4"
        >
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.5 + index * 0.1 }}
                className="bg-gradient-to-br from-[#f0fde8] to-[#e2fad5] rounded-2xl p-5 text-center"
              >
                <div className="w-12 h-12 rounded-2xl bg-[#163300] flex items-center justify-center mx-auto mb-3">
                  <Icon className="w-6 h-6 text-[#9fe870]" />
                </div>
                <p className="text-2xl font-bold text-[#163300] mb-1">{stat.value}</p>
                <p className="text-sm text-[#163300]/70">{stat.label}</p>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Our Values */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9 }}
          className="space-y-3"
        >
          <h3 className="text-xl font-bold text-[#0a0b09] mb-4">{c.ourValues}</h3>
          {values.map((value, index) => {
            const Icon = value.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: isRTL ? 20 : -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 1 + index * 0.1 }}
                className="bg-white rounded-2xl border border-[rgba(0,0,0,0.06)] p-5 shadow-card"
              >
                <div className={`flex items-start gap-4 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
                  <div className="w-14 h-14 rounded-2xl bg-[#f0fde8] flex items-center justify-center flex-shrink-0">
                    <Icon className="w-7 h-7 text-[#163300]" />
                  </div>
                  <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                    <h4 className="font-bold text-[#0a0b09] mb-2">{value.title}</h4>
                    <p className="text-sm text-[#6a6c6a] leading-relaxed">
                      {value.description}
                    </p>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Features Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.5 }}
          className="bg-gradient-to-br from-[#163300] to-[#0f2409] rounded-2xl p-6"
        >
          <h3 className="text-xl font-bold text-white mb-4 text-center">{c.whyRabit}</h3>
          <div className="grid grid-cols-2 gap-3">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 1.6 + index * 0.1 }}
                className="bg-white/10 backdrop-blur-sm rounded-xl p-4 text-center"
              >
                <p className="font-bold text-white mb-1">{feature.title}</p>
                <p className="text-xs text-white/70">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Team Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 2.0 }}
          className="bg-white rounded-2xl border border-[rgba(0,0,0,0.06)] p-6 shadow-card text-center"
        >
          <h3 className="text-xl font-bold text-[#0a0b09] mb-3">{c.ourTeam}</h3>
          <p className="text-[#6a6c6a] text-sm leading-relaxed mb-4">
            {c.teamDescription}
          </p>
          <div className="flex justify-center gap-2">
            {[1, 2, 3, 4, 5].map((i) => (
              <div
                key={i}
                className="w-10 h-10 rounded-full bg-gradient-to-br from-[#163300] to-[#9fe870]"
              />
            ))}
          </div>
        </motion.div>

        {/* Technology Stack */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 2.2 }}
          className="bg-white rounded-2xl border border-[rgba(0,0,0,0.06)] p-6 shadow-card"
        >
          <h3 className="text-xl font-bold text-[#0a0b09] mb-3 text-center">{c.technology}</h3>
          <p className="text-[#6a6c6a] text-sm leading-relaxed text-center mb-4">
            {c.techDescription}
          </p>
          <div className="flex flex-wrap justify-center gap-2">
            {["React", "TypeScript", "Tailwind", "Motion", "iOS"].map((tech) => (
              <span
                key={tech}
                className="px-4 py-2 bg-[#f0fde8] text-[#163300] text-sm font-medium rounded-full"
              >
                {tech}
              </span>
            ))}
          </div>
        </motion.div>

        {/* Contact Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 2.4 }}
          className="bg-gradient-to-br from-[#f0fde8] to-[#e2fad5] rounded-2xl p-6 text-center"
        >
          <h3 className="text-xl font-bold text-[#163300] mb-3">{c.contactUs}</h3>
          <div className="space-y-2 text-sm text-[#163300]">
            <p>📧 info@rabit.sa</p>
            <p>📱 +966 50 123 4567</p>
            <p>📍 {language === 'ar' ? 'الرياض، المملكة العربية السعودية' : 'Riyadh, Saudi Arabia'}</p>
            <p>🌐 www.rabit.sa</p>
          </div>
          <div className="flex justify-center gap-3 mt-4">
            <button className="w-11 h-11 rounded-full bg-[#163300] flex items-center justify-center text-white hover:bg-[#0f2409] transition-all">
              <span className="text-lg">𝕏</span>
            </button>
            <button className="w-11 h-11 rounded-full bg-[#163300] flex items-center justify-center text-white hover:bg-[#0f2409] transition-all">
              <span className="text-lg">📷</span>
            </button>
            <button className="w-11 h-11 rounded-full bg-[#163300] flex items-center justify-center text-white hover:bg-[#0f2409] transition-all">
              <span className="text-lg">📘</span>
            </button>
          </div>
        </motion.div>

        {/* Legal Links */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 2.6 }}
          className="flex justify-center gap-4 text-sm text-[#6a6c6a]"
        >
          <button className="hover:text-[#163300]">{c.termsConditions}</button>
          <span>•</span>
          <button className="hover:text-[#163300]">{c.privacyPolicy}</button>
        </motion.div>

        {/* Copyright */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2.8 }}
          className="text-center text-xs text-[#a3a3a3] pb-4"
        >
          <p>{c.copyright}</p>
        </motion.div>
      </div>
    </div>
  );
}
