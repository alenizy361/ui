import { motion } from "motion/react";
import { ChevronRight, TrendingUp, TrendingDown, DollarSign } from "lucide-react";
import { useState } from "react";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";

interface RabitSellerTransactionHistoryScreenProps {
  onBack: () => void;
}

export function RabitSellerTransactionHistoryScreen({ onBack }: RabitSellerTransactionHistoryScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);
  const [filter, setFilter] = useState<"all" | "sale" | "withdrawal">("all");

  const transactions: Transaction[] = [
    {
      id: "1",
      type: "sale",
      amount: 4500,
      description: "بيع آيفون 14 برو ماكس",
      date: "2024-12-24",
      status: "completed",
      orderId: "RBT-2024-5678",
    },
    {
      id: "2",
      type: "withdrawal",
      amount: -3000,
      description: "سحب إلى الحساب البنكي",
      date: "2024-12-22",
      status: "completed",
    },
    {
      id: "3",
      type: "sale",
      amount: 1800,
      description: "بيع ساعة أبل Series 8",
      date: "2024-12-20",
      status: "completed",
      orderId: "RBT-2024-5544",
    },
    {
      id: "4",
      type: "refund",
      amount: -950,
      description: "استرجاع مبلغ - طلب ملغي",
      date: "2024-12-18",
      status: "completed",
      orderId: "RBT-2024-5432",
    },
    {
      id: "5",
      type: "sale",
      amount: 2300,
      description: "بيع لاب توب Dell XPS",
      date: "2024-12-15",
      status: "pending",
      orderId: "RBT-2024-5321",
    },
    {
      id: "6",
      type: "withdrawal",
      amount: -2500,
      description: "سحب إلى الحساب البنكي",
      date: "2024-12-12",
      status: "completed",
    },
    {
      id: "7",
      type: "sale",
      amount: 650,
      description: "بيع سماعات AirPods Pro",
      date: "2024-12-10",
      status: "completed",
      orderId: "RBT-2024-5210",
    },
  ];

  const filteredTransactions = transactions.filter((t) => {
    if (filter === "all") return true;
    return t.type === filter;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "text-[#008026] bg-[#008026]/10";
      case "pending":
        return "text-[#df8700] bg-[#df8700]/10";
      case "failed":
        return "text-[#cb272f] bg-[#cb272f]/10";
      default:
        return "text-[#6a6c6a] bg-[#6a6c6a]/10";
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "completed":
        return "مكتمل";
      case "pending":
        return "قيد المعالجة";
      case "failed":
        return "فشل";
      default:
        return status;
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "sale":
        return "مبيعات";
      case "withdrawal":
        return "سحب";
      case "refund":
        return "استرجاع";
      default:
        return type;
    }
  };

  return (
    <div className="min-h-screen bg-white" style={{ fontFamily: 'Cairo, sans-serif' }}>
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 flex items-center justify-between z-10"
      >
        <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
          <ChevronRight className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-semibold text-[#0e0f0c]">سجل المعاملات</h1>
        <div className="w-10" />
      </motion.div>

      <div className="p-6">
        {/* Filter Chips */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {[
            { value: "all", label: "الكل" },
            { value: "sale", label: "مبيعات" },
            { value: "withdrawal", label: "سحوبات" },
          ].map((filterOption) => (
            <button
              key={filterOption.value}
              onClick={() => setFilter(filterOption.value as any)}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                filter === filterOption.value
                  ? "bg-[#163300] text-white"
                  : "bg-[rgba(22,51,0,0.07843)] text-[#163300] hover:bg-[rgba(22,51,0,0.12)]"
              }`}
            >
              {filterOption.label}
            </button>
          ))}
        </div>

        {/* Summary Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-br from-[#163300] to-[#0d1f00] rounded-[12px] p-4 mb-6 text-white"
        >
          <p className="text-sm opacity-80 mb-1 text-right">إجمالي المبيعات هذا الشهر</p>
          <p className="text-2xl font-bold text-right">٩٬٢٥٠ ر.س</p>
          <div className="flex items-center justify-between mt-3 pt-3 border-t border-white/20">
            <span className="text-sm">عمولة رابط (٥٪)</span>
            <span className="font-semibold">٤٦٢.٥٠ ر.س</span>
          </div>
        </motion.div>

        {/* Transactions List */}
        <div className="space-y-3">
          {filteredTransactions.map((transaction, index) => (
            <motion.div
              key={transaction.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
              className="bg-white border border-[rgba(14,15,12,0.12157)] rounded-[12px] p-4"
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-start gap-3 flex-1">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    transaction.type === "sale" 
                      ? "bg-[#008026]/10" 
                      : transaction.type === "withdrawal"
                      ? "bg-[#163300]/10"
                      : "bg-[#cb272f]/10"
                  }`}>
                    {transaction.type === "sale" ? (
                      <Package className="w-5 h-5 text-[#008026]" />
                    ) : transaction.type === "withdrawal" ? (
                      <ArrowDownLeft className="w-5 h-5 text-[#163300]" />
                    ) : (
                      <ArrowUpRight className="w-5 h-5 text-[#cb272f]" />
                    )}
                  </div>
                  <div className="flex-1 text-right">
                    <p className="font-semibold text-[#0e0f0c] mb-1">{transaction.description}</p>
                    <div className="flex items-center gap-2 mb-2 justify-end">
                      <span className="text-xs text-[#6a6c6a]">
                        {transaction.date}
                      </span>
                      {transaction.orderId && (
                        <>
                          <span className="text-xs text-[#6a6c6a]">•</span>
                          <span className="text-xs text-[#6a6c6a]">{transaction.orderId}</span>
                        </>
                      )}
                    </div>
                    <div className="flex items-center gap-2 justify-end">
                      <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(transaction.status)}`}>
                        {getStatusText(transaction.status)}
                      </span>
                      <span className="text-xs px-2 py-1 rounded-full bg-[rgba(22,51,0,0.07843)] text-[#163300]">
                        {getTypeLabel(transaction.type)}
                      </span>
                    </div>
                  </div>
                </div>
                <span
                  className={`text-lg font-bold ${
                    transaction.amount > 0 ? "text-[#008026]" : "text-[#cb272f]"
                  }`}
                >
                  {transaction.amount > 0 ? "+" : ""}{transaction.amount} ر.س
                </span>
              </div>
            </motion.div>
          ))}
        </div>

        {filteredTransactions.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <Filter className="w-12 h-12 text-[#6a6c6a] mx-auto mb-3 opacity-50" />
            <p className="text-[#6a6c6a]">لا توجد معاملات</p>
          </motion.div>
        )}
      </div>
    </div>
  );
}