import { motion } from "motion/react";
import { ChevronRight, Eye, EyeOff, Phone, User, Mail, Lock, Check, CreditCard, Sparkles, ShoppingBag, Store } from "lucide-react";
import { WiseButton } from "../../components/WiseButton";
import { useState } from "react";
import { triggerHaptic } from "../../utils/haptics";
import { WiseInput } from "../../components/WiseInput";
import { toast } from "sonner";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";
import { LanguageSwitcher } from "../../components/LanguageSwitcher";
import { 
  validateEmail, 
  validatePhone, 
  validatePassword, 
  validateConfirmPassword, 
  validateFullName, 
  validateNationalId,
  validateTermsAcceptance 
} from "../../utils/validation";
import { SupabaseConnectionError } from "../../components/SupabaseConnectionError";
import { EmailValidationError } from "../../components/EmailValidationError";
import { projectId } from "../../../../utils/supabase/info";

interface RabitRegisterScreenProps {
  onBack: () => void;
  onContinue: (email: string, password: string, fullName: string, phone: string, nationalId: string) => void; // Pass form data to parent
}

export function RabitRegisterScreen({ onBack, onContinue }: RabitRegisterScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);
  
  const [formData, setFormData] = useState({
    fullName: "",
    nationalId: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [showConnectionError, setShowConnectionError] = useState(false);
  const [showEmailValidationError, setShowEmailValidationError] = useState(false);

  // Real-time field validation
  const validateField = (field: string, value: string) => {
    let result;
    
    switch (field) {
      case 'fullName':
        result = validateFullName(value);
        break;
      case 'nationalId':
        result = validateNationalId(value);
        break;
      case 'email':
        result = validateEmail(value);
        break;
      case 'phone':
        result = validatePhone(value);
        break;
      case 'password':
        result = validatePassword(value);
        break;
      case 'confirmPassword':
        result = validateConfirmPassword(formData.password, value);
        break;
      default:
        return;
    }
    
    if (!result.isValid) {
      setErrors(prev => ({ 
        ...prev, 
        [field]: language === 'ar' ? (result.errorAr || '') : (result.error || '') 
      }));
    } else {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  };

  const handleSubmit = async () => {
    triggerHaptic('medium');
    
    console.log('🎯 [Register Screen] Form submitted');
    
    // Validate all fields
    const fullNameValidation = validateFullName(formData.fullName);
    const nationalIdValidation = validateNationalId(formData.nationalId);
    const emailValidation = validateEmail(formData.email);
    const phoneValidation = validatePhone(formData.phone);
    const passwordValidation = validatePassword(formData.password);
    const confirmPasswordValidation = validateConfirmPassword(formData.password, formData.confirmPassword);
    const termsValidation = validateTermsAcceptance(termsAccepted);
    
    const newErrors: Record<string, string> = {};
    
    if (!fullNameValidation.isValid) {
      newErrors.fullName = language === 'ar' ? (fullNameValidation.errorAr || '') : (fullNameValidation.error || '');
    }
    if (!nationalIdValidation.isValid) {
      newErrors.nationalId = language === 'ar' ? (nationalIdValidation.errorAr || '') : (nationalIdValidation.error || '');
    }
    if (!emailValidation.isValid) {
      newErrors.email = language === 'ar' ? (emailValidation.errorAr || '') : (emailValidation.error || '');
    }
    if (!phoneValidation.isValid) {
      newErrors.phone = language === 'ar' ? (phoneValidation.errorAr || '') : (phoneValidation.error || '');
    }
    if (!passwordValidation.isValid) {
      newErrors.password = language === 'ar' ? (passwordValidation.errorAr || '') : (passwordValidation.error || '');
    }
    if (!confirmPasswordValidation.isValid) {
      newErrors.confirmPassword = language === 'ar' ? (confirmPasswordValidation.errorAr || '') : (confirmPasswordValidation.error || '');
    }
    
    if (Object.keys(newErrors).length > 0) {
      console.log('❌ [Register Screen] Validation errors:', newErrors);
      setErrors(newErrors);
      triggerHaptic('error');
      toast.error(language === 'ar' ? "يرجى تصحيح الأخطاء" : "Please fix the errors");
      return;
    }
    
    if (!termsValidation.isValid) {
      console.log('❌ [Register Screen] Terms not accepted');
      triggerHaptic('error');
      toast.error(language === 'ar' ? termsValidation.errorAr : termsValidation.error);
      return;
    }
    
    console.log('✅ [Register Screen] All validations passed');
    
    triggerHaptic('success');
    
    // Don't call signUp here - just pass data to parent to go to role selection
    console.log('📝 [Register Screen] Passing registration data to parent for role selection');
    console.log('📧 [Register Screen] Email:', formData.email);
    
    // Pass form data to parent - they will handle role selection and then signUp
    onContinue(formData.email, formData.password, formData.fullName, formData.phone, formData.nationalId);
    
    console.log('✅ [Register Screen] onContinue called successfully');
  };

  // Show connection error screen if needed
  if (showConnectionError) {
    return <SupabaseConnectionError onRetry={() => setShowConnectionError(false)} />;
  }

  return (
    <div 
      className="min-h-screen bg-gradient-to-br from-[#fafafa] via-white to-[#f0fde8]/20 flex flex-col relative overflow-hidden" 
      style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Email Validation Error Modal */}
      <EmailValidationError
        show={showEmailValidationError}
        onClose={() => setShowEmailValidationError(false)}
        email={formData.email}
        projectId={projectId}
      />
      
      {/* Animated Background Orbs */}
      <motion.div
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.1, 0.2, 0.1],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute -top-40 -right-40 w-96 h-96 bg-gradient-to-br from-[#9fe870] to-[#163300] rounded-full blur-3xl"
      />
      <motion.div
        animate={{
          scale: [1.2, 1, 1.2],
          opacity: [0.08, 0.15, 0.08],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute -bottom-32 -left-32 w-80 h-80 bg-gradient-to-tr from-[#163300] to-[#9fe870] rounded-full blur-3xl"
      />

      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white/80 backdrop-blur-2xl border-b border-white/50 px-6 py-4 flex items-center gap-4 z-10 shadow-sm"
      >
        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={onBack}
          className="w-11 h-11 rounded-2xl bg-white/80 backdrop-blur-sm border border-white/60 flex items-center justify-center text-[#163300] shadow-md hover:shadow-lg transition-all duration-200"
        >
          <ChevronRight className={`w-6 h-6 ${isRTL ? '' : 'rotate-180'}`} strokeWidth={2.5} />
        </motion.button>
        <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
          <h1 className="text-xl font-black bg-gradient-to-l from-[#163300] to-[#0a0b09] bg-clip-text text-transparent">
            {t.registerTitle}
          </h1>
          <p className="text-xs text-[#6a6c6a]">{t.registerSubtitle}</p>
        </div>
      </motion.div>

      {/* Welcome Section */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.1 }}
        className="px-6 pt-6 pb-4 relative z-10"
      >
        <div className="bg-gradient-to-br from-white/60 to-[#f0fde8]/40 backdrop-blur-xl rounded-3xl p-6 border border-white/60 shadow-lg">
          <div className={`flex items-center gap-4 mb-4 ${isRTL ? 'flex-row' : 'flex-row-reverse'}`}>
            <div className="flex gap-3">
              <motion.div
                animate={{
                  y: [0, -8, 0],
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: 0,
                }}
                className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#9fe870] to-[#b5ff8a] flex items-center justify-center shadow-lg"
              >
                <ShoppingBag className="w-7 h-7 text-[#163300]" strokeWidth={2.5} />
              </motion.div>
              <motion.div
                animate={{
                  y: [0, -8, 0],
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: 0.3,
                }}
                className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#163300] to-[#0f2409] flex items-center justify-center shadow-lg"
              >
                <Store className="w-7 h-7 text-[#9fe870]" strokeWidth={2.5} />
              </motion.div>
            </div>
            <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
              <h2 className="text-lg font-black text-[#0a0b09] mb-1">
                {language === 'ar' ? 'اشتري وبع بكل سهولة' : 'Buy and Sell with Ease'}
              </h2>
              <p className="text-xs text-[#6a6c6a] leading-relaxed">
                {language === 'ar' ? 'سجّل الآن وابدأ رحلتك في أكبر منصة تسوق' : 'Sign up now and start your journey on the biggest marketplace'}
              </p>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Form */}
      <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <WiseInput
            label={t.fullName}
            placeholder={language === 'ar' ? 'أدخل اسمك الكامل' : 'Enter your full name'}
            value={formData.fullName}
            onChange={(e) => handleInputChange('fullName', e.target.value)}
            leftIcon={<User className="w-5 h-5" />}
            error={errors.fullName}
          />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
        >
          <WiseInput
            label={language === 'ar' ? 'رقم الهوية / الإقامة' : 'National ID / Iqama'}
            placeholder="1234567890"
            value={formData.nationalId}
            onChange={(e) => handleInputChange('nationalId', e.target.value)}
            leftIcon={<CreditCard className="w-5 h-5" />}
            error={errors.nationalId}
          />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <WiseInput
            label={t.email}
            type="email"
            placeholder="example@email.com"
            value={formData.email}
            onChange={(e) => handleInputChange('email', e.target.value)}
            leftIcon={<Mail className="w-5 h-5" />}
            error={errors.email}
          />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35 }}
        >
          <label className={`block text-sm font-bold text-[#0a0b09] mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
            {t.phoneNumber}
          </label>
          <div className="flex gap-3">
            <div className="w-20 h-[52px] bg-white/80 backdrop-blur-sm rounded-2xl flex items-center justify-center border border-white/60 shadow-sm">
              <span className="font-black text-[#163300]">966+</span>
            </div>
            <div className="flex-1">
              <input
                type="tel"
                placeholder="501234567"
                value={formData.phone}
                onChange={(e) => handleInputChange('phone', e.target.value.replace(/\D/g, ""))}
                className={`w-full h-[52px] px-5 rounded-2xl bg-white/80 backdrop-blur-sm border transition-all shadow-sm ${
                  errors.phone 
                    ? 'border-[#ef4444] focus:ring-[#ef4444]' 
                    : 'border-white/60 focus:ring-[#163300]'
                } text-[#0a0b09] font-medium placeholder:text-[#6a6c6a] focus:outline-none focus:ring-2 focus:border-transparent ${isRTL ? 'text-right' : 'text-left'}`}
                maxLength={9}
              />
            </div>
          </div>
          {errors.phone && (
            <p className={`text-xs text-[#ef4444] mt-2 ${isRTL ? 'text-right' : 'text-left'}`}>
              {errors.phone}
            </p>
          )}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <WiseInput
            label={t.password}
            type={showPassword ? "text" : "password"}
            placeholder="••••••••"
            value={formData.password}
            onChange={(e) => handleInputChange('password', e.target.value)}
            leftIcon={<Lock className="w-5 h-5" />}
            rightIcon={
              <button
                onClick={() => {
                  setShowPassword(!showPassword);
                  triggerHaptic('light');
                }}
                className="w-5 h-5"
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            }
            error={errors.password}
          />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.45 }}
        >
          <WiseInput
            label={t.confirmPassword}
            type={showConfirmPassword ? "text" : "password"}
            placeholder="••••••••"
            value={formData.confirmPassword}
            onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
            leftIcon={<Lock className="w-5 h-5" />}
            rightIcon={
              <button
                onClick={() => {
                  setShowConfirmPassword(!showConfirmPassword);
                  triggerHaptic('light');
                }}
                className="w-5 h-5"
              >
                {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            }
            error={errors.confirmPassword}
          />
        </motion.div>

        {/* Terms Checkbox */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="pt-2"
        >
          <button
            onClick={() => {
              setTermsAccepted(!termsAccepted);
              triggerHaptic('light');
            }}
            className="flex gap-3 items-start w-full p-4 rounded-2xl bg-white/60 backdrop-blur-sm border border-white/60 hover:bg-white/80 transition-all duration-200"
          >
            <div
              className={`w-7 h-7 rounded-xl border-2 flex items-center justify-center flex-shrink-0 transition-all duration-200 ${
                termsAccepted
                  ? "bg-gradient-to-br from-[#163300] to-[#0f2409] border-[#163300] shadow-lg"
                  : "border-[rgba(0,0,0,0.15)] bg-white/50"
              }`}
            >
              {termsAccepted && (
                <motion.div
                  initial={{ scale: 0, rotate: -180 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <Check className="w-5 h-5 text-[#9fe870]" strokeWidth={3} />
                </motion.div>
              )}
            </div>
            <p className={`text-sm text-[#6a6c6a] leading-relaxed flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
              {language === 'ar' ? (
                <>
                  أوافق على{" "}
                  <span className="text-[#163300] font-black">الشروط والأحكام</span>
                  {" "}و{" "}
                  <span className="text-[#163300] font-black">سياسة الخصوصية</span>
                  {" "}الخاصة بمنصة رابط
                </>
              ) : (
                <>
                  I agree to Rabit's{" "}
                  <span className="text-[#163300] font-black">Terms & Conditions</span>
                  {" "}and{" "}
                  <span className="text-[#163300] font-black">Privacy Policy</span>
                </>
              )}
            </p>
          </button>
        </motion.div>
      </div>

      {/* Bottom CTA */}
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.6 }}
        className="sticky bottom-0 bg-white/80 backdrop-blur-2xl border-t border-white/50 p-6 shadow-[0_-8px_32px_rgba(0,0,0,0.04)] relative z-10"
      >
        <WiseButton
          onClick={handleSubmit}
          variant="primary"
          fullWidth
          size="lg"
          loading={loading}
          disabled={!termsAccepted || !formData.phone || !formData.password}
        >
          <span className="flex items-center justify-center gap-2">
            {t.continue}
            <Sparkles className="w-4 h-4" />
          </span>
        </WiseButton>
      </motion.div>
    </div>
  );
}