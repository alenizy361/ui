import { useState, useRef, useEffect } from "react";
import { motion } from "motion/react";
import { ChevronLeft, ChevronRight, Camera, X, Image, PackageCheck, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";
import { createProduct } from "../../services/products.service";
import { uploadProductImage } from "../../services/storage.service";
import { getCategories, type Category } from "../../services/categories.service";
import { useAuth } from "../../contexts/AuthContext";
import { WiseButton } from "../../components/WiseButton";
import { StorageSetupError } from "../../components/StorageSetupError";
import { DatabaseSetupError } from "../../components/DatabaseSetupError";
import { projectId } from "../../../../utils/supabase/info";

interface RabitAddProductScreenProps {
  onBack: () => void;
  onPublishSuccess: () => void;
}

export function RabitAddProductScreen({ onBack, onPublishSuccess }: RabitAddProductScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);
  const { user } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showStorageError, setShowStorageError] = useState(false);
  const [storageErrorMessage, setStorageErrorMessage] = useState('');
  const [showDatabaseError, setShowDatabaseError] = useState(false);
  const [databaseErrorMessage, setDatabaseErrorMessage] = useState('');
  const [showSuccess, setShowSuccess] = useState(false);
  const [title, setTitle] = useState("");
  const [price, setPrice] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("");
  const [condition, setCondition] = useState<"new" | "used" | "">("");
  const [city, setCity] = useState("");
  const [images, setImages] = useState<string[]>([]);
  const [quantity, setQuantity] = useState("1"); // New: Quantity field
  const [categories, setCategories] = useState<Category[]>([]);
  const [isLoadingCategories, setIsLoadingCategories] = useState(false);

  const citiesData = {
    ar: [
      "الرياض",
      "جدة",
      "مكة المكرمة",
      "المدينة المنورة",
      "الدمام",
      "الخبر",
      "الطائف",
      "تبوك",
    ],
    en: [
      "Riyadh",
      "Jeddah",
      "Mecca",
      "Medina",
      "Dammam",
      "Khobar",
      "Taif",
      "Tabuk",
    ]
  };

  // Fetch categories on mount
  useEffect(() => {
    const fetchCategories = async () => {
      setIsLoadingCategories(true);
      try {
        const result = await getCategories();
        if (result.success && result.categories) {
          setCategories(result.categories);
        } else {
          toast.error(language === 'ar' ? 'فشل تحميل الفئات' : 'Failed to load categories');
        }
      } catch (error) {
        console.error('Error fetching categories:', error);
        toast.error(language === 'ar' ? 'حدث خطأ أثناء تحميل الفئات' : 'Error loading categories');
      }
      setIsLoadingCategories(false);
    };

    fetchCategories();
  }, [language]);

  const handleAddImage = () => {
    if (images.length < 5) {
      // Trigger file input
      fileInputRef.current?.click();
    }
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    
    // Validate file type
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    if (!allowedTypes.includes(file.type)) {
      toast.error(language === 'ar' ? 'نوع الملف غير مدعوم. يرجى اختيار صورة JPEG أو PNG أو WebP' : 'Unsupported file type. Please select JPEG, PNG, or WebP image');
      return;
    }

    // Validate file size (5MB max)
    if (file.size > 5242880) {
      toast.error(language === 'ar' ? 'حجم الملف كبير جداً. الحد الأقصى 5 ميجابايت' : 'File too large. Maximum size is 5MB');
      return;
    }

    if (!user?.accessToken) {
      toast.error(language === 'ar' ? 'يجب تسجيل الدخول لتحميل الصور' : 'You must be logged in to upload images');
      return;
    }

    console.log('📤 Starting image upload...');
    setUploadingImage(true);
    
    try {
      const result = await uploadProductImage(file);
      
      console.log('Upload result:', result);
      
      if (result.success && result.url) {
        setImages([...images, result.url]);
        toast.success(language === 'ar' ? 'تم تحميل الصورة بنجاح ✓' : 'Image uploaded successfully ✓');
      } else {
        console.error('Upload failed:', result);
        
        // Show storage error modal if it's an RLS error or bucket missing error
        if (result.error && (
          result.error.includes('RLS_POLICY_ERROR') || 
          result.error.includes('SETUP_REQUIRED') ||
          result.error.includes('row-level security') ||
          result.error.includes('not found')
        )) {
          setShowStorageError(true);
          setStorageErrorMessage(result.error);
        }
        
        toast.error(language === 'ar' ? result.error || 'فشل تحميل الصورة' : result.error || 'Failed to upload image');
      }
    } catch (error) {
      console.error('Error uploading image:', error);
      toast.error(language === 'ar' ? 'حدث خطأ أثناء تحميل الصورة' : 'An error occurred while uploading the image');
      setShowStorageError(true);
      setStorageErrorMessage('An error occurred while uploading the image');
    } finally {
      setUploadingImage(false);
    }
  };

  const handleRemoveImage = (index: number) => {
    setImages(images.filter((_, i) => i !== index));
  };

  const handlePublish = async () => {
    if (!user) {
      toast.error(language === 'ar' ? 'يجب تسجيل الدخول لنشر المنتج' : 'You must be logged in to publish a product');
      return;
    }

    setLoading(true);
    
    try {
      const result = await createProduct({
        title,
        description,
        price: parseFloat(price),
        category,
        condition,
        images,
        location: city,
        quantity: parseInt(quantity),
        delivery_options: ['delivery', 'meetup'],
      });

      if (result.success) {
        setShowSuccess(true);
        toast.success(t.productPublishedSuccess + " 🎉");
        setTimeout(() => {
          onPublishSuccess();
        }, 3000);
      } else {
        // Show helpful error messages
        if (result.error?.includes('DATABASE_SETUP_REQUIRED') || result.error?.includes('PGRST205') || result.error?.includes('schema cache')) {
          setShowDatabaseError(true);
          setDatabaseErrorMessage(result.error);
          toast.error(language === 'ar' 
            ? 'يرجى إنشاء جدول المنتجات في Supabase Dashboard' 
            : 'Please create products table in Supabase Dashboard');
        } else if (result.error?.includes('RLS_POLICY_ERROR')) {
          toast.error(language === 'ar' 
            ? 'يرجى تكوين سياسات RLS لجدول المنتجات' 
            : 'Please configure RLS policies for products table');
        } else {
          toast.error(language === 'ar' ? 'فشل نشر المنتج' : result.error || 'Failed to publish product');
        }
      }
    } catch (error) {
      console.error('Error creating product:', error);
      toast.error(language === 'ar' ? 'حدث خطأ أثناء نشر المنتج' : 'An error occurred while publishing the product');
    } finally {
      setLoading(false);
    }
  };

  const isFormValid = title && price && description && category && condition && city && images.length > 0;

  // Success screen
  if (showSuccess) {
    return (
      <div 
        className="min-h-screen bg-white flex flex-col items-center justify-center p-6" 
        style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
        dir={isRTL ? 'rtl' : 'ltr'}
      >
        {/* Animated Package Icon */}
        <motion.div
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ 
            type: "spring", 
            stiffness: 200, 
            damping: 15,
            duration: 0.6
          }}
          className="mb-8"
        >
          <motion.div
            animate={{ 
              y: [0, -15, 0],
            }}
            transition={{
              repeat: Infinity,
              duration: 2,
              ease: "easeInOut"
            }}
            className="w-32 h-32 bg-gradient-to-br from-[#163300] to-[#1a3d00] rounded-full flex items-center justify-center relative"
          >
            <PackageCheck className="w-16 h-16 text-white" />
            
            {/* Sparkles */}
            {[0, 1, 2, 3].map((i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0 }}
                animate={{ 
                  opacity: [0, 1, 0],
                  scale: [0, 1, 0],
                  x: [0, (i % 2 === 0 ? 40 : -40)],
                  y: [0, (i < 2 ? -40 : 40)]
                }}
                transition={{
                  repeat: Infinity,
                  duration: 2,
                  delay: i * 0.2
                }}
                className="absolute"
                style={{
                  left: i % 2 === 0 ? '70%' : '30%',
                  top: i < 2 ? '20%' : '70%'
                }}
              >
                <Sparkles className="w-5 h-5 text-[#9fe870]" />
              </motion.div>
            ))}
          </motion.div>
        </motion.div>

        {/* Success checkmark */}
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ 
            delay: 0.3,
            type: "spring", 
            stiffness: 200, 
            damping: 15 
          }}
          className="w-20 h-20 bg-[#008026] rounded-full flex items-center justify-center mb-6"
        >
          <motion.svg
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="w-10 h-10 text-white"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
          >
            <motion.path
              d="M5 13l4 4L19 7"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </motion.svg>
        </motion.div>

        {/* Success text */}
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="text-2xl font-bold text-[#163300] mb-2 text-center"
        >
          {t.productPublishedSuccess} 🎉
        </motion.h2>
        
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="text-[#6a6c6a] text-center mb-6"
        >
          {t.productNowAvailable}
        </motion.p>

        {/* Product card */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.8 }}
          className="bg-[rgba(22,51,0,0.07843)] rounded-[16px] p-5 w-full max-w-sm"
        >
          <div className={`flex items-center justify-between mb-3 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
            <span className="text-sm text-[#6a6c6a]">{t.productTitle}</span>
            <span className={`font-medium text-[#0e0f0c] text-sm ${isRTL ? 'text-right' : 'text-left'}`}>{title.substring(0, 25)}...</span>
          </div>
          <div className={`flex items-center justify-between mb-3 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
            <span className="text-sm text-[#6a6c6a]">{t.price}</span>
            <span className="font-bold text-[#163300]">{price} {t.sar}</span>
          </div>
          <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
            <span className="text-sm text-[#6a6c6a]">{t.condition}</span>
            <span className="px-3 py-1 bg-[#163300] text-white text-xs rounded-full font-medium">
              {condition === "new" ? t.conditionNew : t.conditionUsed}
            </span>
          </div>
        </motion.div>

        {/* Animated dots */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="flex gap-2 mt-8"
        >
          {[0, 1, 2].map((i) => (
            <motion.div
              key={i}
              animate={{
                scale: [1, 1.5, 1],
                opacity: [0.3, 1, 0.3],
              }}
              transition={{
                repeat: Infinity,
                duration: 1.5,
                delay: i * 0.2,
              }}
              className="w-2 h-2 bg-[#163300] rounded-full"
            />
          ))}
        </motion.div>
      </div>
    );
  }

  return (
    <div 
      className="min-h-screen bg-white flex flex-col" 
      style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      <motion.div 
        initial={{ opacity: 0, y: -20 }} 
        animate={{ opacity: 1, y: 0 }} 
        className="sticky top-0 bg-white/95 backdrop-blur-lg border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 flex items-center gap-4 z-10"
      >
        <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center text-[#0e0f0c]">
          {isRTL ? <ChevronRight className="w-6 h-6" /> : <ChevronLeft className="w-6 h-6" />}
        </button>
        <h1 className={`text-xl font-semibold text-[#0e0f0c] flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
          {t.addProductTitle}
        </h1>
      </motion.div>
      
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Images Upload */}
        <div>
          <label className={`block text-sm font-medium text-[#0e0f0c] mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
            {t.productPhotos} <span className="text-[#cb272f]">*</span>
          </label>
          <p className={`text-xs text-[#6a6c6a] mb-3 ${isRTL ? 'text-right' : 'text-left'}`}>
            {language === 'ar' ? 'أضف حتى 5 صور (الصورة الأولى ستكون الصورة الرئيسية)' : 'Add up to 5 images (first image will be the primary)'}
          </p>
          
          {/* Image Grid */}
          <div className="grid grid-cols-3 gap-3 mb-3">
            {images.map((img, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                className="relative aspect-square bg-[rgba(22,51,0,0.07843)] rounded-[10px] border border-[rgba(14,15,12,0.12157)] overflow-hidden"
              >
                {index === 0 && (
                  <div className={`absolute top-2 ${isRTL ? 'right-2' : 'left-2'} bg-[#163300] text-white text-xs px-2 py-0.5 rounded-full z-10`}>
                    {language === 'ar' ? 'رئيسية' : 'Primary'}
                  </div>
                )}
                <div className="absolute inset-0 flex items-center justify-center">
                  <Image className="w-8 h-8 text-[#6a6c6a]" />
                </div>
                <button
                  onClick={() => handleRemoveImage(index)}
                  className={`absolute top-2 ${isRTL ? 'left-2' : 'right-2'} w-6 h-6 bg-[#cb272f] rounded-full flex items-center justify-center text-white z-10`}
                >
                  <X className="w-4 h-4" />
                </button>
              </motion.div>
            ))}
            
            {/* Add Image Button */}
            {images.length < 5 && (
              <button
                onClick={handleAddImage}
                className="aspect-square bg-[rgba(22,51,0,0.07843)] rounded-[10px] border-2 border-dashed border-[rgba(14,15,12,0.12157)] hover:border-[#163300] transition-colors flex flex-col items-center justify-center gap-2"
              >
                <Camera className="w-6 h-6 text-[#6a6c6a]" />
                <span className="text-xs text-[#6a6c6a]">{language === 'ar' ? 'إضافة' : 'Add'}</span>
              </button>
            )}
          </div>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileSelect}
            accept="image/jpeg, image/jpg, image/png, image/webp"
            className="hidden"
          />
        </div>

        {/* Product Title */}
        <div>
          <label className={`block text-sm font-medium text-[#0e0f0c] mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
            {t.productTitle} <span className="text-[#cb272f]">*</span>
          </label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder={language === 'ar' ? 'مثال: آيفون 14 برو ماكس - حالة ممتازة' : 'Example: iPhone 14 Pro Max - Excellent Condition'}
            className={`w-full px-4 py-3 rounded-[10px] bg-[rgba(22,51,0,0.07843)] border border-transparent text-[#0e0f0c] placeholder:text-[#6a6c6a] focus:outline-none focus:ring-2 focus:ring-[#163300] focus:bg-white transition-all ${isRTL ? 'text-right' : 'text-left'}`}
            style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
          />
        </div>

        {/* Category */}
        <div>
          <label className={`block text-sm font-medium text-[#0e0f0c] mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
            {t.category} <span className="text-[#cb272f]">*</span>
          </label>
          <div className="grid grid-cols-2 gap-2">
            {isLoadingCategories ? (
              <div className="col-span-2 text-center text-sm text-[#6a6c6a]">Loading categories...</div>
            ) : (
              categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setCategory(cat.id)}
                  className={`py-2.5 px-4 rounded-[10px] text-sm font-medium transition-all ${
                    category === cat.id
                      ? "bg-[#163300] text-white"
                      : "bg-[rgba(22,51,0,0.07843)] text-[#0e0f0c] border border-[rgba(14,15,12,0.12157)]"
                  }`}
                >
                  {cat.icon} {language === 'ar' ? cat.nameAr : cat.name}
                </button>
              ))
            )}
          </div>
        </div>

        {/* Price */}
        <div>
          <label className={`block text-sm font-medium text-[#0e0f0c] mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
            {t.price} <span className="text-[#cb272f]">*</span>
          </label>
          <div className="relative">
            <input
              type="number"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              placeholder="0"
              className={`w-full px-4 py-3 rounded-[10px] bg-[rgba(22,51,0,0.07843)] border border-transparent text-[#0e0f0c] placeholder:text-[#6a6c6a] focus:outline-none focus:ring-2 focus:ring-[#163300] focus:bg-white transition-all ${isRTL ? 'text-right pr-16' : 'text-left pl-16'}`}
              style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
            />
            <span className={`absolute ${isRTL ? 'left-4' : 'right-4'} top-1/2 -translate-y-1/2 text-[#6a6c6a]`}>{t.sar}</span>
          </div>
        </div>

        {/* Quantity */}
        <div>
          <label className={`block text-sm font-medium text-[#0e0f0c] mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
            {t.quantity} <span className="text-[#cb272f]">*</span>
          </label>
          <input
            type="number"
            value={quantity}
            onChange={(e) => setQuantity(e.target.value)}
            placeholder="1"
            min="1"
            className={`w-full px-4 py-3 rounded-[10px] bg-[rgba(22,51,0,0.07843)] border border-transparent text-[#0e0f0c] placeholder:text-[#6a6c6a] focus:outline-none focus:ring-2 focus:ring-[#163300] focus:bg-white transition-all ${isRTL ? 'text-right' : 'text-left'}`}
            style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
          />
          <p className={`text-xs text-[#6a6c6a] mt-2 ${isRTL ? 'text-right' : 'text-left'}`}>
            {language === 'ar' ? 'عدد القطع المتاحة للبيع' : 'Number of items available for sale'}
          </p>
        </div>

        {/* Condition */}
        <div>
          <label className={`block text-sm font-medium text-[#0e0f0c] mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
            {t.condition} <span className="text-[#cb272f]">*</span>
          </label>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => setCondition("new")}
              className={`py-3 px-4 rounded-[10px] text-sm font-medium transition-all ${
                condition === "new"
                  ? "bg-[#163300] text-white"
                  : "bg-[rgba(22,51,0,0.07843)] text-[#0e0f0c] border border-[rgba(14,15,12,0.12157)]"
              }`}
            >
              {t.conditionNew}
            </button>
            <button
              onClick={() => setCondition("used")}
              className={`py-3 px-4 rounded-[10px] text-sm font-medium transition-all ${
                condition === "used"
                  ? "bg-[#163300] text-white"
                  : "bg-[rgba(22,51,0,0.07843)] text-[#0e0f0c] border border-[rgba(14,15,12,0.12157)]"
              }`}
            >
              {t.conditionUsed}
            </button>
          </div>
        </div>

        {/* City */}
        <div>
          <label className={`block text-sm font-medium text-[#0e0f0c] mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
            {t.city} <span className="text-[#cb272f]">*</span>
          </label>
          <select
            value={city}
            onChange={(e) => setCity(e.target.value)}
            className={`w-full px-4 py-3 rounded-[10px] bg-[rgba(22,51,0,0.07843)] border border-transparent text-[#0e0f0c] focus:outline-none focus:ring-2 focus:ring-[#163300] focus:bg-white transition-all ${isRTL ? 'text-right' : 'text-left'}`}
            style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
          >
            <option value="">{t.selectCity}</option>
            {citiesData[language].map((cityName) => (
              <option key={cityName} value={cityName}>{cityName}</option>
            ))}
          </select>
        </div>

        {/* Description */}
        <div>
          <label className={`block text-sm font-medium text-[#0e0f0c] mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
            {t.productDescription} <span className="text-[#cb272f]">*</span>
          </label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder={language === 'ar' ? 'اكتب وصفاً تفصيلياً للمنتج...' : 'Write a detailed description of the product...'}
            className={`w-full h-32 px-4 py-3 rounded-[10px] bg-[rgba(22,51,0,0.07843)] border border-transparent text-[#0e0f0c] placeholder:text-[#6a6c6a] focus:outline-none focus:ring-2 focus:ring-[#163300] focus:bg-white transition-all resize-none ${isRTL ? 'text-right' : 'text-left'}`}
            style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
          />
          <p className={`text-xs text-[#6a6c6a] mt-1 ${isRTL ? 'text-right' : 'text-left'}`}>
            {description.length}/500 {language === 'ar' ? 'حرف' : 'characters'}
          </p>
        </div>

        {/* Info Box */}
        <div className="bg-[#163300]/10 border border-[#163300]/30 rounded-[10px] p-4">
          <p className={`text-sm text-[#0e0f0c] font-medium mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
            💡 {language === 'ar' ? 'نصائح لبيع أسرع' : 'Tips for Faster Sale'}
          </p>
          <ul className={`text-xs text-[#6a6c6a] space-y-1 ${isRTL ? 'text-right' : 'text-left'}`}>
            <li>• {language === 'ar' ? 'استخدم صوراً واضحة وذات جودة عالية' : 'Use clear and high-quality images'}</li>
            <li>• {language === 'ar' ? 'اكتب وصفاً تفصيلياً ودقيقاً' : 'Write a detailed and accurate description'}</li>
            <li>• {language === 'ar' ? 'سعّر المنتج بشكل منافس' : 'Price the product competitively'}</li>
            <li>• {language === 'ar' ? 'رد على الرسائل بسرعة' : 'Respond to messages quickly'}</li>
          </ul>
        </div>
      </div>
      
      <motion.div
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        className="sticky bottom-0 bg-white border-t border-[rgba(14,15,12,0.12157)] p-6"
      >
        <WiseButton 
          onClick={handlePublish} 
          variant="primary" 
          fullWidth 
          size="lg" 
          loading={loading}
          disabled={!isFormValid}
        >
          {t.publishListing}
        </WiseButton>
      </motion.div>

      {/* Storage Error Modal */}
      {showStorageError && (
        <StorageSetupError 
          projectId={projectId}
          errorMessage={storageErrorMessage}
          onRetry={() => {
            setShowStorageError(false);
            setStorageErrorMessage('');
            handleAddImage();
          }}
          onShowFullGuide={() => {
            setShowStorageError(false);
            window.open('https://supabase.com/dashboard/project/' + projectId + '/storage/buckets', '_blank');
          }}
        />
      )}

      {/* Database Error Modal */}
      {showDatabaseError && (
        <DatabaseSetupError 
          tableName="products"
          projectId={projectId}
          errorMessage={databaseErrorMessage}
          onDismiss={() => {
            setShowDatabaseError(false);
            setDatabaseErrorMessage('');
          }}
        />
      )}
    </div>
  );
}