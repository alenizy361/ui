import { motion } from "motion/react";
import { WiseButton } from "../../components/WiseButton";
import { ChevronRight, AlertCircle } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { useLanguage } from "../../contexts/LanguageContext";

interface RabitAddAddressScreenProps {
  onBack: () => void;
  onSaveSuccess: () => void;
}

export function RabitAddAddressScreen({ onBack, onSaveSuccess }: RabitAddAddressScreenProps) {
  const { language, isRTL } = useLanguage();
  const [formData, setFormData] = useState({
    title: "",
    fullName: "",
    phone: "",
    city: "",
    district: "",
    street: "",
    building: "",
    additionalInfo: "",
  });
  const [isDefault, setIsDefault] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [showSuccess, setShowSuccess] = useState(false);

  const content = {
    ar: {
      addressTitleRequired: "عنوان العنوان مطلوب",
      fullNameRequired: "الاسم الكامل مطلوب",
      phoneRequired: "رقم الهاتف مطلوب",
      cityRequired: "المدينة مطلوبة",
      districtRequired: "الحي مطلوب",
      streetRequired: "اسم الشارع مطلوب",
      addressSavedSuccessfully: "تم حفظ العنوان بنجاح",
      savedSuccessfully: "تم الحفظ بنجاح",
      newDeliveryAddressAdded: "تمت إضافة عنوان توصيل جديد",
      addNewAddress: "إضافة عنوان جديد",
      addressTitle: "عنوان العنوان",
      titlePlaceholder: "مثال: المنزل، العمل، الشقة",
      fullName: "الاسم الكامل",
      fullNamePlaceholder: "أدخل الاسم الكامل",
      phone: "رقم الهاتف",
      city: "المدينة",
      selectCity: "اختر المدينة",
      district: "الحي",
      districtPlaceholder: "مثال: العليا، الملقا",
      street: "اسم الشارع",
      streetPlaceholder: "مثال: شارع الملك فهد",
      buildingNumber: "رقم المبنى",
      buildingPlaceholder: "مثال: مبنى 123",
      additionalInfo: "معلومات إضافية",
      additionalInfoPlaceholder: "مثال: بجوار محطة البنزين، الطابق الثاني",
      setAsDefault: "تعيين كعنوان افتراضي",
      saving: "جاري الحفظ...",
      saveAddress: "حفظ العنوان",
    },
    en: {
      addressTitleRequired: "Address title is required",
      fullNameRequired: "Full name is required",
      phoneRequired: "Phone number is required",
      cityRequired: "City is required",
      districtRequired: "District is required",
      streetRequired: "Street name is required",
      addressSavedSuccessfully: "Address saved successfully",
      savedSuccessfully: "Saved Successfully",
      newDeliveryAddressAdded: "New delivery address added",
      addNewAddress: "Add New Address",
      addressTitle: "Address Title",
      titlePlaceholder: "Example: Home, Work, Apartment",
      fullName: "Full Name",
      fullNamePlaceholder: "Enter full name",
      phone: "Phone Number",
      city: "City",
      selectCity: "Select city",
      district: "District",
      districtPlaceholder: "Example: Al Olaya, Al Malqa",
      street: "Street Name",
      streetPlaceholder: "Example: King Fahd Street",
      buildingNumber: "Building Number",
      buildingPlaceholder: "Example: Building 123",
      additionalInfo: "Additional Information",
      additionalInfoPlaceholder: "Example: Next to gas station, 2nd floor",
      setAsDefault: "Set as default address",
      saving: "Saving...",
      saveAddress: "Save Address",
    },
  };
  const c = content[language];

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.title.trim()) newErrors.title = c.addressTitleRequired;
    if (!formData.fullName.trim()) newErrors.fullName = c.fullNameRequired;
    if (!formData.phone.trim()) newErrors.phone = c.phoneRequired;
    if (!formData.city) newErrors.city = c.cityRequired;
    if (!formData.district.trim()) newErrors.district = c.districtRequired;
    if (!formData.street.trim()) newErrors.street = c.streetRequired;
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = () => {
    if (!validate()) return;
    
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setShowSuccess(true);
      toast.success(c.addressSavedSuccessfully + " 📍");
      setTimeout(() => {
        onSaveSuccess();
      }, 2000);
    }, 1500);
  };

  if (showSuccess) {
    return (
      <div 
        className="min-h-screen bg-white flex flex-col items-center justify-center p-6" 
        style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
        dir={isRTL ? 'rtl' : 'ltr'}
      >
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 200, damping: 15 }}
          className="w-24 h-24 bg-[#163300] rounded-full flex items-center justify-center mb-6"
        >
          <motion.svg
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="w-12 h-12 text-white"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
          >
            <motion.path
              d="M5 13l4 4L19 7"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </motion.svg>
        </motion.div>
        
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-2xl font-bold text-[#163300] mb-2 text-center"
        >
          {c.savedSuccessfully} ✓
        </motion.h2>
        
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="text-[#6a6c6a] text-center"
        >
          {c.newDeliveryAddressAdded}
        </motion.p>
      </div>
    );
  }

  const cities = [
    { ar: "الرياض", en: "Riyadh" },
    { ar: "جدة", en: "Jeddah" },
    { ar: "الدمام", en: "Dammam" },
    { ar: "مكة", en: "Makkah" },
    { ar: "المدينة", en: "Madinah" },
  ];

  return (
    <div 
      className="min-h-screen bg-white pb-32" 
      style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 flex items-center justify-between z-10"
      >
        <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
          <ChevronRight className="w-6 h-6 text-[#0e0f0c]" />
        </button>
        <h1 className="text-xl font-semibold text-[#0e0f0c]">{c.addNewAddress}</h1>
        <div className="w-10" />
      </motion.div>

      <div className="p-6 space-y-6">
        {/* Title */}
        <div>
          <label className={`block text-sm font-semibold text-[#0e0f0c] mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
            {c.addressTitle}
          </label>
          <input
            type="text"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            placeholder={c.titlePlaceholder}
            className={`w-full px-4 py-3 rounded-[10px] border border-[rgba(14,15,12,0.12157)] ${isRTL ? 'text-right' : 'text-left'} focus:outline-none focus:border-[#163300]`}
          />
          {errors.title && (
            <div className="flex items-center gap-2 mt-2 text-[#cb272f] text-sm">
              <AlertCircle className="w-4 h-4" />
              <span>{errors.title}</span>
            </div>
          )}
        </div>

        {/* Full Name */}
        <div>
          <label className={`block text-sm font-semibold text-[#0e0f0c] mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
            {c.fullName}
          </label>
          <input
            type="text"
            value={formData.fullName}
            onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
            placeholder={c.fullNamePlaceholder}
            className={`w-full px-4 py-3 rounded-[10px] border border-[rgba(14,15,12,0.12157)] ${isRTL ? 'text-right' : 'text-left'} focus:outline-none focus:border-[#163300]`}
          />
          {errors.fullName && (
            <div className="flex items-center gap-2 mt-2 text-[#cb272f] text-sm">
              <AlertCircle className="w-4 h-4" />
              <span>{errors.fullName}</span>
            </div>
          )}
        </div>

        {/* Phone */}
        <div>
          <label className={`block text-sm font-semibold text-[#0e0f0c] mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
            {c.phone}
          </label>
          <input
            type="tel"
            value={formData.phone}
            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
            placeholder="+966 5X XXX XXXX"
            className={`w-full px-4 py-3 rounded-[10px] border border-[rgba(14,15,12,0.12157)] ${isRTL ? 'text-right' : 'text-left'} focus:outline-none focus:border-[#163300]`}
          />
          {errors.phone && (
            <div className="flex items-center gap-2 mt-2 text-[#cb272f] text-sm">
              <AlertCircle className="w-4 h-4" />
              <span>{errors.phone}</span>
            </div>
          )}
        </div>

        {/* City */}
        <div>
          <label className={`block text-sm font-semibold text-[#0e0f0c] mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
            {c.city}
          </label>
          <select
            value={formData.city}
            onChange={(e) => setFormData({ ...formData, city: e.target.value })}
            className={`w-full px-4 py-3 rounded-[10px] border border-[rgba(14,15,12,0.12157)] ${isRTL ? 'text-right' : 'text-left'} focus:outline-none focus:border-[#163300] bg-white`}
          >
            <option value="">{c.selectCity}</option>
            {cities.map((city) => (
              <option key={city.ar} value={city.ar}>
                {language === 'ar' ? city.ar : city.en}
              </option>
            ))}
          </select>
          {errors.city && (
            <div className="flex items-center gap-2 mt-2 text-[#cb272f] text-sm">
              <AlertCircle className="w-4 h-4" />
              <span>{errors.city}</span>
            </div>
          )}
        </div>

        {/* District */}
        <div>
          <label className={`block text-sm font-semibold text-[#0e0f0c] mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
            {c.district}
          </label>
          <input
            type="text"
            value={formData.district}
            onChange={(e) => setFormData({ ...formData, district: e.target.value })}
            placeholder={c.districtPlaceholder}
            className={`w-full px-4 py-3 rounded-[10px] border border-[rgba(14,15,12,0.12157)] ${isRTL ? 'text-right' : 'text-left'} focus:outline-none focus:border-[#163300]`}
          />
          {errors.district && (
            <div className="flex items-center gap-2 mt-2 text-[#cb272f] text-sm">
              <AlertCircle className="w-4 h-4" />
              <span>{errors.district}</span>
            </div>
          )}
        </div>

        {/* Street */}
        <div>
          <label className={`block text-sm font-semibold text-[#0e0f0c] mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
            {c.street}
          </label>
          <input
            type="text"
            value={formData.street}
            onChange={(e) => setFormData({ ...formData, street: e.target.value })}
            placeholder={c.streetPlaceholder}
            className={`w-full px-4 py-3 rounded-[10px] border border-[rgba(14,15,12,0.12157)] ${isRTL ? 'text-right' : 'text-left'} focus:outline-none focus:border-[#163300]`}
          />
          {errors.street && (
            <div className="flex items-center gap-2 mt-2 text-[#cb272f] text-sm">
              <AlertCircle className="w-4 h-4" />
              <span>{errors.street}</span>
            </div>
          )}
        </div>

        {/* Building */}
        <div>
          <label className={`block text-sm font-semibold text-[#0e0f0c] mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
            {c.buildingNumber}
          </label>
          <input
            type="text"
            value={formData.building}
            onChange={(e) => setFormData({ ...formData, building: e.target.value })}
            placeholder={c.buildingPlaceholder}
            className={`w-full px-4 py-3 rounded-[10px] border border-[rgba(14,15,12,0.12157)] ${isRTL ? 'text-right' : 'text-left'} focus:outline-none focus:border-[#163300]`}
          />
        </div>

        {/* Additional Info */}
        <div>
          <label className={`block text-sm font-semibold text-[#0e0f0c] mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
            {c.additionalInfo}
          </label>
          <textarea
            value={formData.additionalInfo}
            onChange={(e) => setFormData({ ...formData, additionalInfo: e.target.value })}
            placeholder={c.additionalInfoPlaceholder}
            rows={3}
            className={`w-full px-4 py-3 rounded-[10px] border border-[rgba(14,15,12,0.12157)] ${isRTL ? 'text-right' : 'text-left'} focus:outline-none focus:border-[#163300] resize-none`}
          />
        </div>

        {/* Set as Default */}
        <button
          onClick={() => setIsDefault(!isDefault)}
          className="flex items-center gap-3 w-full"
        >
          <div
            className={`w-6 h-6 rounded border-2 flex items-center justify-center transition-colors ${
              isDefault
                ? "bg-[#163300] border-[#163300]"
                : "border-[rgba(14,15,12,0.12157)]"
            }`}
          >
            {isDefault && <span className="text-white text-sm">✓</span>}
          </div>
          <span className="text-sm text-[#0e0f0c]">{c.setAsDefault}</span>
        </button>
      </div>

      {/* Fixed Bottom Button */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-[rgba(14,15,12,0.12157)] px-6 py-4 max-w-[430px] mx-auto">
        <WiseButton
          onClick={handleSave}
          variant="primary"
          fullWidth
          loading={isLoading}
          disabled={isLoading}
        >
          {isLoading ? c.saving : c.saveAddress}
        </WiseButton>
      </div>
    </div>
  );
}
