import { motion } from "motion/react";
import { WiseButton } from "../../components/WiseButton";
import { Check, Package } from "lucide-react";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";

export function RabitOrderSuccessScreen({ orderNumber, onViewOrders, onContinueShopping }: { orderNumber: string; onViewOrders: () => void; onContinueShopping: () => void }) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);

  return (
    <div 
      className="min-h-screen bg-white flex flex-col items-center justify-center p-6" 
      style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", stiffness: 200, damping: 15 }} className="w-24 h-24 bg-[#163300] rounded-full flex items-center justify-center mb-8 relative">
        <Check className="w-12 h-12 text-[#9fe870]" strokeWidth={3} />
        <motion.div initial={{ scale: 1 }} animate={{ scale: 2, opacity: 0 }} transition={{ duration: 1, repeat: 2 }} className="absolute inset-0 bg-[#9fe870] rounded-full" />
      </motion.div>
      
      <h1 className="text-3xl font-bold mb-3 text-[#0e0f0c]">{t.orderSuccessTitle}</h1>
      <p className="text-[#6a6c6a] mb-2">{t.orderNumber}</p>
      <p className="text-xl font-bold text-[#163300] mb-8">{orderNumber}</p>
      
      <div className={`bg-[rgba(22,51,0,0.07843)] rounded-[10px] p-6 mb-8 border border-[rgba(14,15,12,0.12157)] w-full`}>
        <div className={`flex items-center gap-4 ${isRTL ? 'text-right' : 'text-left'}`}>
          <div className="flex-1">
            <h3 className="font-semibold text-[#0e0f0c] mb-1">{language === 'ar' ? 'الخطوات القادمة' : 'Next Steps'}</h3>
            <p className="text-sm text-[#6a6c6a]">{language === 'ar' ? 'سيقوم البائع بشحن المنتج خلال 2-3 أيام عمل' : 'Seller will ship the product within 2-3 business days'}</p>
          </div>
          <Package className="w-12 h-12 text-[#163300]" />
        </div>
      </div>
      
      <div className="w-full space-y-3">
        <WiseButton onClick={onViewOrders} variant="primary" fullWidth size="lg">
          {t.viewOrders}
        </WiseButton>
        <WiseButton onClick={onContinueShopping} variant="outline" fullWidth size="lg">
          {t.continueShopping}
        </WiseButton>
      </div>
    </div>
  );
}