import { motion } from "motion/react";
import { useEffect } from "react";
import { ShoppingBag, Store, Sparkles } from "lucide-react";
import { triggerHaptic } from "../../utils/haptics";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";

interface RabitSplashScreenProps {
  onComplete: () => void;
}

export function RabitSplashScreen({ onComplete }: RabitSplashScreenProps) {
  const { language } = useLanguage();
  const t = getTranslation(language);

  useEffect(() => {
    triggerHaptic('medium');
    setTimeout(() => triggerHaptic('light'), 1500);
    setTimeout(() => triggerHaptic('success'), 2800);
    
    const timer = setTimeout(onComplete, 3500);
    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.4 }}
      className="fixed inset-0 bg-white flex items-center justify-center overflow-hidden"
    >
      {/* Clean Decorative Circles */}
      <motion.div
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.03, 0.05, 0.03],
        }}
        transition={{
          duration: 4,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute top-0 right-0 w-[400px] h-[400px] bg-[#9fe870] rounded-full blur-[100px]"
      />
      <motion.div
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.03, 0.05, 0.03],
        }}
        transition={{
          duration: 4,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 2,
        }}
        className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-[#9fe870] rounded-full blur-[100px]"
      />

      {/* Main Content */}
      <div className="relative z-10 flex flex-col items-center gap-10 px-8">
        {/* Logo */}
        <motion.div
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{
            type: "spring",
            stiffness: 200,
            damping: 20,
            delay: 0.2,
          }}
        >
          <motion.div
            animate={{
              y: [0, -12, 0],
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            className="relative"
          >
            {/* Logo Container */}
            <div className="w-40 h-40 bg-white rounded-[32px] flex items-center justify-center shadow-[0_20px_60px_rgba(159,232,112,0.2)]">
              <img 
                src="https://rabit.sa/logo.svg" 
                alt="Rabit Logo" 
                className="w-32 h-32 object-contain"
              />
            </div>

            {/* Sparkle Accents */}
            <motion.div
              initial={{ scale: 0, rotate: 0 }}
              animate={{
                scale: [0, 1, 1, 0],
                rotate: [0, 0, 180, 180],
              }}
              transition={{
                duration: 2.5,
                repeat: Infinity,
                repeatDelay: 1,
                times: [0, 0.2, 0.8, 1],
              }}
              className="absolute -top-2 -right-2"
            >
              <Sparkles className="w-6 h-6 text-[#9fe870]" fill="#9fe870" />
            </motion.div>
            <motion.div
              initial={{ scale: 0, rotate: 0 }}
              animate={{
                scale: [0, 1, 1, 0],
                rotate: [0, 0, 180, 180],
              }}
              transition={{
                duration: 2.5,
                repeat: Infinity,
                repeatDelay: 1,
                delay: 1.2,
                times: [0, 0.2, 0.8, 1],
              }}
              className="absolute -bottom-2 -left-2"
            >
              <Sparkles className="w-6 h-6 text-[#9fe870]" fill="#9fe870" />
            </motion.div>
          </motion.div>
        </motion.div>

        {/* App Name */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9, duration: 0.6 }}
          className="text-center space-y-3"
        >
          <h1 
            className="text-6xl font-black text-[#163300]"
            style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
          >
            {t.platformName}
          </h1>
          <p 
            className="text-lg font-semibold text-[#163300]/70"
            style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
          >
            {t.splashTagline}
          </p>
        </motion.div>

        {/* Loading Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.4 }}
          className="flex flex-col items-center gap-3"
        >
          {/* Dots Loading */}
          <div className="flex items-center gap-2">
            {[0, 1, 2].map((i) => (
              <motion.div
                key={i}
                animate={{
                  scale: [1, 1.3, 1],
                  opacity: [0.4, 1, 0.4],
                }}
                transition={{
                  duration: 1.2,
                  repeat: Infinity,
                  delay: i * 0.2,
                }}
                className="w-2.5 h-2.5 bg-[#163300] rounded-full"
              />
            ))}
          </div>
          
          <motion.p
            animate={{
              opacity: [0.5, 1, 0.5],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
            }}
            className="text-sm font-medium text-[#163300]"
            style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
          >
            {t.splashLoading}
          </motion.p>
        </motion.div>
      </div>

      {/* Bottom Info */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.8 }}
        className="absolute bottom-8 text-center"
      >
        <p className="text-xs font-medium text-[#163300]/50" style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}>
          {t.splashVersion}
        </p>
      </motion.div>
    </motion.div>
  );
}