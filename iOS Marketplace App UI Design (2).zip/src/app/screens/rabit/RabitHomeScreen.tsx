import { motion } from "motion/react";
import { RabitBuyerHomeScreen } from "./RabitBuyerHomeScreen";
import { RabitSellerHomeScreen } from "./RabitSellerHomeScreen";
import { type RabitProduct } from "../../data/rabitProducts";
import { useLanguage } from "../../contexts/LanguageContext";
import React from "react";

interface RabitHomeScreenProps {
  userRole: "buyer" | "seller" | "both";
  onProductClick: (product: RabitProduct) => void;
  onSearchClick: () => void;
  onCategoryClick: () => void;
  onAddProductClick: () => void;
  onOrdersClick: () => void;
  onWalletClick: () => void;
  onSettingsClick: () => void;
  onNotificationsClick: () => void;
  onFavoritesClick?: () => void;
}

export function RabitHomeScreen({
  userRole,
  onProductClick,
  onSearchClick,
  onCategoryClick,
  onAddProductClick,
  onOrdersClick,
  onWalletClick,
  onSettingsClick,
  onNotificationsClick,
  onFavoritesClick,
}: RabitHomeScreenProps) {
  const { language } = useLanguage();

  // For "both" role, default to buyer view but allow switching
  const canSwitchToSeller = userRole === "both";
  const canSwitchToBuyer = userRole === "both";

  const [currentView, setCurrentView] = React.useState<"buyer" | "seller">(
    userRole === "seller" ? "seller" : "buyer"
  );

  if (userRole === "seller" || (userRole === "both" && currentView === "seller")) {
    return (
      <RabitSellerHomeScreen
        onAddProductClick={onAddProductClick}
        onProductClick={onProductClick}
        onOrdersClick={onOrdersClick}
        onWalletClick={onWalletClick}
        onSettingsClick={onSettingsClick}
        onNotificationsClick={onNotificationsClick}
        onCategoriesClick={onCategoryClick}
        onSwitchToBuyer={canSwitchToBuyer ? () => setCurrentView("buyer") : undefined}
        canSwitchToBuyer={canSwitchToBuyer}
      />
    );
  }

  return (
    <RabitBuyerHomeScreen
      onProductClick={onProductClick}
      onSearchClick={onSearchClick}
      onCategoryClick={onCategoryClick}
      onOrdersClick={onOrdersClick}
      onWalletClick={onWalletClick}
      onSettingsClick={onSettingsClick}
      onNotificationsClick={onNotificationsClick}
      onFavoritesClick={onFavoritesClick}
      onSwitchToSeller={canSwitchToSeller ? () => setCurrentView("seller") : undefined}
      canSwitchToSeller={canSwitchToSeller}
    />
  );
}