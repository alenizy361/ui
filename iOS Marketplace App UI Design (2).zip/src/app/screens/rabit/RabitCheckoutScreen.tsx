import { motion } from "motion/react";
import { WiseButton } from "../../components/WiseButton";
import { ChevronRight, MapPin, CreditCard, Package, Truck, Shield } from "lucide-react";
import { type RabitProduct } from "../../data/rabitProducts";
import { toast } from "sonner";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";
import { ordersAPI } from "../../utils/api";
import { useAuth } from "../../contexts/AuthContext";
import { useState } from "react";

export function RabitCheckoutScreen({ product, onBack, onContinueToPayment }: { product: RabitProduct; onBack: () => void; onContinueToPayment: () => void }) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  
  // Calculate fees
  const shipping = 15;
  const fee = 5.99;
  const total = product.price + shipping + fee;
  
  const handlePlaceOrder = async () => {
    if (!user) {
      console.error('❌ No user found');
      toast.error(language === 'ar' ? 'يرجى تسجيل الدخول أولاً' : 'Please log in first');
      return;
    }

    if (!user.accessToken) {
      console.error('❌ No access token found. User object:', {
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        role: user.role,
        hasAccessToken: !!user.accessToken
      });
      toast.error(
        language === 'ar' 
          ? '⚠️ جلسة غير صالحة. يرجى تسجيل الخروج ثم تسجيل الدخول مرة أخرى' 
          : '⚠️ Invalid session. Please log out and log in again',
        { duration: 5000 }
      );
      return;
    }

    console.log('🔑 Using access token:', user.accessToken.substring(0, 20) + '...');
    console.log('👤 User ID:', user.id);
    setLoading(true);
    
    try {
      // Create order via backend
      const response = await ordersAPI.createOrder({
        productId: product.id,
        quantity: 1,
        deliveryMethod: 'delivery',
        deliveryAddress: {
          fullName: language === 'ar' ? 'أحمد محمد' : 'Ahmed Mohammed',
          phone: '+966501234567',
          street: language === 'ar' ? 'شارع الملك فهد، حي النخيل' : 'King Fahd St, Al Nakheel',
          city: language === 'ar' ? 'الرياض' : 'Riyadh',
          district: language === 'ar' ? 'حي النخيل' : 'Al Nakheel',
        },
        paymentMethod: 'card',
        notes: ''
      }, user.accessToken);
      
      console.log('📦 Order response:', response);
      
      if (response.success && response.data) {
        console.log('✅ Order created successfully:', response.data);
        toast.success(language === 'ar' ? 'تم إنشاء الطلب بنجاح!' : 'Order created successfully!');
        onContinueToPayment();
      } else {
        console.error('❌ Order creation failed:', response.error);
        
        // Show helpful error message for auth issues
        if (response.error?.includes('JWT') || response.error?.includes('Unauthorized') || response.error?.includes('token')) {
          toast.error(
            language === 'ar' 
              ? '⚠️ جلسة منتهية. يرجى تسجيل الخروج ثم تسجيل الدخول مرة أخرى' 
              : '⚠️ Session expired. Please log out and log in again',
            { duration: 5000 }
          );
        } else {
          toast.error(response.error || (language === 'ar' ? 'فشل إنشاء الطلب' : 'Failed to create order'));
        }
      }
    } catch (error) {
      console.error('❌ Order creation error:', error);
      toast.error(language === 'ar' ? 'حدث خطأ أثناء إنشاء الطلب' : 'Error creating order');
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <div 
      className="min-h-screen bg-[#fafafa] flex flex-col" 
      style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }} 
        animate={{ opacity: 1, y: 0 }} 
        className="sticky top-0 bg-white border-b border-[rgba(0,0,0,0.08)] px-6 py-4 flex items-center gap-4 z-10"
        style={{ boxShadow: '0 1px 3px rgba(0, 0, 0, 0.04)' }}
      >
        <button 
          onClick={onBack} 
          className="w-10 h-10 rounded-full bg-[#f5f5f5] flex items-center justify-center hover:bg-[#ececec] transition-colors"
        >
          <ChevronRight className={`w-5 h-5 text-[#0a0b09] ${isRTL ? '' : 'rotate-180'}`} />
        </button>
        <h1 className="text-xl font-bold text-[#0a0b09]">{t.checkoutTitle}</h1>
      </motion.div>
      
      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto pb-32">
        <div className="px-6 py-6 space-y-4">
          
          {/* Product Card */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white rounded-2xl p-4 border border-[rgba(0,0,0,0.08)]"
            style={{ boxShadow: '0 1px 3px rgba(0, 0, 0, 0.06)' }}
          >
            <div className="flex items-start gap-4" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
              <div className="w-20 h-20 bg-[#fafafa] rounded-xl overflow-hidden flex-shrink-0">
                <img 
                  src={product.image} 
                  alt={language === 'ar' ? product.titleAr : product.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex-1 min-w-0" style={{ textAlign: isRTL ? 'right' : 'left' }}>
                <h3 className="text-base font-bold text-[#0a0b09] mb-1 truncate">
                  {language === 'ar' ? product.titleAr : product.title}
                </h3>
                <p className="text-sm text-[#6a6c6a] mb-2">
                  {language === 'ar' ? product.sellerAr : product.seller}
                </p>
                <div className="flex items-center gap-2" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                  <span className="text-xs px-2.5 py-1 bg-[#f0fde4] text-[#163300] rounded-lg font-semibold">
                    {language === 'ar' ? product.conditionAr : (product.condition === 'new' ? 'New' : 'Used')}
                  </span>
                  <span className="text-lg font-bold text-[#163300]">
                    {product.price} {language === 'ar' ? 'ر.س' : 'SAR'}
                  </span>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Delivery Address */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white rounded-2xl p-4 border border-[rgba(0,0,0,0.08)]"
            style={{ boxShadow: '0 1px 3px rgba(0, 0, 0, 0.06)' }}
          >
            <div className="flex items-center justify-between mb-3" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
              <div className="flex items-center gap-2.5" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                <div className="w-10 h-10 bg-[#163300] rounded-xl flex items-center justify-center">
                  <MapPin className="w-5 h-5 text-white" />
                </div>
                <h3 className="text-base font-bold text-[#0a0b09]">
                  {language === 'ar' ? 'عنوان التوصيل' : 'Delivery Address'}
                </h3>
              </div>
              <button className="text-sm text-[#163300] font-semibold hover:underline">
                {language === 'ar' ? 'تغيير' : 'Change'}
              </button>
            </div>
            <div className="p-3 bg-[#fafafa] rounded-xl" style={{ textAlign: isRTL ? 'right' : 'left' }}>
              <p className="text-sm font-semibold text-[#0a0b09] mb-1">
                {language === 'ar' ? 'أحمد محمد' : 'Ahmed Mohammed'}
              </p>
              <p className="text-sm text-[#6a6c6a] leading-relaxed">
                {language === 'ar' 
                  ? 'شارع الملك فهد، حي النخيل، الرياض 12345' 
                  : 'King Fahd St, Al Nakheel, Riyadh 12345'}
              </p>
              <p className="text-sm text-[#6a6c6a] mt-1">
                {language === 'ar' ? 'الهاتف: ' : 'Phone: '}+966 50 123 4567
              </p>
            </div>
          </motion.div>

          {/* Delivery Method */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-white rounded-2xl p-4 border border-[rgba(0,0,0,0.08)]"
            style={{ boxShadow: '0 1px 3px rgba(0, 0, 0, 0.06)' }}
          >
            <div className="flex items-center gap-2.5 mb-3" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
              <div className="w-10 h-10 bg-[#9fe870] rounded-xl flex items-center justify-center">
                <Truck className="w-5 h-5 text-[#163300]" />
              </div>
              <h3 className="text-base font-bold text-[#0a0b09]">
                {language === 'ar' ? 'طريقة التوصيل' : 'Delivery Method'}
              </h3>
            </div>
            <div className="p-3 bg-[#f0fde4] rounded-xl border-2 border-[#163300]" style={{ textAlign: isRTL ? 'right' : 'left' }}>
              <div className="flex items-center justify-between mb-1" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                <p className="text-sm font-bold text-[#0a0b09]">
                  {language === 'ar' ? 'توصيل سريع' : 'Express Delivery'}
                </p>
                <span className="text-sm font-bold text-[#163300]">
                  {shipping} {language === 'ar' ? 'ر.س' : 'SAR'}
                </span>
              </div>
              <p className="text-xs text-[#6a6c6a]">
                {language === 'ar' ? 'التوصيل خلال 2-3 أيام عمل' : 'Delivery within 2-3 business days'}
              </p>
            </div>
          </motion.div>

          {/* Payment Method */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-white rounded-2xl p-4 border border-[rgba(0,0,0,0.08)]"
            style={{ boxShadow: '0 1px 3px rgba(0, 0, 0, 0.06)' }}
          >
            <div className="flex items-center justify-between mb-3" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
              <div className="flex items-center gap-2.5" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                <div className="w-10 h-10 bg-[#163300] rounded-xl flex items-center justify-center">
                  <CreditCard className="w-5 h-5 text-white" />
                </div>
                <h3 className="text-base font-bold text-[#0a0b09]">
                  {language === 'ar' ? 'طريقة الدفع' : 'Payment Method'}
                </h3>
              </div>
              <button className="text-sm text-[#163300] font-semibold hover:underline">
                {language === 'ar' ? 'تغيير' : 'Change'}
              </button>
            </div>
            <div className="p-3 bg-[#fafafa] rounded-xl" style={{ textAlign: isRTL ? 'right' : 'left' }}>
              <div className="flex items-center gap-3" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                <div className="w-12 h-8 bg-gradient-to-r from-[#163300] to-[#9fe870] rounded-lg flex items-center justify-center">
                  <CreditCard className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-[#0a0b09]">
                    {language === 'ar' ? 'بطاقة الائتمان' : 'Credit Card'}
                  </p>
                  <p className="text-xs text-[#6a6c6a]">•••• •••• •••• 4567</p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Order Summary */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="bg-white rounded-2xl p-4 border border-[rgba(0,0,0,0.08)]"
            style={{ boxShadow: '0 1px 3px rgba(0, 0, 0, 0.06)' }}
          >
            <div className="flex items-center gap-2.5 mb-4" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
              <div className="w-10 h-10 bg-[#9fe870] rounded-xl flex items-center justify-center">
                <Package className="w-5 h-5 text-[#163300]" />
              </div>
              <h3 className="text-base font-bold text-[#0a0b09]">
                {language === 'ar' ? 'ملخص الطلب' : 'Order Summary'}
              </h3>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                <span className="text-sm text-[#6a6c6a]">{t.productPrice}</span>
                <span className="text-sm font-semibold text-[#0a0b09]">
                  {product.price} {language === 'ar' ? 'ر.س' : 'SAR'}
                </span>
              </div>
              
              <div className="flex items-center justify-between" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                <span className="text-sm text-[#6a6c6a]">{t.deliveryFee}</span>
                <span className="text-sm font-semibold text-[#0a0b09]">
                  {shipping} {language === 'ar' ? 'ر.س' : 'SAR'}
                </span>
              </div>
              
              <div className="flex items-center justify-between" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                <div className="flex items-center gap-1.5" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                  <span className="text-sm text-[#6a6c6a]">{t.platformFee}</span>
                  <Shield className="w-3.5 h-3.5 text-[#6a6c6a]" />
                </div>
                <span className="text-sm font-semibold text-[#0a0b09]">
                  {fee.toFixed(2)} {language === 'ar' ? 'ر.س' : 'SAR'}
                </span>
              </div>

              <div className="pt-3 mt-3 border-t-2 border-[rgba(0,0,0,0.08)]">
                <div className="flex items-center justify-between" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
                  <span className="text-base font-bold text-[#0a0b09]">{t.total}</span>
                  <span className="text-2xl font-bold text-[#163300]">
                    {total.toFixed(2)} {language === 'ar' ? 'ر.س' : 'SAR'}
                  </span>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Security Notice */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="flex items-start gap-3 p-4 bg-[#f0fde4] rounded-xl border border-[#9fe870]"
            style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}
          >
            <Shield className="w-5 h-5 text-[#163300] flex-shrink-0 mt-0.5" />
            <div style={{ textAlign: isRTL ? 'right' : 'left' }}>
              <p className="text-sm font-semibold text-[#163300] mb-1">
                {language === 'ar' ? 'الدفع الآمن' : 'Secure Payment'}
              </p>
              <p className="text-xs text-[#6a6c6a] leading-relaxed">
                {language === 'ar' 
                  ? 'معلوماتك محمية بتشفير من الدرجة المصرفية. الأموال محجوزة حتى تأكيد الاستلام.'
                  : 'Your information is protected with bank-grade encryption. Funds held until delivery confirmed.'}
              </p>
            </div>
          </motion.div>
        </div>
      </div>
      
      {/* Fixed Bottom Button */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
        className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-lg border-t border-[rgba(0,0,0,0.08)] p-6"
        style={{ boxShadow: '0 -4px 12px rgba(0, 0, 0, 0.06)' }}
      >
        <div className="max-w-[430px] mx-auto space-y-3">
          <div className="flex items-center justify-between mb-2" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
            <span className="text-sm text-[#6a6c6a]">{t.total}</span>
            <span className="text-xl font-bold text-[#163300]">
              {total.toFixed(2)} {language === 'ar' ? 'ر.س' : 'SAR'}
            </span>
          </div>
          <WiseButton onClick={handlePlaceOrder} variant="primary" fullWidth size="lg" loading={loading}>
            {t.proceedToPayment}
          </WiseButton>
        </div>
      </motion.div>
    </div>
  );
}