import { motion } from "motion/react";
import { WiseButton } from "../../components/WiseButton";
import { ShoppingBag, Store, Handshake, Check } from "lucide-react";
import { useState, useEffect } from "react";
import { storage } from "../../utils/storage";
import { triggerHaptic } from "../../utils/haptics";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";

interface RabitRoleSelectionScreenProps {
  onRoleSelect: (role: "buyer" | "seller" | "both") => void;
}

export function RabitRoleSelectionScreen({ onRoleSelect }: RabitRoleSelectionScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);
  const [selectedRole, setSelectedRole] = useState<"buyer" | "seller" | "both" | null>(() => {
    // Check if user already selected a role before
    return storage.getRoleSelection();
  });

  // If user already has a saved role, you could auto-navigate or just pre-select it
  useEffect(() => {
    const savedRole = storage.getRoleSelection();
    if (savedRole) {
      setSelectedRole(savedRole);
    }
  }, []);

  const handleRoleSelect = (role: "buyer" | "seller" | "both") => {
    triggerHaptic('selection');
    setSelectedRole(role);
  };

  const handleContinue = () => {
    if (selectedRole) {
      triggerHaptic('success');
      // Save role to localStorage
      storage.setRoleSelection(selectedRole);
      onRoleSelect(selectedRole);
    }
  };

  const roles = [
    {
      id: "buyer" as const,
      icon: ShoppingBag,
      titleAr: "مشتري",
      titleEn: "Buyer",
      descriptionAr: "أبحث عن منتجات للشراء",
      descriptionEn: "Looking to buy products",
      benefitsAr: [
        "تصفح آلاف المنتجات",
        "دفع آمن ومضمون",
        "تتبع الطلبات",
      ],
      benefitsEn: [
        "Browse thousands of products",
        "Secure payment",
        "Track orders",
      ],
    },
    {
      id: "seller" as const,
      icon: Store,
      titleAr: "بائع",
      titleEn: "Seller",
      descriptionAr: "أريد بيع منتجاتي",
      descriptionEn: "Want to sell my products",
      benefitsAr: [
        "عرض منتجاتك",
        "استلام المدفوعات بأمان",
        "إدارة الطلبات",
      ],
      benefitsEn: [
        "List your products",
        "Receive payments securely",
        "Manage orders",
      ],
    },
    {
      id: "both" as const,
      icon: Handshake,
      titleAr: "بائع ومشتري",
      titleEn: "Both",
      descriptionAr: "أريد البيع والشراء",
      descriptionEn: "Want to buy and sell",
      benefitsAr: [
        "كل مزايا البائع والمشتري",
        "محفظة موحدة",
        "تجربة شاملة",
      ],
      benefitsEn: [
        "All buyer & seller features",
        "Unified wallet",
        "Complete experience",
      ],
      recommended: true,
    },
  ];

  return (
    <div 
      className="min-h-screen bg-white flex flex-col p-6" 
      style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-8 mt-12"
      >
        <h1 className="text-3xl font-bold mb-3 text-[#0e0f0c]">{t.roleTitle}</h1>
        <p className="text-[#6a6c6a]">
          {t.roleSubtitle}
        </p>
      </motion.div>

      <div className="flex-1 space-y-4 mb-8">
        {roles.map((role, index) => (
          <motion.button
            key={role.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 + index * 0.1 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => handleRoleSelect(role.id)}
            className={`w-full bg-white rounded-[16px] p-6 ${isRTL ? 'text-right' : 'text-left'} transition-all relative overflow-hidden ${
              selectedRole === role.id
                ? "ring-2 ring-[#163300] shadow-lg"
                : "border border-[rgba(14,15,12,0.12157)] shadow-sm"
            }`}
          >
            {role.recommended && (
              <div className="absolute top-0 left-0 bg-[#9fe870] text-[#163300] text-xs font-semibold px-3 py-1 rounded-br-[10px]">
                {language === 'ar' ? 'موصى به' : 'Recommended'}
              </div>
            )}
            
            <div className="flex gap-4 items-start mb-4">
              <div className="flex-1">
                <h3 className="font-bold text-xl mb-2 text-[#0e0f0c]">{language === 'ar' ? role.titleAr : role.titleEn}</h3>
                <p className="text-sm text-[#6a6c6a] mb-4">{language === 'ar' ? role.descriptionAr : role.descriptionEn}</p>
                
                <div className="space-y-2">
                  {(language === 'ar' ? role.benefitsAr : role.benefitsEn).map((benefit, i) => (
                    <div key={i} className="flex items-center gap-2 justify-end">
                      <span className="text-sm text-[#454745]">{benefit}</span>
                      <Check className="w-4 h-4 text-[#163300]" />
                    </div>
                  ))}
                </div>
              </div>

              <div
                className={`w-16 h-16 rounded-[12px] flex items-center justify-center flex-shrink-0 transition-all ${
                  selectedRole === role.id
                    ? "bg-[#163300]"
                    : "bg-[rgba(22,51,0,0.07843)]"
                }`}
              >
                <role.icon
                  className={`w-8 h-8 ${
                    selectedRole === role.id ? "text-[#9fe870]" : "text-[#163300]"
                  }`}
                />
              </div>
            </div>
          </motion.button>
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <WiseButton
          onClick={handleContinue}
          variant="primary"
          fullWidth
          size="lg"
          disabled={!selectedRole}
        >
          {t.continue}
        </WiseButton>
        <p className="text-center text-xs text-[#6a6c6a] mt-3">
          {language === 'ar' ? 'يمكنك تغيير دورك لاحقاً من الإعدادات' : 'You can change your role later in Settings'}
        </p>
      </motion.div>
    </div>
  );
}