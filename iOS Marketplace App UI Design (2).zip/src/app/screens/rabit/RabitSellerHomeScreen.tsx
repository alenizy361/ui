import { motion } from "motion/react";
import { Package, Plus, Wallet, Settings, Bell, ShoppingBag, MessageCircle, TrendingUp, CheckCircle, CreditCard, Grid3x3, BarChart3, History, DollarSign } from "lucide-react";
import { useState, useEffect } from "react";
import { type RabitProduct } from "../../data/rabitProducts";
import { PullToRefresh } from "../../components/PullToRefresh";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";
import { getProducts } from "../../services/products.service";
import { useAuth } from "../../contexts/AuthContext";
import { toast } from "sonner";

interface RabitSellerHomeScreenProps {
  onAddProductClick: () => void;
  onProductClick: (product: RabitProduct) => void;
  onOrdersClick: () => void;
  onWalletClick: () => void;
  onSettingsClick: () => void;
  onNotificationsClick: () => void;
  onCategoriesClick?: () => void;
  onMessagesClick?: () => void;
  onAnalyticsClick?: () => void;
  onVerificationClick?: () => void;
  onWithdrawalHistoryClick?: () => void;
  onSwitchToBuyer?: () => void;
  canSwitchToBuyer?: boolean;
}

// Simple mock for unread counts
const useUnreadCounts = () => {
  return {
    notifications: 3,
    messages: 5,
  };
};

export function RabitSellerHomeScreen({
  onAddProductClick,
  onProductClick,
  onOrdersClick,
  onWalletClick,
  onSettingsClick,
  onNotificationsClick,
  onCategoriesClick,
  onMessagesClick,
  onAnalyticsClick,
  onVerificationClick,
  onWithdrawalHistoryClick,
  onSwitchToBuyer,
  canSwitchToBuyer,
}: RabitSellerHomeScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);
  const { user } = useAuth();
  const { notifications: unreadNotifications, messages: unreadMessages } = useUnreadCounts();
  const [activeTab, setActiveTab] = useState("home");
  const [myProducts, setMyProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Fetch seller products
  const fetchProducts = async () => {
    if (!user) {
      setLoading(false);
      return;
    }

    console.log('🔍 Fetching seller products...');
    setLoading(true);
    setError(null);

    try {
      const result = await getProducts();
      
      if (result.success && result.products) {
        console.log('✅ Fetched seller products:', result.products.length);
        setMyProducts(result.products);
      } else {
        console.error('❌ Failed to fetch products:', result.error);
        setError(result.error || 'Failed to fetch products');
        toast.error(language === 'ar' ? 'فشل تحميل المنتجات' : 'Failed to load products');
        setMyProducts([]);
      }
    } catch (err: any) {
      console.error('❌ Error fetching products:', err);
      setError(err.message || 'An error occurred');
      toast.error(language === 'ar' ? 'حدث خطأ أثناء تحميل المنتجات' : 'Error loading products');
      setMyProducts([]);
    } finally {
      setLoading(false);
    }
  };

  // Initial fetch
  useEffect(() => {
    fetchProducts();
  }, [user]);

  const handleRefresh = async () => {
    console.log("Refreshing seller home data...");
    await fetchProducts();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-[#008026] text-white";
      case "sold":
        return "bg-[#6a6c6a] text-white";
      case "draft":
        return "bg-[#df8700] text-white";
      default:
        return "bg-[rgba(22,51,0,0.07843)] text-[#0e0f0c]";
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "active":
        return t.statusActive;
      case "sold":
        return t.statusSold;
      case "draft":
        return t.statusDraft;
      default:
        return status;
    }
  };

  return (
    <PullToRefresh onRefresh={handleRefresh}>
      <div 
        className="min-h-screen bg-[#fafafa] pb-20" 
        style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
        dir={isRTL ? 'rtl' : 'ltr'}
      >
        {/* Header - Clean & Minimal */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white px-6 pt-12 pb-6 border-b border-[rgba(0,0,0,0.06)]"
        >
          {/* Top Bar */}
          <div className={`flex items-center justify-between mb-6 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
            <div className={`flex gap-2 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
              <button
                onClick={onNotificationsClick}
                className="w-10 h-10 rounded-xl bg-[#fafafa] flex items-center justify-center text-[#163300] relative transition-all duration-200 hover:bg-[#f0fde8] active:scale-95"
              >
                <Bell className="w-5 h-5" />
                <span className={`absolute -top-1 ${isRTL ? '-left-1' : '-right-1'} w-4 h-4 bg-[#ef4444] rounded-full text-white text-[9px] flex items-center justify-center font-bold`}>
                  {unreadNotifications}
                </span>
              </button>
              <button
                onClick={onSettingsClick}
                className="w-10 h-10 rounded-xl bg-[#fafafa] flex items-center justify-center text-[#163300] transition-all duration-200 hover:bg-[#f0fde8] active:scale-95"
              >
                <Settings className="w-5 h-5" />
              </button>
            </div>
            
            {/* Mode Switcher */}
            {canSwitchToBuyer && onSwitchToBuyer && (
              <motion.div
                whileTap={{ scale: 0.95 }}
                onClick={onSwitchToBuyer}
                className="flex items-center gap-2 bg-[#fafafa] rounded-2xl p-1.5 cursor-pointer transition-all duration-200 hover:bg-[#f0fde8]"
              >
                <div className={`text-[#6a6c6a] px-4 py-2 rounded-xl flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
                  <ShoppingBag className="w-4 h-4" />
                  <span className="text-sm font-medium">{t.buyer}</span>
                </div>
                <div className={`bg-[#163300] text-white px-4 py-2 rounded-xl flex items-center gap-2 shadow-sm ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
                  <Package className="w-4 h-4" />
                  <span className="text-sm font-semibold">{t.seller}</span>
                </div>
              </motion.div>
            )}
            
            {/* If can't switch, just show mode badge */}
            {!canSwitchToBuyer && (
              <div className={`bg-[#163300] text-white px-4 py-2 rounded-2xl flex items-center gap-2 shadow-sm ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
                <Package className="w-4 h-4" />
                <span className="text-sm font-semibold">{t.seller}</span>
              </div>
            )}
          </div>

          {/* Add Product Button */}
          <motion.button
            whileTap={{ scale: 0.98 }}
            onClick={onAddProductClick}
            className={`w-full h-12 bg-[#163300] rounded-2xl flex items-center justify-center gap-2 px-4 text-white font-semibold transition-all duration-200 hover:bg-[#0f2409] ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}
          >
            <Plus className="w-5 h-5" />
            <span className="text-sm">{t.addNewProduct}</span>
          </motion.button>
        </motion.div>

        {/* Stats Cards */}
        <div className="px-6 py-5 bg-white border-b border-[rgba(0,0,0,0.06)]">
          <div className="grid grid-cols-4 gap-2">
            <div className="text-center bg-[#fafafa] rounded-xl p-3">
              <div className="text-lg font-bold text-[#163300] mb-0.5">{myProducts.length}</div>
              <div className="text-[10px] text-[#6a6c6a]">{language === 'ar' ? 'منتجات' : 'Products'}</div>
            </div>
            <div className="text-center bg-[#fafafa] rounded-xl p-3">
              <div className="text-lg font-bold text-[#163300] mb-0.5">{myProducts.filter(p => p.status === "active").length}</div>
              <div className="text-[10px] text-[#6a6c6a]">{language === 'ar' ? 'نشطة' : 'Active'}</div>
            </div>
            <div className="text-center bg-[#fafafa] rounded-xl p-3">
              <div className="text-lg font-bold text-[#163300] mb-0.5">{myProducts.filter(p => p.status === "sold").length}</div>
              <div className="text-[10px] text-[#6a6c6a]">{language === 'ar' ? 'مباعة' : 'Sold'}</div>
            </div>
            <div className="text-center bg-[#fafafa] rounded-xl p-3">
              <div className="text-xs font-bold text-[#163300] mb-0.5">{myProducts.reduce((acc, p) => acc + p.price, 0).toLocaleString()}</div>
              <div className="text-[10px] text-[#6a6c6a]">{t.sar}</div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="px-6 py-5 bg-white border-b border-[rgba(0,0,0,0.06)]">
          <h2 className={`text-sm font-semibold text-[#6a6c6a] mb-3 ${isRTL ? 'text-right' : 'text-left'}`}>
            {t.quickActions}
          </h2>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={onAddProductClick}
              className={`h-11 bg-[#163300] rounded-xl font-medium text-white text-sm hover:bg-[#0f2409] transition-colors flex items-center justify-center gap-2 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}
            >
              <Plus className="w-4 h-4" />
              <span>{t.addProduct}</span>
            </button>
            <button
              onClick={onCategoriesClick}
              className={`h-11 bg-[#fafafa] border border-[rgba(0,0,0,0.08)] rounded-xl font-medium text-[#163300] text-sm hover:bg-[#f0fde8] transition-colors flex items-center justify-center gap-2 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}
            >
              <Grid3x3 className="w-4 h-4" />
              <span>{t.categories}</span>
            </button>
          </div>
        </div>

        {/* Seller Tools */}
        <div className="px-6 py-5 bg-white border-b border-[rgba(0,0,0,0.06)]">
          <h2 className={`text-sm font-semibold text-[#6a6c6a] mb-3 ${isRTL ? 'text-right' : 'text-left'}`}>
            {language === 'ar' ? 'أدوات البائع' : 'Seller Tools'}
          </h2>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={onAnalyticsClick}
              className={`h-11 bg-[#fafafa] border border-[rgba(0,0,0,0.08)] rounded-xl font-medium text-[#163300] text-sm hover:bg-[#f0fde8] transition-colors flex items-center justify-center gap-2 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}
            >
              <BarChart3 className="w-4 h-4" />
              <span>{language === 'ar' ? 'التحليلات' : 'Analytics'}</span>
            </button>
            <button
              onClick={onMessagesClick}
              className={`h-11 bg-[#fafafa] border border-[rgba(0,0,0,0.08)] rounded-xl font-medium text-[#163300] text-sm hover:bg-[#f0fde8] transition-colors flex items-center justify-center gap-2 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}
            >
              <MessageCircle className="w-4 h-4" />
              <span className={`text-sm font-medium ${unreadMessages > 0 ? 'text-[#ef4444]' : 'text-[#163300]'}`}>
                {t.messages}
                {unreadMessages > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#ef4444] rounded-full text-white text-[9px] flex items-center justify-center font-bold">
                    {unreadMessages}
                  </span>
                )}
              </span>
            </button>
            <button
              onClick={onVerificationClick}
              className={`h-11 bg-[#fafafa] border border-[rgba(0,0,0,0.08)] rounded-xl font-medium text-[#163300] text-sm hover:bg-[#f0fde8] transition-colors flex items-center justify-center gap-2 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}
            >
              <CheckCircle className="w-4 h-4" />
              <span>{language === 'ar' ? 'التحقق' : 'Verification'}</span>
            </button>
            <button
              onClick={onWithdrawalHistoryClick}
              className={`h-11 bg-[#fafafa] border border-[rgba(0,0,0,0.08)] rounded-xl font-medium text-[#163300] text-sm hover:bg-[#f0fde8] transition-colors flex items-center justify-center gap-2 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}
            >
              <History className="w-4 h-4" />
              <span>{language === 'ar' ? 'سحوبات' : 'Withdrawals'}</span>
            </button>
          </div>
        </div>

        {/* My Listings */}
        <div className="px-6 py-6">
          <div className={`flex items-center justify-between mb-4 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
            <h2 className={`text-lg font-bold text-[#0e0f0c] ${isRTL ? 'text-right' : 'text-left'}`}>
              {t.myProducts}
            </h2>
            <button className="text-sm text-[#163300] font-medium">{t.viewAll}</button>
          </div>

          <div className="space-y-3">
            {myProducts.map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                onClick={() => onProductClick(product)}
                whileTap={{ scale: 0.98 }}
                className="bg-white rounded-[12px] border border-[rgba(14,15,12,0.12157)] p-4 shadow-sm cursor-pointer hover:shadow-lg transition-all"
              >
                <div className={`flex gap-4 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
                  <div className="w-20 h-20 bg-[rgba(22,51,0,0.07843)] rounded-[8px] flex-shrink-0 overflow-hidden">
                    <img
                      src={product.images?.[0] || product.image || '/placeholder.png'}
                      alt={product.title || product.titleAr || ''}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                    <div className={`flex items-start justify-between mb-2 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
                      <div className={`flex-1 ${isRTL ? 'mr-2' : 'ml-2'}`}>
                        <p className="font-semibold text-[#0e0f0c] mb-1 text-sm">
                          {product.title || product.titleAr || product.titleEn || 'Untitled'}
                        </p>
                        <p className="text-lg font-bold text-[#163300]">{product.price} {t.sar}</p>
                      </div>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(product.status || 'active')}`}>
                        {getStatusText(product.status || 'active')}
                      </span>
                    </div>
                    <div className={`flex items-center gap-4 text-xs text-[#6a6c6a] ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
                      <span>👁 {product.views || 0} {language === 'ar' ? 'مشاهدة' : 'views'}</span>
                      <span>💬 {product.messages || 0} {language === 'ar' ? 'رسالة' : 'messages'}</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Floating Add Button */}
        <motion.button
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.5 }}
          whileTap={{ scale: 0.9 }}
          onClick={onAddProductClick}
          className={`fixed bottom-24 ${isRTL ? 'right-6' : 'left-6'} w-16 h-16 bg-[#163300] rounded-full flex items-center justify-center shadow-2xl`}
        >
          <Plus className="w-8 h-8 text-[#9fe870]" />
        </motion.button>

        {/* Bottom Navigation - Seller */}
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-[rgba(14,15,12,0.12157)] px-6 py-3 shadow-lg">
          <div className="flex justify-around items-center max-w-[430px] mx-auto">
            <button
              onClick={() => setActiveTab("home")}
              className={`flex flex-col items-center gap-1 transition-colors ${
                activeTab === "home" ? "text-[#163300]" : "text-[#6a6c6a]"
              }`}
            >
              <Package className="w-6 h-6" />
              <span className="text-xs font-medium">{t.myProducts}</span>
            </button>
            <button
              onClick={onOrdersClick}
              className={`flex flex-col items-center gap-1 transition-colors ${
                activeTab === "orders" ? "text-[#163300]" : "text-[#6a6c6a]"
              }`}
            >
              <ShoppingBag className="w-6 h-6" />
              <span className="text-xs font-medium">{t.sales}</span>
            </button>
            <button
              onClick={onWalletClick}
              className={`flex flex-col items-center gap-1 transition-colors ${
                activeTab === "wallet" ? "text-[#163300]" : "text-[#6a6c6a]"
              }`}
            >
              <DollarSign className="w-6 h-6" />
              <span className="text-xs font-medium">{t.revenue}</span>
            </button>
          </div>
        </div>
      </div>
    </PullToRefresh>
  );
}