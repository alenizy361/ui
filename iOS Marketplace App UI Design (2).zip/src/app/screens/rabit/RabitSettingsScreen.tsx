import { motion } from "motion/react";
import { ChevronRight, User, Shield, Bell, FileText, LogOut, ChevronLeft, MapPin, CreditCard, HelpCircle, Info, Globe, Moon, Volume2, Vibrate } from "lucide-react";
import { type UserProfile } from "../../App";
import { ModernButton } from "../../components/design-system";
import { useAppSettings, useSavedAddresses, useSavedPaymentMethods } from "../../hooks/useLocalStorage";
import { triggerHaptic } from "../../utils/haptics";
import { useState } from "react";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";

export function RabitSettingsScreen({ 
  userProfile, 
  onBack, 
  onSwitchRole,
  onEditProfile,
  onManageAddresses,
  onManagePaymentMethods,
  onNotificationSettings,
  onLogout,
  onTerms,
  onPrivacy,
  onHelp,
  onAbout,
}: { 
  userProfile: UserProfile | null; 
  onBack: () => void; 
  onSwitchRole: (role: "buyer" | "seller" | "both") => void;
  onEditProfile?: () => void;
  onManageAddresses?: () => void;
  onManagePaymentMethods?: () => void;
  onNotificationSettings?: () => void;
  onLogout?: () => void;
  onTerms?: () => void;
  onPrivacy?: () => void;
  onHelp?: () => void;
  onAbout?: () => void;
}) {
  const { language, setLanguage, isRTL } = useLanguage();
  const t = getTranslation(language);
  const { settings, updateSettings, toggleNotification } = useAppSettings();
  const { count: addressCount } = useSavedAddresses();
  const { count: paymentCount } = useSavedPaymentMethods();
  const [showNotifications, setShowNotifications] = useState(false);

  const handleToggleHaptics = () => {
    triggerHaptic('selection');
    updateSettings({ hapticFeedback: !settings.hapticFeedback });
  };

  const handleToggleSounds = () => {
    triggerHaptic('selection');
    updateSettings({ soundEffects: !settings.soundEffects });
  };

  const handleToggleAutoPlay = () => {
    triggerHaptic('selection');
    updateSettings({ autoPlayVideos: !settings.autoPlayVideos });
  };

  const handleNotificationToggle = (key: keyof typeof settings.notifications) => {
    triggerHaptic('selection');
    toggleNotification(key);
  };

  const handleLanguageChange = (lang: 'ar' | 'en') => {
    triggerHaptic('medium');
    setLanguage(lang);
  };

  const settingsItems = [
    { 
      icon: User, 
      titleAr: "تعديل الملف الشخصي", 
      titleEn: "Edit Profile",
      descAr: "إدارة معلوماتك الشخصية", 
      descEn: "Manage your personal information",
      onClick: onEditProfile 
    },
    { 
      icon: MapPin, 
      titleAr: "عناوين الشحن", 
      titleEn: "Shipping Addresses",
      descAr: addressCount > 0 ? `${addressCount} عنوان محفوظ` : "إدارة عناوينك", 
      descEn: addressCount > 0 ? `${addressCount} saved addresses` : "Manage your addresses",
      onClick: onManageAddresses 
    },
    { 
      icon: CreditCard, 
      titleAr: "طرق الدفع", 
      titleEn: "Payment Methods",
      descAr: paymentCount > 0 ? `${paymentCount} طريقة محفوظة` : "إدارة البطاقات", 
      descEn: paymentCount > 0 ? `${paymentCount} saved methods` : "Manage cards",
      onClick: onManagePaymentMethods 
    },
    { 
      icon: Shield, 
      titleAr: "الخصوصية والأمان", 
      titleEn: "Privacy & Security",
      descAr: "سياسة الخصوصية", 
      descEn: "Privacy policy",
      onClick: onPrivacy 
    },
    { 
      icon: Bell, 
      titleAr: "الإشعارات", 
      titleEn: "Notifications",
      descAr: "إدارة التنبيهات", 
      descEn: "Manage alerts",
      onClick: () => {
        triggerHaptic('selection');
        setShowNotifications(!showNotifications);
      }
    },
    { 
      icon: FileText, 
      titleAr: "الشروط والأحكام", 
      titleEn: "Terms & Conditions",
      descAr: "سياسة الاستخدام", 
      descEn: "Usage policy",
      onClick: onTerms 
    },
    { 
      icon: HelpCircle, 
      titleAr: "المساعدة والدعم", 
      titleEn: "Help & Support",
      descAr: "الأسئلة الشائعة", 
      descEn: "FAQ",
      onClick: onHelp 
    },
    { 
      icon: Info, 
      titleAr: "عن التطبيق", 
      titleEn: "About App",
      descAr: "معلومات التطبيق", 
      descEn: "App information",
      onClick: onAbout 
    },
  ];

  return (
    <div 
      className="min-h-screen bg-[#fafafa]" 
      style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Modern Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }} 
        animate={{ opacity: 1, y: 0 }} 
        className="sticky top-0 bg-white/95 backdrop-blur-lg border-b border-[rgba(0,0,0,0.06)] px-6 py-4 flex items-center gap-4 z-10"
        style={{ boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04)' }}
      >
        <button 
          onClick={onBack} 
          className="w-11 h-11 rounded-2xl bg-[#f0fde8] border border-[rgba(22,51,0,0.1)] flex items-center justify-center text-[#163300] transition-all duration-200 hover:bg-[#e2fad5] active:scale-95"
        >
          <ChevronRight className={`w-6 h-6 ${isRTL ? '' : 'rotate-180'}`} />
        </button>
        <h1 className={`text-xl font-semibold text-[#0a0b09] flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
          {t.settingsTitle}
        </h1>
      </motion.div>
      
      <div className="p-6">
        {/* Modern Profile Card */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-2xl p-6 mb-6 border border-[rgba(0,0,0,0.08)] text-center shadow-card"
        >
          <motion.div 
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
            className="w-24 h-24 bg-gradient-to-br from-[#163300] to-[#0f2409] rounded-2xl mx-auto mb-4 flex items-center justify-center text-white text-3xl font-bold shadow-md"
          >
            {userProfile?.name?.[0] || "A"}
          </motion.div>
          <motion.h2 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="text-xl font-bold text-[#0a0b09] mb-1"
          >
            {userProfile?.name || "المستخدم"}
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="text-sm text-[#6a6c6a] mb-4"
          >
            {userProfile?.email}
          </motion.p>
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5 }}
            className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-br from-[#163300] to-[#0f2409] text-white rounded-xl text-sm font-medium shadow-sm"
          >
            {userProfile?.verified && <span className="text-[#9fe870]">✓</span>}
            {userProfile?.role === "buyer" && (language === 'ar' ? 'مشتري' : 'Buyer')}
            {userProfile?.role === "seller" && (language === 'ar' ? 'بائع' : 'Seller')}
            {userProfile?.role === "both" && (language === 'ar' ? 'مشتري وبائع' : 'Buyer & Seller')}
          </motion.div>
        </motion.div>

        {/* App Preferences */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-2xl p-6 mb-6 border border-[rgba(0,0,0,0.08)] shadow-card"
        >
          <h3 className={`font-bold text-[#0a0b09] mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
            {t.preferences}
          </h3>
          
          {/* Language Selection - CHANGE LANGUAGE ONCE, REFLECTS EVERYWHERE */}
          <div className="mb-4 pb-4 border-b border-[rgba(0,0,0,0.06)]">
            <div className={`flex items-center gap-3 mb-3 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
              <Globe className="w-5 h-5 text-[#6a6c6a]" />
              <p className="font-medium text-[#0a0b09] text-sm flex-1">{t.language}</p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => handleLanguageChange('ar')}
                className={`flex-1 py-3 px-4 rounded-xl font-bold text-sm transition-all duration-300 ${
                  language === 'ar'
                    ? 'bg-gradient-to-br from-[#163300] to-[#0f2409] text-white shadow-lg scale-105'
                    : 'bg-[#f0fde8] text-[#163300] hover:bg-[#e2fad5]'
                }`}
              >
                🇸🇦 العربية
              </button>
              <button
                onClick={() => handleLanguageChange('en')}
                className={`flex-1 py-3 px-4 rounded-xl font-bold text-sm transition-all duration-300 ${
                  language === 'en'
                    ? 'bg-gradient-to-br from-[#163300] to-[#0f2409] text-white shadow-lg scale-105'
                    : 'bg-[#f0fde8] text-[#163300] hover:bg-[#e2fad5]'
                }`}
              >
                🇬🇧 English
              </button>
            </div>
            <p className="text-xs text-[#6a6c6a] mt-2 text-center">
              {language === 'ar' 
                ? '⚡ تغيير اللغة سينعكس على جميع الشاشات فوراً' 
                : '⚡ Language change reflects across all screens instantly'}
            </p>
          </div>
          
          {/* Haptic Feedback Toggle */}
          <button
            onClick={handleToggleHaptics}
            className="w-full flex items-center justify-between p-3 hover:bg-[#fafafa] rounded-xl transition-colors"
          >
            <div className={`w-12 h-7 rounded-full transition-colors ${settings.hapticFeedback ? 'bg-[#163300]' : 'bg-[#d1d5db]'} relative`}>
              <div className={`absolute top-1 ${settings.hapticFeedback ? (isRTL ? 'right-1' : 'left-1') : (isRTL ? 'left-1' : 'right-1')} w-5 h-5 bg-white rounded-full transition-all`} />
            </div>
            <div className={`flex-1 ${isRTL ? 'text-right mr-3' : 'text-left ml-3'}`}>
              <p className="font-medium text-[#0a0b09] text-sm">
                {language === 'ar' ? 'الاهتزاز اللمسي' : 'Haptic Feedback'}
              </p>
            </div>
            <Vibrate className="w-5 h-5 text-[#6a6c6a]" />
          </button>

          {/* Sound Effects Toggle */}
          <button
            onClick={handleToggleSounds}
            className="w-full flex items-center justify-between p-3 hover:bg-[#fafafa] rounded-xl transition-colors"
          >
            <div className={`w-12 h-7 rounded-full transition-colors ${settings.soundEffects ? 'bg-[#163300]' : 'bg-[#d1d5db]'} relative`}>
              <div className={`absolute top-1 ${settings.soundEffects ? (isRTL ? 'right-1' : 'left-1') : (isRTL ? 'left-1' : 'right-1')} w-5 h-5 bg-white rounded-full transition-all`} />
            </div>
            <div className={`flex-1 ${isRTL ? 'text-right mr-3' : 'text-left ml-3'}`}>
              <p className="font-medium text-[#0a0b09] text-sm">
                {language === 'ar' ? 'المؤثرات الصوتية' : 'Sound Effects'}
              </p>
            </div>
            <Volume2 className="w-5 h-5 text-[#6a6c6a]" />
          </button>

          {/* Auto-play Videos Toggle */}
          <button
            onClick={handleToggleAutoPlay}
            className="w-full flex items-center justify-between p-3 hover:bg-[#fafafa] rounded-xl transition-colors"
          >
            <div className={`w-12 h-7 rounded-full transition-colors ${settings.autoPlayVideos ? 'bg-[#163300]' : 'bg-[#d1d5db]'} relative`}>
              <div className={`absolute top-1 ${settings.autoPlayVideos ? (isRTL ? 'right-1' : 'left-1') : (isRTL ? 'left-1' : 'right-1')} w-5 h-5 bg-white rounded-full transition-all`} />
            </div>
            <div className={`flex-1 ${isRTL ? 'text-right mr-3' : 'text-left ml-3'}`}>
              <p className="font-medium text-[#0a0b09] text-sm">
                {language === 'ar' ? 'تشغيل الفيديو تلقائياً' : 'Auto-play Videos'}
              </p>
            </div>
          </button>
        </motion.div>

        {/* Notification Preferences (Expandable) */}
        {showNotifications && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-white rounded-2xl p-6 mb-6 border border-[rgba(0,0,0,0.08)] shadow-card overflow-hidden"
          >
            <h3 className={`font-bold text-[#0a0b09] mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
              {language === 'ar' ? 'إعدادات الإشعارات' : 'Notification Settings'}
            </h3>
            
            {[
              { key: 'orders' as const, labelAr: 'إشعارات الطلبات', labelEn: 'Order Notifications' },
              { key: 'messages' as const, labelAr: 'إشعارات الرسائل', labelEn: 'Message Notifications' },
              { key: 'offers' as const, labelAr: 'إشعارات العروض', labelEn: 'Offer Notifications' },
              { key: 'marketing' as const, labelAr: 'إشعارات التسويق', labelEn: 'Marketing Notifications' },
            ].map(({ key, labelAr, labelEn }) => (
              <button
                key={key}
                onClick={() => handleNotificationToggle(key)}
                className="w-full flex items-center justify-between p-3 hover:bg-[#fafafa] rounded-xl transition-colors"
                style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}
              >
                <div className={`w-12 h-7 rounded-full transition-colors ${settings.notifications[key] ? 'bg-[#163300]' : 'bg-[#d1d5db]'} relative`}>
                  <div className={`absolute top-1 ${settings.notifications[key] ? (isRTL ? 'right-1' : 'left-1') : (isRTL ? 'left-1' : 'right-1')} w-5 h-5 bg-white rounded-full transition-all`} />
                </div>
                <div className={`flex-1 ${isRTL ? 'text-right mr-3' : 'text-left ml-3'}`}>
                  <p className="font-medium text-[#0a0b09] text-sm">
                    {language === 'ar' ? labelAr : labelEn}
                  </p>
                </div>
              </button>
            ))}
          </motion.div>
        )}
        
        {/* Modern Settings List */}
        <div className="space-y-3 mb-6">
          {settingsItems.map((setting, i) => (
            <motion.button
              key={i}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 * i + 0.2 }}
              whileTap={{ scale: 0.98 }}
              className="w-full flex items-center gap-4 p-4 bg-white rounded-2xl border border-[rgba(0,0,0,0.08)] text-right transition-all duration-200 shadow-card hover:shadow-card-hover"
              onClick={setting.onClick}
              disabled={!setting.onClick}
            >
              <ChevronLeft className="w-5 h-5 text-[#6a6c6a]" />
              <div className="flex-1 text-right">
                <p className="font-semibold text-[#0a0b09]">{language === 'ar' ? setting.titleAr : setting.titleEn}</p>
                <p className="text-sm text-[#6a6c6a]">{language === 'ar' ? setting.descAr : setting.descEn}</p>
              </div>
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-[#f0fde8] to-[#e2fad5] flex items-center justify-center">
                <setting.icon className="w-6 h-6 text-[#163300]" />
              </div>
            </motion.button>
          ))}
        </div>
        
        {/* Modern Logout Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
        >
          <ModernButton
            onClick={onLogout}
            variant="danger"
            fullWidth
            size="lg"
          >
            <div className="flex items-center justify-center gap-2">
              <LogOut className="w-5 h-5" />
              <span>{t.logout}</span>
            </div>
          </ModernButton>
        </motion.div>
      </div>
    </div>
  );
}