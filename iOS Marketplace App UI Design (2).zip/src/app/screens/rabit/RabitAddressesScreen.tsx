import { motion } from "motion/react";
import { ChevronRight, Plus, MapPin, Edit, Trash2, Check } from "lucide-react";
import { useState } from "react";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";

interface Address {
  id: string;
  name: string;
  phone: string;
  street: string;
  city: string;
  region: string;
  zipCode: string;
  isDefault: boolean;
}

interface RabitAddressesScreenProps {
  onBack: () => void;
  onAddAddress: () => void;
  onEditAddress: (address: Address) => void;
}

export function RabitAddressesScreen({ onBack, onAddAddress, onEditAddress }: RabitAddressesScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);
  const [addresses, setAddresses] = useState<Address[]>([
    {
      id: "1",
      name: "أحمد الراشد",
      phone: "+966501234567",
      street: "شارع الملك فهد",
      city: "الرياض",
      region: "العليا",
      zipCode: "12345",
      isDefault: true,
    },
    {
      id: "2",
      name: "أحمد الراشد",
      phone: "+966501234567",
      street: "طريق الملك عبدالعزيز",
      city: "الرياض",
      region: "الملقا",
      zipCode: "67890",
      isDefault: false,
    },
  ]);

  const [deleteDialog, setDeleteDialog] = useState<{ isOpen: boolean; addressId: string | null }>({
    isOpen: false,
    addressId: null,
  });

  const setDefaultAddress = (addressId: string) => {
    setAddresses(addresses.map(addr => ({
      ...addr,
      isDefault: addr.id === addressId,
    })));
  };

  const handleDelete = () => {
    if (deleteDialog.addressId) {
      setAddresses(addresses.filter(addr => addr.id !== deleteDialog.addressId));
      setDeleteDialog({ isOpen: false, addressId: null });
    }
  };

  return (
    <div className="min-h-screen bg-white pb-32" style={{ fontFamily: 'Cairo, sans-serif' }}>
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 flex items-center justify-between z-10"
      >
        <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
          <ChevronRight className="w-6 h-6 text-[#0e0f0c]" />
        </button>
        <h1 className="text-xl font-semibold text-[#0e0f0c]">عناوين الشحن</h1>
        <div className="w-10" />
      </motion.div>

      <div className="p-6 space-y-4">
        {/* Add New Address Button */}
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          whileTap={{ scale: 0.98 }}
          onClick={onAddAddress}
          className="w-full py-4 px-4 bg-[#163300] text-white rounded-[10px] font-medium flex items-center justify-center gap-2"
        >
          <Plus className="w-5 h-5" />
          <span>إضافة عنوان جديد</span>
        </motion.button>

        {/* Addresses List */}
        {addresses.map((address, index) => (
          <motion.div
            key={address.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className={`bg-white rounded-[12px] border-2 p-4 ${
              address.isDefault
                ? "border-[#163300] bg-[rgba(22,51,0,0.05)]"
                : "border-[rgba(14,15,12,0.12157)]"
            }`}
          >
            {/* Header */}
            <div className="flex items-start justify-between mb-3">
              <div className="flex gap-2">
                <button
                  onClick={() => setDeleteDialog({ isOpen: true, addressId: address.id })}
                  className="w-8 h-8 rounded-full bg-[rgba(203,39,47,0.1)] flex items-center justify-center"
                >
                  <Trash2 className="w-4 h-4 text-[#cb272f]" />
                </button>
                <button
                  onClick={() => onEditAddress(address)}
                  className="w-8 h-8 rounded-full bg-[rgba(22,51,0,0.1)] flex items-center justify-center"
                >
                  <Edit className="w-4 h-4 text-[#163300]" />
                </button>
              </div>
              <div className="text-right flex-1">
                <div className="flex items-center gap-2 justify-end mb-1">
                  <h3 className="font-bold text-[#0e0f0c]">{address.name}</h3>
                  <MapPin className="w-5 h-5 text-[#163300]" />
                </div>
                {address.isDefault && (
                  <span className="inline-flex items-center gap-1 px-2 py-1 bg-[#163300] text-white text-xs rounded-full">
                    <Check className="w-3 h-3" />
                    <span>العنوان الافتراضي</span>
                  </span>
                )}
              </div>
            </div>

            {/* Address Details */}
            <div className="space-y-2 text-right mb-4">
              <p className="text-sm text-[#0e0f0c]">{address.name}</p>
              <p className="text-sm text-[#6a6c6a] text-right" dir="ltr">{address.phone}</p>
              <p className="text-sm text-[#6a6c6a]">
                {address.city} - {address.region}
              </p>
              <p className="text-sm text-[#6a6c6a]">
                {address.street}، {address.zipCode}
              </p>
            </div>

            {/* Set as Default */}
            {!address.isDefault && (
              <button
                onClick={() => setDefaultAddress(address.id)}
                className="w-full py-2 px-4 bg-[rgba(22,51,0,0.07843)] rounded-[8px] text-sm font-medium text-[#163300] hover:bg-[rgba(22,51,0,0.12)] transition-colors"
              >
                تعيين كعنوان افتراضي
              </button>
            )}
          </motion.div>
        ))}
      </div>

      {/* Delete Confirmation */}
      {deleteDialog.isOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-6">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-[16px] p-6 max-w-sm w-full"
            style={{ fontFamily: 'Cairo, sans-serif' }}
          >
            <h3 className="text-xl font-bold text-[#0e0f0c] mb-3 text-right">حذف العنوان</h3>
            <p className="text-sm text-[#6a6c6a] mb-6 text-right leading-relaxed">
              هل أنت متأكد من حذف هذا العنوان؟ لا يمكن التراجع عن هذا الإجراء.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setDeleteDialog({ isOpen: false, addressId: null })}
                className="flex-1 py-3 px-4 bg-[rgba(22,51,0,0.07843)] text-[#163300] rounded-[10px] font-medium"
              >
                إلغاء
              </button>
              <button
                onClick={handleDelete}
                className="flex-1 py-3 px-4 bg-[#cb272f] text-white rounded-[10px] font-medium"
              >
                حذف
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}