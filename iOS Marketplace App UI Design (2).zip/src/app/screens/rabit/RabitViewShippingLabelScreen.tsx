import { motion } from "motion/react";
import { ChevronLeft, Download, Printer, Package, MapPin, Truck, QrCode, ArrowRight } from "lucide-react";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";

interface ViewShippingLabelScreenProps {
  orderNumber: string;
  trackingNumber: string;
  productTitle: string;
  productTitleAr: string;
  shippingAddress: {
    name: string;
    phone: string;
    city: string;
    district: string;
    street: string;
    building: string;
  };
  issuedDate: string;
  onBack: () => void;
  onDownloadLabel: () => void;
}

export function RabitViewShippingLabelScreen({
  orderNumber,
  trackingNumber,
  productTitle,
  productTitleAr,
  shippingAddress,
  issuedDate,
  onBack,
  onDownloadLabel,
}: ViewShippingLabelScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);

  return (
    <div
      className="min-h-screen bg-[#f8f9fa]"
      style={{ fontFamily: language === "ar" ? "Cairo, sans-serif" : "SF Pro Display, sans-serif" }}
    >
      {/* Header */}
      <div className="bg-white border-b border-[#e8e9ea] sticky top-0 z-50">
        <div className="px-4 py-4 flex items-center gap-4">
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-[#f8f9fa] flex items-center justify-center active:scale-95 transition-transform"
          >
            <ChevronLeft className={`w-5 h-5 text-[#0e0f0c] ${isRTL ? "rotate-180" : ""}`} />
          </button>
          <div className="flex-1">
            <h1 className="font-bold text-[#0e0f0c]">
              {language === "ar" ? "بوليصة الشحن" : "Shipping Label"}
            </h1>
            <p className="text-sm text-[#6a6c6a]">{orderNumber}</p>
          </div>
        </div>
      </div>

      <div className="px-4 py-6 space-y-4 pb-32">
        {/* Status Banner */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-gradient-to-br from-[#163300] to-[#1e4500] rounded-[20px] p-5 text-white"
        >
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center">
              <Package className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <p className="text-sm opacity-80 mb-1">
                {language === "ar" ? "حالة البوليصة" : "Label Status"}
              </p>
              <p className="font-bold text-lg">
                {language === "ar" ? "✅ نشطة ومدفوعة" : "✅ Active & Paid"}
              </p>
            </div>
          </div>
          <div className="text-sm opacity-80 pt-3 border-t border-white/20">
            {language === "ar" ? "تم الإصدار: " : "Issued: "}{issuedDate}
          </div>
        </motion.div>

        {/* Label Preview Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-[20px] p-6 border-2 border-dashed border-[#e8e9ea]"
        >
          {/* Tracking Number with QR */}
          <div className="flex items-start gap-4 mb-6 pb-6 border-b border-[#e8e9ea]">
            <div className="flex-1">
              <p className="text-sm text-[#6a6c6a] mb-2">
                {language === "ar" ? "رقم التتبع" : "Tracking Number"}
              </p>
              <p className="text-2xl font-bold text-[#163300] font-mono tracking-wider mb-2">
                {trackingNumber}
              </p>
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-[#9fe870]" />
                <span className="text-sm text-[#6a6c6a]">
                  {language === "ar" ? "شحن سريع - يوم واحد" : "Express Shipping - 1 Day"}
                </span>
              </div>
            </div>
            <div className="w-20 h-20 bg-[#f8f9fa] rounded-xl flex items-center justify-center border border-[#e8e9ea]">
              <QrCode className="w-16 h-16 text-[#163300]" />
            </div>
          </div>

          {/* Product Info */}
          <div className="mb-6 pb-6 border-b border-[#e8e9ea]">
            <p className="text-sm text-[#6a6c6a] mb-2">
              {language === "ar" ? "المنتج" : "Product"}
            </p>
            <p className="font-semibold text-[#0e0f0c]">
              {language === "ar" ? productTitleAr : productTitle}
            </p>
          </div>

          {/* Shipping Address */}
          <div className="mb-6 pb-6 border-b border-[#e8e9ea]">
            <div className="flex items-start gap-3">
              <MapPin className="w-5 h-5 text-[#6a6c6a] mt-1 flex-shrink-0" />
              <div className="flex-1">
                <p className="text-sm text-[#6a6c6a] mb-2">
                  {language === "ar" ? "عنوان التوصيل" : "Delivery Address"}
                </p>
                <p className="text-[#0e0f0c] font-semibold mb-2">{shippingAddress.name}</p>
                <p className="text-[#0e0f0c] mb-1">{shippingAddress.phone}</p>
                <p className="text-sm text-[#6a6c6a] leading-relaxed">
                  {shippingAddress.city}, {shippingAddress.district}
                  <br />
                  {shippingAddress.street}
                  <br />
                  {shippingAddress.building}
                </p>
              </div>
            </div>
          </div>

          {/* Barcode */}
          <div className="bg-[#f8f9fa] rounded-xl p-4 flex flex-col items-center">
            <div className="w-full h-16 bg-white rounded-lg flex items-center justify-center mb-2 border border-[#e8e9ea]">
              <div className="flex gap-[2px]">
                {[...Array(40)].map((_, i) => (
                  <div
                    key={i}
                    className="w-[3px] bg-[#0e0f0c] rounded-sm"
                    style={{ height: `${Math.random() * 20 + 30}px` }}
                  />
                ))}
              </div>
            </div>
            <p className="text-xs text-[#6a6c6a] font-mono">{trackingNumber}</p>
          </div>
        </motion.div>

        {/* Instructions */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="bg-[#9fe870]/10 rounded-[16px] p-4 border border-[#9fe870]/20"
        >
          <p className="font-semibold text-[#163300] mb-3">
            {language === "ar" ? "📦 تعليمات الطباعة" : "📦 Printing Instructions"}
          </p>
          <ul className="space-y-2 text-sm text-[#163300]">
            <li className="flex gap-2">
              <span>•</span>
              <span>
                {language === "ar"
                  ? "اطبع البوليصة على ورق A4 عادي"
                  : "Print the label on regular A4 paper"}
              </span>
            </li>
            <li className="flex gap-2">
              <span>•</span>
              <span>
                {language === "ar"
                  ? "الصق البوليصة على الطرد بشكل واضح"
                  : "Attach the label clearly on the package"}
              </span>
            </li>
            <li className="flex gap-2">
              <span>•</span>
              <span>
                {language === "ar"
                  ? "تأكد من وضوح رقم التتبع والباركود"
                  : "Ensure tracking number and barcode are clear"}
              </span>
            </li>
          </ul>
        </motion.div>

        {/* Info Box */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="bg-blue-50 rounded-[16px] p-4 border border-blue-100"
        >
          <p className="text-sm text-blue-900 text-center">
            {language === "ar"
              ? "💡 يمكنك إعادة طباعة البوليصة في أي وقت دون رسوم إضافية"
              : "💡 You can reprint this label anytime without additional charges"}
          </p>
        </motion.div>
      </div>

      {/* Fixed Bottom Buttons */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-[#e8e9ea] px-4 py-4 safe-area-bottom space-y-3">
        {/* Download Button */}
        <motion.button
          whileTap={{ scale: 0.98 }}
          onClick={onDownloadLabel}
          className="w-full bg-[#163300] text-white rounded-full py-4 px-6 font-semibold flex items-center justify-center gap-2 shadow-lg"
        >
          <Download className="w-5 h-5" />
          <span>{language === "ar" ? "تحميل PDF" : "Download PDF"}</span>
        </motion.button>

        {/* Print Button */}
        <motion.button
          whileTap={{ scale: 0.98 }}
          onClick={() => window.print()}
          className="w-full bg-white text-[#163300] border-2 border-[#163300] rounded-full py-4 px-6 font-semibold flex items-center justify-center gap-2"
        >
          <Printer className="w-5 h-5" />
          <span>{language === "ar" ? "طباعة" : "Print"}</span>
        </motion.button>
      </div>
    </div>
  );
}
