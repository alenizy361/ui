import { motion } from "motion/react";
import { WiseButton } from "../../components/WiseButton";
import { ChevronRight, MessageCircle, Share2, Heart, Flag, ShoppingCart } from "lucide-react";
import { type RabitProduct } from "../../data/rabitProducts";
import { useState, useEffect } from "react";
import { ModernButton, GlassPanel } from "../../components/design-system";
import { ProductDetailSkeleton } from "../../components/Skeleton";
import { storage } from "../../utils/storage";
import { triggerHaptic } from "../../utils/haptics";
import { useCart, useFavorites } from "../../hooks/useLocalStorage";
import { ImageZoomModal } from "../../components/ImageZoomModal";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";

interface RabitProductDetailScreenProps {
  product: RabitProduct;
  onBack: () => void;
  onBuyNow: () => void;
  onChatWithSeller: () => void;
  onSellerClick: () => void;
  onShare?: () => void;
  onReport?: () => void;
  onToggleFavorite?: () => void;
}

export function RabitProductDetailScreen({ 
  product, 
  onBack, 
  onBuyNow, 
  onChatWithSeller, 
  onSellerClick,
  onShare,
  onReport,
  onToggleFavorite,
}: RabitProductDetailScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);
  const [loading, setLoading] = useState(true);
  const [isZoomModalOpen, setIsZoomModalOpen] = useState(false);
  const { addToCart, cart } = useCart();
  const { isFavorite, toggleFavorite } = useFavorites();
  
  const isProductFavorite = isFavorite(product.id);
  const isInCart = cart.some(item => item.productId === product.id);

  // Handle both mock data (image) and database data (images array)
  const productImages = product.images || (product.image ? [product.image] : []);
  const mainImage = productImages[0] || product.image || '';

  // Safe fallbacks for potentially missing fields
  const sellerName = product.seller || 'Unknown Seller';
  const sellerNameAr = product.sellerAr || 'بائع غير معروف';
  const categoryName = product.category || 'Uncategorized';
  const categoryNameAr = product.categoryAr || 'غير مصنف';
  const cityName = product.city || 'Saudi Arabia';
  const cityNameAr = product.cityAr || 'السعودية';
  const productRating = product.rating || 5.0;
  const productDescription = product.description || 'No description available';
  const productDescriptionAr = product.descriptionAr || 'لا يوجد وصف متاح';

  useEffect(() => {
    // Add to recently viewed when product is loaded
    storage.addRecentlyViewed({
      id: product.id,
      title: product.title,
      titleAr: product.titleAr,
      price: product.price,
      image: mainImage,
    });

    // Simulate loading delay
    const timer = setTimeout(() => {
      setLoading(false);
    }, 1000);
    return () => clearTimeout(timer);
  }, [product]);

  const handleShare = () => {
    if (onShare) {
      onShare();
    } else {
      // Fallback: Native share with error handling
      if (navigator.share) {
        navigator.share({
          title: product.nameAr,
          text: `${product.nameAr} - ${product.price} ر.س`,
          url: window.location.href,
        }).catch((error) => {
          // Silently handle share cancel or permission denied
          console.log('Share cancelled or not permitted');
        });
      } else {
        // Fallback: Copy to clipboard
        const shareText = `${product.titleAr} - ${product.price} ر.س\n${window.location.href}`;
        navigator.clipboard?.writeText(shareText).then(() => {
          alert('تم نسخ رابط المنتج');
        }).catch(() => {
          // Final fallback if clipboard also fails
          alert('لا يمكن المشاركة في هذا المتصفح');
        });
      }
    }
  };

  const handleFavorite = () => {
    triggerHaptic('selection');
    toggleFavorite(product.id);
    onToggleFavorite?.();
  };

  const handleAddToCart = () => {
    triggerHaptic('success');
    addToCart({
      productId: product.id,
      title: product.title,
      titleAr: product.titleAr,
      price: product.price,
      quantity: 1,
      image: mainImage,
      sellerId: product.sellerId,
      seller: product.seller,
      sellerAr: product.sellerAr,
    });
  };

  if (loading) {
    return <ProductDetailSkeleton />;
  }

  return (
    <div className="min-h-screen bg-[#fafafa]" style={{ fontFamily: 'Cairo, sans-serif' }}>
      {/* Minimal Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }} 
        animate={{ opacity: 1, y: 0 }} 
        className="sticky top-0 bg-white/95 backdrop-blur-lg border-b border-[rgba(0,0,0,0.06)] px-6 py-4 flex items-center justify-between z-10"
        style={{ boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04)' }}
      >
        <div className="flex gap-2">
          <motion.button 
            whileTap={{ scale: 0.95 }}
            onClick={handleShare} 
            className="w-10 h-10 rounded-xl bg-[#fafafa] flex items-center justify-center text-[#163300] transition-all duration-200 hover:bg-[#f0fde8]"
          >
            <Share2 className="w-5 h-5" />
          </motion.button>
          <motion.button 
            whileTap={{ scale: 0.95 }}
            onClick={handleFavorite} 
            className="w-10 h-10 rounded-xl bg-[#fafafa] flex items-center justify-center transition-all duration-200 hover:bg-[#f0fde8]"
          >
            <motion.div
              animate={{ scale: isProductFavorite ? [1, 1.3, 1] : 1 }}
              transition={{ duration: 0.3 }}
            >
              <Heart className={`w-5 h-5 ${isProductFavorite ? 'fill-[#ef4444] text-[#ef4444]' : 'text-[#163300]'}`} />
            </motion.div>
          </motion.button>
        </div>
        <motion.button 
          whileTap={{ scale: 0.95 }}
          onClick={onBack} 
          className="w-10 h-10 rounded-xl bg-[#fafafa] flex items-center justify-center text-[#163300] transition-all duration-200 hover:bg-[#f0fde8]"
        >
          <ChevronRight className="w-6 h-6" />
        </motion.button>
      </motion.div>
      
      <div className="pb-32">
        {/* Premium Image Container */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3 }}
          className="bg-white relative cursor-pointer"
          onClick={() => {
            if (productImages.length > 0) {
              setIsZoomModalOpen(true);
            }
          }}
        >
          {mainImage ? (
            <img 
              src={mainImage} 
              alt={product.titleAr} 
              className="w-full aspect-square object-cover" 
            />
          ) : (
            <div className="w-full aspect-square bg-[#fafafa] flex items-center justify-center">
              <span className="text-[#6a6c6a] text-sm">No image available</span>
            </div>
          )}
          {product.verified && (
            <div className="absolute top-6 right-6 px-3 py-1.5 bg-white/95 backdrop-blur-md rounded-xl flex items-center gap-2 shadow-lg border border-[rgba(22,51,0,0.1)]" style={{ [isRTL ? 'right' : 'left']: '1.5rem' }}>
              <span className="text-[#163300] text-xs font-bold">✓</span>
              <span className="text-[#163300] text-xs font-semibold">
                {language === 'ar' ? 'موثق' : 'Verified'}
              </span>
            </div>
          )}
          {mainImage && (
            <div className="absolute bottom-4 right-4 px-2 py-1 bg-black/60 backdrop-blur-md rounded-lg" style={{ [isRTL ? 'right' : 'left']: '1rem' }}>
              <span className="text-white text-xs">
                {language === 'ar' ? 'اضغط للتكبير' : 'Tap to zoom'}
              </span>
            </div>
          )}
        </motion.div>
        
        {/* Product Title & Price */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white px-6 py-5"
        >
          <div className="flex items-start justify-between gap-4 mb-3" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
            <div className="flex flex-col gap-1" style={{ alignItems: isRTL ? 'flex-end' : 'flex-start' }}>
              <div className="flex items-center gap-2">
                <span className="text-xs text-[#6a6c6a] flex items-center gap-1">
                  <span className="text-[#f59e0b]">★</span>
                  {productRating}
                </span>
                <span className="text-xs text-[#6a6c6a]">•</span>
                <span className="text-xs text-[#6a6c6a]">{language === 'ar' ? categoryNameAr : categoryName}</span>
              </div>
              <p className="text-xs text-[#6a6c6a]">{language === 'ar' ? cityNameAr : cityName}</p>
            </div>
            <h2 className="text-xl font-bold text-[#0a0b09] flex-1" style={{ textAlign: isRTL ? 'right' : 'left' }}>
              {language === 'ar' ? product.titleAr : product.title}
            </h2>
          </div>
          
          <div className="flex items-end justify-between" style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}>
            <div className="flex flex-col gap-1" style={{ alignItems: isRTL ? 'flex-end' : 'flex-start' }}>
              <span className="text-xs text-[#6a6c6a]">
                {language === 'ar' ? 'السعر' : 'Price'}
              </span>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-bold text-[#163300]">{product.price}</span>
                <span className="text-lg text-[#6a6c6a]">
                  {language === 'ar' ? 'ر.س' : 'SAR'}
                </span>
              </div>
            </div>
            
            {/* Payment Options - Prominent */}
            <div className="flex flex-col gap-1.5" style={{ alignItems: isRTL ? 'flex-end' : 'flex-start' }}>
              <span className="text-xs text-[#6a6c6a]">
                {language === 'ar' ? 'أو قسمها على 4 دفعات' : 'Or split into 4 payments'}
              </span>
              <div className="flex items-center gap-2">
                {/* Tabby */}
                <div className="h-6 px-2.5 bg-[#3AFFA3] rounded-lg flex items-center justify-center">
                  <span className="text-xs font-bold text-black" style={{ fontFamily: 'system-ui, sans-serif' }}>tabby</span>
                </div>
                {/* Tamara */}
                <div className="h-6 px-2.5 bg-black rounded-lg flex items-center justify-center">
                  <span className="text-xs font-bold text-white" style={{ fontFamily: 'system-ui, sans-serif' }}>tamara</span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Description */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="mx-4 my-4 bg-white rounded-2xl p-5 shadow-sm"
        >
          <h3 className="font-semibold text-[#0a0b09] mb-3" style={{ textAlign: isRTL ? 'right' : 'left' }}>
            {language === 'ar' ? 'وصف المنتج' : 'Product Description'}
          </h3>
          <p className="text-[#6a6c6a] leading-relaxed text-sm" style={{ textAlign: isRTL ? 'right' : 'left' }}>
            {language === 'ar' ? productDescriptionAr : productDescription}
          </p>
        </motion.div>

        {/* Seller Info - Premium Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mx-4 mb-4"
        >
          <h3 className="font-semibold text-[#0a0b09] mb-3 px-1" style={{ textAlign: isRTL ? 'right' : 'left' }}>
            {language === 'ar' ? 'البائع' : 'Seller'}
          </h3>
          <button 
            onClick={onSellerClick} 
            className="w-full bg-white rounded-2xl p-5 border border-[rgba(0,0,0,0.08)] shadow-sm hover:shadow-md transition-all duration-200 active:scale-98"
          >
            <div className="flex items-center gap-4" style={{ flexDirection: isRTL ? 'row-reverse' : 'row', textAlign: isRTL ? 'right' : 'left' }}>
              <div className="flex-1" style={{ textAlign: isRTL ? 'right' : 'left' }}>
                <div className="flex items-center gap-2 mb-1" style={{ justifyContent: isRTL ? 'flex-end' : 'flex-start' }}>
                  <p className="font-semibold text-[#0a0b09]">
                    {language === 'ar' ? sellerNameAr : sellerName}
                  </p>
                  {product.verified && (
                    <div className="w-5 h-5 bg-[#163300] rounded-full flex items-center justify-center">
                      <span className="text-white text-xs">✓</span>
                    </div>
                  )}
                </div>
                <div className="flex items-center gap-3 text-sm text-[#6a6c6a]" style={{ justifyContent: isRTL ? 'flex-end' : 'flex-start' }}>
                  <span>{language === 'ar' ? cityNameAr : cityName}</span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <span className="text-[#f59e0b]">★</span>
                    {productRating}
                  </span>
                </div>
              </div>
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#163300] to-[#0f2409] flex items-center justify-center text-white text-xl font-bold shadow-md">
                {language === 'ar' ? sellerNameAr[0] : sellerName[0]}
              </div>
            </div>
            
            {/* Seller Stats */}
            <div className="grid grid-cols-3 gap-3 mt-4 pt-4 border-t border-[rgba(0,0,0,0.06)]">
              <div className="text-center">
                <div className="text-lg font-bold text-[#163300]">247</div>
                <div className="text-xs text-[#6a6c6a]">
                  {language === 'ar' ? 'منتج' : 'Products'}
                </div>
              </div>
              <div className="text-center">
                <div className="text-lg font-bold text-[#163300]">1.2k</div>
                <div className="text-xs text-[#6a6c6a]">
                  {language === 'ar' ? 'متابع' : 'Followers'}
                </div>
              </div>
              <div className="text-center">
                <div className="text-lg font-bold text-[#163300]">98%</div>
                <div className="text-xs text-[#6a6c6a]">
                  {language === 'ar' ? 'تقييم' : 'Rating'}
                </div>
              </div>
            </div>
          </button>
        </motion.div>

        {/* Product Features */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="mx-4 mb-4 bg-white rounded-2xl p-5 shadow-sm"
        >
          <h3 className="font-semibold text-[#0a0b09] mb-4" style={{ textAlign: isRTL ? 'right' : 'left' }}>
            {language === 'ar' ? 'مميزات المنتج' : 'Product Features'}
          </h3>
          <div className="space-y-3">
            <div className="flex items-center gap-3" style={{ justifyContent: isRTL ? 'flex-end' : 'flex-start', flexDirection: isRTL ? 'row-reverse' : 'row' }}>
              <span className="text-sm text-[#6a6c6a]">
                {language === 'ar' ? 'جديد - لم يستخدم' : 'New - Unused'}
              </span>
              <div className="w-8 h-8 rounded-lg bg-[#f0fde8] flex items-center justify-center">
                <span className="text-lg">✨</span>
              </div>
            </div>
            <div className="flex items-center gap-3" style={{ justifyContent: isRTL ? 'flex-end' : 'flex-start', flexDirection: isRTL ? 'row-reverse' : 'row' }}>
              <span className="text-sm text-[#6a6c6a]">
                {language === 'ar' ? 'شحن سريع' : 'Fast Shipping'}
              </span>
              <div className="w-8 h-8 rounded-lg bg-[#f0fde8] flex items-center justify-center">
                <span className="text-lg">🚚</span>
              </div>
            </div>
            <div className="flex items-center gap-3" style={{ justifyContent: isRTL ? 'flex-end' : 'flex-start', flexDirection: isRTL ? 'row-reverse' : 'row' }}>
              <span className="text-sm text-[#6a6c6a]">
                {language === 'ar' ? 'إمكانية الإرجاع' : 'Return Available'}
              </span>
              <div className="w-8 h-8 rounded-lg bg-[#f0fde8] flex items-center justify-center">
                <span className="text-lg">↩️</span>
              </div>
            </div>
            <div className="flex items-center gap-3" style={{ justifyContent: isRTL ? 'flex-end' : 'flex-start', flexDirection: isRTL ? 'row-reverse' : 'row' }}>
              <span className="text-sm text-[#6a6c6a]">
                {language === 'ar' ? 'ضمان البائع' : 'Seller Warranty'}
              </span>
              <div className="w-8 h-8 rounded-lg bg-[#f0fde8] flex items-center justify-center">
                <span className="text-lg">🛡️</span>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
      
      {/* Premium Floating Action Bar */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-lg border-t border-[rgba(0,0,0,0.06)] p-4"
        style={{ boxShadow: '0 -4px 12px rgba(0, 0, 0, 0.04)' }}
      >
        <div className="max-w-[430px] mx-auto">
          {/* Quick Actions Row */}
          <div className="flex gap-2 mb-3">
            <motion.button 
              whileTap={{ scale: 0.95 }}
              onClick={onChatWithSeller} 
              className="flex-1 h-12 rounded-xl bg-[#fafafa] border border-[rgba(0,0,0,0.08)] flex items-center justify-center gap-2 text-[#163300] transition-all duration-200 hover:bg-[#f0fde8]"
            >
              <MessageCircle className="w-5 h-5" />
              <span className="text-sm font-medium">
                {language === 'ar' ? 'محادثة' : 'Chat'}
              </span>
            </motion.button>
            
            {!isInCart && (
              <motion.button 
                whileTap={{ scale: 0.95 }}
                onClick={handleAddToCart} 
                className="flex-1 h-12 rounded-xl bg-[#fafafa] border border-[rgba(0,0,0,0.08)] flex items-center justify-center gap-2 text-[#163300] transition-all duration-200 hover:bg-[#f0fde8]"
              >
                <ShoppingCart className="w-5 h-5" />
                <span className="text-sm font-medium">
                  {language === 'ar' ? 'السلة' : 'Cart'}
                </span>
              </motion.button>
            )}
          </div>
          
          {/* Main CTA */}
          <ModernButton 
            onClick={onBuyNow} 
            variant="primary" 
            fullWidth 
            size="lg"
          >
            {isInCart 
              ? (language === 'ar' ? '🛒 شراء الآن' : '🛒 Buy Now')
              : (language === 'ar' ? '🛍️ أضف للسلة واشتري' : '🛍️ Add to Cart & Buy')
            }
          </ModernButton>
        </div>
      </motion.div>

      {/* Image Zoom Modal */}
      <ImageZoomModal
        images={productImages}
        initialIndex={0}
        isOpen={isZoomModalOpen}
        onClose={() => setIsZoomModalOpen(false)}
      />
    </div>
  );
}