import { motion, AnimatePresence } from "motion/react";
import { useState } from "react";
import { useLanguage } from "../../contexts/LanguageContext";
import { ShoppingBag, MessageCircle, Package, Shield, ChevronRight } from "lucide-react";
import { WiseButton } from "../../components/WiseButton";

interface RabitOnboardingTutorialScreenProps {
  onComplete: () => void;
  onSkip: () => void;
}

export function RabitOnboardingTutorialScreen({
  onComplete,
  onSkip,
}: RabitOnboardingTutorialScreenProps) {
  const { language, isRTL } = useLanguage();
  const [currentStep, setCurrentStep] = useState(0);

  const content = {
    ar: {
      skip: "تخطي",
      next: "التالي",
      getStarted: "ابدأ الآن",
      
      step1Title: "اشتري وبع بسهولة",
      step1Desc: "منصة آمنة تربط المشترين والبائعين في السعودية. ابحث عن منتجات، أو ابدأ بالبيع!",
      
      step2Title: "تواصل مع البائعين",
      step2Desc: "تحدث مع البائعين مباشرة، اسأل عن المنتجات، وتفاوض على السعر قبل الشراء.",
      
      step3Title: "شحن سريع وآمن",
      step3Desc: "نتابع طلبك من لحظة الشراء حتى التسليم. شحن مجاني وتتبع مباشر.",
      
      step4Title: "حماية الدفع",
      step4Desc: "مدفوعاتك محمية. لا يحصل البائع على المال حتى تستلم طلبك وتؤكد رضاك.",
    },
    en: {
      skip: "Skip",
      next: "Next",
      getStarted: "Get Started",
      
      step1Title: "Buy and Sell with Ease",
      step1Desc: "A secure platform connecting buyers and sellers in Saudi Arabia. Browse products or start selling!",
      
      step2Title: "Connect with Sellers",
      step2Desc: "Chat directly with sellers, ask questions about products, and negotiate prices before buying.",
      
      step3Title: "Fast & Secure Shipping",
      step3Desc: "Track your order from purchase to delivery. Free shipping with real-time tracking.",
      
      step4Title: "Payment Protection",
      step4Desc: "Your payments are protected. Sellers receive money only after you confirm receipt and satisfaction.",
    },
  };
  const c = content[language];

  const steps = [
    {
      icon: ShoppingBag,
      title: c.step1Title,
      description: c.step1Desc,
      color: "#163300",
      image: "https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=600",
    },
    {
      icon: MessageCircle,
      title: c.step2Title,
      description: c.step2Desc,
      color: "#9fe870",
      image: "https://images.unsplash.com/photo-1577563908411-5077b6dc7624?w=600",
    },
    {
      icon: Package,
      title: c.step3Title,
      description: c.step3Desc,
      color: "#163300",
      image: "https://images.unsplash.com/photo-1566576912321-d58ddd7a6088?w=600",
    },
    {
      icon: Shield,
      title: c.step4Title,
      description: c.step4Desc,
      color: "#9fe870",
      image: "https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=600",
    },
  ];

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete();
    }
  };

  const currentStepData = steps[currentStep];
  const StepIcon = currentStepData.icon;
  const isLastStep = currentStep === steps.length - 1;

  return (
    <div
      className="min-h-screen bg-gradient-to-br from-[#163300] to-[#1a3d00] flex flex-col"
      style={{ fontFamily: language === "ar" ? "Cairo, sans-serif" : "system-ui, -apple-system, sans-serif" }}
      dir={isRTL ? "rtl" : "ltr"}
    >
      {/* Skip Button */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-6 flex justify-end"
      >
        <button
          onClick={onSkip}
          className="text-white/80 hover:text-white text-sm font-medium transition-colors"
        >
          {c.skip}
        </button>
      </motion.div>

      {/* Content */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 pb-32">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: isRTL ? -50 : 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: isRTL ? 50 : -50 }}
            transition={{ duration: 0.3 }}
            className="w-full max-w-sm"
          >
            {/* Image */}
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.1 }}
              className="relative mb-8"
            >
              <div className="w-64 h-64 mx-auto rounded-[32px] overflow-hidden shadow-2xl">
                <img
                  src={currentStepData.image}
                  alt={currentStepData.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.3, type: "spring", stiffness: 200 }}
                className="absolute -bottom-4 left-1/2 -translate-x-1/2 w-16 h-16 bg-white rounded-full flex items-center justify-center shadow-xl"
              >
                <StepIcon className="w-8 h-8 text-[#163300]" />
              </motion.div>
            </motion.div>

            {/* Text */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-center text-white"
            >
              <h2 className="text-2xl font-bold mb-4">{currentStepData.title}</h2>
              <p className="text-sm opacity-90 leading-relaxed">
                {currentStepData.description}
              </p>
            </motion.div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Bottom Navigation */}
      <div className="px-6 pb-8">
        {/* Dots Indicator */}
        <div className="flex items-center justify-center gap-2 mb-6">
          {steps.map((_, index) => (
            <motion.div
              key={index}
              initial={false}
              animate={{
                width: index === currentStep ? 32 : 8,
                backgroundColor: index === currentStep ? "#ffffff" : "rgba(255,255,255,0.3)",
              }}
              className="h-2 rounded-full transition-all"
            />
          ))}
        </div>

        {/* Buttons */}
        <div className="flex gap-3">
          {currentStep > 0 && (
            <button
              onClick={() => setCurrentStep(currentStep - 1)}
              className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center hover:bg-white/30 transition-colors"
            >
              <ChevronRight className={`w-6 h-6 text-white ${isRTL ? "" : "rotate-180"}`} />
            </button>
          )}
          
          <div className="flex-1">
            <WiseButton
              onClick={handleNext}
              variant="primary"
              fullWidth
              className="bg-white text-[#163300] hover:bg-white/90"
            >
              {isLastStep ? c.getStarted : c.next}
            </WiseButton>
          </div>

          {!isLastStep && (
            <button
              onClick={handleNext}
              className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center hover:bg-white/30 transition-colors"
            >
              <ChevronRight className={`w-6 h-6 text-white ${isRTL ? "rotate-180" : ""}`} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
