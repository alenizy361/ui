import { motion } from "motion/react";
import { ChevronRight, Package, ShoppingBag, Heart, Search } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";

// Import all new premium components
import { EmptyState } from "../../components/EmptyState";
import { LoadingSkeleton } from "../../components/LoadingSkeleton";
import { ProgressIndicator } from "../../components/ProgressIndicator";
import { PullToRefresh } from "../../components/PullToRefresh";
import { HapticButton } from "../../components/HapticButton";
import { SuccessAnimation } from "../../components/SuccessAnimation";
import { EnhancedInput } from "../../components/EnhancedInput";

interface RabitEnhancedExampleScreenProps {
  onBack: () => void;
}

/**
 * 🎨 COMPREHENSIVE EXAMPLE SCREEN
 * 
 * This screen demonstrates ALL premium components in action:
 * - Toast notifications
 * - Empty states
 * - Loading skeletons
 * - Progress indicators
 * - Pull to refresh
 * - Haptic buttons
 * - Success animations
 * - Enhanced inputs
 */
export function RabitEnhancedExampleScreen({ onBack }: RabitEnhancedExampleScreenProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [showEmptyState, setShowEmptyState] = useState(false);
  const [email, setEmail] = useState("");
  const [emailError, setEmailError] = useState("");

  // Example: Simulated data fetch
  const handleRefresh = async () => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsLoading(false);
    toast.success(getTranslation("data_updated_successfully"));
  };

  // Example: Form validation
  const validateEmail = (value: string) => {
    if (!value) {
      setEmailError(getTranslation("email_required"));
      return false;
    }
    if (!value.includes("@")) {
      setEmailError(getTranslation("invalid_email"));
      return false;
    }
    setEmailError("");
    return true;
  };

  // Example: Success flow
  const handleSubmit = async () => {
    if (!validateEmail(email)) {
      toast.error(getTranslation("fix_errors"));
      return;
    }

    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsLoading(false);
    
    setShowSuccess(true);
    setTimeout(() => {
      setShowSuccess(false);
      toast.info(getTranslation("verification_link_sent"));
    }, 3000);
  };

  // Example: Toast demonstrations
  const demoToasts = () => {
    toast.success(getTranslation("changes_saved_successfully"));
    setTimeout(() => toast.error(getTranslation("server_connection_failed")), 1000);
    setTimeout(() => toast.warning(getTranslation("3_attempts_left")), 2000);
    setTimeout(() => toast.info(getTranslation("new_notification")), 3000);
  };

  // Progress tracking example
  const orderSteps = [
    { label: getTranslation("order_confirmation"), status: "completed" as const },
    { label: getTranslation("preparation"), status: "completed" as const },
    { label: getTranslation("shipping"), status: "current" as const },
    { label: getTranslation("delivery"), status: "upcoming" as const },
  ];

  if (showSuccess) {
    return (
      <SuccessAnimation
        icon={Package}
        title="تم الإرسال بنجاح!"
        description="تحقق من بريدك الإلكتروني لإتمام العملية"
        showConfetti={true}
      >
        <div className="bg-white rounded-xl p-4 border border-[rgba(14,15,12,0.12157)] max-w-[300px]">
          <p className="text-sm text-[#6a6c6a] text-center">
            تم إرسال الرابط إلى:
          </p>
          <p className="text-base font-semibold text-[#163300] text-center mt-1">
            {email}
          </p>
        </div>
      </SuccessAnimation>
    );
  }

  return (
    <div className="flex flex-col min-h-screen bg-white">
      {/* Header */}
      <div className="bg-[#163300] px-6 py-4 pb-6">
        <div className="flex items-center justify-between mb-6">
          <button onClick={onBack}>
            <ChevronRight className="w-6 h-6 text-white rotate-180" />
          </button>
          <h1 className="text-xl font-bold text-white">مثال شامل للمكونات</h1>
          <div className="w-6" />
        </div>

        <p className="text-sm text-white/80 text-right">
          جميع المكونات المميزة في شاشة واحدة
        </p>
      </div>

      {/* Pull to Refresh Wrapper */}
      <PullToRefresh onRefresh={handleRefresh}>
        <div className="flex-1 overflow-y-auto pb-24">
          {/* Section 1: Toast Notifications */}
          <div className="px-6 py-6 bg-white border-b border-[rgba(14,15,12,0.12157)]">
            <h2 className="text-lg font-bold text-[#0e0f0c] mb-3 text-right">
              1️⃣ إشعارات Toast
            </h2>
            <p className="text-sm text-[#6a6c6a] mb-4 text-right">
              اضغط على الزر لعرض جميع أنواع الإشعارات
            </p>
            <HapticButton
              onClick={demoToasts}
              variant="primary"
              fullWidth
            >
              عرض الإشعارات
            </HapticButton>
          </div>

          {/* Section 2: Enhanced Inputs */}
          <div className="px-6 py-6 bg-white border-b border-[rgba(14,15,12,0.12157)]">
            <h2 className="text-lg font-bold text-[#0e0f0c] mb-3 text-right">
              2️⃣ حقول الإدخال المحسّنة
            </h2>
            <div className="space-y-4">
              <EnhancedInput
                label="البريد الإلكتروني"
                type="email"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  if (e.target.value) validateEmail(e.target.value);
                }}
                error={emailError}
                success={!emailError && email.length > 0}
                helperText="أدخل بريدك الإلكتروني للمتابعة"
                placeholder="example@email.com"
              />

              <EnhancedInput
                label="كلمة المرور"
                type="password"
                showPasswordToggle
                placeholder="••••••••"
                helperText="يجب أن تكون 8 أحرف على الأقل"
              />

              <HapticButton
                onClick={handleSubmit}
                variant="primary"
                fullWidth
                disabled={!email || !!emailError}
              >
                إرسال
              </HapticButton>
            </div>
          </div>

          {/* Section 3: Progress Indicator */}
          <div className="px-6 py-6 bg-white border-b border-[rgba(14,15,12,0.12157)]">
            <h2 className="text-lg font-bold text-[#0e0f0c] mb-4 text-right">
              3️⃣ مؤشر التقدم
            </h2>
            
            <div className="mb-6">
              <p className="text-sm text-[#6a6c6a] mb-3 text-right">عمودي (Timeline)</p>
              <ProgressIndicator steps={orderSteps} orientation="vertical" />
            </div>

            <div>
              <p className="text-sm text-[#6a6c6a] mb-3 text-right">أفقي (Stepper)</p>
              <ProgressIndicator 
                steps={[
                  { label: "العربة", status: "completed" },
                  { label: "الدفع", status: "current" },
                  { label: "التأكيد", status: "upcoming" },
                ]} 
                orientation="horizontal" 
              />
            </div>
          </div>

          {/* Section 4: Loading Skeletons */}
          <div className="px-6 py-6 bg-white border-b border-[rgba(14,15,12,0.12157)]">
            <h2 className="text-lg font-bold text-[#0e0f0c] mb-3 text-right">
              4️⃣ هياكل التحميل
            </h2>
            <div className="flex items-center justify-between mb-4">
              <HapticButton
                onClick={() => setIsLoading(!isLoading)}
                variant="secondary"
                size="sm"
              >
                {isLoading ? "إيقاف" : "تشغيل"}
              </HapticButton>
              <p className="text-sm text-[#6a6c6a] text-right">
                حالة التحميل
              </p>
            </div>

            {isLoading ? (
              <LoadingSkeleton variant="product" count={2} />
            ) : (
              <div className="space-y-3">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-white rounded-[12px] border border-[rgba(14,15,12,0.12157)] p-4"
                >
                  <div className="flex gap-4">
                    <div className="w-24 h-24 bg-[#e2f6d5] rounded-lg flex items-center justify-center">
                      <Package className="w-12 h-12 text-[#163300]" />
                    </div>
                    <div className="flex-1 text-right">
                      <p className="font-semibold text-[#0e0f0c] mb-2">
                        منتج تجريبي
                      </p>
                      <p className="text-lg font-bold text-[#163300]">
                        ٠٫٠٠ ر.س
                      </p>
                    </div>
                  </div>
                </motion.div>
              </div>
            )}
          </div>

          {/* Section 5: Empty State */}
          <div className="px-6 py-6 bg-white border-b border-[rgba(14,15,12,0.12157)]">
            <h2 className="text-lg font-bold text-[#0e0f0c] mb-3 text-right">
              5️⃣ الحالة الفارغة
            </h2>
            <div className="flex items-center justify-between mb-4">
              <HapticButton
                onClick={() => setShowEmptyState(!showEmptyState)}
                variant="secondary"
                size="sm"
              >
                {showEmptyState ? "إخفاء" : "عرض"}
              </HapticButton>
              <p className="text-sm text-[#6a6c6a] text-right">
                عرض/إخفاء
              </p>
            </div>

            {showEmptyState && (
              <EmptyState
                icon={ShoppingBag}
                title="لا توجد منتجات"
                description="لم تقم بإضافة أي منتجات إلى السلة بعد"
                iconColor="#163300"
                action={{
                  label: "ابدأ التسوق",
                  onClick: () => toast.info("الانتقال إلى المتجر..."),
                }}
              />
            )}
          </div>

          {/* Section 6: Haptic Buttons */}
          <div className="px-6 py-6 bg-white">
            <h2 className="text-lg font-bold text-[#0e0f0c] mb-3 text-right">
              6️⃣ أزرار اللمس
            </h2>
            <p className="text-sm text-[#6a6c6a] mb-4 text-right">
              جميع الأزرار تتضمن ردود فعل لمسية
            </p>
            
            <div className="space-y-3">
              <HapticButton variant="primary" fullWidth>
                زر أساسي
              </HapticButton>

              <HapticButton variant="secondary" fullWidth>
                زر ثانوي
              </HapticButton>

              <HapticButton variant="danger" fullWidth>
                زر خطر
              </HapticButton>

              <div className="grid grid-cols-3 gap-2">
                <HapticButton variant="primary" size="sm">
                  <Heart className="w-4 h-4" />
                </HapticButton>
                <HapticButton variant="secondary" size="sm">
                  <Search className="w-4 h-4" />
                </HapticButton>
                <HapticButton variant="ghost" size="sm">
                  <Package className="w-4 h-4" />
                </HapticButton>
              </div>
            </div>
          </div>
        </div>
      </PullToRefresh>

      {/* Bottom Info */}
      <div className="fixed bottom-0 left-0 right-0 bg-[#e2f6d5] border-t border-[#163300]/20 px-6 py-3">
        <p className="text-sm text-[#163300] text-center font-medium">
          اسحب لأسفل لتحديث المحتوى 👆
        </p>
      </div>
    </div>
  );
}