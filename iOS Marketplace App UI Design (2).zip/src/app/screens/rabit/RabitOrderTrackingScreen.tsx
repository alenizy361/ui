import { motion } from "motion/react";
import { ChevronRight, Package, Truck, MapPin, CheckCircle2, Clock, Phone, MessageCircle } from "lucide-react";
import { useLanguage } from "../../contexts/LanguageContext";
import { WiseButton } from "../../components/WiseButton";

interface RabitOrderTrackingScreenProps {
  orderNumber: string;
  onBack: () => void;
  onContactSeller: () => void;
  onViewDetails: () => void;
}

type TrackingStatus = "placed" | "preparing" | "label_created" | "shipped" | "in_transit" | "out_for_delivery" | "delivered";

export function RabitOrderTrackingScreen({
  orderNumber,
  onBack,
  onContactSeller,
  onViewDetails,
}: RabitOrderTrackingScreenProps) {
  const { language, isRTL } = useLanguage();

  // Mock current status
  const currentStatus: TrackingStatus = "in_transit";

  const content = {
    ar: {
      trackOrder: "تتبع الطلب",
      orderNumber: "رقم الطلب",
      estimatedDelivery: "التسليم المتوقع",
      currentLocation: "الموقع الحالي",
      riyadh: "الرياض، المملكة العربية السعودية",
      contactSeller: "تواصل مع البائع",
      viewDetails: "تفاصيل الطلب",
      trackingHistory: "سجل الشحنة",
      
      // Statuses
      orderPlaced: "تم تقديم الطلب",
      orderPlacedDesc: "طلبك قيد المراجعة",
      preparing: "جاري التحضير",
      preparingDesc: "البائع يقوم بتحضير طلبك",
      labelCreated: "تم إنشاء بوليصة الشحن",
      labelCreatedDesc: "تم إنشاء بوليصة الشحن بنجاح",
      shipped: "تم الشحن",
      shippedDesc: "تم تسليم الطلب لشركة الشحن",
      inTransit: "في الطريق",
      inTransitDesc: "الطلب في طريقه إليك",
      outForDelivery: "خارج للتسليم",
      outForDeliveryDesc: "سيصل الطلب اليوم",
      delivered: "تم التسليم",
      deliveredDesc: "تم تسليم الطلب بنجاح",
      
      // Times
      today: "اليوم",
      yesterday: "أمس",
      daysAgo: "منذ {days} أيام",
    },
    en: {
      trackOrder: "Track Order",
      orderNumber: "Order Number",
      estimatedDelivery: "Estimated Delivery",
      currentLocation: "Current Location",
      riyadh: "Riyadh, Saudi Arabia",
      contactSeller: "Contact Seller",
      viewDetails: "Order Details",
      trackingHistory: "Tracking History",
      
      // Statuses
      orderPlaced: "Order Placed",
      orderPlacedDesc: "Your order is under review",
      preparing: "Preparing",
      preparingDesc: "Seller is preparing your order",
      labelCreated: "Shipping Label Created",
      labelCreatedDesc: "Shipping label created successfully",
      shipped: "Shipped",
      shippedDesc: "Order handed to shipping carrier",
      inTransit: "In Transit",
      inTransitDesc: "Order is on its way to you",
      outForDelivery: "Out for Delivery",
      outForDeliveryDesc: "Order will arrive today",
      delivered: "Delivered",
      deliveredDesc: "Order delivered successfully",
      
      // Times
      today: "Today",
      yesterday: "Yesterday",
      daysAgo: "{days} days ago",
    },
  };
  const c = content[language];

  const trackingSteps: Array<{
    status: TrackingStatus;
    title: string;
    description: string;
    icon: any;
    time: string;
  }> = [
    {
      status: "placed",
      title: c.orderPlaced,
      description: c.orderPlacedDesc,
      icon: CheckCircle2,
      time: "3 " + (language === "ar" ? "أيام" : "days ago"),
    },
    {
      status: "preparing",
      title: c.preparing,
      description: c.preparingDesc,
      icon: Package,
      time: "2 " + (language === "ar" ? "أيام" : "days ago"),
    },
    {
      status: "label_created",
      title: c.labelCreated,
      description: c.labelCreatedDesc,
      icon: Package,
      time: language === "ar" ? "أمس" : "Yesterday",
    },
    {
      status: "shipped",
      title: c.shipped,
      description: c.shippedDesc,
      icon: Truck,
      time: language === "ar" ? "أمس" : "Yesterday",
    },
    {
      status: "in_transit",
      title: c.inTransit,
      description: c.inTransitDesc,
      icon: Truck,
      time: language === "ar" ? "اليوم" : "Today",
    },
    {
      status: "out_for_delivery",
      title: c.outForDelivery,
      description: c.outForDeliveryDesc,
      icon: Truck,
      time: "",
    },
    {
      status: "delivered",
      title: c.delivered,
      description: c.deliveredDesc,
      icon: CheckCircle2,
      time: "",
    },
  ];

  const currentStepIndex = trackingSteps.findIndex((step) => step.status === currentStatus);

  return (
    <div
      className="min-h-screen bg-[#fafafa] pb-32"
      style={{ fontFamily: language === "ar" ? "Cairo, sans-serif" : "system-ui, -apple-system, sans-serif" }}
      dir={isRTL ? "rtl" : "ltr"}
    >
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 flex items-center justify-between z-10"
      >
        <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
          <ChevronRight className={`w-6 h-6 text-[#0e0f0c] ${isRTL ? "" : "rotate-180"}`} />
        </button>
        <h1 className="text-xl font-semibold text-[#0e0f0c]">{c.trackOrder}</h1>
        <div className="w-10" />
      </motion.div>

      <div className="p-6 space-y-6">
        {/* Order Info Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-br from-[#163300] to-[#1a3d00] rounded-[16px] p-6 text-white"
        >
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <p className="text-sm opacity-80 mb-1">{c.orderNumber}</p>
              <p className="text-xl font-bold">#{orderNumber}</p>
            </div>
            <Package className="w-8 h-8 opacity-80" />
          </div>
          
          <div className="border-t border-white/20 pt-4 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm opacity-80">{c.estimatedDelivery}</span>
              <span className="text-sm font-semibold">{language === "ar" ? "25 ديسمبر 2025" : "Dec 25, 2025"}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm opacity-80">{c.currentLocation}</span>
              <span className="text-sm font-semibold">{c.riyadh}</span>
            </div>
          </div>
        </motion.div>

        {/* Map Placeholder */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-[16px] overflow-hidden shadow-sm"
          style={{ height: "200px" }}
        >
          <div className="w-full h-full bg-gradient-to-br from-[#e8f5e9] to-[#c8e6c9] flex items-center justify-center relative">
            <MapPin className="w-12 h-12 text-[#163300] animate-bounce" />
            <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAwIDEwIEwgNDAgMTAgTSAxMCAwIEwgMTAgNDAgTSAwIDIwIEwgNDAgMjAgTSAyMCAwIEwgMjAgNDAgTSAwIDMwIEwgNDAgMzAgTSAzMCAwIEwgMzAgNDAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSgyMiw1MSwwLDAuMSkiIHN0cm9rZS13aWR0aD0iMSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNncmlkKSIvPjwvc3ZnPg==')] opacity-30"></div>
          </div>
        </motion.div>

        {/* Tracking Timeline */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-[16px] p-6 shadow-sm"
        >
          <h2 className={`text-lg font-bold text-[#0e0f0c] mb-6 ${isRTL ? "text-right" : "text-left"}`}>
            {c.trackingHistory}
          </h2>

          <div className="space-y-6">
            {trackingSteps.map((step, index) => {
              const isPast = index <= currentStepIndex;
              const isCurrent = index === currentStepIndex;
              const Icon = step.icon;

              return (
                <motion.div
                  key={step.status}
                  initial={{ opacity: 0, x: isRTL ? 20 : -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + index * 0.05 }}
                  className="relative flex items-start gap-4"
                >
                  {/* Timeline Line */}
                  {index < trackingSteps.length - 1 && (
                    <div
                      className={`absolute ${isRTL ? "right-[19px]" : "left-[19px]"} top-[40px] w-[2px] h-[calc(100%+8px)] ${
                        isPast ? "bg-[#163300]" : "bg-[rgba(14,15,12,0.12157)]"
                      }`}
                    />
                  )}

                  {/* Icon */}
                  <div
                    className={`relative z-10 w-10 h-10 rounded-full flex items-center justify-center ${
                      isPast
                        ? "bg-[#163300] text-white"
                        : "bg-[rgba(14,15,12,0.07843)] text-[#6a6c6a]"
                    } ${isCurrent ? "ring-4 ring-[rgba(22,51,0,0.2)]" : ""}`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>

                  {/* Content */}
                  <div className="flex-1 pb-6">
                    <div className="flex items-start justify-between mb-1">
                      <h3
                        className={`font-semibold ${
                          isPast ? "text-[#0e0f0c]" : "text-[#6a6c6a]"
                        }`}
                      >
                        {step.title}
                      </h3>
                      {step.time && (
                        <span className="text-xs text-[#6a6c6a]">{step.time}</span>
                      )}
                    </div>
                    <p className="text-sm text-[#6a6c6a]">{step.description}</p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="grid grid-cols-2 gap-3"
        >
          <button
            onClick={onContactSeller}
            className="flex items-center justify-center gap-2 px-4 py-3 bg-white border border-[rgba(14,15,12,0.12157)] rounded-[12px] text-[#0e0f0c] font-medium hover:bg-[rgba(22,51,0,0.07843)] transition-colors"
          >
            <MessageCircle className="w-5 h-5" />
            <span>{c.contactSeller}</span>
          </button>
          <button
            onClick={onViewDetails}
            className="flex items-center justify-center gap-2 px-4 py-3 bg-[#163300] rounded-[12px] text-white font-medium hover:bg-[#1a3d00] transition-colors"
          >
            <Package className="w-5 h-5" />
            <span>{c.viewDetails}</span>
          </button>
        </motion.div>
      </div>
    </div>
  );
}
