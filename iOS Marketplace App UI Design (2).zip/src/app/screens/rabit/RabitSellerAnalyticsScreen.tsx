import { motion } from "motion/react";
import { ChevronRight, TrendingUp, Eye, ShoppingCart, DollarSign, Package, Users, BarChart3 } from "lucide-react";
import { useLanguage } from "../../contexts/LanguageContext";
import { Line, Bar } from "recharts";
import { LineChart, BarChart, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";

interface RabitSellerAnalyticsScreenProps {
  onBack: () => void;
}

export function RabitSellerAnalyticsScreen({ onBack }: RabitSellerAnalyticsScreenProps) {
  const { language, isRTL } = useLanguage();

  const content = {
    ar: {
      analytics: "التحليلات",
      overview: "نظرة عامة",
      revenue: "الإيرادات",
      views: "المشاهدات",
      orders: "الطلبات",
      conversionRate: "معدل التحويل",
      totalRevenue: "إجمالي الإيرادات",
      totalViews: "إجمالي المشاهدات",
      totalOrders: "إجمالي الطلبات",
      avgOrderValue: "متوسط قيمة الطلب",
      revenueOverTime: "الإيرادات خلال الفترة",
      topProducts: "المنتجات الأكثر مبيعاً",
      customerInsights: "رؤى العملاء",
      newCustomers: "عملاء جدد",
      returningCustomers: "عملاء عائدون",
      trafficSources: "مصادر الزيارات",
      thisMonth: "هذا الشهر",
      lastMonth: "الشهر الماضي",
      change: "التغيير",
      sar: "ر.س",
      product: "المنتج",
      sales: "المبيعات",
      revenue: "الإيرادات",
      search: "البحث",
      direct: "مباشر",
      social: "وسائل التواصل",
      other: "أخرى",
      week: "أسبوع",
      month: "شهر",
      year: "سنة",
    },
    en: {
      analytics: "Analytics",
      overview: "Overview",
      revenue: "Revenue",
      views: "Views",
      orders: "Orders",
      conversionRate: "Conversion Rate",
      totalRevenue: "Total Revenue",
      totalViews: "Total Views",
      totalOrders: "Total Orders",
      avgOrderValue: "Avg Order Value",
      revenueOverTime: "Revenue Over Time",
      topProducts: "Top Selling Products",
      customerInsights: "Customer Insights",
      newCustomers: "New Customers",
      returningCustomers: "Returning Customers",
      trafficSources: "Traffic Sources",
      thisMonth: "This Month",
      lastMonth: "Last Month",
      change: "Change",
      sar: "SAR",
      product: "Product",
      sales: "Sales",
      revenue: "Revenue",
      search: "Search",
      direct: "Direct",
      social: "Social Media",
      other: "Other",
      week: "Week",
      month: "Month",
      year: "Year",
    },
  };
  const c = content[language];

  // Mock analytics data
  const stats = [
    {
      label: c.totalRevenue,
      value: "42,500",
      currency: c.sar,
      change: "+12.5%",
      isPositive: true,
      icon: DollarSign,
      color: "#163300",
    },
    {
      label: c.totalViews,
      value: "8,432",
      change: "+8.2%",
      isPositive: true,
      icon: Eye,
      color: "#9fe870",
    },
    {
      label: c.totalOrders,
      value: "156",
      change: "+15.3%",
      isPositive: true,
      icon: ShoppingCart,
      color: "#163300",
    },
    {
      label: c.conversionRate,
      value: "1.85%",
      change: "+0.3%",
      isPositive: true,
      icon: TrendingUp,
      color: "#9fe870",
    },
  ];

  // Revenue chart data
  const revenueData = [
    { name: language === "ar" ? "السبت" : "Sat", revenue: 3200, orders: 12 },
    { name: language === "ar" ? "الأحد" : "Sun", revenue: 4100, orders: 15 },
    { name: language === "ar" ? "الاثنين" : "Mon", revenue: 3800, orders: 14 },
    { name: language === "ar" ? "الثلاثاء" : "Tue", revenue: 5200, orders: 19 },
    { name: language === "ar" ? "الأربعاء" : "Wed", revenue: 4600, orders: 17 },
    { name: language === "ar" ? "الخميس" : "Thu", revenue: 6100, orders: 22 },
    { name: language === "ar" ? "الجمعة" : "Fri", revenue: 7200, orders: 26 },
  ];

  // Top products data
  const topProducts = [
    { name: "آيفون 14 برو", sales: 45, revenue: 67500 },
    { name: "ساعة ذكية", sales: 38, revenue: 19000 },
    { name: "لابتوب HP", sales: 29, revenue: 43500 },
    { name: "سماعات AirPods", sales: 52, revenue: 26000 },
    { name: "كاميرا كانون", sales: 18, revenue: 36000 },
  ];

  // Traffic sources
  const trafficSources = [
    { source: c.search, percentage: 45, visitors: 3800 },
    { source: c.direct, percentage: 30, visitors: 2530 },
    { source: c.social, percentage: 20, visitors: 1690 },
    { source: c.other, percentage: 5, visitors: 422 },
  ];

  return (
    <div
      className="min-h-screen bg-[#fafafa] pb-6"
      style={{ fontFamily: language === "ar" ? "Cairo, sans-serif" : "system-ui, -apple-system, sans-serif" }}
      dir={isRTL ? "rtl" : "ltr"}
    >
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 z-10"
      >
        <div className="flex items-center justify-between">
          <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
            <ChevronRight className={`w-6 h-6 text-[#0e0f0c] ${isRTL ? "" : "rotate-180"}`} />
          </button>
          <h1 className="text-xl font-semibold text-[#0e0f0c]">{c.analytics}</h1>
          <div className="w-10" />
        </div>
      </motion.div>

      <div className="p-6 space-y-6">
        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
                className="bg-white rounded-[12px] p-4"
              >
                <div className="flex items-center justify-between mb-2">
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center"
                    style={{ backgroundColor: `${stat.color}15` }}
                  >
                    <Icon className="w-5 h-5" style={{ color: stat.color }} />
                  </div>
                  <span
                    className={`text-xs font-semibold ${
                      stat.isPositive ? "text-[#008026]" : "text-[#cb272f]"
                    }`}
                  >
                    {stat.change}
                  </span>
                </div>
                <p className="text-2xl font-bold text-[#0e0f0c] mb-1">
                  {stat.value}
                  {stat.currency && <span className="text-sm text-[#6a6c6a] mr-1">{stat.currency}</span>}
                </p>
                <p className={`text-xs text-[#6a6c6a] ${isRTL ? "text-right" : "text-left"}`}>{stat.label}</p>
              </motion.div>
            );
          })}
        </div>

        {/* Revenue Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-[16px] p-6"
        >
          <h2 className={`text-lg font-bold text-[#0e0f0c] mb-4 ${isRTL ? "text-right" : "text-left"}`}>
            {c.revenueOverTime}
          </h2>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={revenueData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="name" stroke="#6a6c6a" style={{ fontSize: "12px" }} />
              <YAxis stroke="#6a6c6a" style={{ fontSize: "12px" }} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "white",
                  border: "1px solid #e5e7eb",
                  borderRadius: "8px",
                  fontSize: "12px",
                }}
              />
              <Line
                type="monotone"
                dataKey="revenue"
                stroke="#163300"
                strokeWidth={3}
                dot={{ fill: "#163300", r: 4 }}
                activeDot={{ r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Top Products */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white rounded-[16px] p-6"
        >
          <h2 className={`text-lg font-bold text-[#0e0f0c] mb-4 ${isRTL ? "text-right" : "text-left"}`}>
            {c.topProducts}
          </h2>
          <div className="space-y-3">
            {topProducts.map((product, index) => (
              <div
                key={product.name}
                className="flex items-center justify-between py-3 border-b border-[rgba(14,15,12,0.12157)] last:border-0"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-[rgba(22,51,0,0.12157)] flex items-center justify-center">
                    <span className="text-sm font-bold text-[#163300]">{index + 1}</span>
                  </div>
                  <div>
                    <p className={`font-semibold text-[#0e0f0c] text-sm ${isRTL ? "text-right" : "text-left"}`}>
                      {product.name}
                    </p>
                    <p className="text-xs text-[#6a6c6a]">
                      {product.sales} {c.sales}
                    </p>
                  </div>
                </div>
                <span className="font-bold text-[#163300]">
                  {product.revenue.toLocaleString()} {c.sar}
                </span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Traffic Sources */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-white rounded-[16px] p-6"
        >
          <h2 className={`text-lg font-bold text-[#0e0f0c] mb-4 ${isRTL ? "text-right" : "text-left"}`}>
            {c.trafficSources}
          </h2>
          <div className="space-y-4">
            {trafficSources.map((source) => (
              <div key={source.source}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-semibold text-[#0e0f0c]">{source.source}</span>
                  <span className="text-sm text-[#6a6c6a]">
                    {source.percentage}% ({source.visitors.toLocaleString()})
                  </span>
                </div>
                <div className="h-2 bg-[rgba(14,15,12,0.12157)] rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#163300] transition-all"
                    style={{ width: `${source.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Customer Insights */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="grid grid-cols-2 gap-3"
        >
          <div className="bg-white rounded-[12px] p-4">
            <div className="w-10 h-10 rounded-full bg-[rgba(159,232,112,0.2)] flex items-center justify-center mb-3">
              <Users className="w-5 h-5 text-[#163300]" />
            </div>
            <p className="text-2xl font-bold text-[#0e0f0c] mb-1">89</p>
            <p className={`text-xs text-[#6a6c6a] ${isRTL ? "text-right" : "text-left"}`}>{c.newCustomers}</p>
          </div>
          <div className="bg-white rounded-[12px] p-4">
            <div className="w-10 h-10 rounded-full bg-[rgba(159,232,112,0.2)] flex items-center justify-center mb-3">
              <Users className="w-5 h-5 text-[#163300]" />
            </div>
            <p className="text-2xl font-bold text-[#0e0f0c] mb-1">67</p>
            <p className={`text-xs text-[#6a6c6a] ${isRTL ? "text-right" : "text-left"}`}>
              {c.returningCustomers}
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
