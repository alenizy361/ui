/**
 * Storage Test Screen
 * 
 * Quick verification screen to test Supabase Storage setup
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { useAuth } from '../../contexts/AuthContext';
import { useLanguage } from '../../contexts/LanguageContext';
import { uploadProductImage, uploadProfileImage } from '../../services/storage.service';
import { ArrowRight, Upload, CheckCircle2, XCircle, Image as ImageIcon, User } from 'lucide-react';

export default function RabitStorageTestScreen({ onBack }: { onBack: () => void }) {
  const { user } = useAuth();
  const { language } = useLanguage();
  const isRTL = language === 'ar';

  const [productFile, setProductFile] = useState<File | null>(null);
  const [profileFile, setProfileFile] = useState<File | null>(null);
  
  const [productUploading, setProductUploading] = useState(false);
  const [profileUploading, setProfileUploading] = useState(false);
  
  const [productResult, setProductResult] = useState<{ success: boolean; url?: string; error?: string } | null>(null);
  const [profileResult, setProfileResult] = useState<{ success: boolean; url?: string; error?: string } | null>(null);

  const translations = {
    title: {
      ar: 'اختبار التخزين',
      en: 'Storage Test'
    },
    subtitle: {
      ar: 'تحقق من إعداد Supabase Storage',
      en: 'Verify Supabase Storage Setup'
    },
    productImage: {
      ar: 'صورة المنتج',
      en: 'Product Image'
    },
    profileImage: {
      ar: 'صورة الملف الشخصي',
      en: 'Profile Image'
    },
    chooseFile: {
      ar: 'اختر ملف',
      en: 'Choose File'
    },
    upload: {
      ar: 'رفع',
      en: 'Upload'
    },
    uploading: {
      ar: 'جاري الرفع...',
      en: 'Uploading...'
    },
    success: {
      ar: 'نجح!',
      en: 'Success!'
    },
    failed: {
      ar: 'فشل',
      en: 'Failed'
    },
    notAuthenticated: {
      ar: 'يجب تسجيل الدخول أولاً',
      en: 'Please sign in first'
    },
    bucketStatus: {
      ar: 'حالة الحاويات',
      en: 'Bucket Status'
    },
    setupInstructions: {
      ar: 'تعليمات الإعداد',
      en: 'Setup Instructions'
    },
    step1: {
      ar: '1. تأكد من إنشاء الحاويات في Supabase Dashboard',
      en: '1. Ensure buckets are created in Supabase Dashboard'
    },
    step2: {
      ar: '2. قم بتكوين سياسات RLS للحاويات',
      en: '2. Configure RLS policies for buckets'
    },
    step3: {
      ar: '3. اختبر رفع الصور باستخدام هذه الشاشة',
      en: '3. Test image uploads using this screen'
    },
    viewImage: {
      ar: 'عرض الصورة',
      en: 'View Image'
    }
  };

  const t = (key: keyof typeof translations) => translations[key][language];

  const handleProductUpload = async () => {
    if (!productFile) return;
    
    setProductUploading(true);
    setProductResult(null);
    
    try {
      const result = await uploadProductImage(productFile);
      setProductResult(result);
      
      if (result.success) {
        console.log('✅ Product image uploaded:', result.url);
      }
    } catch (error: any) {
      setProductResult({
        success: false,
        error: error.message
      });
    } finally {
      setProductUploading(false);
    }
  };

  const handleProfileUpload = async () => {
    if (!profileFile) return;
    
    setProfileUploading(true);
    setProfileResult(null);
    
    try {
      const result = await uploadProfileImage(profileFile);
      setProfileResult(result);
      
      if (result.success) {
        console.log('✅ Profile image uploaded:', result.url);
      }
    } catch (error: any) {
      setProfileResult({
        success: false,
        error: error.message
      });
    } finally {
      setProfileUploading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8faf9] to-white" dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-2xl mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ArrowRight className={`w-5 h-5 ${isRTL ? '' : 'rotate-180'}`} />
            </button>
            <div>
              <h1 className="text-xl font-semibold text-gray-900">{t('title')}</h1>
              <p className="text-sm text-gray-500">{t('subtitle')}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-2xl mx-auto px-4 py-6">
        {/* Authentication Status */}
        {!user && (
          <div className="mb-6 p-4 bg-yellow-50 border border-yellow-200 rounded-xl">
            <p className="text-sm text-yellow-800 text-center">{t('notAuthenticated')}</p>
          </div>
        )}

        {/* User Info */}
        {user && (
          <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-xl">
            <div className="flex items-center gap-2 text-green-800">
              <CheckCircle2 className="w-5 h-5" />
              <p className="text-sm">
                {language === 'ar' ? 'مسجل الدخول كـ: ' : 'Signed in as: '}
                <strong>{user.email}</strong>
              </p>
            </div>
          </div>
        )}

        {/* Setup Instructions */}
        <div className="mb-6 p-6 bg-blue-50 border border-blue-200 rounded-xl">
          <h2 className="text-lg font-semibold text-blue-900 mb-4">{t('setupInstructions')}</h2>
          <div className="space-y-3 text-sm text-blue-800">
            <p>{t('step1')}</p>
            <ul className={`${isRTL ? 'mr-6' : 'ml-6'} list-disc space-y-1`}>
              <li>product-images (Public, 5MB)</li>
              <li>profile-images (Public, 2MB)</li>
            </ul>
            <p>{t('step2')}</p>
            <p>{t('step3')}</p>
          </div>
        </div>

        {/* Product Image Upload */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6 p-6 bg-white border border-gray-200 rounded-xl shadow-sm"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
              <ImageIcon className="w-5 h-5 text-[#163300]" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900">{t('productImage')}</h3>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t('chooseFile')}
              </label>
              <input
                type="file"
                accept="image/*"
                onChange={(e) => setProductFile(e.target.files?.[0] || null)}
                className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-green-50 file:text-[#163300] hover:file:bg-green-100"
                disabled={!user || productUploading}
              />
            </div>

            {productFile && (
              <button
                onClick={handleProductUpload}
                disabled={productUploading || !user}
                className="w-full py-3 px-4 bg-[#163300] text-white rounded-xl font-medium hover:bg-[#1a3d00] transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                <Upload className="w-5 h-5" />
                {productUploading ? t('uploading') : t('upload')}
              </button>
            )}

            {/* Result */}
            {productResult && (
              <div className={`p-4 rounded-xl ${productResult.success ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'}`}>
                <div className="flex items-start gap-3">
                  {productResult.success ? (
                    <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  ) : (
                    <XCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                  )}
                  <div className="flex-1">
                    <p className={`text-sm font-medium ${productResult.success ? 'text-green-900' : 'text-red-900'}`}>
                      {productResult.success ? t('success') : t('failed')}
                    </p>
                    {productResult.success && productResult.url && (
                      <div className="mt-2">
                        <img src={productResult.url} alt="Uploaded" className="w-32 h-32 object-cover rounded-lg mb-2" />
                        <a
                          href={productResult.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-xs text-green-700 hover:underline"
                        >
                          {t('viewImage')}
                        </a>
                      </div>
                    )}
                    {productResult.error && (
                      <p className="mt-1 text-xs text-red-700 font-mono break-all">{productResult.error}</p>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </motion.div>

        {/* Profile Image Upload */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-6 p-6 bg-white border border-gray-200 rounded-xl shadow-sm"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
              <User className="w-5 h-5 text-blue-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900">{t('profileImage')}</h3>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t('chooseFile')}
              </label>
              <input
                type="file"
                accept="image/*"
                onChange={(e) => setProfileFile(e.target.files?.[0] || null)}
                className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-600 hover:file:bg-blue-100"
                disabled={!user || profileUploading}
              />
            </div>

            {profileFile && (
              <button
                onClick={handleProfileUpload}
                disabled={profileUploading || !user}
                className="w-full py-3 px-4 bg-blue-600 text-white rounded-xl font-medium hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                <Upload className="w-5 h-5" />
                {profileUploading ? t('uploading') : t('upload')}
              </button>
            )}

            {/* Result */}
            {profileResult && (
              <div className={`p-4 rounded-xl ${profileResult.success ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'}`}>
                <div className="flex items-start gap-3">
                  {profileResult.success ? (
                    <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  ) : (
                    <XCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                  )}
                  <div className="flex-1">
                    <p className={`text-sm font-medium ${profileResult.success ? 'text-green-900' : 'text-red-900'}`}>
                      {profileResult.success ? t('success') : t('failed')}
                    </p>
                    {profileResult.success && profileResult.url && (
                      <div className="mt-2">
                        <img src={profileResult.url} alt="Uploaded" className="w-32 h-32 object-cover rounded-full mb-2" />
                        <a
                          href={profileResult.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-xs text-green-700 hover:underline"
                        >
                          {t('viewImage')}
                        </a>
                      </div>
                    )}
                    {profileResult.error && (
                      <p className="mt-1 text-xs text-red-700 font-mono break-all">{profileResult.error}</p>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
