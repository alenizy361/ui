import { motion } from "motion/react";
import { ChevronRight, Plus, CreditCard, Trash2, Check, X } from "lucide-react";
import { useState } from "react";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";

interface PaymentMethod {
  id: string;
  type: "mada" | "visa" | "mastercard";
  last4: string;
  expiryMonth: string;
  expiryYear: string;
  holderName: string;
  isDefault: boolean;
}

interface RabitPaymentMethodsScreenProps {
  onBack: () => void;
  onAddCard: () => void;
}

interface DeleteConfirmationDialogProps {
  isOpen: boolean;
  title: string;
  message: string;
  confirmText: string;
  cancelText: string;
  onConfirm: () => void;
  onCancel: () => void;
}

function DeleteConfirmationDialog({
  isOpen,
  title,
  message,
  confirmText,
  cancelText,
  onConfirm,
  onCancel,
}: DeleteConfirmationDialogProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/50">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className="bg-white rounded-3xl p-6 max-w-sm w-full"
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-[#0a0b09]">{title}</h3>
          <button
            onClick={onCancel}
            className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center"
          >
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>
        <p className="text-[#6a6c6a] text-sm mb-6">{message}</p>
        <div className="flex gap-3">
          <button
            onClick={onCancel}
            className="flex-1 py-3 px-4 bg-gray-100 rounded-2xl font-medium text-[#0a0b09] hover:bg-gray-200 transition-colors"
          >
            {cancelText}
          </button>
          <button
            onClick={onConfirm}
            className="flex-1 py-3 px-4 bg-[#cb272f] rounded-2xl font-medium text-white hover:bg-[#b01f26] transition-colors"
          >
            {confirmText}
          </button>
        </div>
      </motion.div>
    </div>
  );
}

export function RabitPaymentMethodsScreen({ onBack, onAddCard }: RabitPaymentMethodsScreenProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);
  const [cards, setCards] = useState<PaymentMethod[]>([
    {
      id: "1",
      type: "mada",
      last4: "4532",
      expiryMonth: "12",
      expiryYear: "25",
      holderName: "أحمد الراشد",
      isDefault: true,
    },
    {
      id: "2",
      type: "visa",
      last4: "8765",
      expiryMonth: "08",
      expiryYear: "26",
      holderName: "Ahmed Al-Rashid",
      isDefault: false,
    },
  ]);

  const [deleteDialog, setDeleteDialog] = useState<{ isOpen: boolean; cardId: string | null }>({
    isOpen: false,
    cardId: null,
  });

  const setDefaultCard = (cardId: string) => {
    setCards(cards.map(card => ({
      ...card,
      isDefault: card.id === cardId,
    })));
  };

  const handleDelete = () => {
    if (deleteDialog.cardId) {
      setCards(cards.filter(card => card.id !== deleteDialog.cardId));
      setDeleteDialog({ isOpen: false, cardId: null });
    }
  };

  const getCardColor = (type: string) => {
    switch (type) {
      case "mada":
        return "from-[#008026] to-[#163300]";
      case "visa":
        return "from-[#1434CB] to-[#0A1F7D]";
      case "mastercard":
        return "from-[#EB001B] to-[#F79E1B]";
      default:
        return "from-[#163300] to-[#1a3d00]";
    }
  };

  const getCardLogo = (type: string) => {
    switch (type) {
      case "mada":
        return "مدى";
      case "visa":
        return "VISA";
      case "mastercard":
        return "Mastercard";
      default:
        return type.toUpperCase();
    }
  };

  return (
    <div className="min-h-screen bg-white pb-32" style={{ fontFamily: 'Cairo, sans-serif' }}>
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 flex items-center justify-between z-10"
      >
        <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
          <ChevronRight className="w-6 h-6 text-[#0e0f0c]" />
        </button>
        <h1 className="text-xl font-semibold text-[#0e0f0c]">طرق الدفع</h1>
        <div className="w-10" />
      </motion.div>

      <div className="p-6 space-y-4">
        {/* Add New Card Button */}
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          whileTap={{ scale: 0.98 }}
          onClick={onAddCard}
          className="w-full py-4 px-4 bg-[#163300] text-white rounded-[10px] font-medium flex items-center justify-center gap-2"
        >
          <Plus className="w-5 h-5" />
          <span>إضافة بطاقة جديدة</span>
        </motion.button>

        {/* Cards List */}
        {cards.map((card, index) => (
          <motion.div
            key={card.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className="relative"
          >
            {/* Card Design */}
            <div className={`bg-gradient-to-br ${getCardColor(card.type)} rounded-[16px] p-6 text-white relative overflow-hidden`}>
              {/* Background Pattern */}
              <div className="absolute inset-0 opacity-10">
                <div className="absolute top-0 right-0 w-40 h-40 bg-white rounded-full -translate-y-1/2 translate-x-1/2" />
                <div className="absolute bottom-0 left-0 w-32 h-32 bg-white rounded-full translate-y-1/2 -translate-x-1/2" />
              </div>

              {/* Card Content */}
              <div className="relative">
                <div className="flex items-center justify-between mb-8">
                  <CreditCard className="w-10 h-10" />
                  <span className="text-xl font-bold">{getCardLogo(card.type)}</span>
                </div>

                <div className="mb-6">
                  <p className="text-2xl font-mono tracking-wider" dir="ltr">
                    •••• •••• •••• {card.last4}
                  </p>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs opacity-80 mb-1">حامل البطاقة</p>
                    <p className="text-sm font-medium">{card.holderName}</p>
                  </div>
                  <div className="text-left">
                    <p className="text-xs opacity-80 mb-1">ينتهي في</p>
                    <p className="text-sm font-medium" dir="ltr">{card.expiryMonth}/{card.expiryYear}</p>
                  </div>
                </div>
              </div>

              {/* Default Badge */}
              {card.isDefault && (
                <div className="absolute top-4 left-4 bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full flex items-center gap-1">
                  <Check className="w-3 h-3" />
                  <span className="text-xs">الافتراضية</span>
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2 mt-3">
              {!card.isDefault && (
                <button
                  onClick={() => setDefaultCard(card.id)}
                  className="flex-1 py-2 px-4 bg-[rgba(22,51,0,0.07843)] rounded-[8px] text-sm font-medium text-[#163300] hover:bg-[rgba(22,51,0,0.12)] transition-colors"
                >
                  تعيين كافتراضية
                </button>
              )}
              <button
                onClick={() => setDeleteDialog({ isOpen: true, cardId: card.id })}
                className="px-4 py-2 bg-[rgba(203,39,47,0.1)] rounded-[8px] text-sm font-medium text-[#cb272f] hover:bg-[rgba(203,39,47,0.15)] transition-colors"
              >
                حذف
              </button>
            </div>
          </motion.div>
        ))}

        {/* Info Box */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="bg-[rgba(159,232,112,0.1)] rounded-[12px] p-4 mt-6"
        >
          <p className="text-sm text-[#6a6c6a] text-right">
            🔒 جميع بياناتك المالية محمية ومشفرة. نحن لا نحتفظ بمعلومات بطاقتك الائتمانية على خوادمنا.
          </p>
        </motion.div>
      </div>

      {/* Delete Confirmation */}
      <DeleteConfirmationDialog
        isOpen={deleteDialog.isOpen}
        title="حذف البطاقة"
        message="هل أنت متأكد من حذف هذه البطاقة؟ لا يمكن التراجع عن هذا الإجراء."
        confirmText="حذف"
        cancelText="إلغاء"
        onConfirm={handleDelete}
        onCancel={() => setDeleteDialog({ isOpen: false, cardId: null })}
      />
    </div>
  );
}