import { motion } from "motion/react";
import { WiseButton } from "../../components/WiseButton";
import { ChevronRight, CreditCard, Lock } from "lucide-react";
import { useState } from "react";
import { type RabitProduct } from "../../data/rabitProducts";
import { useLanguage } from "../../contexts/LanguageContext";
import { getTranslation } from "../../utils/translations";

export function RabitPaymentScreen({ product, onBack, onPaymentSuccess }: { product: RabitProduct; onBack: () => void; onPaymentSuccess: () => void }) {
  const { language, isRTL } = useLanguage();
  const [selectedPayment, setSelectedPayment] = useState("card");
  const [loading, setLoading] = useState(false);

  const content = {
    ar: {
      payment: "الدفع",
      totalAmount: "المبلغ الإجمالي",
      creditCard: "بطاقة ائتمانية",
      creditCardDesc: "ادفع بأمان باستخدام بطاقتك",
      pay: "ادفع",
    },
    en: {
      payment: "Payment",
      totalAmount: "Total Amount",
      creditCard: "Credit Card",
      creditCardDesc: "Pay securely using your card",
      pay: "Pay",
    },
  };
  const c = content[language];

  const handlePay = () => {
    setLoading(true);
    setTimeout(() => {
      onPaymentSuccess();
    }, 2000);
  };

  return (
    <div 
      className="min-h-screen bg-white flex flex-col" 
      style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 flex items-center gap-4">
        <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
          <ChevronRight className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-semibold text-[#0e0f0c]">{c.payment}</h1>
      </motion.div>
      
      <div className="flex-1 p-6 space-y-6">
        <div className="text-center py-8">
          <p className="text-sm text-[#6a6c6a] mb-2">{c.totalAmount}</p>
          <h1 className="text-5xl font-semibold text-[#0e0f0c]">{product.price.toFixed(2)} ر.س</h1>
        </div>
        
        <div className="space-y-3">
          <button
            key="card"
            onClick={() => setSelectedPayment("card")}
            className={`w-full bg-white rounded-[10px] p-4 flex items-center gap-4 transition-all ${
              selectedPayment === "card" ? "ring-2 ring-[#163300]" : "border border-[rgba(14,15,12,0.12157)]"
            }`}
          >
            <div className={`w-12 h-12 rounded-[10px] flex items-center justify-center ${
              selectedPayment === "card" ? "bg-[#163300]" : "bg-[rgba(22,51,0,0.07843)]"
            }`}>
              <CreditCard className={`w-6 h-6 ${selectedPayment === "card" ? "text-[#9fe870]" : "text-[#163300]"}`} />
            </div>
            <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
              <p className="font-medium text-[#0e0f0c]">{c.creditCard}</p>
              <p className="text-sm text-[#6a6c6a]">{c.creditCardDesc}</p>
            </div>
            <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
              selectedPayment === "card" ? "border-[#163300] bg-[#163300]" : "border-[rgba(14,15,12,0.12157)]"
            }`}>
              {selectedPayment === "card" && <Lock className="w-4 h-4 text-white" />}
            </div>
          </button>
        </div>
      </div>
      
      <div className="sticky bottom-0 bg-white border-t border-[rgba(14,15,12,0.12157)] p-6">
        <WiseButton onClick={handlePay} variant="primary" fullWidth size="lg" loading={loading}>
          {c.pay} {product.price.toFixed(2)} ر.س
        </WiseButton>
      </div>
    </div>
  );
}