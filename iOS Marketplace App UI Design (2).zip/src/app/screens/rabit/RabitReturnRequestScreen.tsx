import { motion } from "motion/react";
import { ChevronRight, AlertCircle, Camera, Package } from "lucide-react";
import { useState } from "react";
import { useLanguage } from "../../contexts/LanguageContext";
import { WiseButton } from "../../components/WiseButton";
import { toast } from "sonner";

interface RabitReturnRequestScreenProps {
  orderNumber: string;
  productName: string;
  productImage: string;
  orderTotal: number;
  onBack: () => void;
  onSubmitSuccess: () => void;
}

export function RabitReturnRequestScreen({
  orderNumber,
  productName,
  productImage,
  orderTotal,
  onBack,
  onSubmitSuccess,
}: RabitReturnRequestScreenProps) {
  const { language, isRTL } = useLanguage();
  const [reason, setReason] = useState("");
  const [description, setDescription] = useState("");
  const [images, setImages] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const content = {
    ar: {
      returnRequest: "طلب إرجاع",
      orderNumber: "رقم الطلب",
      product: "المنتج",
      orderTotal: "إجمالي الطلب",
      selectReason: "اختر سبب الإرجاع",
      reasonPlaceholder: "اختر السبب...",
      reasons: {
        defective: "المنتج معيب أو تالف",
        wrongItem: "تم إرسال المنتج الخطأ",
        notAsDescribed: "المنتج لا يطابق الوصف",
        notFit: "المقاس غير مناسب",
        changedMind: "غيرت رأيي",
        other: "سبب آخر",
      },
      description: "وصف المشكلة",
      descriptionPlaceholder: "اشرح المشكلة بالتفصيل...",
      uploadPhotos: "إرفاق صور (اختياري)",
      uploadPhotosDesc: "أضف صور توضح المشكلة",
      addPhoto: "إضافة صورة",
      returnPolicy: "سياسة الإرجاع:",
      policy1: "يجب تقديم طلب الإرجاع خلال 7 أيام من الاستلام",
      policy2: "المنتج يجب أن يكون بحالته الأصلية",
      policy3: "سيتم مراجعة الطلب خلال 24-48 ساعة",
      policy4: "سيتم استرداد المبلغ خلال 3-5 أيام عمل",
      submitRequest: "إرسال الطلب",
      pleaseSelectReason: "الرجاء اختيار سبب الإرجاع",
      pleaseAddDescription: "الرجاء إضافة وصف للمشكلة",
      requestSubmitted: "تم إرسال طلب الإرجاع بنجاح",
      processing: "جاري الإرسال...",
      refundAmount: "مبلغ الاسترداد",
    },
    en: {
      returnRequest: "Return Request",
      orderNumber: "Order Number",
      product: "Product",
      orderTotal: "Order Total",
      selectReason: "Select Return Reason",
      reasonPlaceholder: "Choose reason...",
      reasons: {
        defective: "Defective or damaged product",
        wrongItem: "Wrong item sent",
        notAsDescribed: "Not as described",
        notFit: "Size doesn't fit",
        changedMind: "Changed my mind",
        other: "Other reason",
      },
      description: "Describe the Issue",
      descriptionPlaceholder: "Explain the problem in detail...",
      uploadPhotos: "Upload Photos (Optional)",
      uploadPhotosDesc: "Add photos showing the issue",
      addPhoto: "Add Photo",
      returnPolicy: "Return Policy:",
      policy1: "Return request must be made within 7 days of delivery",
      policy2: "Product must be in original condition",
      policy3: "Request will be reviewed within 24-48 hours",
      policy4: "Refund will be processed within 3-5 business days",
      submitRequest: "Submit Request",
      pleaseSelectReason: "Please select a return reason",
      pleaseAddDescription: "Please add a description",
      requestSubmitted: "Return request submitted successfully",
      processing: "Submitting...",
      refundAmount: "Refund Amount",
    },
  };
  const c = content[language];

  const reasons = [
    { value: "defective", label: c.reasons.defective },
    { value: "wrongItem", label: c.reasons.wrongItem },
    { value: "notAsDescribed", label: c.reasons.notAsDescribed },
    { value: "notFit", label: c.reasons.notFit },
    { value: "changedMind", label: c.reasons.changedMind },
    { value: "other", label: c.reasons.other },
  ];

  const handleSubmit = () => {
    if (!reason) {
      toast.error(c.pleaseSelectReason);
      return;
    }
    if (!description.trim()) {
      toast.error(c.pleaseAddDescription);
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      toast.success(c.requestSubmitted + " ✓");
      setTimeout(() => {
        onSubmitSuccess();
      }, 1500);
    }, 2000);
  };

  const handleAddPhoto = () => {
    // Mock adding photo
    const mockPhoto = `https://images.unsplash.com/photo-${Date.now() % 1000000000000}?w=200`;
    setImages([...images, mockPhoto]);
  };

  return (
    <div
      className="min-h-screen bg-[#fafafa] pb-32"
      style={{ fontFamily: language === "ar" ? "Cairo, sans-serif" : "system-ui, -apple-system, sans-serif" }}
      dir={isRTL ? "rtl" : "ltr"}
    >
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white border-b border-[rgba(14,15,12,0.12157)] px-6 py-4 z-10"
      >
        <div className="flex items-center justify-between">
          <button onClick={onBack} className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center">
            <ChevronRight className={`w-6 h-6 text-[#0e0f0c] ${isRTL ? "" : "rotate-180"}`} />
          </button>
          <h1 className="text-xl font-semibold text-[#0e0f0c]">{c.returnRequest}</h1>
          <div className="w-10" />
        </div>
      </motion.div>

      <div className="p-6 space-y-6">
        {/* Order Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-[16px] p-4"
        >
          <div className="flex items-center gap-3 mb-4">
            <img src={productImage} alt={productName} className="w-16 h-16 rounded-[8px] object-cover" />
            <div className="flex-1">
              <p className={`font-semibold text-[#0e0f0c] mb-1 ${isRTL ? "text-right" : "text-left"}`}>
                {productName}
              </p>
              <p className="text-sm text-[#6a6c6a]">
                {c.orderNumber}: #{orderNumber}
              </p>
            </div>
          </div>
          <div className="border-t border-[rgba(14,15,12,0.12157)] pt-3 flex items-center justify-between">
            <span className="text-sm text-[#6a6c6a]">{c.refundAmount}</span>
            <span className="font-bold text-[#163300]">{orderTotal.toLocaleString()} ر.س</span>
          </div>
        </motion.div>

        {/* Return Reason */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <label className={`block text-sm font-semibold text-[#0e0f0c] mb-2 ${isRTL ? "text-right" : "text-left"}`}>
            {c.selectReason}
          </label>
          <select
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            className={`w-full px-4 py-3 rounded-[10px] border border-[rgba(14,15,12,0.12157)] bg-white ${isRTL ? "text-right" : "text-left"} focus:outline-none focus:border-[#163300]`}
          >
            <option value="">{c.reasonPlaceholder}</option>
            {reasons.map((r) => (
              <option key={r.value} value={r.value}>
                {r.label}
              </option>
            ))}
          </select>
        </motion.div>

        {/* Description */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <label className={`block text-sm font-semibold text-[#0e0f0c] mb-2 ${isRTL ? "text-right" : "text-left"}`}>
            {c.description}
          </label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder={c.descriptionPlaceholder}
            rows={5}
            className={`w-full px-4 py-3 rounded-[10px] border border-[rgba(14,15,12,0.12157)] ${isRTL ? "text-right" : "text-left"} focus:outline-none focus:border-[#163300] resize-none`}
          />
        </motion.div>

        {/* Upload Photos */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <label className={`block text-sm font-semibold text-[#0e0f0c] mb-2 ${isRTL ? "text-right" : "text-left"}`}>
            {c.uploadPhotos}
          </label>
          <p className={`text-xs text-[#6a6c6a] mb-3 ${isRTL ? "text-right" : "text-left"}`}>
            {c.uploadPhotosDesc}
          </p>
          
          <div className="flex gap-2 flex-wrap">
            {images.map((img, index) => (
              <div key={index} className="relative w-20 h-20">
                <img src={img} alt={`Upload ${index + 1}`} className="w-full h-full rounded-[8px] object-cover" />
                <button
                  onClick={() => setImages(images.filter((_, i) => i !== index))}
                  className="absolute -top-2 -right-2 w-6 h-6 bg-[#cb272f] text-white rounded-full flex items-center justify-center text-xs"
                >
                  ×
                </button>
              </div>
            ))}
            
            {images.length < 5 && (
              <button
                onClick={handleAddPhoto}
                className="w-20 h-20 rounded-[8px] border-2 border-dashed border-[rgba(14,15,12,0.12157)] flex flex-col items-center justify-center gap-1 hover:border-[#163300] transition-colors"
              >
                <Camera className="w-6 h-6 text-[#6a6c6a]" />
                <span className="text-xs text-[#6a6c6a]">{c.addPhoto}</span>
              </button>
            )}
          </div>
        </motion.div>

        {/* Return Policy */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-[rgba(159,232,112,0.1)] rounded-[12px] p-4"
        >
          <div className="flex items-start gap-2 mb-2">
            <AlertCircle className="w-5 h-5 text-[#163300] flex-shrink-0 mt-0.5" />
            <p className={`text-sm font-semibold text-[#163300] ${isRTL ? "text-right" : "text-left"}`}>
              {c.returnPolicy}
            </p>
          </div>
          <ul className={`text-xs text-[#6a6c6a] space-y-1 ${isRTL ? "pr-7 text-right" : "pl-7 text-left"} list-disc`}>
            <li>{c.policy1}</li>
            <li>{c.policy2}</li>
            <li>{c.policy3}</li>
            <li>{c.policy4}</li>
          </ul>
        </motion.div>
      </div>

      {/* Fixed Bottom Button */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-[rgba(14,15,12,0.12157)] px-6 py-4 max-w-[430px] mx-auto">
        <WiseButton
          onClick={handleSubmit}
          variant="primary"
          fullWidth
          loading={isLoading}
          disabled={isLoading || !reason || !description.trim()}
        >
          {isLoading ? c.processing : c.submitRequest}
        </WiseButton>
      </div>
    </div>
  );
}
