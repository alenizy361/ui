import { motion } from "motion/react";
import { ShoppingBag } from "lucide-react";

interface SplashScreenProps {
  onComplete: () => void;
}

export function SplashScreen({ onComplete }: SplashScreenProps) {
  return (
    <motion.div
      initial={{ opacity: 1 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onAnimationComplete={() => setTimeout(onComplete, 1500)}
      className="fixed inset-0 bg-gradient-to-br from-[#163300] via-[#0d1f00] to-[#0e0f0c] flex items-center justify-center"
    >
      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{
          type: "spring",
          stiffness: 200,
          damping: 20,
          delay: 0.2,
        }}
        className="flex flex-col items-center gap-4"
      >
        <motion.div
          animate={{
            rotate: [0, 10, -10, 0],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="w-20 h-20 bg-[#9fe870] rounded-[16px] flex items-center justify-center shadow-2xl"
        >
          <ShoppingBag className="w-10 h-10 text-[#163300]" />
        </motion.div>
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="text-3xl font-semibold text-white"
        >
          Marketplace
        </motion.h1>
      </motion.div>
    </motion.div>
  );
}