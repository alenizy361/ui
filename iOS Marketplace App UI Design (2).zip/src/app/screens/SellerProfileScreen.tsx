import { motion } from "motion/react";
import { ChevronLeft, Star, MapPin, Package } from "lucide-react";
import { Product, products } from "../data/products";
import { useState } from "react";
import { ImageZoomModal } from "../components/ImageZoomModal";

interface SellerProfileScreenProps {
  sellerId: string;
  onBack: () => void;
  onProductClick: (product: Product) => void;
}

export function SellerProfileScreen({
  sellerId,
  onBack,
  onProductClick,
}: SellerProfileScreenProps) {
  const [isAvatarZoomOpen, setIsAvatarZoomOpen] = useState(false);
  const sellerProducts = products.filter((p) => p.seller.id === sellerId);
  const seller = sellerProducts[0]?.seller;

  if (!seller) return null;

  return (
    <div className="min-h-screen bg-[#f8f8f9]">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white border-b border-gray-100 px-6 py-4 flex items-center gap-4 z-10"
      >
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full bg-[#f3f3f5] flex items-center justify-center"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-bold">Seller Profile</h1>
      </motion.div>

      {/* Seller Info */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-white p-6 mb-4"
      >
        <div className="flex items-start gap-4 mb-6">
          <img
            src={seller.avatar}
            alt={seller.name}
            className="w-20 h-20 rounded-full cursor-pointer hover:opacity-80 transition-opacity"
            onClick={() => setIsAvatarZoomOpen(true)}
          />
          <div className="flex-1">
            <h2 className="text-2xl font-bold mb-2">{seller.name}</h2>
            <div className="flex items-center gap-4 text-sm text-gray-600">
              <div className="flex items-center gap-1">
                <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                <span className="font-medium">{seller.rating}</span>
              </div>
              <div className="flex items-center gap-1">
                <Package className="w-4 h-4" />
                <span>{seller.totalSales} sales</span>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4">
          <div className="bg-[#f8f8f9] rounded-[12px] p-4 text-center">
            <div className="text-2xl font-bold mb-1">{sellerProducts.length}</div>
            <div className="text-xs text-gray-600">Products</div>
          </div>
          <div className="bg-[#f8f8f9] rounded-[12px] p-4 text-center">
            <div className="text-2xl font-bold mb-1">{seller.rating}</div>
            <div className="text-xs text-gray-600">Rating</div>
          </div>
          <div className="bg-[#f8f8f9] rounded-[12px] p-4 text-center">
            <div className="text-2xl font-bold mb-1">100%</div>
            <div className="text-xs text-gray-600">Response</div>
          </div>
        </div>
      </motion.div>

      {/* Products */}
      <div className="px-6 pb-6">
        <h3 className="text-lg font-bold mb-4">
          Products ({sellerProducts.length})
        </h3>
        <div className="grid grid-cols-2 gap-4">
          {sellerProducts.map((product, index) => (
            <motion.button
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => onProductClick(product)}
              className="bg-white rounded-[16px] overflow-hidden shadow-sm"
            >
              <div className="relative aspect-square">
                <img
                  src={product.image}
                  alt={product.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-3 text-left">
                <h3 className="font-semibold text-sm mb-1 line-clamp-2">
                  {product.title}
                </h3>
                <span className="text-lg font-bold">${product.price}</span>
              </div>
            </motion.button>
          ))}
        </div>
      </div>

      {/* Avatar Zoom Modal */}
      <ImageZoomModal
        images={[seller.avatar]}
        initialIndex={0}
        isOpen={isAvatarZoomOpen}
        onClose={() => setIsAvatarZoomOpen(false)}
      />
    </div>
  );
}