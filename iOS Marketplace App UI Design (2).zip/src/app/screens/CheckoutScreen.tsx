import { motion } from "motion/react";
import { ChevronLeft, MapPin, Truck, ChevronRight } from "lucide-react";
import { Product } from "../data/products";
import { Button } from "../components/Button";

interface CheckoutScreenProps {
  product: Product;
  onBack: () => void;
  onContinueToPayment: () => void;
}

export function CheckoutScreen({
  product,
  onBack,
  onContinueToPayment,
}: CheckoutScreenProps) {
  const shippingCost = 15;
  const total = product.price + shippingCost;

  return (
    <div className="min-h-screen bg-[#f8f8f9]">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white border-b border-gray-100 px-6 py-4 flex items-center gap-4 z-10"
      >
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full bg-[#f3f3f5] flex items-center justify-center"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-bold">Order Review</h1>
      </motion.div>

      <div className="p-6 space-y-4">
        {/* Product Summary */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-[16px] p-4"
        >
          <h2 className="font-semibold mb-3">Order Summary</h2>
          <div className="flex gap-4">
            <img
              src={product.image}
              alt={product.title}
              className="w-20 h-20 rounded-[12px] object-cover"
            />
            <div className="flex-1">
              <h3 className="font-semibold mb-1">{product.title}</h3>
              <p className="text-sm text-gray-600 mb-2">by {product.seller.name}</p>
              <p className="font-bold">${product.price}</p>
            </div>
          </div>
        </motion.div>

        {/* Shipping Address */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-[16px] p-4"
        >
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-semibold">Shipping Address</h2>
            <button className="text-sm text-[#030213] font-medium">Change</button>
          </div>
          <div className="flex gap-3">
            <div className="w-10 h-10 bg-[#f3f3f5] rounded-[10px] flex items-center justify-center flex-shrink-0">
              <MapPin className="w-5 h-5" />
            </div>
            <div className="text-sm">
              <p className="font-medium mb-1">John Doe</p>
              <p className="text-gray-600">123 King Fahd Road</p>
              <p className="text-gray-600">Riyadh, 12345</p>
              <p className="text-gray-600">+966 50 123 4567</p>
            </div>
          </div>
        </motion.div>

        {/* Shipping Method */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white rounded-[16px] p-4"
        >
          <h2 className="font-semibold mb-3">Shipping Method</h2>
          <button className="w-full bg-[#f8f8f9] rounded-[12px] p-4 flex items-center gap-3">
            <div className="w-10 h-10 bg-white rounded-[10px] flex items-center justify-center">
              <Truck className="w-5 h-5" />
            </div>
            <div className="flex-1 text-left">
              <p className="font-medium">Standard Delivery</p>
              <p className="text-sm text-gray-600">3-5 business days</p>
            </div>
            <div className="text-right">
              <p className="font-bold">${shippingCost}</p>
            </div>
          </button>
        </motion.div>

        {/* Price Breakdown */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-white rounded-[16px] p-4"
        >
          <h2 className="font-semibold mb-3">Price Details</h2>
          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Product Price</span>
              <span className="font-medium">${product.price}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Shipping</span>
              <span className="font-medium">${shippingCost}</span>
            </div>
            <div className="pt-3 border-t border-gray-100 flex justify-between">
              <span className="font-semibold">Total</span>
              <span className="font-bold text-xl">${total}</span>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Bottom CTA */}
      <motion.div
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 p-6 safe-area-bottom"
      >
        <div className="flex items-center justify-between mb-4">
          <span className="text-gray-600">Total Amount</span>
          <span className="text-2xl font-bold">${total}</span>
        </div>
        <Button onClick={onContinueToPayment} variant="primary" fullWidth>
          Continue to Payment
        </Button>
      </motion.div>
    </div>
  );
}
