import { motion } from "motion/react";
import { ChevronLeft, Heart, Share2, Star } from "lucide-react";
import { useState } from "react";
import { Product } from "../data/products";
import { Button } from "../components/Button";
import { ImageZoomModal } from "../components/ImageZoomModal";

interface ProductDetailScreenProps {
  product: Product;
  onBack: () => void;
  onBuyNow: (product: Product) => void;
  onSellerClick: (sellerId: string) => void;
}

export function ProductDetailScreen({
  product,
  onBack,
  onBuyNow,
  onSellerClick,
}: ProductDetailScreenProps) {
  const [currentImage, setCurrentImage] = useState(0);
  const [liked, setLiked] = useState(false);
  const [isZoomModalOpen, setIsZoomModalOpen] = useState(false);
  const images = [product.image, product.image, product.image]; // Demo: same image 3 times

  return (
    <div className="min-h-screen bg-white">
      {/* Image Carousel */}
      <div className="relative">
        <div
          className="aspect-square bg-[#f8f8f9] overflow-hidden cursor-pointer"
          onClick={() => setIsZoomModalOpen(true)}
        >
          <motion.div
            key={currentImage}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <img
              src={images[currentImage]}
              alt={product.title}
              className="w-full h-full object-cover"
            />
          </motion.div>
        </div>

        {/* Top Bar */}
        <div className="absolute top-0 left-0 right-0 flex items-center justify-between p-4">
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center shadow-lg"
          >
            <ChevronLeft className="w-6 h-6" />
          </motion.button>
          <div className="flex gap-2">
            <motion.button
              whileTap={{ scale: 0.95 }}
              className="w-10 h-10 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center shadow-lg"
            >
              <Share2 className="w-5 h-5" />
            </motion.button>
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={() => setLiked(!liked)}
              className="w-10 h-10 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center shadow-lg"
            >
              <Heart
                className={`w-5 h-5 ${liked ? "fill-red-500 text-red-500" : ""}`}
              />
            </motion.button>
          </div>
        </div>

        {/* Image Indicators */}
        <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2">
          {images.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentImage(index)}
              className={`h-1.5 rounded-full transition-all ${
                currentImage === index
                  ? "w-8 bg-white"
                  : "w-1.5 bg-white/50"
              }`}
            />
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          {/* Price & Title */}
          <div className="mb-6">
            <div className="flex items-start justify-between mb-2">
              <h1 className="text-2xl font-bold flex-1">{product.title}</h1>
              <div className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-medium">
                {product.condition}
              </div>
            </div>
            <div className="flex items-center gap-2 mb-3">
              <span className="text-3xl font-bold">${product.price}</span>
            </div>
            <p className="text-sm text-gray-600">{product.city}</p>
          </div>

          {/* Seller Card */}
          <motion.button
            whileTap={{ scale: 0.98 }}
            onClick={() => onSellerClick(product.seller.id)}
            className="w-full bg-[#f8f8f9] rounded-[16px] p-4 flex items-center gap-4 mb-6"
          >
            <img
              src={product.seller.avatar}
              alt={product.seller.name}
              className="w-12 h-12 rounded-full"
            />
            <div className="flex-1 text-left">
              <h3 className="font-semibold">{product.seller.name}</h3>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  <span>{product.seller.rating}</span>
                </div>
                <span>•</span>
                <span>{product.seller.totalSales} sales</span>
              </div>
            </div>
            <ChevronLeft className="w-5 h-5 rotate-180 text-gray-400" />
          </motion.button>

          {/* Description */}
          <div className="mb-6">
            <h2 className="text-lg font-semibold mb-3">Description</h2>
            <p className="text-gray-700 leading-relaxed">{product.description}</p>
          </div>

          {/* Specs */}
          <div className="mb-6">
            <h2 className="text-lg font-semibold mb-3">Specifications</h2>
            <div className="space-y-3">
              {product.specs.map((spec, index) => (
                <div
                  key={index}
                  className="flex justify-between py-3 border-b border-gray-100 last:border-0"
                >
                  <span className="text-gray-600">{spec.label}</span>
                  <span className="font-medium">{spec.value}</span>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>

      {/* Bottom CTA */}
      <motion.div
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 p-6 safe-area-bottom"
      >
        <Button onClick={() => onBuyNow(product)} variant="primary" fullWidth>
          Buy Now
        </Button>
      </motion.div>

      {/* Image Zoom Modal */}
      <ImageZoomModal
        images={images}
        initialIndex={currentImage}
        isOpen={isZoomModalOpen}
        onClose={() => setIsZoomModalOpen(false)}
      />
    </div>
  );
}