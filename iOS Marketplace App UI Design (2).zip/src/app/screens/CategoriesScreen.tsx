import { motion } from "motion/react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { categories } from "../data/products";

interface CategoriesScreenProps {
  onBack: () => void;
  onCategorySelect: (category: string) => void;
}

export function CategoriesScreen({
  onBack,
  onCategorySelect,
}: CategoriesScreenProps) {
  return (
    <div className="min-h-screen bg-white">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white border-b border-gray-100 px-6 py-4 flex items-center gap-4"
      >
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full bg-[#f3f3f5] flex items-center justify-center"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-bold">All Categories</h1>
      </motion.div>

      <div className="p-6">
        <div className="grid grid-cols-2 gap-4">
          {categories.map((category, index) => (
            <motion.button
              key={category.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => {
                onCategorySelect(category.name);
                onBack();
              }}
              className="bg-gradient-to-br from-[#f8f8f9] to-white rounded-[20px] p-6 flex flex-col items-center gap-3 shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="text-5xl">{category.icon}</div>
              <span className="font-semibold">{category.name}</span>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </motion.button>
          ))}
        </div>
      </div>
    </div>
  );
}
