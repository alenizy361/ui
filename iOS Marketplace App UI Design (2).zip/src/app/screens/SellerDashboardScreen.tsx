import { motion } from "motion/react";
import { ChevronLeft, Package, TrendingUp, DollarSign } from "lucide-react";
import { Button } from "../components/Button";
import { useState } from "react";

interface Sale {
  id: string;
  orderNumber: string;
  productTitle: string;
  productImage: string;
  salePrice: number;
  shippingCost: number;
  serviceFee: number;
  netPayout: number;
  status: "paid" | "shipped" | "completed";
  buyer: string;
  date: string;
}

interface SellerDashboardScreenProps {
  onBack: () => void;
}

export function SellerDashboardScreen({ onBack }: SellerDashboardScreenProps) {
  const [sales] = useState<Sale[]>([
    {
      id: "1",
      orderNumber: "MPL-2024-S001",
      productTitle: "iPhone 14 Pro Max",
      productImage: "https://images.unsplash.com/photo-1758186355698-bd0183fc75ed?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBlbGVjdHJvbmljcyUyMHNtYXJ0cGhvbmV8ZW58MXx8fHwxNzY2NzUwNTUxfDA&ixlib=rb-4.1.0&q=80&w=1080",
      salePrice: 899,
      shippingCost: 15,
      serviceFee: 44.95,
      netPayout: 869.05,
      status: "paid",
      buyer: "John D.",
      date: "Dec 26, 2024",
    },
    {
      id: "2",
      orderNumber: "MPL-2024-S002",
      productTitle: "Apple Watch Series 8",
      productImage: "https://images.unsplash.com/photo-1719744755507-a4c856c57cf7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbWFydHdhdGNoJTIwd2VhcmFibGV8ZW58MXx8fHwxNzY2NzIyMjU3fDA&ixlib=rb-4.1.0&q=80&w=1080",
      salePrice: 399,
      shippingCost: 10,
      serviceFee: 19.95,
      netPayout: 389.05,
      status: "shipped",
      buyer: "Sarah M.",
      date: "Dec 25, 2024",
    },
  ]);

  const totalRevenue = sales.reduce((sum, sale) => sum + sale.salePrice, 0);
  const totalPayout = sales.reduce((sum, sale) => sum + sale.netPayout, 0);

  const handleShip = (saleId: string) => {
    alert(`Shipping label generated for order ${saleId}`);
  };

  return (
    <div className="min-h-screen bg-[#f8f8f9]">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white border-b border-gray-100 px-6 py-4 z-10"
      >
        <div className="flex items-center gap-4">
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-[#f3f3f5] flex items-center justify-center"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-bold">Seller Dashboard</h1>
        </div>
      </motion.div>

      <div className="p-6 space-y-4">
        {/* Stats Cards */}
        <div className="grid grid-cols-2 gap-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-[16px] p-4 text-white"
          >
            <TrendingUp className="w-6 h-6 mb-2 opacity-80" />
            <p className="text-sm opacity-90 mb-1">Total Sales</p>
            <p className="text-2xl font-bold">{sales.length}</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-gradient-to-br from-green-500 to-green-600 rounded-[16px] p-4 text-white"
          >
            <DollarSign className="w-6 h-6 mb-2 opacity-80" />
            <p className="text-sm opacity-90 mb-1">Net Payout</p>
            <p className="text-2xl font-bold">${totalPayout.toFixed(0)}</p>
          </motion.div>
        </div>

        {/* Sales List */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <h2 className="font-semibold mb-3">Recent Sales</h2>
          <div className="space-y-3">
            {sales.map((sale, index) => (
              <motion.div
                key={sale.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 + index * 0.1 }}
                className="bg-white rounded-[16px] p-4 shadow-sm"
              >
                <div className="flex gap-4 mb-4">
                  <img
                    src={sale.productImage}
                    alt={sale.productTitle}
                    className="w-20 h-20 rounded-[12px] object-cover"
                  />
                  <div className="flex-1">
                    <h3 className="font-semibold mb-1">{sale.productTitle}</h3>
                    <p className="text-sm text-gray-600 mb-2">
                      Buyer: {sale.buyer}
                    </p>
                    <p className="text-xs text-gray-500">{sale.orderNumber}</p>
                  </div>
                </div>

                {/* Financial Breakdown */}
                <div className="bg-[#f8f8f9] rounded-[12px] p-3 mb-3 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Sale Price</span>
                    <span className="font-medium">${sale.salePrice}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Shipping (buyer pays)</span>
                    <span className="font-medium text-green-600">
                      +${sale.shippingCost}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Platform Fee (5%)</span>
                    <span className="font-medium text-red-600">
                      -${sale.serviceFee}
                    </span>
                  </div>
                  <div className="pt-2 border-t border-gray-200 flex justify-between">
                    <span className="font-semibold">Net Payout</span>
                    <span className="font-bold text-lg text-green-600">
                      ${sale.netPayout}
                    </span>
                  </div>
                </div>

                {/* Actions */}
                {sale.status === "paid" && (
                  <Button
                    onClick={() => handleShip(sale.id)}
                    variant="primary"
                    fullWidth
                  >
                    <Package className="w-5 h-5" />
                    Ship Now
                  </Button>
                )}

                {sale.status === "shipped" && (
                  <div className="bg-blue-50 text-blue-700 rounded-[12px] px-4 py-3 text-center font-medium">
                    ✓ Shipped - Awaiting Delivery
                  </div>
                )}

                {sale.status === "completed" && (
                  <div className="bg-green-50 text-green-700 rounded-[12px] px-4 py-3 text-center font-medium">
                    ✓ Completed - Payment Released
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
