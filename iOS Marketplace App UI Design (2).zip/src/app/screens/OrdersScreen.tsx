import { motion } from "motion/react";
import { ChevronLeft, Package, Clock, Truck, CheckCircle2 } from "lucide-react";
import { useState } from "react";

interface Order {
  id: string;
  orderNumber: string;
  productTitle: string;
  productImage: string;
  price: number;
  status: "paid" | "shipped" | "delivered" | "completed";
  date: string;
  seller: string;
}

interface OrdersScreenProps {
  onBack: () => void;
  onOrderClick: (order: Order) => void;
  onSellerDashboard: () => void;
}

export function OrdersScreen({
  onBack,
  onOrderClick,
  onSellerDashboard,
}: OrdersScreenProps) {
  const [activeTab, setActiveTab] = useState<"buying" | "selling">("buying");

  const orders: Order[] = [
    {
      id: "1",
      orderNumber: "MPL-2024-001",
      productTitle: "iPhone 14 Pro Max",
      productImage: "https://images.unsplash.com/photo-1758186355698-bd0183fc75ed?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBlbGVjdHJvbmljcyUyMHNtYXJ0cGhvbmV8ZW58MXx8fHwxNzY2NzUwNTUxfDA&ixlib=rb-4.1.0&q=80&w=1080",
      price: 919.99,
      status: "paid",
      date: "Dec 26, 2024",
      seller: "TechStore",
    },
    {
      id: "2",
      orderNumber: "MPL-2024-002",
      productTitle: "MacBook Pro 14\" M2",
      productImage: "https://images.unsplash.com/flagged/photo-1576697010739-6373b63f3204?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsYXB0b3AlMjBjb21wdXRlciUyMGRlc2t8ZW58MXx8fHwxNzY2Njg1ODc5fDA&ixlib=rb-4.1.0&q=80&w=1080",
      price: 1919.99,
      status: "shipped",
      date: "Dec 24, 2024",
      seller: "AppleHub",
    },
    {
      id: "3",
      orderNumber: "MPL-2024-003",
      productTitle: "Sony WH-1000XM5 Headphones",
      productImage: "https://images.unsplash.com/photo-1765279339828-bb765f3631c8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3aXJlbGVzcyUyMGhlYWRwaG9uZXMlMjBwcmVtaXVtfGVufDF8fHx8MTc2NjcxMDQ1NHww&ixlib=rb-4.1.0&q=80&w=1080",
      price: 344.99,
      status: "delivered",
      date: "Dec 20, 2024",
      seller: "AudioPro",
    },
  ];

  const statusConfig = {
    paid: {
      icon: Clock,
      label: "Paid",
      color: "bg-blue-100 text-blue-700",
    },
    shipped: {
      icon: Truck,
      label: "Shipped",
      color: "bg-purple-100 text-purple-700",
    },
    delivered: {
      icon: Package,
      label: "Delivered",
      color: "bg-orange-100 text-orange-700",
    },
    completed: {
      icon: CheckCircle2,
      label: "Completed",
      color: "bg-green-100 text-green-700",
    },
  };

  return (
    <div className="min-h-screen bg-[#f8f8f9]">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white border-b border-gray-100 px-6 py-4 z-10"
      >
        <div className="flex items-center gap-4 mb-4">
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-[#f3f3f5] flex items-center justify-center"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-bold">My Orders</h1>
        </div>

        {/* Tabs */}
        <div className="flex gap-2">
          <button
            onClick={() => setActiveTab("buying")}
            className={`flex-1 py-2 rounded-[10px] font-medium transition-all ${
              activeTab === "buying"
                ? "bg-[#030213] text-white"
                : "bg-[#f3f3f5] text-gray-600"
            }`}
          >
            Buying
          </button>
          <button
            onClick={() => {
              setActiveTab("selling");
              onSellerDashboard();
            }}
            className={`flex-1 py-2 rounded-[10px] font-medium transition-all ${
              activeTab === "selling"
                ? "bg-[#030213] text-white"
                : "bg-[#f3f3f5] text-gray-600"
            }`}
          >
            Selling
          </button>
        </div>
      </motion.div>

      {/* Orders List */}
      <div className="p-6 space-y-4">
        {orders.map((order, index) => {
          const status = statusConfig[order.status];
          const StatusIcon = status.icon;

          return (
            <motion.button
              key={order.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => onOrderClick(order)}
              className="w-full bg-white rounded-[16px] p-4 shadow-sm"
            >
              <div className="flex gap-4 mb-3">
                <img
                  src={order.productImage}
                  alt={order.productTitle}
                  className="w-20 h-20 rounded-[12px] object-cover"
                />
                <div className="flex-1 text-left">
                  <h3 className="font-semibold mb-1">{order.productTitle}</h3>
                  <p className="text-sm text-gray-600 mb-2">by {order.seller}</p>
                  <p className="font-bold">${order.price}</p>
                </div>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                <div className="flex items-center gap-2">
                  <div className={`px-3 py-1.5 rounded-full flex items-center gap-2 ${status.color}`}>
                    <StatusIcon className="w-4 h-4" />
                    <span className="text-sm font-medium">{status.label}</span>
                  </div>
                </div>
                <span className="text-sm text-gray-600">{order.date}</span>
              </div>
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}
