import { motion } from "motion/react";
import { WiseButton } from "../components/WiseButton";
import { WiseInput } from "../components/WiseInput";
import { ChevronLeft } from "lucide-react";
import { useState } from "react";

interface PhoneScreenProps {
  onBack: () => void;
  onContinue: (phone: string) => void;
}

export function PhoneScreen({ onBack, onContinue }: PhoneScreenProps) {
  const [phone, setPhone] = useState("");
  const [loading, setLoading] = useState(false);

  const handleContinue = () => {
    if (phone.length >= 9) {
      setLoading(true);
      setTimeout(() => {
        onContinue(phone);
      }, 1500);
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col p-6">
      <motion.button
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        onClick={onBack}
        className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center mb-8 text-[#0e0f0c]"
        whileTap={{ scale: 0.95 }}
      >
        <ChevronLeft className="w-6 h-6" />
      </motion.button>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-semibold mb-3 text-[#0e0f0c]">Enter your phone number</h1>
        <p className="text-[#6a6c6a]">
          We'll send you a verification code to confirm your number
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="flex-1"
      >
        <div className="mb-6">
          <label className="block text-sm font-medium text-[#0e0f0c] mb-2">Phone Number</label>
          <div className="flex gap-3">
            <div className="w-20 h-[48px] bg-[rgba(22,51,0,0.07843)] rounded-[10px] flex items-center justify-center border border-transparent">
              <span className="font-medium text-[#0e0f0c]">+966</span>
            </div>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value.replace(/\D/g, ""))}
              placeholder="50 123 4567"
              className="flex-1 h-[48px] bg-[rgba(22,51,0,0.07843)] rounded-[10px] px-4 outline-none focus:ring-2 focus:ring-[#163300] transition-all text-[#0e0f0c] placeholder:text-[#6a6c6a] border border-transparent focus:bg-white"
              maxLength={9}
            />
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <WiseButton
          onClick={handleContinue}
          variant="primary"
          fullWidth
          size="lg"
          loading={loading}
          disabled={phone.length < 9}
        >
          Continue
        </WiseButton>
      </motion.div>
    </div>
  );
}