import { motion } from "motion/react";
import { ChevronLeft, MapPin, Package, Truck, CheckCircle2 } from "lucide-react";
import { Button } from "../components/Button";

interface Order {
  id: string;
  orderNumber: string;
  productTitle: string;
  productImage: string;
  price: number;
  status: "paid" | "shipped" | "delivered" | "completed";
  date: string;
  seller: string;
}

interface OrderDetailScreenProps {
  order: Order;
  onBack: () => void;
}

export function OrderDetailScreen({ order, onBack }: OrderDetailScreenProps) {
  const trackingSteps = [
    {
      icon: CheckCircle2,
      label: "Order Placed",
      date: "Dec 26, 10:30 AM",
      completed: true,
    },
    {
      icon: Package,
      label: "Payment Confirmed",
      date: "Dec 26, 10:31 AM",
      completed: true,
    },
    {
      icon: Truck,
      label: "Shipped",
      date: order.status === "paid" ? "Pending" : "Dec 26, 2:15 PM",
      completed: order.status !== "paid",
    },
    {
      icon: MapPin,
      label: "Delivered",
      date: "Estimated Dec 29",
      completed: false,
    },
  ];

  return (
    <div className="min-h-screen bg-[#f8f8f9]">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white border-b border-gray-100 px-6 py-4 flex items-center gap-4 z-10"
      >
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full bg-[#f3f3f5] flex items-center justify-center"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-bold">Order Details</h1>
      </motion.div>

      <div className="p-6 space-y-4">
        {/* Order Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-[16px] p-4"
        >
          <div className="flex gap-4 mb-4">
            <img
              src={order.productImage}
              alt={order.productTitle}
              className="w-24 h-24 rounded-[12px] object-cover"
            />
            <div className="flex-1">
              <h3 className="font-semibold mb-1">{order.productTitle}</h3>
              <p className="text-sm text-gray-600 mb-2">by {order.seller}</p>
              <p className="font-bold text-xl">${order.price}</p>
            </div>
          </div>
          <div className="pt-4 border-t border-gray-100">
            <div className="flex justify-between text-sm mb-1">
              <span className="text-gray-600">Order Number</span>
              <span className="font-medium">{order.orderNumber}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Order Date</span>
              <span className="font-medium">{order.date}</span>
            </div>
          </div>
        </motion.div>

        {/* Tracking */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-[16px] p-6"
        >
          <h2 className="font-semibold mb-6">Order Tracking</h2>
          <div className="space-y-6">
            {trackingSteps.map((step, index) => {
              const StepIcon = step.icon;
              const isLast = index === trackingSteps.length - 1;

              return (
                <div key={index} className="flex gap-4 relative">
                  {/* Timeline Line */}
                  {!isLast && (
                    <div
                      className={`absolute left-6 top-12 w-0.5 h-full -translate-x-1/2 ${
                        step.completed ? "bg-[#030213]" : "bg-gray-200"
                      }`}
                    />
                  )}

                  {/* Icon */}
                  <div
                    className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 relative z-10 ${
                      step.completed
                        ? "bg-[#030213] text-white"
                        : "bg-gray-100 text-gray-400"
                    }`}
                  >
                    <StepIcon className="w-6 h-6" />
                  </div>

                  {/* Content */}
                  <div className="flex-1 pt-2">
                    <h3
                      className={`font-semibold mb-1 ${
                        step.completed ? "text-gray-900" : "text-gray-400"
                      }`}
                    >
                      {step.label}
                    </h3>
                    <p
                      className={`text-sm ${
                        step.completed ? "text-gray-600" : "text-gray-400"
                      }`}
                    >
                      {step.date}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </motion.div>

        {/* Shipping Address */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white rounded-[16px] p-4"
        >
          <h2 className="font-semibold mb-3">Shipping Address</h2>
          <div className="flex gap-3">
            <div className="w-10 h-10 bg-[#f3f3f5] rounded-[10px] flex items-center justify-center flex-shrink-0">
              <MapPin className="w-5 h-5" />
            </div>
            <div className="text-sm">
              <p className="font-medium mb-1">John Doe</p>
              <p className="text-gray-600">123 King Fahd Road</p>
              <p className="text-gray-600">Riyadh, 12345</p>
              <p className="text-gray-600">+966 50 123 4567</p>
            </div>
          </div>
        </motion.div>

        {/* Contact Seller */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Button variant="secondary" fullWidth>
            Contact Seller
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
