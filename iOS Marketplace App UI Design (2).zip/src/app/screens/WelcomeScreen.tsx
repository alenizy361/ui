import { motion } from "motion/react";
import { WiseButton } from "../components/WiseButton";
import { ShoppingBag, Package, Shield, Zap } from "lucide-react";

interface WelcomeScreenProps {
  onGetStarted: () => void;
}

export function WelcomeScreen({ onGetStarted }: WelcomeScreenProps) {
  const features = [
    {
      icon: Package,
      title: "Buy & Sell",
      description: "Discover unique items from trusted sellers",
    },
    {
      icon: Shield,
      title: "Secure Payments",
      description: "Protected transactions with buyer guarantee",
    },
    {
      icon: Zap,
      title: "Fast Delivery",
      description: "Track your orders in real-time",
    },
  ];

  return (
    <div className="min-h-screen bg-white flex flex-col p-6">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="flex justify-center mt-12 mb-8"
      >
        <div className="w-20 h-20 bg-[#163300] rounded-[16px] flex items-center justify-center shadow-lg">
          <ShoppingBag className="w-10 h-10 text-[#9fe870]" />
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="text-center mb-12"
      >
        <h1 className="text-4xl font-semibold mb-3 text-[#0e0f0c]">Welcome to Marketplace</h1>
        <p className="text-[#6a6c6a]">
          Your premium destination for buying and selling quality products
        </p>
      </motion.div>

      <div className="flex-1 space-y-6 mb-8">
        {features.map((feature, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 + index * 0.1 }}
            className="bg-[rgba(22,51,0,0.07843)] rounded-[10px] p-6 flex gap-4 border border-[rgba(14,15,12,0.12157)]"
          >
            <div className="w-12 h-12 bg-white rounded-[10px] flex items-center justify-center flex-shrink-0 border border-[rgba(14,15,12,0.12157)]">
              <feature.icon className="w-6 h-6 text-[#163300]" />
            </div>
            <div>
              <h3 className="font-medium mb-1 text-[#0e0f0c]">{feature.title}</h3>
              <p className="text-sm text-[#6a6c6a]">{feature.description}</p>
            </div>
          </motion.div>
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
      >
        <WiseButton onClick={onGetStarted} variant="primary" fullWidth size="lg">
          Get Started
        </WiseButton>
        <p className="text-center text-xs text-[#6a6c6a] mt-4">
          By continuing, you agree to our Terms & Privacy Policy
        </p>
      </motion.div>
    </div>
  );
}