import { motion } from "motion/react";
import { WiseButton } from "../components/WiseButton";
import { ChevronLeft } from "lucide-react";
import { useState, useRef, useEffect } from "react";

interface OTPScreenProps {
  onBack: () => void;
  onVerify: () => void;
  phone: string;
}

export function OTPScreen({ onBack, onVerify, phone }: OTPScreenProps) {
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [loading, setLoading] = useState(false);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    inputRefs.current[0]?.focus();
  }, []);

  const handleChange = (index: number, value: string) => {
    if (value.length > 1) return;
    if (!/^\d*$/.test(value)) return;

    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handleVerify = () => {
    if (otp.every((digit) => digit !== "")) {
      setLoading(true);
      setTimeout(() => {
        onVerify();
      }, 1500);
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col p-6">
      <motion.button
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        onClick={onBack}
        className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center mb-8 text-[#0e0f0c] hover:bg-[rgba(22,51,0,0.12941)] transition-colors"
        whileTap={{ scale: 0.95 }}
      >
        <ChevronLeft className="w-6 h-6" />
      </motion.button>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-semibold mb-3 text-[#0e0f0c]">Enter verification code</h1>
        <p className="text-[#6a6c6a]">
          We sent a code to +966 {phone}
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="flex-1"
      >
        <div className="flex gap-3 justify-center mb-8">
          {otp.map((digit, index) => (
            <motion.input
              key={index}
              ref={(el) => (inputRefs.current[index] = el)}
              type="text"
              inputMode="numeric"
              value={digit}
              onChange={(e) => handleChange(index, e.target.value)}
              onKeyDown={(e) => handleKeyDown(index, e)}
              className="w-12 h-14 bg-[rgba(22,51,0,0.07843)] rounded-[10px] text-center text-xl font-semibold outline-none focus:ring-2 focus:ring-[#163300] transition-all text-[#0e0f0c] border border-transparent focus:bg-white"
              maxLength={1}
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: index * 0.05 }}
            />
          ))}
        </div>

        <div className="text-center">
          <button className="text-sm text-[#6a6c6a]">
            Didn't receive code?{" "}
            <span className="text-[#163300] font-medium hover:text-[#0d1f00] transition-colors">Resend</span>
          </button>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <WiseButton
          onClick={handleVerify}
          variant="primary"
          fullWidth
          size="lg"
          loading={loading}
          disabled={otp.some((digit) => digit === "")}
        >
          Verify
        </WiseButton>
      </motion.div>
    </div>
  );
}