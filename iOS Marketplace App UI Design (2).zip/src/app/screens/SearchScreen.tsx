import { motion } from "motion/react";
import { ChevronLeft, Search, SlidersHorizontal, X } from "lucide-react";
import { useState } from "react";
import { Product, products, categories } from "../data/products";
import { BottomSheet } from "../components/BottomSheet";
import { Button } from "../components/Button";

interface SearchScreenProps {
  onBack: () => void;
  onProductClick: (product: Product) => void;
}

export function SearchScreen({ onBack, onProductClick }: SearchScreenProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    category: "",
    priceMin: "",
    priceMax: "",
    city: "",
    condition: "",
  });

  const filteredProducts = products.filter((product) => {
    const matchesSearch = product.title
      .toLowerCase()
      .includes(searchQuery.toLowerCase());
    const matchesCategory = !filters.category || product.category === filters.category;
    const matchesCity = !filters.city || product.city === filters.city;
    const matchesCondition = !filters.condition || product.condition === filters.condition;
    const matchesPriceMin = !filters.priceMin || product.price >= Number(filters.priceMin);
    const matchesPriceMax = !filters.priceMax || product.price <= Number(filters.priceMax);

    return (
      matchesSearch &&
      matchesCategory &&
      matchesCity &&
      matchesCondition &&
      matchesPriceMin &&
      matchesPriceMax
    );
  });

  const cities = ["Riyadh", "Jeddah", "Dubai", "Abu Dhabi"];
  const hasActiveFilters = Object.values(filters).some((v) => v !== "");

  return (
    <div className="min-h-screen bg-[#f8f8f9]">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 bg-white border-b border-gray-100 px-6 py-4"
      >
        <div className="flex items-center gap-3 mb-3">
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-[#f3f3f5] flex items-center justify-center"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search products..."
              className="w-full h-11 bg-[#f3f3f5] rounded-[12px] pl-11 pr-4 outline-none focus:ring-2 focus:ring-[#030213] transition-all"
              autoFocus
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="absolute right-3 top-1/2 -translate-y-1/2"
              >
                <X className="w-5 h-5 text-gray-400" />
              </button>
            )}
          </div>
          <button
            onClick={() => setShowFilters(true)}
            className={`w-11 h-11 rounded-full flex items-center justify-center relative ${
              hasActiveFilters ? "bg-[#030213] text-white" : "bg-[#f3f3f5]"
            }`}
          >
            <SlidersHorizontal className="w-5 h-5" />
            {hasActiveFilters && (
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full" />
            )}
          </button>
        </div>
      </motion.div>

      <div className="p-6">
        <p className="text-sm text-gray-600 mb-4">
          {filteredProducts.length} products found
        </p>

        <div className="grid grid-cols-2 gap-4">
          {filteredProducts.map((product, index) => (
            <motion.button
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => onProductClick(product)}
              className="bg-white rounded-[16px] overflow-hidden shadow-sm"
            >
              <div className="relative aspect-square">
                <img
                  src={product.image}
                  alt={product.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-3 text-left">
                <h3 className="font-semibold text-sm mb-1 line-clamp-2">
                  {product.title}
                </h3>
                <p className="text-xs text-gray-600 mb-2">{product.city}</p>
                <span className="text-lg font-bold">${product.price}</span>
              </div>
            </motion.button>
          ))}
        </div>
      </div>

      {/* Filters Bottom Sheet */}
      <BottomSheet
        isOpen={showFilters}
        onClose={() => setShowFilters(false)}
        title="Filters"
      >
        <div className="space-y-6 pb-6">
          <div>
            <label className="block text-sm font-medium mb-2">Category</label>
            <select
              value={filters.category}
              onChange={(e) => setFilters({ ...filters, category: e.target.value })}
              className="w-full h-12 bg-[#f3f3f5] rounded-[12px] px-4 outline-none"
            >
              <option value="">All Categories</option>
              {categories.map((cat) => (
                <option key={cat.id} value={cat.name}>
                  {cat.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Price Range</label>
            <div className="flex gap-3">
              <input
                type="number"
                placeholder="Min"
                value={filters.priceMin}
                onChange={(e) => setFilters({ ...filters, priceMin: e.target.value })}
                className="flex-1 h-12 bg-[#f3f3f5] rounded-[12px] px-4 outline-none"
              />
              <input
                type="number"
                placeholder="Max"
                value={filters.priceMax}
                onChange={(e) => setFilters({ ...filters, priceMax: e.target.value })}
                className="flex-1 h-12 bg-[#f3f3f5] rounded-[12px] px-4 outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">City</label>
            <select
              value={filters.city}
              onChange={(e) => setFilters({ ...filters, city: e.target.value })}
              className="w-full h-12 bg-[#f3f3f5] rounded-[12px] px-4 outline-none"
            >
              <option value="">All Cities</option>
              {cities.map((city) => (
                <option key={city} value={city}>
                  {city}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Condition</label>
            <div className="flex gap-3">
              <button
                onClick={() =>
                  setFilters({
                    ...filters,
                    condition: filters.condition === "new" ? "" : "new",
                  })
                }
                className={`flex-1 h-12 rounded-[12px] font-medium transition-all ${
                  filters.condition === "new"
                    ? "bg-[#030213] text-white"
                    : "bg-[#f3f3f5]"
                }`}
              >
                New
              </button>
              <button
                onClick={() =>
                  setFilters({
                    ...filters,
                    condition: filters.condition === "used" ? "" : "used",
                  })
                }
                className={`flex-1 h-12 rounded-[12px] font-medium transition-all ${
                  filters.condition === "used"
                    ? "bg-[#030213] text-white"
                    : "bg-[#f3f3f5]"
                }`}
              >
                Used
              </button>
            </div>
          </div>

          <div className="flex gap-3 pt-4">
            <Button
              onClick={() =>
                setFilters({
                  category: "",
                  priceMin: "",
                  priceMax: "",
                  city: "",
                  condition: "",
                })
              }
              variant="secondary"
              fullWidth
            >
              Reset
            </Button>
            <Button
              onClick={() => setShowFilters(false)}
              variant="primary"
              fullWidth
            >
              Apply
            </Button>
          </div>
        </div>
      </BottomSheet>
    </div>
  );
}
