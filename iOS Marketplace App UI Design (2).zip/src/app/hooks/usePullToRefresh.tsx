import { useState, useRef, useCallback } from "react";
import { motion, useMotionValue, useTransform } from "motion/react";

interface UsePullToRefreshOptions {
  onRefresh: () => Promise<void>;
  threshold?: number;
  enabled?: boolean;
}

export function usePullToRefresh({
  onRefresh,
  threshold = 80,
  enabled = true,
}: UsePullToRefreshOptions) {
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isPulling, setIsPulling] = useState(false);
  const startY = useRef(0);
  const pullDistance = useMotionValue(0);

  // Transform pull distance to rotation for spinner
  const rotation = useTransform(pullDistance, [0, threshold], [0, 360]);
  const opacity = useTransform(pullDistance, [0, threshold], [0, 1]);
  const scale = useTransform(pullDistance, [0, threshold], [0.5, 1]);

  const handleTouchStart = useCallback(
    (e: React.TouchEvent) => {
      if (!enabled || isRefreshing) return;
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      if (scrollTop === 0) {
        startY.current = e.touches[0].clientY;
        setIsPulling(true);
      }
    },
    [enabled, isRefreshing]
  );

  const handleTouchMove = useCallback(
    (e: React.TouchEvent) => {
      if (!enabled || isRefreshing || !isPulling) return;
      const currentY = e.touches[0].clientY;
      const distance = Math.max(0, currentY - startY.current);
      
      // Apply resistance to the pull
      const adjustedDistance = Math.min(distance * 0.5, threshold * 1.5);
      pullDistance.set(adjustedDistance);
    },
    [enabled, isRefreshing, isPulling, pullDistance, threshold]
  );

  const handleTouchEnd = useCallback(async () => {
    if (!enabled || isRefreshing || !isPulling) return;
    
    setIsPulling(false);
    const distance = pullDistance.get();

    if (distance >= threshold) {
      setIsRefreshing(true);
      pullDistance.set(threshold);

      try {
        await onRefresh();
      } finally {
        setIsRefreshing(false);
        pullDistance.set(0);
      }
    } else {
      pullDistance.set(0);
    }
  }, [enabled, isRefreshing, isPulling, pullDistance, threshold, onRefresh]);

  return {
    isRefreshing,
    isPulling,
    pullDistance,
    rotation,
    opacity,
    scale,
    handlers: {
      onTouchStart: handleTouchStart,
      onTouchMove: handleTouchMove,
      onTouchEnd: handleTouchEnd,
    },
  };
}

interface PullToRefreshIndicatorProps {
  pullDistance: any;
  rotation: any;
  opacity: any;
  scale: any;
  isRefreshing: boolean;
}

export function PullToRefreshIndicator({
  pullDistance,
  rotation,
  opacity,
  scale,
  isRefreshing,
}: PullToRefreshIndicatorProps) {
  return (
    <motion.div
      className="absolute top-0 left-0 right-0 flex justify-center pointer-events-none z-10"
      style={{ y: pullDistance }}
    >
      <motion.div
        className="mt-4 w-12 h-12 rounded-full bg-white shadow-lg flex items-center justify-center"
        style={{ opacity, scale }}
      >
        {isRefreshing ? (
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            className="w-6 h-6 border-3 border-[#163300] border-t-transparent rounded-full"
          />
        ) : (
          <motion.svg
            className="w-6 h-6 text-[#163300]"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            style={{ rotate: rotation }}
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
            />
          </motion.svg>
        )}
      </motion.div>
    </motion.div>
  );
}
