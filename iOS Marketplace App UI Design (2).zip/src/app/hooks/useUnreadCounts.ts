import { useState, useEffect } from 'react';
import { messagingAPI, notificationsAPI } from '../utils/api';
import { useAuth } from '../contexts/AuthContext';

interface UnreadCounts {
  messages: number;
  notifications: number;
  isLoading: boolean;
  refresh: () => Promise<void>;
}

/**
 * Custom hook to fetch and track unread message and notification counts
 * Auto-refreshes every 15 seconds
 */
export function useUnreadCounts(): UnreadCounts {
  const { user } = useAuth();
  const [messageCounts, setMessageCounts] = useState(0);
  const [notificationCounts, setNotificationCounts] = useState(0);
  const [isLoading, setIsLoading] = useState(false);

  const fetchCounts = async () => {
    // ⚠️ Don't make API calls if no access token
    if (!user?.accessToken) {
      console.log('⏭️ Skipping unread counts - no access token');
      // Reset counts when no token
      setMessageCounts(0);
      setNotificationCounts(0);
      return;
    }

    // ✅ REMOVED: JWT validation that was auto-logging out users
    // JWT validation now happens ONLY in backend - frontend stays logged in
    
    setIsLoading(true);
    
    try {
      // Fetch both counts in parallel
      const [messageResponse, notificationResponse] = await Promise.all([
        messagingAPI.getUnreadCount(user.accessToken),
        notificationsAPI.getUnreadCount(user.accessToken)
      ]);

      // ✅ Just show warnings, don't logout on errors
      // Backend will handle invalid tokens, frontend stays stable
      
      // Backend returns 'unreadCount', not 'count'
      if (messageResponse.success && typeof messageResponse.unreadCount === 'number') {
        setMessageCounts(messageResponse.unreadCount);
      } else if (messageResponse.error) {
        console.warn('⚠️ Message count error:', messageResponse.error);
        // Don't reset counts on error, keep previous value
      }

      if (notificationResponse.success && typeof notificationResponse.unreadCount === 'number') {
        setNotificationCounts(notificationResponse.unreadCount);
      } else if (notificationResponse.error) {
        console.warn('⚠️ Notification count error:', notificationResponse.error);
        // Don't reset counts on error, keep previous value
      }
    } catch (error) {
      console.warn('⚠️ Error fetching unread counts (non-critical):', error);
      // Don't crash or logout - just skip this refresh
    } finally {
      setIsLoading(false);
    }
  };

  // Initial fetch
  useEffect(() => {
    fetchCounts();
  }, [user?.accessToken]);

  // Auto-refresh every 15 seconds
  useEffect(() => {
    if (!user?.accessToken) return;

    const interval = setInterval(() => {
      fetchCounts();
    }, 15000); // 15 seconds

    return () => clearInterval(interval);
  }, [user?.accessToken]);

  return {
    messages: messageCounts,
    notifications: notificationCounts,
    isLoading,
    refresh: fetchCounts
  };
}