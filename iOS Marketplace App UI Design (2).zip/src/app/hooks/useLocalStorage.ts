/**
 * Custom React Hooks for localStorage
 * Provides reactive state management with automatic persistence
 */

import { useState, useEffect, useCallback } from 'react';
import {
  storage,
  UserProfile,
  CartItem,
  SavedAddress,
  SavedPaymentMethod,
  DraftProduct,
  FilterPreferences,
  AppSettings,
  RecentlyViewed,
} from '../utils/storage';

// ============================================
// CART HOOK
// ============================================

export function useCart() {
  const [cart, setCart] = useState<CartItem[]>(() => storage.getCartItems());

  const addToCart = useCallback((item: Omit<CartItem, 'addedAt'>) => {
    storage.addToCart(item);
    setCart(storage.getCartItems());
  }, []);

  const removeFromCart = useCallback((productId: string) => {
    storage.removeFromCart(productId);
    setCart(storage.getCartItems());
  }, []);

  const updateQuantity = useCallback((productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
    } else {
      storage.updateCartItemQuantity(productId, quantity);
      setCart(storage.getCartItems());
    }
  }, [removeFromCart]);

  const clearCart = useCallback(() => {
    storage.clearCart();
    setCart([]);
  }, []);

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const itemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return {
    cart,
    addToCart,
    removeFromCart,
    updateQuantity,
    clearCart,
    total,
    itemCount,
  };
}

// ============================================
// FAVORITES HOOK
// ============================================

export function useFavorites() {
  const [favorites, setFavorites] = useState<string[]>(() => storage.getFavorites());

  const addFavorite = useCallback((productId: string) => {
    storage.addFavorite(productId);
    setFavorites(storage.getFavorites());
  }, []);

  const removeFavorite = useCallback((productId: string) => {
    storage.removeFavorite(productId);
    setFavorites(storage.getFavorites());
  }, []);

  const toggleFavorite = useCallback((productId: string) => {
    const isNowFavorite = storage.toggleFavorite(productId);
    setFavorites(storage.getFavorites());
    return isNowFavorite;
  }, []);

  const isFavorite = useCallback((productId: string) => {
    return favorites.includes(productId);
  }, [favorites]);

  const clearFavorites = useCallback(() => {
    storage.clearFavorites();
    setFavorites([]);
  }, []);

  return {
    favorites,
    addFavorite,
    removeFavorite,
    toggleFavorite,
    isFavorite,
    clearFavorites,
    count: favorites.length,
  };
}

// ============================================
// USER PROFILE HOOK
// ============================================

export function useUserProfile() {
  const [profile, setProfile] = useState<UserProfile | null>(() => storage.getUserProfile());

  const updateProfile = useCallback((updates: Partial<UserProfile>) => {
    storage.updateUserProfile(updates);
    setProfile(storage.getUserProfile());
  }, []);

  const setUserProfile = useCallback((newProfile: UserProfile) => {
    storage.setUserProfile(newProfile);
    setProfile(newProfile);
  }, []);

  const clearProfile = useCallback(() => {
    storage.clearUserProfile();
    setProfile(null);
  }, []);

  return {
    profile,
    updateProfile,
    setUserProfile,
    clearProfile,
    isLoggedIn: !!profile,
  };
}

// ============================================
// SEARCH HISTORY HOOK
// ============================================

export function useSearchHistory() {
  const [history, setHistory] = useState<string[]>(() => storage.getSearchHistory());

  const addSearch = useCallback((query: string) => {
    storage.addSearchQuery(query);
    setHistory(storage.getSearchHistory());
  }, []);

  const removeSearch = useCallback((query: string) => {
    storage.removeSearchQuery(query);
    setHistory(storage.getSearchHistory());
  }, []);

  const clearHistory = useCallback(() => {
    storage.clearSearchHistory();
    setHistory([]);
  }, []);

  return {
    history,
    addSearch,
    removeSearch,
    clearHistory,
  };
}

// ============================================
// DRAFT PRODUCTS HOOK
// ============================================

export function useDraftProducts() {
  const [drafts, setDrafts] = useState<DraftProduct[]>(() => storage.getDraftProducts());

  const saveDraft = useCallback((product: Omit<DraftProduct, 'savedAt'>) => {
    storage.saveDraftProduct(product);
    setDrafts(storage.getDraftProducts());
  }, []);

  const updateDraft = useCallback((index: number, product: Omit<DraftProduct, 'savedAt'>) => {
    storage.updateDraftProduct(index, product);
    setDrafts(storage.getDraftProducts());
  }, []);

  const deleteDraft = useCallback((index: number) => {
    storage.deleteDraftProduct(index);
    setDrafts(storage.getDraftProducts());
  }, []);

  const clearDrafts = useCallback(() => {
    storage.clearDraftProducts();
    setDrafts([]);
  }, []);

  return {
    drafts,
    saveDraft,
    updateDraft,
    deleteDraft,
    clearDrafts,
    count: drafts.length,
  };
}

// ============================================
// SAVED ADDRESSES HOOK
// ============================================

export function useSavedAddresses() {
  const [addresses, setAddresses] = useState<SavedAddress[]>(() => storage.getSavedAddresses());

  const addAddress = useCallback((address: Omit<SavedAddress, 'id' | 'createdAt'>) => {
    storage.addSavedAddress(address);
    setAddresses(storage.getSavedAddresses());
  }, []);

  const updateAddress = useCallback((id: string, updates: Partial<SavedAddress>) => {
    storage.updateSavedAddress(id, updates);
    setAddresses(storage.getSavedAddresses());
  }, []);

  const deleteAddress = useCallback((id: string) => {
    storage.deleteSavedAddress(id);
    setAddresses(storage.getSavedAddresses());
  }, []);

  const getDefault = useCallback(() => {
    return storage.getDefaultAddress();
  }, []);

  return {
    addresses,
    addAddress,
    updateAddress,
    deleteAddress,
    getDefault,
    count: addresses.length,
  };
}

// ============================================
// SAVED PAYMENT METHODS HOOK
// ============================================

export function useSavedPaymentMethods() {
  const [methods, setMethods] = useState<SavedPaymentMethod[]>(() => 
    storage.getSavedPaymentMethods()
  );

  const addMethod = useCallback((method: Omit<SavedPaymentMethod, 'id' | 'createdAt'>) => {
    storage.addSavedPaymentMethod(method);
    setMethods(storage.getSavedPaymentMethods());
  }, []);

  const updateMethod = useCallback((id: string, updates: Partial<SavedPaymentMethod>) => {
    storage.updateSavedPaymentMethod(id, updates);
    setMethods(storage.getSavedPaymentMethods());
  }, []);

  const deleteMethod = useCallback((id: string) => {
    storage.deleteSavedPaymentMethod(id);
    setMethods(storage.getSavedPaymentMethods());
  }, []);

  const getDefault = useCallback(() => {
    return storage.getDefaultPaymentMethod();
  }, []);

  return {
    methods,
    addMethod,
    updateMethod,
    deleteMethod,
    getDefault,
    count: methods.length,
  };
}

// ============================================
// APP SETTINGS HOOK
// ============================================

export function useAppSettings() {
  const [settings, setSettings] = useState<AppSettings>(() => storage.getAppSettings());

  const updateSettings = useCallback((updates: Partial<AppSettings>) => {
    storage.updateAppSettings(updates);
    setSettings(storage.getAppSettings());
  }, []);

  const toggleNotification = useCallback((key: keyof AppSettings['notifications']) => {
    const current = storage.getAppSettings();
    storage.updateAppSettings({
      notifications: {
        ...current.notifications,
        [key]: !current.notifications[key],
      },
    });
    setSettings(storage.getAppSettings());
  }, []);

  const setLanguage = useCallback((language: 'ar' | 'en') => {
    updateSettings({ language });
  }, [updateSettings]);

  const setTheme = useCallback((theme: 'light' | 'dark' | 'auto') => {
    updateSettings({ theme });
  }, [updateSettings]);

  return {
    settings,
    updateSettings,
    toggleNotification,
    setLanguage,
    setTheme,
  };
}

// ============================================
// FILTER PREFERENCES HOOK
// ============================================

export function useFilterPreferences() {
  const [filters, setFilters] = useState<FilterPreferences>(() => 
    storage.getFilterPreferences()
  );

  const updateFilters = useCallback((updates: Partial<FilterPreferences>) => {
    storage.updateFilterPreferences(updates);
    setFilters(storage.getFilterPreferences());
  }, []);

  const clearFilters = useCallback(() => {
    storage.clearFilterPreferences();
    setFilters(storage.getFilterPreferences());
  }, []);

  return {
    filters,
    updateFilters,
    clearFilters,
  };
}

// ============================================
// RECENTLY VIEWED HOOK
// ============================================

export function useRecentlyViewed() {
  const [viewed, setViewed] = useState<RecentlyViewed[]>(() => storage.getRecentlyViewed());

  const addViewed = useCallback((product: Omit<RecentlyViewed, 'viewedAt'>) => {
    storage.addRecentlyViewed(product);
    setViewed(storage.getRecentlyViewed());
  }, []);

  const clearViewed = useCallback(() => {
    storage.clearRecentlyViewed();
    setViewed([]);
  }, []);

  return {
    viewed,
    addViewed,
    clearViewed,
    count: viewed.length,
  };
}

// ============================================
// GENERIC PERSISTED STATE HOOK
// ============================================

export function usePersistedState<T>(
  key: string,
  defaultValue: T
): [T, (value: T | ((prev: T) => T)) => void] {
  const [state, setState] = useState<T>(() => {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : defaultValue;
    } catch {
      return defaultValue;
    }
  });

  const setValue = useCallback((value: T | ((prev: T) => T)) => {
    setState(prev => {
      const newValue = value instanceof Function ? value(prev) : value;
      try {
        localStorage.setItem(key, JSON.stringify(newValue));
      } catch (error) {
        console.error(`Failed to persist ${key}:`, error);
      }
      return newValue;
    });
  }, [key]);

  return [state, setValue];
}
