/**
 * Global App Context
 * Provides cart, favorites, and search functionality across all screens
 */

import React, { createContext, useContext, ReactNode } from 'react';
import { useCart, useFavorites, useSearchHistory } from '../hooks/useLocalStorage';
import type { CartItem } from '../utils/storage';

interface AppContextType {
  // Cart
  cart: CartItem[];
  addToCart: (item: Omit<CartItem, 'addedAt'>) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  cartTotal: number;
  cartItemCount: number;
  
  // Favorites
  favorites: string[];
  toggleFavorite: (productId: string) => boolean;
  isFavorite: (productId: string) => boolean;
  favoritesCount: number;
  
  // Search
  searchHistory: string[];
  addSearch: (query: string) => void;
  clearSearchHistory: () => void;
}

const AppContext = createContext<AppContextType | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const {
    cart,
    addToCart,
    removeFromCart,
    updateQuantity,
    clearCart,
    total,
    itemCount,
  } = useCart();

  const {
    favorites,
    toggleFavorite,
    isFavorite,
    count: favoritesCount,
  } = useFavorites();

  const {
    history: searchHistory,
    addSearch,
    clearHistory: clearSearchHistory,
  } = useSearchHistory();

  return (
    <AppContext.Provider
      value={{
        // Cart
        cart,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        cartTotal: total,
        cartItemCount: itemCount,
        
        // Favorites
        favorites,
        toggleFavorite,
        isFavorite,
        favoritesCount,
        
        // Search
        searchHistory,
        addSearch,
        clearSearchHistory,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
}