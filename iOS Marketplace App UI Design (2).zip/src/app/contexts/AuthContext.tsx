/**
 * Authentication Context - Clean Implementation
 * Uses Supabase Auth API directly with session management
 */

import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { User } from '@supabase/supabase-js';

// User profile from metadata
interface UserProfile {
  id: string;
  email: string;
  name: string;
  phone: string;
  role: 'buyer' | 'seller' | 'both';
  verified: boolean;
  accessToken?: string;
}

interface AuthContextValue {
  user: UserProfile | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  signUp: (email: string, password: string, name: string, phone: string, role: 'buyer' | 'seller') => Promise<{ success: boolean; error?: string }>;
  signIn: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signOut: () => Promise<void>;
  updateRole: (role: 'buyer' | 'seller' | 'both') => Promise<{ success: boolean; error?: string }>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Convert Supabase user to UserProfile
  const convertToProfile = (supabaseUser: User, accessToken?: string): UserProfile => {
    const metadata = supabaseUser.user_metadata || {};
    return {
      id: supabaseUser.id,
      email: supabaseUser.email || '',
      name: metadata.name || 'User',
      phone: metadata.phone || '',
      role: metadata.role || 'buyer',
      verified: !!supabaseUser.email_confirmed_at,
      accessToken,
    };
  };

  // Initialize - check for existing session
  useEffect(() => {
    let mounted = true;

    const initialize = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        
        if (mounted && session?.user) {
          setUser(convertToProfile(session.user, session.access_token));
        }
      } catch (error) {
        console.error('Auth initialization error:', error);
      } finally {
        if (mounted) {
          setIsLoading(false);
        }
      }
    };

    initialize();

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (mounted) {
        if (session?.user) {
          setUser(convertToProfile(session.user, session.access_token));
        } else {
          setUser(null);
        }
      }
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  // Sign up new user
  const signUp = async (
    email: string,
    password: string,
    name: string,
    phone: string,
    role: 'buyer' | 'seller'
  ): Promise<{ success: boolean; error?: string }> => {
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            name,
            phone,
            role,
          },
        },
      });

      if (error) {
        return { success: false, error: error.message };
      }

      if (!data.user) {
        return { success: false, error: 'Failed to create user' };
      }

      // Set user profile with access token from session
      setUser(convertToProfile(data.user, data.session?.access_token));

      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message || 'Sign up failed' };
    }
  };

  // Sign in existing user
  const signIn = async (
    email: string,
    password: string
  ): Promise<{ success: boolean; error?: string }> => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        return { success: false, error: error.message };
      }

      if (!data.user || !data.session) {
        return { success: false, error: 'Failed to sign in' };
      }

      // Set user profile with access token from session
      setUser(convertToProfile(data.user, data.session.access_token));

      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message || 'Sign in failed' };
    }
  };

  // Sign out
  const signOut = async (): Promise<void> => {
    try {
      await supabase.auth.signOut();
      setUser(null);
    } catch (error) {
      console.error('Sign out error:', error);
      // Clear user anyway
      setUser(null);
    }
  };

  // Update user role
  const updateRole = async (
    role: 'buyer' | 'seller' | 'both'
  ): Promise<{ success: boolean; error?: string }> => {
    try {
      if (!user) {
        return { success: false, error: 'No user logged in' };
      }

      const { data, error } = await supabase.auth.updateUser({
        data: {
          role,
          name: user.name,
          phone: user.phone,
        },
      });

      if (error) {
        return { success: false, error: error.message };
      }

      if (data.user) {
        // Preserve the access token when updating role
        setUser(convertToProfile(data.user, user.accessToken));
      }

      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message || 'Role update failed' };
    }
  };

  const value: AuthContextValue = {
    user,
    isAuthenticated: !!user,
    isLoading,
    signUp,
    signIn,
    signOut,
    updateRole,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}