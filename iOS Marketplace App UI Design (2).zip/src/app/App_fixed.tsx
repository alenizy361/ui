// This is a placeholder - checking if write works
