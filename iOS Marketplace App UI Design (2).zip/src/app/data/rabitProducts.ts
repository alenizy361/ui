export interface RabitProduct {
  id: string;
  title: string;
  titleAr: string;
  price: number;
  image: string;
  seller: string;
  sellerAr: string;
  sellerId: string;
  rating: number;
  category: string;
  categoryAr: string;
  condition: "new" | "used";
  conditionAr: string;
  city: string;
  cityAr: string;
  description: string;
  descriptionAr: string;
  images: string[];
  verified: boolean;
  quantity?: number; // Available stock quantity
  sold?: number; // Number of items sold (for analytics)
}

export interface RabitCategory {
  id: string;
  name: string;
  nameAr: string;
  icon: string;
  iconComponent?: string; // Lucide icon name
  gradient?: string; // Tailwind gradient classes
  count: number;
}

// Mock data removed - all data now fetched from database via services
// Use getCategories() from categories.service.ts
// Use getProducts() from products.service.ts