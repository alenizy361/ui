export interface Product {
  id: string;
  title: string;
  price: number;
  image: string;
  category: string;
  condition: "new" | "used";
  city: string;
  seller: {
    id: string;
    name: string;
    avatar: string;
    rating: number;
    totalSales: number;
  };
  description: string;
  specs: { label: string; value: string }[];
}

export const products: Product[] = [
  {
    id: "1",
    title: "iPhone 14 Pro Max",
    price: 899,
    image: "https://images.unsplash.com/photo-1758186355698-bd0183fc75ed?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBlbGVjdHJvbmljcyUyMHNtYXJ0cGhvbmV8ZW58MXx8fHwxNzY2NzUwNTUxfDA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Electronics",
    condition: "new",
    city: "Riyadh",
    seller: {
      id: "s1",
      name: "TechStore",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=TechStore",
      rating: 4.8,
      totalSales: 342,
    },
    description: "Brand new iPhone 14 Pro Max with 256GB storage. Comes with original box and all accessories. Never used, sealed package.",
    specs: [
      { label: "Storage", value: "256GB" },
      { label: "Color", value: "Deep Purple" },
      { label: "Condition", value: "New" },
      { label: "Warranty", value: "1 Year" },
    ],
  },
  {
    id: "2",
    title: "Sony WH-1000XM5 Headphones",
    price: 329,
    image: "https://images.unsplash.com/photo-1765279339828-bb765f3631c8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3aXJlbGVzcyUyMGhlYWRwaG9uZXMlMjBwcmVtaXVtfGVufDF8fHx8MTc2NjcxMDQ1NHww&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Audio",
    condition: "used",
    city: "Jeddah",
    seller: {
      id: "s2",
      name: "AudioPro",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=AudioPro",
      rating: 4.9,
      totalSales: 189,
    },
    description: "Premium noise-cancelling headphones in excellent condition. Used for 3 months, comes with original case and cables.",
    specs: [
      { label: "Type", value: "Over-ear" },
      { label: "Connectivity", value: "Bluetooth 5.2" },
      { label: "Battery Life", value: "30 hours" },
      { label: "Condition", value: "Like New" },
    ],
  },
  {
    id: "3",
    title: "MacBook Pro 14\" M2",
    price: 1899,
    image: "https://images.unsplash.com/flagged/photo-1576697010739-6373b63f3204?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsYXB0b3AlMjBjb21wdXRlciUyMGRlc2t8ZW58MXx8fHwxNzY2Njg1ODc5fDA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Computers",
    condition: "new",
    city: "Dubai",
    seller: {
      id: "s3",
      name: "AppleHub",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=AppleHub",
      rating: 5.0,
      totalSales: 567,
    },
    description: "Latest MacBook Pro with M2 chip. Perfect for professionals and creators. Includes Apple Care+ warranty.",
    specs: [
      { label: "Processor", value: "Apple M2" },
      { label: "RAM", value: "16GB" },
      { label: "Storage", value: "512GB SSD" },
      { label: "Display", value: "14\" Liquid Retina XDR" },
    ],
  },
  {
    id: "4",
    title: "Canon EOS R6 Camera",
    price: 2299,
    image: "https://images.unsplash.com/photo-1764557359097-f15dd0c0a17b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYW1lcmElMjBwaG90b2dyYXBoeSUyMGVxdWlwbWVudHxlbnwxfHx8fDE3NjY3MTU0NTd8MA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Cameras",
    condition: "used",
    city: "Abu Dhabi",
    seller: {
      id: "s4",
      name: "ProPhoto",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=ProPhoto",
      rating: 4.7,
      totalSales: 123,
    },
    description: "Professional mirrorless camera with full-frame sensor. Excellent condition, low shutter count. Includes lens and accessories.",
    specs: [
      { label: "Megapixels", value: "20.1MP" },
      { label: "Video", value: "4K 60fps" },
      { label: "Lens", value: "24-105mm f/4" },
      { label: "Shutter Count", value: "8,500" },
    ],
  },
  {
    id: "5",
    title: "Apple Watch Series 8",
    price: 399,
    image: "https://images.unsplash.com/photo-1719744755507-a4c856c57cf7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbWFydHdhdGNoJTIwd2VhcmFibGV8ZW58MXx8fHwxNzY2NzIyMjU3fDA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Wearables",
    condition: "new",
    city: "Riyadh",
    seller: {
      id: "s1",
      name: "TechStore",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=TechStore",
      rating: 4.8,
      totalSales: 342,
    },
    description: "Latest Apple Watch with advanced health features. GPS + Cellular. Brand new, sealed in box.",
    specs: [
      { label: "Size", value: "45mm" },
      { label: "Connectivity", value: "GPS + Cellular" },
      { label: "Battery", value: "18 hours" },
      { label: "Water Resistance", value: "50m" },
    ],
  },
  {
    id: "6",
    title: "Modern Designer Chair",
    price: 449,
    image: "https://images.unsplash.com/photo-1709346739762-e8ecacc96e0a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZXNpZ25lciUyMGZ1cm5pdHVyZSUyMG1vZGVybnxlbnwxfHx8fDE3NjY3NTA1NTN8MA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Furniture",
    condition: "new",
    city: "Dubai",
    seller: {
      id: "s5",
      name: "HomeDesign",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=HomeDesign",
      rating: 4.6,
      totalSales: 234,
    },
    description: "Ergonomic designer chair with premium materials. Perfect for home office or study. Brand new.",
    specs: [
      { label: "Material", value: "Leather & Wood" },
      { label: "Color", value: "Navy Blue" },
      { label: "Dimensions", value: "80x90x110cm" },
      { label: "Weight Capacity", value: "150kg" },
    ],
  },
  {
    id: "7",
    title: "Designer Leather Bag",
    price: 189,
    image: "https://images.unsplash.com/photo-1660406734595-06458af8e5c5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXNoaW9uJTIwYWNjZXNzb3JpZXMlMjBsaWZlc3R5bGV8ZW58MXx8fHwxNzY2NzUwNTU0fDA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Fashion",
    condition: "new",
    city: "Jeddah",
    seller: {
      id: "s6",
      name: "LuxeFashion",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=LuxeFashion",
      rating: 4.9,
      totalSales: 445,
    },
    description: "Premium leather handbag with elegant design. Authentic materials, multiple compartments. Perfect condition.",
    specs: [
      { label: "Material", value: "Genuine Leather" },
      { label: "Color", value: "Cognac Brown" },
      { label: "Size", value: "Medium" },
      { label: "Brand", value: "Designer" },
    ],
  },
  {
    id: "8",
    title: "PlayStation 5 Console",
    price: 499,
    image: "https://images.unsplash.com/photo-1695028644151-1ec92bae9fb0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1pbmclMjBjb25zb2xlJTIwY29udHJvbGxlcnxlbnwxfHx8fDE3NjY3NTA1NTR8MA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Gaming",
    condition: "new",
    city: "Riyadh",
    seller: {
      id: "s7",
      name: "GameZone",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=GameZone",
      rating: 4.8,
      totalSales: 298,
    },
    description: "Brand new PS5 console with disc drive. Includes DualSense controller and all cables. Ready to ship.",
    specs: [
      { label: "Model", value: "Disc Edition" },
      { label: "Storage", value: "825GB SSD" },
      { label: "Resolution", value: "4K UHD" },
      { label: "Includes", value: "Controller + Cables" },
    ],
  },
];

export const categories = [
  { id: "electronics", name: "Electronics", icon: "📱" },
  { id: "audio", name: "Audio", icon: "🎧" },
  { id: "computers", name: "Computers", icon: "💻" },
  { id: "cameras", name: "Cameras", icon: "📷" },
  { id: "wearables", name: "Wearables", icon: "⌚" },
  { id: "furniture", name: "Furniture", icon: "🪑" },
  { id: "fashion", name: "Fashion", icon: "👜" },
  { id: "gaming", name: "Gaming", icon: "🎮" },
];
