/**
 * LocalStorage Manager for Rabit Platform
 * Handles all localStorage operations with type safety, data migration, and versioning
 * Version: 1.0.0
 */

// ============================================
// TYPESCRIPT INTERFACES
// ============================================

export interface UserProfile {
  id: string;
  name: string;
  nameAr: string;
  phone: string;
  email: string;
  avatar?: string;
  role: 'buyer' | 'seller' | 'both';
  verified: boolean;
  createdAt: string;
  rating?: number;
  totalSales?: number;
  totalPurchases?: number;
  accessToken?: string;
}

export interface CartItem {
  productId: string;
  title: string;
  titleAr: string;
  price: number;
  quantity: number;
  image: string;
  sellerId: string;
  seller: string;
  sellerAr: string;
  addedAt: string;
}

export interface SavedAddress {
  id: string;
  label: string;
  labelAr: string;
  fullName: string;
  fullNameAr: string;
  phone: string;
  street: string;
  streetAr: string;
  city: string;
  cityAr: string;
  district: string;
  districtAr: string;
  postalCode?: string;
  isDefault: boolean;
  createdAt: string;
}

export interface SavedPaymentMethod {
  id: string;
  type: 'card' | 'wallet' | 'bank';
  label: string;
  labelAr: string;
  last4?: string;
  cardBrand?: string;
  expiryMonth?: string;
  expiryYear?: string;
  walletProvider?: string;
  bankName?: string;
  bankNameAr?: string;
  isDefault: boolean;
  token: string; // Tokenized for security
  createdAt: string;
}

export interface DraftProduct {
  title: string;
  titleAr: string;
  description: string;
  descriptionAr: string;
  price: number;
  category: string;
  categoryAr: string;
  condition: 'new' | 'used';
  city: string;
  cityAr: string;
  images: string[];
  savedAt: string;
}

export interface FilterPreferences {
  minPrice?: number;
  maxPrice?: number;
  categories: string[];
  condition?: 'new' | 'used' | 'all';
  cities: string[];
  sortBy: 'recent' | 'price-low' | 'price-high' | 'popular';
}

export interface AppSettings {
  language: 'ar' | 'en';
  theme: 'light' | 'dark' | 'auto';
  notifications: {
    orders: boolean;
    messages: boolean;
    offers: boolean;
    marketing: boolean;
  };
  hapticFeedback: boolean;
  soundEffects: boolean;
  autoPlayVideos: boolean;
}

export interface RecentlyViewed {
  id: string;
  title: string;
  titleAr: string;
  price: number;
  image: string;
  viewedAt: string;
}

// ============================================
// STORAGE KEYS & VERSION
// ============================================

const STORAGE_VERSION = '1.0.0';

const STORAGE_KEYS = {
  VERSION: 'rabit_storage_version',
  USER_PROFILE: 'rabit_user_profile',
  AUTH_TOKEN: 'rabit_auth_token',
  ROLE_SELECTION: 'rabit_role_selection',
  CART_ITEMS: 'rabit_cart_items',
  FAVORITES: 'rabit_favorites',
  SEARCH_HISTORY: 'rabit_search_history',
  DRAFT_PRODUCTS: 'rabit_draft_products',
  FILTER_PREFERENCES: 'rabit_filter_preferences',
  SAVED_ADDRESSES: 'rabit_saved_addresses',
  SAVED_PAYMENT_METHODS: 'rabit_saved_payment_methods',
  APP_SETTINGS: 'rabit_app_settings',
  RECENTLY_VIEWED: 'rabit_recently_viewed',
  ONBOARDING_COMPLETED: 'rabit_onboarding_completed',
} as const;

// ============================================
// HELPER FUNCTIONS
// ============================================

function safeGet<T>(key: string, defaultValue: T): T {
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : defaultValue;
  } catch (error) {
    console.error(`Failed to get ${key}:`, error);
    return defaultValue;
  }
}

function safeSet(key: string, value: any): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.error(`Failed to set ${key}:`, error);
    // Handle quota exceeded error
    if (error instanceof DOMException && error.name === 'QuotaExceededError') {
      console.warn('localStorage quota exceeded. Clearing old data...');
      clearOldData();
    }
  }
}

function clearOldData(): void {
  // Clear recently viewed if it's too large
  const viewed = safeGet<RecentlyViewed[]>(STORAGE_KEYS.RECENTLY_VIEWED, []);
  if (viewed.length > 10) {
    safeSet(STORAGE_KEYS.RECENTLY_VIEWED, viewed.slice(0, 10));
  }
  
  // Clear search history if it's too large
  const searchHistory = safeGet<string[]>(STORAGE_KEYS.SEARCH_HISTORY, []);
  if (searchHistory.length > 10) {
    safeSet(STORAGE_KEYS.SEARCH_HISTORY, searchHistory.slice(0, 10));
  }
}

// ============================================
// DATA MIGRATION
// ============================================

function migrateData(): void {
  const currentVersion = localStorage.getItem(STORAGE_KEYS.VERSION);
  
  if (currentVersion === STORAGE_VERSION) {
    return; // No migration needed
  }
  
  console.log(`Migrating data from ${currentVersion || 'unknown'} to ${STORAGE_VERSION}`);
  
  // Future migrations will go here
  // Example:
  // if (currentVersion === '0.9.0') {
  //   // Migrate from 0.9.0 to 1.0.0
  // }
  
  localStorage.setItem(STORAGE_KEYS.VERSION, STORAGE_VERSION);
}

// Run migration on import
migrateData();

// ============================================
// STORAGE MANAGER
// ============================================

export const storage = {
  // ========== USER PROFILE ==========
  setUserProfile: (profile: UserProfile) => {
    safeSet(STORAGE_KEYS.USER_PROFILE, profile);
  },

  getUserProfile: (): UserProfile | null => {
    return safeGet<UserProfile | null>(STORAGE_KEYS.USER_PROFILE, null);
  },

  updateUserProfile: (updates: Partial<UserProfile>) => {
    const current = storage.getUserProfile();
    if (current) {
      storage.setUserProfile({ ...current, ...updates });
    }
  },

  clearUserProfile: () => {
    localStorage.removeItem(STORAGE_KEYS.USER_PROFILE);
  },

  // ========== AUTH TOKEN ==========
  setAuthToken: (token: string) => {
    localStorage.setItem(STORAGE_KEYS.AUTH_TOKEN, token);
  },

  getAuthToken: (): string | null => {
    return localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
  },

  clearAuthToken: () => {
    localStorage.removeItem(STORAGE_KEYS.AUTH_TOKEN);
  },

  // ========== ROLE SELECTION ==========
  setRoleSelection: (role: 'buyer' | 'seller' | 'both') => {
    localStorage.setItem(STORAGE_KEYS.ROLE_SELECTION, role);
  },

  getRoleSelection: (): 'buyer' | 'seller' | 'both' | null => {
    return localStorage.getItem(STORAGE_KEYS.ROLE_SELECTION) as 'buyer' | 'seller' | 'both' | null;
  },

  clearRoleSelection: () => {
    localStorage.removeItem(STORAGE_KEYS.ROLE_SELECTION);
  },

  // ========== CART ITEMS ==========
  getCartItems: (): CartItem[] => {
    return safeGet<CartItem[]>(STORAGE_KEYS.CART_ITEMS, []);
  },

  setCartItems: (items: CartItem[]) => {
    safeSet(STORAGE_KEYS.CART_ITEMS, items);
  },

  addToCart: (item: Omit<CartItem, 'addedAt'>) => {
    const cart = storage.getCartItems();
    const existingIndex = cart.findIndex(i => i.productId === item.productId);
    
    if (existingIndex >= 0) {
      // Update quantity if already in cart
      cart[existingIndex].quantity += item.quantity;
    } else {
      // Add new item
      cart.push({ ...item, addedAt: new Date().toISOString() });
    }
    
    storage.setCartItems(cart);
  },

  removeFromCart: (productId: string) => {
    const cart = storage.getCartItems();
    storage.setCartItems(cart.filter(item => item.productId !== productId));
  },

  updateCartItemQuantity: (productId: string, quantity: number) => {
    const cart = storage.getCartItems();
    const item = cart.find(i => i.productId === productId);
    if (item) {
      item.quantity = quantity;
      storage.setCartItems(cart);
    }
  },

  clearCart: () => {
    localStorage.removeItem(STORAGE_KEYS.CART_ITEMS);
  },

  getCartTotal: (): number => {
    const cart = storage.getCartItems();
    return cart.reduce((total, item) => total + (item.price * item.quantity), 0);
  },

  getCartItemCount: (): number => {
    const cart = storage.getCartItems();
    return cart.reduce((total, item) => total + item.quantity, 0);
  },

  // ========== FAVORITES ==========
  getFavorites: (): string[] => {
    return safeGet<string[]>(STORAGE_KEYS.FAVORITES, []);
  },

  setFavorites: (favorites: string[]) => {
    safeSet(STORAGE_KEYS.FAVORITES, favorites);
  },

  addFavorite: (productId: string) => {
    const favorites = storage.getFavorites();
    if (!favorites.includes(productId)) {
      favorites.push(productId);
      storage.setFavorites(favorites);
    }
  },

  removeFavorite: (productId: string) => {
    const favorites = storage.getFavorites();
    storage.setFavorites(favorites.filter(id => id !== productId));
  },

  isFavorite: (productId: string): boolean => {
    return storage.getFavorites().includes(productId);
  },

  toggleFavorite: (productId: string): boolean => {
    const isFav = storage.isFavorite(productId);
    if (isFav) {
      storage.removeFavorite(productId);
    } else {
      storage.addFavorite(productId);
    }
    return !isFav;
  },

  clearFavorites: () => {
    localStorage.removeItem(STORAGE_KEYS.FAVORITES);
  },

  // ========== SEARCH HISTORY ==========
  getSearchHistory: (): string[] => {
    return safeGet<string[]>(STORAGE_KEYS.SEARCH_HISTORY, []);
  },

  addSearchQuery: (query: string) => {
    if (!query.trim()) return;
    
    const history = storage.getSearchHistory();
    // Remove if already exists
    const filtered = history.filter(q => q.toLowerCase() !== query.toLowerCase());
    // Add to front
    filtered.unshift(query.trim());
    // Keep only last 20
    const limited = filtered.slice(0, 20);
    safeSet(STORAGE_KEYS.SEARCH_HISTORY, limited);
  },

  removeSearchQuery: (query: string) => {
    const history = storage.getSearchHistory();
    safeSet(STORAGE_KEYS.SEARCH_HISTORY, history.filter(q => q !== query));
  },

  clearSearchHistory: () => {
    localStorage.removeItem(STORAGE_KEYS.SEARCH_HISTORY);
  },

  // ========== DRAFT PRODUCTS ==========
  getDraftProducts: (): DraftProduct[] => {
    return safeGet<DraftProduct[]>(STORAGE_KEYS.DRAFT_PRODUCTS, []);
  },

  saveDraftProduct: (product: Omit<DraftProduct, 'savedAt'>) => {
    const drafts = storage.getDraftProducts();
    drafts.push({ ...product, savedAt: new Date().toISOString() });
    safeSet(STORAGE_KEYS.DRAFT_PRODUCTS, drafts);
  },

  updateDraftProduct: (index: number, product: Omit<DraftProduct, 'savedAt'>) => {
    const drafts = storage.getDraftProducts();
    if (drafts[index]) {
      drafts[index] = { ...product, savedAt: new Date().toISOString() };
      safeSet(STORAGE_KEYS.DRAFT_PRODUCTS, drafts);
    }
  },

  deleteDraftProduct: (index: number) => {
    const drafts = storage.getDraftProducts();
    drafts.splice(index, 1);
    safeSet(STORAGE_KEYS.DRAFT_PRODUCTS, drafts);
  },

  clearDraftProducts: () => {
    localStorage.removeItem(STORAGE_KEYS.DRAFT_PRODUCTS);
  },

  // ========== FILTER PREFERENCES ==========
  getFilterPreferences: (): FilterPreferences => {
    return safeGet<FilterPreferences>(STORAGE_KEYS.FILTER_PREFERENCES, {
      categories: [],
      cities: [],
      sortBy: 'recent',
    });
  },

  setFilterPreferences: (preferences: FilterPreferences) => {
    safeSet(STORAGE_KEYS.FILTER_PREFERENCES, preferences);
  },

  updateFilterPreferences: (updates: Partial<FilterPreferences>) => {
    const current = storage.getFilterPreferences();
    storage.setFilterPreferences({ ...current, ...updates });
  },

  clearFilterPreferences: () => {
    localStorage.removeItem(STORAGE_KEYS.FILTER_PREFERENCES);
  },

  // ========== SAVED ADDRESSES ==========
  getSavedAddresses: (): SavedAddress[] => {
    return safeGet<SavedAddress[]>(STORAGE_KEYS.SAVED_ADDRESSES, []);
  },

  addSavedAddress: (address: Omit<SavedAddress, 'id' | 'createdAt'>) => {
    const addresses = storage.getSavedAddresses();
    
    // If this is default, remove default from others
    if (address.isDefault) {
      addresses.forEach(addr => addr.isDefault = false);
    }
    
    const newAddress: SavedAddress = {
      ...address,
      id: `addr_${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    
    addresses.push(newAddress);
    safeSet(STORAGE_KEYS.SAVED_ADDRESSES, addresses);
  },

  updateSavedAddress: (id: string, updates: Partial<SavedAddress>) => {
    const addresses = storage.getSavedAddresses();
    const index = addresses.findIndex(a => a.id === id);
    
    if (index >= 0) {
      // If setting as default, remove default from others
      if (updates.isDefault) {
        addresses.forEach(addr => addr.isDefault = false);
      }
      
      addresses[index] = { ...addresses[index], ...updates };
      safeSet(STORAGE_KEYS.SAVED_ADDRESSES, addresses);
    }
  },

  deleteSavedAddress: (id: string) => {
    const addresses = storage.getSavedAddresses();
    safeSet(STORAGE_KEYS.SAVED_ADDRESSES, addresses.filter(a => a.id !== id));
  },

  getDefaultAddress: (): SavedAddress | null => {
    const addresses = storage.getSavedAddresses();
    return addresses.find(a => a.isDefault) || addresses[0] || null;
  },

  clearSavedAddresses: () => {
    localStorage.removeItem(STORAGE_KEYS.SAVED_ADDRESSES);
  },

  // ========== SAVED PAYMENT METHODS ==========
  getSavedPaymentMethods: (): SavedPaymentMethod[] => {
    return safeGet<SavedPaymentMethod[]>(STORAGE_KEYS.SAVED_PAYMENT_METHODS, []);
  },

  addSavedPaymentMethod: (method: Omit<SavedPaymentMethod, 'id' | 'createdAt'>) => {
    const methods = storage.getSavedPaymentMethods();
    
    // If this is default, remove default from others
    if (method.isDefault) {
      methods.forEach(m => m.isDefault = false);
    }
    
    const newMethod: SavedPaymentMethod = {
      ...method,
      id: `pm_${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    
    methods.push(newMethod);
    safeSet(STORAGE_KEYS.SAVED_PAYMENT_METHODS, methods);
  },

  updateSavedPaymentMethod: (id: string, updates: Partial<SavedPaymentMethod>) => {
    const methods = storage.getSavedPaymentMethods();
    const index = methods.findIndex(m => m.id === id);
    
    if (index >= 0) {
      // If setting as default, remove default from others
      if (updates.isDefault) {
        methods.forEach(m => m.isDefault = false);
      }
      
      methods[index] = { ...methods[index], ...updates };
      safeSet(STORAGE_KEYS.SAVED_PAYMENT_METHODS, methods);
    }
  },

  deleteSavedPaymentMethod: (id: string) => {
    const methods = storage.getSavedPaymentMethods();
    safeSet(STORAGE_KEYS.SAVED_PAYMENT_METHODS, methods.filter(m => m.id !== id));
  },

  getDefaultPaymentMethod: (): SavedPaymentMethod | null => {
    const methods = storage.getSavedPaymentMethods();
    return methods.find(m => m.isDefault) || methods[0] || null;
  },

  clearSavedPaymentMethods: () => {
    localStorage.removeItem(STORAGE_KEYS.SAVED_PAYMENT_METHODS);
  },

  // ========== APP SETTINGS ==========
  getAppSettings: (): AppSettings => {
    return safeGet<AppSettings>(STORAGE_KEYS.APP_SETTINGS, {
      language: 'ar',
      theme: 'light',
      notifications: {
        orders: true,
        messages: true,
        offers: true,
        marketing: false,
      },
      hapticFeedback: true,
      soundEffects: true,
      autoPlayVideos: false,
    });
  },

  setAppSettings: (settings: AppSettings) => {
    safeSet(STORAGE_KEYS.APP_SETTINGS, settings);
  },

  updateAppSettings: (updates: Partial<AppSettings>) => {
    const current = storage.getAppSettings();
    storage.setAppSettings({ ...current, ...updates });
  },

  // ========== RECENTLY VIEWED ==========
  getRecentlyViewed: (): RecentlyViewed[] => {
    return safeGet<RecentlyViewed[]>(STORAGE_KEYS.RECENTLY_VIEWED, []);
  },

  addRecentlyViewed: (product: Omit<RecentlyViewed, 'viewedAt'>) => {
    const viewed = storage.getRecentlyViewed();
    // Remove if already exists
    const filtered = viewed.filter(p => p.id !== product.id);
    // Add to front
    filtered.unshift({ ...product, viewedAt: new Date().toISOString() });
    // Keep only last 30
    const limited = filtered.slice(0, 30);
    safeSet(STORAGE_KEYS.RECENTLY_VIEWED, limited);
  },

  clearRecentlyViewed: () => {
    localStorage.removeItem(STORAGE_KEYS.RECENTLY_VIEWED);
  },

  // ========== ONBOARDING ==========
  setOnboardingCompleted: (completed: boolean) => {
    localStorage.setItem(STORAGE_KEYS.ONBOARDING_COMPLETED, String(completed));
  },

  getOnboardingCompleted: (): boolean => {
    return localStorage.getItem(STORAGE_KEYS.ONBOARDING_COMPLETED) === 'true';
  },

  // ========== BULK OPERATIONS ==========
  clearAllUserData: () => {
    storage.clearUserProfile();
    storage.clearAuthToken();
    storage.clearRoleSelection();
    storage.clearCart();
    storage.clearFavorites();
    storage.clearSearchHistory();
    storage.clearDraftProducts();
    storage.clearFilterPreferences();
    storage.clearSavedAddresses();
    storage.clearSavedPaymentMethods();
    storage.clearRecentlyViewed();
  },

  clearAll: () => {
    Object.values(STORAGE_KEYS).forEach(key => {
      localStorage.removeItem(key);
    });
  },

  // ========== EXPORT/IMPORT (for debugging) ==========
  exportData: (): Record<string, any> => {
    const data: Record<string, any> = {};
    Object.entries(STORAGE_KEYS).forEach(([key, storageKey]) => {
      const value = localStorage.getItem(storageKey);
      if (value) {
        try {
          data[key] = JSON.parse(value);
        } catch {
          data[key] = value;
        }
      }
    });
    return data;
  },

  importData: (data: Record<string, any>) => {
    Object.entries(data).forEach(([key, value]) => {
      const storageKey = STORAGE_KEYS[key as keyof typeof STORAGE_KEYS];
      if (storageKey) {
        if (typeof value === 'string') {
          localStorage.setItem(storageKey, value);
        } else {
          safeSet(storageKey, value);
        }
      }
    });
  },

  // ========== STORAGE INFO ==========
  getStorageSize: (): { used: number; total: number; percentage: number } => {
    let used = 0;
    Object.values(STORAGE_KEYS).forEach(key => {
      const value = localStorage.getItem(key);
      if (value) {
        used += value.length;
      }
    });
    
    const total = 5 * 1024 * 1024; // 5MB typical localStorage limit
    const percentage = (used / total) * 100;
    
    return { used, total, percentage };
  },
};