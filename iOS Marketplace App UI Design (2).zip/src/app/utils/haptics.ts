/**
 * Haptic Feedback Utility for Rabit Platform
 * Provides native-like tactile feedback for iOS-style interactions
 */

export type HapticType = 
  | 'light'        // Subtle tap (selections, toggles)
  | 'medium'       // Standard tap (buttons, links)
  | 'heavy'        // Strong tap (confirmations, important actions)
  | 'success'      // Success feedback (completed actions)
  | 'warning'      // Warning feedback (alerts)
  | 'error'        // Error feedback (failed actions)
  | 'selection'    // Selection change (picker, tabs)
  | 'impact';      // Impact feedback (drag & drop)

/**
 * Trigger haptic feedback
 * Uses Vibration API with different patterns for each type
 */
export const triggerHaptic = (type: HapticType = 'medium') => {
  // Check if vibration API is supported
  if (!navigator.vibrate) {
    return;
  }

  // Haptic patterns (in milliseconds)
  const patterns: Record<HapticType, number | number[]> = {
    light: 10,                    // Quick, subtle
    medium: 20,                   // Standard tap
    heavy: 30,                    // Strong feedback
    success: [10, 50, 10],        // Double tap pattern
    warning: [15, 30, 15],        // Alert pattern
    error: [20, 50, 20, 50, 20],  // Triple tap pattern
    selection: 5,                 // Very light
    impact: 25,                   // Medium-heavy
  };

  try {
    navigator.vibrate(patterns[type]);
  } catch (error) {
    // Silently fail if vibration is not supported or blocked
    console.debug('Haptic feedback not available:', error);
  }
};

/**
 * React hook for haptic feedback
 */
export const useHaptics = () => {
  return {
    light: () => triggerHaptic('light'),
    medium: () => triggerHaptic('medium'),
    heavy: () => triggerHaptic('heavy'),
    success: () => triggerHaptic('success'),
    warning: () => triggerHaptic('warning'),
    error: () => triggerHaptic('error'),
    selection: () => triggerHaptic('selection'),
    impact: () => triggerHaptic('impact'),
    trigger: triggerHaptic,
  };
};

/**
 * Haptic-enabled button handler wrapper
 * Usage: onClick={withHaptic(() => yourHandler(), 'medium')}
 */
export const withHaptic = <T extends (...args: any[]) => any>(
  handler: T,
  hapticType: HapticType = 'medium'
): T => {
  return ((...args: any[]) => {
    triggerHaptic(hapticType);
    return handler(...args);
  }) as T;
};

/**
 * Debounced haptic feedback (prevents rapid-fire vibrations)
 */
let lastHapticTime = 0;
const HAPTIC_DEBOUNCE_MS = 50;

export const triggerHapticDebounced = (type: HapticType = 'medium') => {
  const now = Date.now();
  if (now - lastHapticTime > HAPTIC_DEBOUNCE_MS) {
    triggerHaptic(type);
    lastHapticTime = now;
  }
};
