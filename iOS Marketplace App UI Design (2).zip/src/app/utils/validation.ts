/**
 * Form Validation Utilities
 * Provides validation functions for user input with Arabic/English support
 */

export interface ValidationResult {
  isValid: boolean;
  error?: string;
  errorAr?: string;
}

// Email validation
export function validateEmail(email: string): ValidationResult {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  
  if (!email.trim()) {
    return {
      isValid: false,
      error: "Email is required",
      errorAr: "البريد الإلكتروني مطلوب",
    };
  }
  
  if (!emailRegex.test(email)) {
    return {
      isValid: false,
      error: "Please enter a valid email address",
      errorAr: "يرجى إدخال بريد إلكتروني صحيح",
    };
  }
  
  return { isValid: true };
}

// Phone validation (Saudi format)
export function validatePhone(phone: string): ValidationResult {
  // Remove spaces and special characters
  const cleanPhone = phone.replace(/[\s\-\(\)]/g, '');
  
  if (!cleanPhone) {
    return {
      isValid: false,
      error: "Phone number is required",
      errorAr: "رقم الهاتف مطلوب",
    };
  }
  
  // Saudi phone format: 
  // - 9 digits (501234567) - user input without prefix
  // - 10 digits starting with 05 (0501234567)
  // - 12 digits starting with 966 or +966 (966501234567 or +966501234567)
  const saudiRegex = /^(\d{9}|05\d{8}|(\+?966)5\d{8})$/;
  
  if (!saudiRegex.test(cleanPhone)) {
    return {
      isValid: false,
      error: "Please enter a valid Saudi phone number (5XXXXXXXX)",
      errorAr: "يرجى إدخال رقم هاتف سعودي صحيح (5XXXXXXXX)",
    };
  }
  
  return { isValid: true };
}

// Password validation
export function validatePassword(password: string): ValidationResult {
  if (!password) {
    return {
      isValid: false,
      error: "Password is required",
      errorAr: "كلمة المرور مطلوبة",
    };
  }
  
  if (password.length < 8) {
    return {
      isValid: false,
      error: "Password must be at least 8 characters",
      errorAr: "كلمة المرور يجب أن تكون 8 أحرف على الأقل",
    };
  }
  
  // Must contain at least one letter and one number
  const hasLetter = /[a-zA-Z]/.test(password);
  const hasNumber = /\d/.test(password);
  
  if (!hasLetter || !hasNumber) {
    return {
      isValid: false,
      error: "Password must contain letters and numbers",
      errorAr: "كلمة المرور يجب أن تحتوي على حروف وأرقام",
    };
  }
  
  return { isValid: true };
}

// Confirm password validation
export function validateConfirmPassword(password: string, confirmPassword: string): ValidationResult {
  if (!confirmPassword) {
    return {
      isValid: false,
      error: "Please confirm your password",
      errorAr: "يرجى تأكيد كلمة المرور",
    };
  }
  
  if (password !== confirmPassword) {
    return {
      isValid: false,
      error: "Passwords do not match",
      errorAr: "كلمات المرور غير متطابقة",
    };
  }
  
  return { isValid: true };
}

// Full name validation
export function validateFullName(name: string): ValidationResult {
  if (!name.trim()) {
    return {
      isValid: false,
      error: "Full name is required",
      errorAr: "الاسم الكامل مطلوب",
    };
  }
  
  if (name.trim().length < 3) {
    return {
      isValid: false,
      error: "Name must be at least 3 characters",
      errorAr: "الاسم يجب أن يكون 3 أحرف على الأقل",
    };
  }
  
  // Should contain at least first and last name (two words)
  const nameParts = name.trim().split(/\s+/);
  if (nameParts.length < 2) {
    return {
      isValid: false,
      error: "Please enter your full name (first and last name)",
      errorAr: "يرجى إدخال الاسم الكامل (الاسم الأول والأخير)",
    };
  }
  
  return { isValid: true };
}

// National ID validation (Saudi format)
export function validateNationalId(id: string): ValidationResult {
  const cleanId = id.replace(/\s/g, '');
  
  if (!cleanId) {
    return {
      isValid: false,
      error: "National ID is required",
      errorAr: "رقم الهوية الوطنية مطلوب",
    };
  }
  
  // Saudi national ID is 10 digits starting with 1 or 2
  const saudiIdRegex = /^[12]\d{9}$/;
  
  if (!saudiIdRegex.test(cleanId)) {
    return {
      isValid: false,
      error: "Please enter a valid 10-digit National ID",
      errorAr: "يرجى إدخال رقم هوية وطنية صحيح (10 أرقام)",
    };
  }
  
  return { isValid: true };
}

// OTP validation
export function validateOTP(otp: string): ValidationResult {
  const cleanOTP = otp.replace(/\s/g, '');
  
  if (!cleanOTP) {
    return {
      isValid: false,
      error: "Verification code is required",
      errorAr: "رمز التحقق مطلوب",
    };
  }
  
  if (!/^\d{4,6}$/.test(cleanOTP)) {
    return {
      isValid: false,
      error: "Please enter a valid 4-6 digit code",
      errorAr: "يرجى إدخال رمز مكون من 4-6 أرقام",
    };
  }
  
  return { isValid: true };
}

// Terms acceptance validation
export function validateTermsAcceptance(accepted: boolean): ValidationResult {
  if (!accepted) {
    return {
      isValid: false,
      error: "You must accept the terms and conditions",
      errorAr: "يجب قبول الشروط والأحكام",
    };
  }
  
  return { isValid: true };
}

// Generic required field validation
export function validateRequired(value: string, fieldName: string, fieldNameAr: string): ValidationResult {
  if (!value || !value.trim()) {
    return {
      isValid: false,
      error: `${fieldName} is required`,
      errorAr: `${fieldNameAr} مطلوب`,
    };
  }
  
  return { isValid: true };
}

// Price validation
export function validatePrice(price: string | number): ValidationResult {
  const numPrice = typeof price === 'string' ? parseFloat(price) : price;
  
  if (isNaN(numPrice) || numPrice <= 0) {
    return {
      isValid: false,
      error: "Please enter a valid price greater than 0",
      errorAr: "يرجى إدخال سعر صحيح أكبر من 0",
    };
  }
  
  if (numPrice > 1000000) {
    return {
      isValid: false,
      error: "Price cannot exceed 1,000,000 SAR",
      errorAr: "السعر لا يمكن أن يتجاوز 1,000,000 ريال",
    };
  }
  
  return { isValid: true };
}

// URL validation
export function validateURL(url: string): ValidationResult {
  if (!url.trim()) {
    return { isValid: true }; // URL is optional
  }
  
  try {
    new URL(url);
    return { isValid: true };
  } catch {
    return {
      isValid: false,
      error: "Please enter a valid URL",
      errorAr: "يرجى إدخال رابط صحيح",
    };
  }
}