/**
 * Authentication & Session Management
 * Handles user registration, login, and session state
 */

import { storage, type UserProfile } from './storage';
import { normalizePhone } from './phoneUtils';
import { authAPI } from './api';

export interface RegistrationData {
  fullName: string;
  nationalId: string;
  email: string;
  phone: string;
  password: string;
}

export interface LoginCredentials {
  emailOrPhone: string;
  password: string;
}

// Mock OTP for development (in production, this would be sent via email)
const MOCK_OTP = '123456';

/**
 * Register a new user
 * Returns success status and any error messages
 */
export async function registerUser(data: RegistrationData): Promise<{
  success: boolean;
  error?: string;
  errorAr?: string;
  userId?: string;
}> {
  try {
    const response = await authAPI.register(data);
    return response;
  } catch (error) {
    console.error('Registration error:', error);
    return {
      success: false,
      error: 'Registration failed',
      errorAr: 'فشل التسجيل',
    };
  }
}

/**
 * Send OTP code
 * In production, this would trigger email via SendGrid/etc
 */
export async function sendOTP(email: string): Promise<{
  success: boolean;
  error?: string;
  errorAr?: string;
}> {
  try {
    const response = await authAPI.sendOTP(email);
    console.log(`📧 OTP sent to ${email}: ${MOCK_OTP}`);
    return response;
  } catch (error) {
    console.error('Send OTP error:', error);
    return {
      success: false,
      error: 'Failed to send OTP',
      errorAr: 'فشل إرسال رمز التحقق',
    };
  }
}

/**
 * Verify OTP code
 */
export async function verifyOTP(email: string, otp: string): Promise<{
  success: boolean;
  error?: string;
  errorAr?: string;
}> {
  try {
    const response = await authAPI.verifyOTP(email, otp);
    return response;
  } catch (error) {
    console.error('Verify OTP error:', error);
    return {
      success: false,
      error: 'Verification failed',
      errorAr: 'فشل التحقق',
    };
  }
}

/**
 * Login user with email/phone and password
 * NOTE: This is deprecated - use OTP login instead
 */
export async function loginUser(credentials: LoginCredentials): Promise<{
  success: boolean;
  error?: string;
  errorAr?: string;
  user?: UserProfile;
}> {
  // This function is kept for backward compatibility
  // But the app now uses OTP-based login
  return {
    success: false,
    error: 'Please use OTP login',
    errorAr: 'يرجى استخدام تسجيل الدخول عبر رمز التحقق',
  };
}

/**
 * Set user role (buyer, seller, or both)
 */
export async function setUserRole(userId: string, role: 'buyer' | 'seller' | 'both'): Promise<{
  success: boolean;
  user?: UserProfile;
  error?: string;
  errorAr?: string;
}> {
  try {
    const response = await authAPI.setUserRole(userId, role);
    
    if (response.success && response.user) {
      // Ensure token version is set for new registrations
      localStorage.setItem('rabit_token_version', '2.0');
      
      // Save to local storage for persistence
      storage.setUserProfile(response.user);
      storage.setRoleSelection(role);
      
      console.log('✅ Role set successfully:', {
        userId: response.user.id,
        role,
        hasToken: !!response.user.accessToken,
        tokenVersion: localStorage.getItem('rabit_token_version')
      });
    }
    
    return response;
  } catch (error) {
    console.error('Set role error:', error);
    return {
      success: false,
      error: 'Failed to set role',
      errorAr: 'فشل تعيين الدور',
    };
  }
}

/**
 * Logout user
 */
export function logoutUser(): void {
  storage.clearUserProfile();
}

/**
 * Get current logged-in user
 */
export function getCurrentUser(): UserProfile | null {
  return storage.getUserProfile();
}

/**
 * Check if user is logged in
 */
export function isLoggedIn(): boolean {
  return !!storage.getUserProfile();
}

/**
 * Check if user with email exists (for login)
 */
export async function checkUserExists(email: string): Promise<{
  success: boolean;
  exists: boolean;
  error?: string;
  errorAr?: string;
  userId?: string;
}> {
  try {
    const response = await authAPI.checkUserExists(email);
    return response;
  } catch (error) {
    console.error('Check user error:', error);
    return {
      success: false,
      exists: false,
      error: 'Check failed',
      errorAr: 'فشل الفحص',
    };
  }
}

/**
 * Login with OTP (after OTP verification)
 * This is called after OTP is verified to complete login
 */
export async function loginWithOTP(email: string): Promise<{
  success: boolean;
  error?: string;
  errorAr?: string;
  user?: UserProfile;
}> {
  try {
    const response = await authAPI.loginWithOTP(email);
    
    if (response.success && response.user) {
      // Ensure token version is set for new logins
      localStorage.setItem('rabit_token_version', '2.0');
      
      // Save to local storage for session persistence
      storage.setUserProfile(response.user);
      
      console.log('✅ Login successful - User saved:', {
        userId: response.user.id,
        hasToken: !!response.user.accessToken,
        tokenLength: response.user.accessToken?.length,
        tokenVersion: localStorage.getItem('rabit_token_version')
      });
    }
    
    return response;
  } catch (error) {
    console.error('Login with OTP error:', error);
    return {
      success: false,
      error: 'Login failed',
      errorAr: 'فشل تسجيل الدخول',
    };
  }
}

/**
 * Reset password (mock implementation)
 */
export async function resetPassword(emailOrPhone: string): Promise<{
  success: boolean;
  error?: string;
  errorAr?: string;
}> {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 800));
  
  console.log(`🔐 Password reset OTP sent: ${MOCK_OTP}`);
  
  return { success: true };
}

/**
 * Update password
 */
export async function updatePassword(phone: string, newPassword: string): Promise<{
  success: boolean;
  error?: string;
  errorAr?: string;
}> {
  // TODO: Implement with backend API
  await new Promise(resolve => setTimeout(resolve, 600));
  
  return { success: true };
}

/**
 * Get mock OTP for development
 */
export function getMockOTP(): string {
  return MOCK_OTP;
}

/**
 * Get user by phone number
 */
export async function getUserByPhone(phone: string): Promise<any> {
  // This is now handled by the backend
  const response = await authAPI.checkUserExists(phone);
  return response.exists ? { phone } : null;
}

/**
 * Get user by ID
 */
export async function getUserById(userId: string): Promise<UserProfile | null> {
  try {
    const response = await authAPI.getUserProfile(userId);
    return response.success ? response.user : null;
  } catch (error) {
    console.error('Get user by ID error:', error);
    return null;
  }
}