type Language = 'ar' | 'en';

export interface Translations {
  // Welcome Screen
  welcomeTitle: string;
  welcomeSubtitle: string;
  welcomeDescription: string;
  buyWithConfidenceTitle: string;
  buyWithConfidenceDesc: string;
  startSellingTitle: string;
  startSellingDesc: string;
  transactionsLabel: string;
  transactionsValue: string;
  deliveryLabel: string;
  deliveryValue: string;
  createAccount: string;
  login: string;
  termsPrefix: string;
  terms: string;
  and: string;
  privacy: string;
  
  // Splash Screen
  splashTagline: string;
  splashLoading: string;
  splashVersion: string;
  
  // Common
  rabit: string;
  platformName: string;
  back: string;
  next: string;
  continue: string;
  save: string;
  cancel: string;
  confirm: string;
  delete: string;
  edit: string;
  search: string;
  filter: string;
  sort: string;
  apply: string;
  reset: string;
  submit: string;
  done: string;
  skip: string;
  close: string;
  viewAll: string;
  seeAll: string;
  
  // Navigation
  home: string;
  categories: string;
  orders: string;
  wallet: string;
  settings: string;
  notifications: string;
  favorites: string;
  profile: string;
  chat: string;
  
  // Register Screen
  registerTitle: string;
  registerSubtitle: string;
  fullName: string;
  email: string;
  phoneNumber: string;
  password: string;
  confirmPassword: string;
  agreeToTerms: string;
  alreadyHaveAccount: string;
  
  // Login Screen
  loginTitle: string;
  loginSubtitle: string;
  emailOrPhone: string;
  forgotPassword: string;
  noAccount: string;
  signUp: string;
  welcomeBack: string;
  
  // OTP Screen
  otpTitle: string;
  otpSubtitle: string;
  otpSentTo: string;
  verifyCode: string;
  resendCode: string;
  didntReceive: string;
  verify: string;
  enterCode: string;
  
  // Role Selection
  roleTitle: string;
  roleSubtitle: string;
  buyer: string;
  seller: string;
  both: string;
  buyerDesc: string;
  sellerDesc: string;
  bothDesc: string;
  selectRole: string;
  
  // Home Screen
  searchPlaceholder: string;
  featured: string;
  recommended: string;
  newArrivals: string;
  trending: string;
  popularItems: string;
  switchToSeller: string;
  switchToBuyer: string;
  startSelling: string;
  addProduct: string;
  myProducts: string;
  
  // Product
  condition: string;
  conditionNew: string;
  conditionUsed: string;
  price: string;
  location: string;
  description: string;
  specifications: string;
  buyNow: string;
  addToFavorites: string;
  removeFromFavorites: string;
  chatWithSeller: string;
  reportListing: string;
  shareProduct: string;
  productDetails: string;
  sellerInformation: string;
  
  // Seller Profile
  sellerProfile: string;
  memberSince: string;
  responseTime: string;
  activeListings: string;
  totalSales: string;
  contactSeller: string;
  verified: string;
  rating: string;
  reviews: string;
  
  // Chat
  typeMessage: string;
  sendOffer: string;
  viewProduct: string;
  online: string;
  offline: string;
  typing: string;
  chatWithBuyer: string;
  attach: string;
  call: string;
  moreOptions: string;
  
  // Checkout
  checkoutTitle: string;
  orderSummary: string;
  productPrice: string;
  platformFee: string;
  deliveryFee: string;
  totalAmount: string;
  shippingAddress: string;
  selectAddress: string;
  addNewAddress: string;
  paymentMethod: string;
  selectPaymentMethod: string;
  proceedToPayment: string;
  feeBreakdown: string;
  
  // Payment
  paymentTitle: string;
  paymentSubtitle: string;
  cardNumber: string;
  expiryDate: string;
  cvv: string;
  cardholderName: string;
  payNow: string;
  securePayment: string;
  addPaymentMethod: string;
  
  // Order Success
  orderSuccessTitle: string;
  orderSuccessMessage: string;
  orderNumber: string;
  viewOrders: string;
  continueShopping: string;
  trackOrder: string;
  
  // Orders
  ordersTitle: string;
  activeOrders: string;
  completedOrders: string;
  cancelledOrders: string;
  orderStatus: string;
  pending: string;
  processing: string;
  shipped: string;
  delivered: string;
  cancelled: string;
  allOrders: string;
  noOrders: string;
  
  // Wallet
  walletTitle: string;
  availableBalance: string;
  totalEarnings: string;
  pendingAmount: string;
  withdraw: string;
  addFunds: string;
  transactionHistory: string;
  recentTransactions: string;
  
  // Settings
  settingsTitle: string;
  accountSettings: string;
  editProfile: string;
  changePassword: string;
  manageAddresses: string;
  paymentMethods: string;
  preferences: string;
  language: string;
  helpSupport: string;
  helpCenter: string;
  aboutUs: string;
  logout: string;
  deleteAccount: string;
  
  // Notifications
  notificationsTitle: string;
  markAllRead: string;
  noNotifications: string;
  today: string;
  yesterday: string;
  thisWeek: string;
  earlier: string;
  
  // Add Product
  addProductTitle: string;
  editProductTitle: string;
  productPhotos: string;
  uploadPhotos: string;
  productTitle: string;
  productDescription: string;
  category: string;
  selectCategory: string;
  productCondition: string;
  setProductPrice: string;
  productLocation: string;
  quantity: string; // New: Quantity field
  availableStock: string; // New: Available stock
  inStock: string; // New: In stock
  outOfStock: string; // New: Out of stock
  itemsLeft: string; // New: X items left
  publishListing: string;
  updateListing: string;
  saveDraft: string;
  productImagesHelper: string;
  primaryImage: string;
  addImageButton: string;
  required: string;
  charactersCount: string;
  tipsForFasterSale: string;
  tip1: string;
  tip2: string;
  tip3: string;
  tip4: string;
  productPublishedSuccess: string;
  productNowAvailable: string;
  placeholderProductTitle: string;
  placeholderDescription: string;
  
  // Seller Home
  sellerMode: string;
  buyerMode: string;
  addNewProduct: string;
  activeProducts: string;
  soldProducts: string;
  totalRevenue: string;
  quickActions: string;
  myListings: string;
  statusActive: string;
  statusSold: string;
  statusDraft: string;
  views: string;
  messages: string;
  sales: string;
  revenue: string;
  
  // Categories
  electronics: string;
  fashion: string;
  homeGarden: string;
  sports: string;
  automotive: string;
  books: string;
  toys: string;
  other: string;
  allCategories: string;
  
  // Cities
  riyadh: string;
  jeddah: string;
  dammam: string;
  mecca: string;
  medina: string;
  selectCity: string;
  
  // Messages
  successMessage: string;
  errorMessage: string;
  loading: string;
  noResults: string;
  tryAgain: string;
  somethingWentWrong: string;
  
  // Address
  addressTitle: string;
  addAddress: string;
  editAddress: string;
  name: string;
  phone: string;
  city: string;
  district: string;
  street: string;
  building: string;
  postalCode: string;
  setAsDefault: string;
  
  // Reviews
  writeReview: string;
  yourRating: string;
  yourReview: string;
  submitReview: string;
  
  // Dispute
  openDispute: string;
  disputeReason: string;
  disputeDescription: string;
  submitDispute: string;
  
  // Shipping
  shipOrder: string;
  shippingDetails: string;
  trackingNumber: string;
  shippingCompany: string;
  estimatedDelivery: string;
  
  // Success Messages
  accountCreated: string;
  loginSuccessful: string;
  productAdded: string;
  productUpdated: string;
  orderPlaced: string;
  paymentSuccessful: string;
  profileUpdated: string;
  
  // Time
  justNow: string;
  minutesAgo: string;
  hoursAgo: string;
  daysAgo: string;
  weeksAgo: string;
  
  // Currency
  sar: string;
  currency: string;
}

export const translations: Record<Language, Translations> = {
  ar: {
    // Welcome Screen
    welcomeTitle: 'مرحباً بك في',
    welcomeSubtitle: 'رابط',
    welcomeDescription: 'منصة البيع والشراء الأكثر أماناً في المملكة ✨',
    buyWithConfidenceTitle: 'اشتري بثقة',
    buyWithConfidenceDesc: 'اكتشف آلاف المنتجات من بائعين موثوقين مع حماية كاملة للمشتري',
    startSellingTitle: 'ابدأ البيع الآن',
    startSellingDesc: 'حوّل منتجاتك إلى أرباح مع عمولات منخفضة ودعم فوري',
    transactionsLabel: 'معاملات',
    transactionsValue: '100% آمنة',
    deliveryLabel: 'توصيل',
    deliveryValue: 'سريع',
    createAccount: 'إنشاء حساب جديد',
    login: 'تسجيل الدخول',
    termsPrefix: 'بالمتابعة، أنت توافق على',
    terms: 'الشروط والأحكام',
    and: 'و',
    privacy: 'سياسة الخصوصية',
    
    // Splash Screen
    splashTagline: 'بيع واشتري على راحتك',
    splashLoading: 'جاري التحميل...',
    splashVersion: 'v1.0.0 • منصة آمنة وموثوقة',
    
    // Common
    rabit: 'رابط',
    platformName: 'رابط',
    back: 'رجوع',
    next: 'التالي',
    continue: 'متابعة',
    save: 'حفظ',
    cancel: 'إلغاء',
    confirm: 'تأكيد',
    delete: 'حذف',
    edit: 'تعديل',
    search: 'بحث',
    filter: 'تصفية',
    sort: 'ترتيب',
    apply: 'تطبيق',
    reset: 'إعادة تعيين',
    submit: 'إرسال',
    done: 'تم',
    skip: 'تخطي',
    close: 'إغلاق',
    viewAll: 'عرض الكل',
    seeAll: 'مشاهدة الكل',
    
    // Navigation
    home: 'الرئيسية',
    categories: 'الفئات',
    orders: 'الطلبات',
    wallet: 'المحفظة',
    settings: 'الإعدادات',
    notifications: 'الإشعارات',
    favorites: 'المفضلة',
    profile: 'الملف الشخصي',
    chat: 'الدردشة',
    
    // Register Screen
    registerTitle: 'إنشاء حساب جديد',
    registerSubtitle: 'انضم إلى آلاف المستخدمين على منصة رابط',
    fullName: 'الاسم الكامل',
    email: 'البريد الإلكتروني',
    phoneNumber: 'رقم الجوال',
    password: 'كلمة المرور',
    confirmPassword: 'تأكيد كلمة المرور',
    agreeToTerms: 'أوافق على الشروط والأحكام',
    alreadyHaveAccount: 'لديك حساب بالفعل؟',
    
    // Login Screen
    loginTitle: 'تسجيل الدخول',
    loginSubtitle: 'مرحباً بعودتك إلى رابط',
    emailOrPhone: 'البريد الإلكتروني أو رقم الجوال',
    forgotPassword: 'نسيت كلمة المرور؟',
    noAccount: 'ليس لديك حساب؟',
    signUp: 'إنشاء حساب',
    welcomeBack: 'مرحباً بعودتك',
    
    // OTP Screen
    otpTitle: 'التحقق من الرقم',
    otpSubtitle: 'أدخل الرمز المكون من 6 أرقام',
    otpSentTo: 'تم إرسال الرمز إلى',
    verifyCode: 'التحقق من الرمز',
    resendCode: 'إعادة إرسال الرمز',
    didntReceive: 'لم تستلم الرمز؟',
    verify: 'تحقق',
    enterCode: 'أدخل الرمز',
    
    // Role Selection
    roleTitle: 'اختر دورك',
    roleSubtitle: 'كيف تريد استخدام منصة رابط؟',
    buyer: 'مشتري',
    seller: 'بائع',
    both: 'الإثنين معاً',
    buyerDesc: 'تصفح وشراء المنتجات من بائعين موثوقين',
    sellerDesc: 'بيع منتجاتك وتحقيق الأرباح',
    bothDesc: 'شراء وبيع المنتجات في مكان واحد',
    selectRole: 'اختر دورك',
    
    // Home Screen
    searchPlaceholder: 'ابحث عن منتجات...',
    featured: 'مميزة',
    recommended: 'موصى بها',
    newArrivals: 'وصل حديثاً',
    trending: 'رائجة',
    popularItems: 'الأكثر شعبية',
    switchToSeller: 'التبديل لوضع البائع',
    switchToBuyer: 'التبديل لوضع المشتري',
    startSelling: 'ابدأ البيع',
    addProduct: 'إضافة منتج',
    myProducts: 'منتجاتي',
    
    // Product
    condition: 'الحالة',
    conditionNew: 'جديد',
    conditionUsed: 'مستعمل',
    price: 'السعر',
    location: 'الموقع',
    description: 'الوصف',
    specifications: 'المواصفات',
    buyNow: 'اشتري الآن',
    addToFavorites: 'إضافة للمفضلة',
    removeFromFavorites: 'إزالة من المفضلة',
    chatWithSeller: 'تواصل مع البائع',
    reportListing: 'الإبلاغ عن الإعلان',
    shareProduct: 'مشاركة المنتج',
    productDetails: 'تفاصيل المنتج',
    sellerInformation: 'معلومات البائع',
    
    // Seller Profile
    sellerProfile: 'ملف البائع',
    memberSince: 'عضو منذ',
    responseTime: 'وقت الاستجابة',
    activeListings: 'الإعلانات النشطة',
    totalSales: 'إجمالي المبيعات',
    contactSeller: 'تواصل مع البائع',
    verified: 'موثق',
    rating: 'التقييم',
    reviews: 'التقييمات',
    
    // Chat
    typeMessage: 'اكتب رسالة...',
    sendOffer: 'إرسال عرض',
    viewProduct: 'عرض المنتج',
    online: 'متصل',
    offline: 'غير متصل',
    typing: 'يكتب...',
    chatWithBuyer: 'تواصل مع المشتري',
    attach: 'إرفاق ملف',
    call: 'اتصال',
    moreOptions: 'خيارات أخرى',
    
    // Checkout
    checkoutTitle: 'إتمام الطلب',
    orderSummary: 'ملخص الطلب',
    productPrice: 'سعر المنتج',
    platformFee: 'عمولة المنصة',
    deliveryFee: 'رسوم التوصيل',
    totalAmount: 'المبلغ الإجمالي',
    shippingAddress: 'عنوان الشحن',
    selectAddress: 'اختر عنوان',
    addNewAddress: 'إضافة عنوان جديد',
    paymentMethod: 'طريقة الدفع',
    selectPaymentMethod: 'اختر طريقة الدفع',
    proceedToPayment: 'متابعة للدفع',
    feeBreakdown: 'تفصيل الرسوم',
    
    // Payment
    paymentTitle: 'الدفع',
    paymentSubtitle: 'أدخل معلومات بطاقتك',
    cardNumber: 'رقم البطاقة',
    expiryDate: 'تاريخ الانتهاء',
    cvv: 'رمز الأمان',
    cardholderName: 'اسم حامل البطاقة',
    payNow: 'ادفع الآن',
    securePayment: 'دفع آمن',
    addPaymentMethod: 'إضافة طريقة دفع',
    
    // Order Success
    orderSuccessTitle: 'تم تأكيد طلبك!',
    orderSuccessMessage: 'شكراً لك! سيتم شحن طلبك قريباً',
    orderNumber: 'رقم الطلب',
    viewOrders: 'عرض الطلبات',
    continueShopping: 'متابعة التسوق',
    trackOrder: 'تتبع الطلب',
    
    // Orders
    ordersTitle: 'طلباتي',
    activeOrders: 'الطلبات النشطة',
    completedOrders: 'الطلبات المكتملة',
    cancelledOrders: 'الطلبات الملغاة',
    orderStatus: 'حالة الطلب',
    pending: 'قيد الانتظار',
    processing: 'قيد المعالجة',
    shipped: 'تم الشحن',
    delivered: 'تم التوصيل',
    cancelled: 'ملغي',
    allOrders: 'جميع الطلبات',
    noOrders: 'لا توجد طلبات',
    
    // Wallet
    walletTitle: 'محفظتي',
    availableBalance: 'الرصيد المتاح',
    totalEarnings: 'إجمالي الأرباح',
    pendingAmount: 'المبلغ المعلق',
    withdraw: 'سحب',
    addFunds: 'إضافة رصيد',
    transactionHistory: 'سجل المعاملات',
    recentTransactions: 'المعاملات الأخيرة',
    
    // Settings
    settingsTitle: 'الإعدادات',
    accountSettings: 'إعدادات الحساب',
    editProfile: 'تعديل الملف الشخصي',
    changePassword: 'تغيير كلمة المرور',
    manageAddresses: 'إدارة العناوين',
    paymentMethods: 'طرق الدفع',
    preferences: 'التفضيلات',
    language: 'اللغة',
    helpSupport: 'المساعدة والدعم',
    helpCenter: 'مركز امساعدة',
    aboutUs: 'من نحن',
    logout: 'تسجيل الخروج',
    deleteAccount: 'حذف الحساب',
    
    // Notifications
    notificationsTitle: 'الإشعارات',
    markAllRead: 'تعليم الكل كمقروء',
    noNotifications: 'لا توجد إشعارات',
    today: 'اليوم',
    yesterday: 'أمس',
    thisWeek: 'هذا الأسبوع',
    earlier: 'سابقاً',
    
    // Add Product
    addProductTitle: 'إضافة منتج جديد',
    editProductTitle: 'تعديل المنتج',
    productPhotos: 'صور المنتج',
    uploadPhotos: 'تحميل الصور',
    productTitle: 'عنوان المنتج',
    productDescription: 'وصف المنتج',
    category: 'الفئة',
    selectCategory: 'اختر الفئة',
    productCondition: 'حالة المنتج',
    setProductPrice: 'تحديد سعر المنتج',
    productLocation: 'موقع المنتج',
    quantity: 'الكمية', // New: Quantity field
    availableStock: 'الكمية المتاحة', // New: Available stock
    inStock: 'في المخزن', // New: In stock
    outOfStock: 'غير متاح', // New: Out of stock
    itemsLeft: 'منتجات متبقية: {0}', // New: X items left
    publishListing: 'نشر الإعلان',
    updateListing: 'تحديث الإعلان',
    saveDraft: 'حفظ كمسودة',
    productImagesHelper: 'يمكنك إضافة صور متعددة للمنتج لجذب المزيد من المشترين',
    primaryImage: 'الصورة الأساسية',
    addImageButton: 'إضافة صورة',
    required: 'مطلوب',
    charactersCount: 'عدد الحروف: {0}',
    tipsForFasterSale: 'نصائح لبيع المنتج بشكل أسرع',
    tip1: 'أضف صوراً عالية الجودة للمنتج',
    tip2: 'أضف وصفاً مفصلاً وموجزاً للمنتج',
    tip3: 'حدد سعر مناسباً للمنتج',
    tip4: 'أضف تفاصيل المنتج مثل المواصفات والحجم واللون',
    productPublishedSuccess: 'تم نشر المنتج بنجاح!',
    productNowAvailable: 'المنتج الآن متاح للبيع',
    placeholderProductTitle: 'عنوان المنتج',
    placeholderDescription: 'وصف المنتج',
    
    // Seller Home
    sellerMode: 'وضع البائع',
    buyerMode: 'وضع المشتري',
    addNewProduct: 'إضافة منتج جديد',
    activeProducts: 'منتجات نشطة',
    soldProducts: 'منتجات مباعة',
    totalRevenue: 'إجمالي الإيرادات',
    quickActions: 'إجراءات سريعة',
    myListings: 'إعلاناتي',
    statusActive: 'نشط',
    statusSold: 'مباعة',
    statusDraft: 'مسودة',
    views: 'مشاهدات',
    messages: 'رسائل',
    sales: 'المبيعات',
    revenue: 'الإيرادات',
    
    // Categories
    electronics: 'إلكترونيات',
    fashion: 'أزياء',
    homeGarden: 'منزل وحديقة',
    sports: 'رياضة',
    automotive: 'سيارات',
    books: 'كتب',
    toys: 'ألعاب',
    other: 'أخرى',
    allCategories: 'جميع الفئات',
    
    // Cities
    riyadh: 'الرياض',
    jeddah: 'جدة',
    dammam: 'الدمام',
    mecca: 'مكة',
    medina: 'المدينة',
    selectCity: 'اختر المدينة',
    
    // Messages
    successMessage: 'تمت العملية بنجاح',
    errorMessage: 'حدث خطأ ما',
    loading: 'جاري التحميل...',
    noResults: 'لا توجد نتائج',
    tryAgain: 'حاول مرة أخرى',
    somethingWentWrong: 'حدث خطأ ما',
    
    // Address
    addressTitle: 'العناوين',
    addAddress: 'إضافة عنوان',
    editAddress: 'تعديل العنوان',
    name: 'الاسم',
    phone: 'الهاتف',
    city: 'المدينة',
    district: 'الحي',
    street: 'الشارع',
    building: 'المبنى',
    postalCode: 'الرمز البريدي',
    setAsDefault: 'تعيين كعنوان افتراضي',
    
    // Reviews
    writeReview: 'كتابة تقييم',
    yourRating: 'تقييمك',
    yourReview: 'تقييمك',
    submitReview: 'إرسال التقييم',
    
    // Dispute
    openDispute: 'فتح نزاع',
    disputeReason: 'سبب النزاع',
    disputeDescription: 'وصف النزاع',
    submitDispute: 'إرسال النزاع',
    
    // Shipping
    shipOrder: 'شحن الطلب',
    shippingDetails: 'تفاصيل الشحن',
    trackingNumber: 'رقم التتبع',
    shippingCompany: 'شركة الشحن',
    estimatedDelivery: 'التوصيل المتوقع',
    
    // Success Messages
    accountCreated: 'تم إنشاء الحساب بنجاح',
    loginSuccessful: 'تم تسجيل الدخول بنجاح',
    productAdded: 'تم إضافة المنتج بنجاح',
    productUpdated: 'تم تحديث المنتج بنجاح',
    orderPlaced: 'تم تقديم الطلب بنجاح',
    paymentSuccessful: 'تم الدفع بنجاح',
    profileUpdated: 'تم تحديث الملف الشخصي',
    
    // Time
    justNow: 'الآن',
    minutesAgo: 'منذ {0} دقيقة',
    hoursAgo: 'منذ {0} ساعة',
    daysAgo: 'منذ {0} يوم',
    weeksAgo: 'منذ {0} أسبوع',
    
    // Currency
    sar: 'ر.س',
    currency: 'ر.س',
  },
  en: {
    // Welcome Screen
    welcomeTitle: 'Welcome to',
    welcomeSubtitle: 'Rabit',
    welcomeDescription: 'The safest marketplace platform in Saudi Arabia ✨',
    buyWithConfidenceTitle: 'Buy with Confidence',
    buyWithConfidenceDesc: 'Discover thousands of products from trusted sellers with full buyer protection',
    startSellingTitle: 'Start Selling Now',
    startSellingDesc: 'Turn your products into profits with low fees and instant support',
    transactionsLabel: 'Transactions',
    transactionsValue: '100% Secure',
    deliveryLabel: 'Delivery',
    deliveryValue: 'Fast',
    createAccount: 'Create New Account',
    login: 'Sign In',
    termsPrefix: 'By continuing, you agree to',
    terms: 'Terms & Conditions',
    and: 'and',
    privacy: 'Privacy Policy',
    
    // Splash Screen
    splashTagline: 'Buy and sell with ease',
    splashLoading: 'Loading...',
    splashVersion: 'v1.0.0 • Secure & Trusted Platform',
    
    // Common
    rabit: 'Rabit',
    platformName: 'Rabit',
    back: 'Back',
    next: 'Next',
    continue: 'Continue',
    save: 'Save',
    cancel: 'Cancel',
    confirm: 'Confirm',
    delete: 'Delete',
    edit: 'Edit',
    search: 'Search',
    filter: 'Filter',
    sort: 'Sort',
    apply: 'Apply',
    reset: 'Reset',
    submit: 'Submit',
    done: 'Done',
    skip: 'Skip',
    close: 'Close',
    viewAll: 'View All',
    seeAll: 'See All',
    
    // Navigation
    home: 'Home',
    categories: 'Categories',
    orders: 'Orders',
    wallet: 'Wallet',
    settings: 'Settings',
    notifications: 'Notifications',
    favorites: 'Favorites',
    profile: 'Profile',
    chat: 'Chat',
    
    // Register Screen
    registerTitle: 'Create Account',
    registerSubtitle: 'Join thousands of users on Rabit platform',
    fullName: 'Full Name',
    email: 'Email',
    phoneNumber: 'Phone Number',
    password: 'Password',
    confirmPassword: 'Confirm Password',
    agreeToTerms: 'I agree to Terms & Conditions',
    alreadyHaveAccount: 'Already have an account?',
    
    // Login Screen
    loginTitle: 'Sign In',
    loginSubtitle: 'Welcome back to Rabit',
    emailOrPhone: 'Email or Phone Number',
    forgotPassword: 'Forgot Password?',
    noAccount: "Don't have an account?",
    signUp: 'Sign Up',
    welcomeBack: 'Welcome Back',
    
    // OTP Screen
    otpTitle: 'Verify Number',
    otpSubtitle: 'Enter 6-digit code',
    otpSentTo: 'Code sent to',
    verifyCode: 'Verify Code',
    resendCode: 'Resend Code',
    didntReceive: "Didn't receive code?",
    verify: 'Verify',
    enterCode: 'Enter Code',
    
    // Role Selection
    roleTitle: 'Choose Your Role',
    roleSubtitle: 'How would you like to use Rabit?',
    buyer: 'Buyer',
    seller: 'Seller',
    both: 'Both',
    buyerDesc: 'Browse and buy products from trusted sellers',
    sellerDesc: 'Sell your products and earn money',
    bothDesc: 'Buy and sell products in one place',
    selectRole: 'Select Your Role',
    
    // Home Screen
    searchPlaceholder: 'Search for products...',
    featured: 'Featured',
    recommended: 'Recommended',
    newArrivals: 'New Arrivals',
    trending: 'Trending',
    popularItems: 'Popular Items',
    switchToSeller: 'Switch to Seller Mode',
    switchToBuyer: 'Switch to Buyer Mode',
    startSelling: 'Start Selling',
    addProduct: 'Add Product',
    myProducts: 'My Products',
    
    // Product
    condition: 'Condition',
    conditionNew: 'New',
    conditionUsed: 'Used',
    price: 'Price',
    location: 'Location',
    description: 'Description',
    specifications: 'Specifications',
    buyNow: 'Buy Now',
    addToFavorites: 'Add to Favorites',
    removeFromFavorites: 'Remove from Favorites',
    chatWithSeller: 'Chat with Seller',
    reportListing: 'Report Listing',
    shareProduct: 'Share Product',
    productDetails: 'Product Details',
    sellerInformation: 'Seller Information',
    
    // Seller Profile
    sellerProfile: 'Seller Profile',
    memberSince: 'Member Since',
    responseTime: 'Response Time',
    activeListings: 'Active Listings',
    totalSales: 'Total Sales',
    contactSeller: 'Contact Seller',
    verified: 'Verified',
    rating: 'Rating',
    reviews: 'Reviews',
    
    // Chat
    typeMessage: 'Type a message...',
    sendOffer: 'Send Offer',
    viewProduct: 'View Product',
    online: 'Online',
    offline: 'Offline',
    typing: 'Typing...',
    chatWithBuyer: 'Chat with Buyer',
    attach: 'Attach File',
    call: 'Call',
    moreOptions: 'More Options',
    
    // Checkout
    checkoutTitle: 'Checkout',
    orderSummary: 'Order Summary',
    productPrice: 'Product Price',
    platformFee: 'Platform Fee',
    deliveryFee: 'Delivery Fee',
    totalAmount: 'Total Amount',
    shippingAddress: 'Shipping Address',
    selectAddress: 'Select Address',
    addNewAddress: 'Add New Address',
    paymentMethod: 'Payment Method',
    selectPaymentMethod: 'Select Payment Method',
    proceedToPayment: 'Proceed to Payment',
    feeBreakdown: 'Fee Breakdown',
    
    // Payment
    paymentTitle: 'Payment',
    paymentSubtitle: 'Enter your card details',
    cardNumber: 'Card Number',
    expiryDate: 'Expiry Date',
    cvv: 'CVV',
    cardholderName: 'Cardholder Name',
    payNow: 'Pay Now',
    securePayment: 'Secure Payment',
    addPaymentMethod: 'Add Payment Method',
    
    // Order Success
    orderSuccessTitle: 'Order Confirmed!',
    orderSuccessMessage: 'Thank you! Your order will be shipped soon',
    orderNumber: 'Order Number',
    viewOrders: 'View Orders',
    continueShopping: 'Continue Shopping',
    trackOrder: 'Track Order',
    
    // Orders
    ordersTitle: 'My Orders',
    activeOrders: 'Active Orders',
    completedOrders: 'Completed Orders',
    cancelledOrders: 'Cancelled Orders',
    orderStatus: 'Order Status',
    pending: 'Pending',
    processing: 'Processing',
    shipped: 'Shipped',
    delivered: 'Delivered',
    cancelled: 'Cancelled',
    allOrders: 'All Orders',
    noOrders: 'No Orders',
    
    // Wallet
    walletTitle: 'My Wallet',
    availableBalance: 'Available Balance',
    totalEarnings: 'Total Earnings',
    pendingAmount: 'Pending Amount',
    withdraw: 'Withdraw',
    addFunds: 'Add Funds',
    transactionHistory: 'Transaction History',
    recentTransactions: 'Recent Transactions',
    
    // Settings
    settingsTitle: 'Settings',
    accountSettings: 'Account Settings',
    editProfile: 'Edit Profile',
    changePassword: 'Change Password',
    manageAddresses: 'Manage Addresses',
    paymentMethods: 'Payment Methods',
    preferences: 'Preferences',
    language: 'Language',
    helpSupport: 'Help & Support',
    helpCenter: 'Help Center',
    aboutUs: 'About Us',
    logout: 'Logout',
    deleteAccount: 'Delete Account',
    
    // Notifications
    notificationsTitle: 'Notifications',
    markAllRead: 'Mark All as Read',
    noNotifications: 'No Notifications',
    today: 'Today',
    yesterday: 'Yesterday',
    thisWeek: 'This Week',
    earlier: 'Earlier',
    
    // Add Product
    addProductTitle: 'Add New Product',
    editProductTitle: 'Edit Product',
    productPhotos: 'Product Photos',
    uploadPhotos: 'Upload Photos',
    productTitle: 'Product Title',
    productDescription: 'Product Description',
    category: 'Category',
    selectCategory: 'Select Category',
    productCondition: 'Product Condition',
    setProductPrice: 'Set Product Price',
    productLocation: 'Product Location',
    quantity: 'Quantity', // New: Quantity field
    availableStock: 'Available Stock', // New: Available stock
    inStock: 'In Stock', // New: In stock
    outOfStock: 'Out of Stock', // New: Out of stock
    itemsLeft: '{0} Items Left', // New: X items left
    publishListing: 'Publish Listing',
    updateListing: 'Update Listing',
    saveDraft: 'Save as Draft',
    productImagesHelper: 'You can add multiple images of the product to attract more buyers',
    primaryImage: 'Primary Image',
    addImageButton: 'Add Image',
    required: 'Required',
    charactersCount: 'Characters Count: {0}',
    tipsForFasterSale: 'Tips for Faster Sale',
    tip1: 'Add high-quality images of the product',
    tip2: 'Add a detailed and concise product description',
    tip3: 'Set a reasonable price for the product',
    tip4: 'Add product details such as specifications, size, and color',
    productPublishedSuccess: 'Product published successfully!',
    productNowAvailable: 'The product is now available for sale',
    placeholderProductTitle: 'Product Title',
    placeholderDescription: 'Product Description',
    
    // Seller Home
    sellerMode: 'Seller Mode',
    buyerMode: 'Buyer Mode',
    addNewProduct: 'Add New Product',
    activeProducts: 'Active Products',
    soldProducts: 'Sold Products',
    totalRevenue: 'Total Revenue',
    quickActions: 'Quick Actions',
    myListings: 'My Listings',
    statusActive: 'Active',
    statusSold: 'Sold',
    statusDraft: 'Draft',
    views: 'Views',
    messages: 'Messages',
    sales: 'Sales',
    revenue: 'Revenue',
    
    // Categories
    electronics: 'Electronics',
    fashion: 'Fashion',
    homeGarden: 'Home & Garden',
    sports: 'Sports',
    automotive: 'Automotive',
    books: 'Books',
    toys: 'Toys',
    other: 'Other',
    allCategories: 'All Categories',
    
    // Cities
    riyadh: 'Riyadh',
    jeddah: 'Jeddah',
    dammam: 'Dammam',
    mecca: 'Mecca',
    medina: 'Medina',
    selectCity: 'Select City',
    
    // Messages
    successMessage: 'Operation successful',
    errorMessage: 'Something went wrong',
    loading: 'Loading...',
    noResults: 'No Results',
    tryAgain: 'Try Again',
    somethingWentWrong: 'Something went wrong',
    
    // Address
    addressTitle: 'Addresses',
    addAddress: 'Add Address',
    editAddress: 'Edit Address',
    name: 'Name',
    phone: 'Phone',
    city: 'City',
    district: 'District',
    street: 'Street',
    building: 'Building',
    postalCode: 'Postal Code',
    setAsDefault: 'Set as Default',
    
    // Reviews
    writeReview: 'Write Review',
    yourRating: 'Your Rating',
    yourReview: 'Your Review',
    submitReview: 'Submit Review',
    
    // Dispute
    openDispute: 'Open Dispute',
    disputeReason: 'Dispute Reason',
    disputeDescription: 'Dispute Description',
    submitDispute: 'Submit Dispute',
    
    // Shipping
    shipOrder: 'Ship Order',
    shippingDetails: 'Shipping Details',
    trackingNumber: 'Tracking Number',
    shippingCompany: 'Shipping Company',
    estimatedDelivery: 'Estimated Delivery',
    
    // Success Messages
    accountCreated: 'Account created successfully',
    loginSuccessful: 'Login successful',
    productAdded: 'Product added successfully',
    productUpdated: 'Product updated successfully',
    orderPlaced: 'Order placed successfully',
    paymentSuccessful: 'Payment successful',
    profileUpdated: 'Profile updated successfully',
    
    // Time
    justNow: 'Just now',
    minutesAgo: '{0} minutes ago',
    hoursAgo: '{0} hours ago',
    daysAgo: '{0} days ago',
    weeksAgo: '{0} weeks ago',
    
    // Currency
    sar: 'SAR',
    currency: 'SAR',
  },
};

export function getTranslation(language: Language): Translations {
  return translations[language];
}