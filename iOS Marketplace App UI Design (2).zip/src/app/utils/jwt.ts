/**
 * JWT Utility Functions
 * Handles JWT token decoding and validation
 */

export interface JWTPayload {
  userId?: string;
  sub?: string;
  email?: string;
  role?: string;
  exp?: number;
  iat?: number;
  iss?: string;
}

/**
 * Decode JWT token and return payload
 * Does NOT verify signature (signature verification happens on backend)
 */
export function decodeJWT(token: string): JWTPayload | null {
  try {
    // JWT format: header.payload.signature
    const parts = token.split('.');
    
    if (parts.length !== 3) {
      console.error('❌ Invalid JWT format - expected 3 parts, got:', parts.length);
      return null;
    }
    
    // Decode the payload (middle part)
    const payload = parts[1];
    
    // Decode URL-safe base64 (convert - to + and _ to /)
    const base64 = payload
      .replace(/-/g, '+')
      .replace(/_/g, '/');
    
    // Add padding if needed
    const padded = base64 + '==='.slice((base64.length + 3) % 4);
    
    // Decode base64 to JSON string
    const payloadJson = atob(padded);
    
    // Parse JSON
    const decoded = JSON.parse(payloadJson);
    
    return decoded;
  } catch (error) {
    console.error('❌ Failed to decode JWT:', error);
    return null;
  }
}

/**
 * Check if JWT token is expired
 */
export function isJWTExpired(token: string): boolean {
  const payload = decodeJWT(token);
  
  if (!payload || !payload.exp) {
    // If we can't decode or there's no expiration, consider it expired
    return true;
  }
  
  // exp is in seconds, Date.now() is in milliseconds
  const now = Math.floor(Date.now() / 1000);
  const isExpired = payload.exp < now;
  
  if (isExpired) {
    const expirationDate = new Date(payload.exp * 1000);
    console.warn('⚠️ JWT expired at:', expirationDate.toISOString());
  }
  
  return isExpired;
}

/**
 * Get user ID from JWT token
 */
export function getUserIdFromJWT(token: string): string | null {
  const payload = decodeJWT(token);
  
  if (!payload) {
    return null;
  }
  
  // Try different fields that might contain user ID
  return payload.userId || payload.sub || null;
}

/**
 * Validate JWT token structure and content
 * Returns true if token is valid and not expired
 */
export function validateJWT(token: string): boolean {
  if (!token || typeof token !== 'string') {
    console.error('❌ Invalid token - not a string');
    return false;
  }
  
  // Check format
  const parts = token.split('.');
  if (parts.length !== 3) {
    console.error('❌ Invalid JWT format - expected 3 parts, got:', parts.length);
    return false;
  }
  
  // Decode payload
  const payload = decodeJWT(token);
  if (!payload) {
    console.error('❌ Could not decode JWT payload');
    return false;
  }
  
  // Check for required fields
  const userId = payload.userId || payload.sub;
  if (!userId) {
    console.error('❌ JWT missing user ID (userId or sub)');
    return false;
  }
  
  // Check expiration
  if (isJWTExpired(token)) {
    console.error('❌ JWT is expired');
    return false;
  }
  
  console.log('✅ JWT is valid:', {
    userId,
    email: payload.email,
    expiresAt: payload.exp ? new Date(payload.exp * 1000).toISOString() : 'never',
  });
  
  return true;
}

/**
 * Get time until JWT expires (in milliseconds)
 */
export function getJWTTimeToExpiry(token: string): number | null {
  const payload = decodeJWT(token);
  
  if (!payload || !payload.exp) {
    return null;
  }
  
  const now = Date.now();
  const expiryTime = payload.exp * 1000; // Convert to milliseconds
  const timeToExpiry = expiryTime - now;
  
  return timeToExpiry > 0 ? timeToExpiry : 0;
}

/**
 * Format JWT payload for logging (removes sensitive data)
 */
export function formatJWTForLogging(token: string): object {
  const payload = decodeJWT(token);
  
  if (!payload) {
    return { error: 'Could not decode token' };
  }
  
  return {
    userId: payload.userId || payload.sub,
    email: payload.email,
    role: payload.role,
    issuedAt: payload.iat ? new Date(payload.iat * 1000).toISOString() : 'unknown',
    expiresAt: payload.exp ? new Date(payload.exp * 1000).toISOString() : 'never',
    issuer: payload.iss || 'unknown',
  };
}
