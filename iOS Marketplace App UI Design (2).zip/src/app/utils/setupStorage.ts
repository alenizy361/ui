/**
 * Storage Setup Utility
 * 
 * Verifies storage buckets exist and provides setup instructions if needed
 * 
 * IMPORTANT: Buckets cannot be created from the frontend using anon key.
 * They must be created manually in Supabase Dashboard.
 */

import { supabase } from '../lib/supabase';

export async function setupStorageBuckets() {
  try {
    console.log('🔧 [Setup] Checking storage buckets...');

    // NOTE: listBuckets() requires service_role key, not available with anon key
    // Buckets must be created manually in Supabase Dashboard
    // This check is informational only and won't block the app
    
    try {
      // List existing buckets (this may fail with anon key - that's OK)
      const { data: buckets, error: listError } = await supabase.storage.listBuckets();

      if (listError) {
        console.warn('⚠️ [Setup] Cannot list buckets with anon key (expected behavior)');
        console.warn('ℹ️ [Setup] Make sure you created these buckets in Supabase Dashboard:');
        console.warn('   - product-images (public)');
        console.warn('   - profile-images (public)');
        return { success: true }; // Don't block the app
      }

      console.log('📋 [Setup] Existing buckets:', buckets?.map(b => b.name));

      // Check if required buckets exist
      const productBucketExists = buckets?.some(b => b.name === 'product-images');
      const profileBucketExists = buckets?.some(b => b.name === 'profile-images');

      const missingBuckets: string[] = [];
      
      if (!productBucketExists) {
        missingBuckets.push('product-images');
        console.warn('⚠️ [Setup] Missing bucket: product-images');
      } else {
        console.log('✅ [Setup] product-images bucket exists');
      }

      if (!profileBucketExists) {
        missingBuckets.push('profile-images');
        console.warn('⚠️ [Setup] Missing bucket: profile-images');
      } else {
        console.log('✅ [Setup] profile-images bucket exists');
      }

      // If any buckets are missing, provide setup instructions
      if (missingBuckets.length > 0) {
        console.log('\n📌 [Setup] Storage buckets may need to be created in Supabase Dashboard');
        console.log('ℹ️ [Setup] Missing buckets:', missingBuckets.join(', '));
        console.log('ℹ️ [Setup] This will not affect authentication, but image uploads may fail.');
        console.log('ℹ️ [Setup] See https://supabase.com/dashboard for more info.\n');
      } else {
        console.log('✅ [Setup] All storage buckets are configured correctly');
      }

      return { success: true };
    } catch (innerError: any) {
      console.warn('⚠️ [Setup] Bucket check failed (this is OK - buckets may exist):', innerError.message);
      return { success: true }; // Don't block the app
    }
    
  } catch (error: any) {
    console.error('❌ [Setup] Storage setup error:', error);
    return { success: true }; // Don't block the app even on error
  }
}