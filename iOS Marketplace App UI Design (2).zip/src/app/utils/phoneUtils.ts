/**
 * Phone Number Utilities
 * Handles Saudi phone number formatting and normalization
 */

/**
 * Normalize Saudi phone number to consistent format: 05XXXXXXXX
 * Accepts: 501234567, 0501234567, +966501234567, 966501234567
 * Returns: 0501234567
 */
export function normalizePhone(phone: string): string {
  // Remove all non-digit characters
  const digitsOnly = phone.replace(/\D/g, '');
  
  // Handle different formats
  if (digitsOnly.startsWith('966')) {
    // +966501234567 or 966501234567 → 0501234567
    return '0' + digitsOnly.slice(3);
  } else if (digitsOnly.startsWith('05')) {
    // 0501234567 → 0501234567
    return digitsOnly;
  } else if (digitsOnly.length === 9) {
    // 501234567 → 0501234567
    return '0' + digitsOnly;
  }
  
  // Return as-is if format is unknown
  return digitsOnly;
}

/**
 * Format phone for display: +966 50 123 4567
 */
export function formatPhoneForDisplay(phone: string): string {
  const normalized = normalizePhone(phone);
  
  if (normalized.length === 10 && normalized.startsWith('05')) {
    // 0501234567 → +966 50 123 4567
    return `+966 ${normalized.slice(1, 3)} ${normalized.slice(3, 6)} ${normalized.slice(6)}`;
  }
  
  return phone;
}

/**
 * Get phone without country code for display in input
 * 0501234567 → 501234567
 */
export function getPhoneWithoutCountryCode(phone: string): string {
  const normalized = normalizePhone(phone);
  
  if (normalized.startsWith('05')) {
    return normalized.slice(1); // Remove the 0
  }
  
  return phone;
}

/**
 * Add Saudi country code for international format
 * 0501234567 → +966501234567
 */
export function toInternationalFormat(phone: string): string {
  const normalized = normalizePhone(phone);
  
  if (normalized.startsWith('05')) {
    return '+966' + normalized.slice(1);
  }
  
  return phone;
}
