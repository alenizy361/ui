import { notificationsAPI } from './api';

/**
 * Notification Auto-Trigger Utility
 * Automatically sends notifications when specific events occur throughout the app
 */

interface NotificationTriggerParams {
  userId: string;
  type: string;
  title: string;
  titleAr: string;
  message: string;
  messageAr: string;
  actionUrl?: string;
  productId?: string;
  orderId?: string;
  conversationId?: string;
  imageUrl?: string;
  category?: 'order' | 'message' | 'social' | 'system';
  accessToken: string;
}

/**
 * Generic notification trigger
 */
export const triggerNotification = async (params: NotificationTriggerParams) => {
  try {
    const response = await notificationsAPI.sendNotification(
      {
        userId: params.userId,
        type: params.type,
        title: params.title,
        titleAr: params.titleAr,
        message: params.message,
        messageAr: params.messageAr,
        actionUrl: params.actionUrl,
        productId: params.productId,
        orderId: params.orderId,
        conversationId: params.conversationId,
        imageUrl: params.imageUrl,
        category: params.category,
      },
      params.accessToken
    );

    if (!response.success) {
      console.error('Failed to send notification:', response.error);
    }

    return response;
  } catch (error) {
    console.error('Error triggering notification:', error);
    return { success: false, error: 'Failed to trigger notification' };
  }
};

/**
 * Trigger notification when a new message is received
 */
export const notifyNewMessage = async (
  recipientId: string,
  senderName: string,
  senderNameAr: string,
  messagePreview: string,
  messagePreviewAr: string,
  conversationId: string,
  productId: string | undefined,
  accessToken: string
) => {
  return triggerNotification({
    userId: recipientId,
    type: 'new_message',
    title: `New message from ${senderName}`,
    titleAr: `رسالة جديدة من ${senderNameAr}`,
    message: messagePreview,
    messageAr: messagePreviewAr,
    actionUrl: `/messages/${conversationId}`,
    conversationId,
    productId,
    category: 'message',
    accessToken,
  });
};

/**
 * Trigger notification when a new order is placed
 */
export const notifyNewOrder = async (
  sellerId: string,
  buyerName: string,
  buyerNameAr: string,
  productTitle: string,
  productTitleAr: string,
  orderId: string,
  productId: string,
  orderTotal: number,
  accessToken: string
) => {
  return triggerNotification({
    userId: sellerId,
    type: 'new_order',
    title: `New order from ${buyerName}`,
    titleAr: `طلب جديد من ${buyerNameAr}`,
    message: `${buyerName} ordered "${productTitle}" for ${orderTotal} SAR`,
    messageAr: `${buyerNameAr} طلب "${productTitleAr}" بمبلغ ${orderTotal} ريال`,
    actionUrl: `/orders/${orderId}`,
    orderId,
    productId,
    category: 'order',
    accessToken,
  });
};

/**
 * Trigger notification when order status changes
 */
export const notifyOrderStatusChange = async (
  buyerId: string,
  orderStatus: string,
  orderStatusAr: string,
  productTitle: string,
  productTitleAr: string,
  orderId: string,
  productId: string,
  accessToken: string
) => {
  return triggerNotification({
    userId: buyerId,
    type: 'order_status_update',
    title: `Order status updated`,
    titleAr: `تم تحديث حالة الطلب`,
    message: `Your order for "${productTitle}" is now ${orderStatus}`,
    messageAr: `طلبك لـ "${productTitleAr}" أصبح ${orderStatusAr}`,
    actionUrl: `/orders/${orderId}`,
    orderId,
    productId,
    category: 'order',
    accessToken,
  });
};

/**
 * Trigger notification when a product is sold
 */
export const notifyProductSold = async (
  sellerId: string,
  productTitle: string,
  productTitleAr: string,
  productId: string,
  orderId: string,
  saleAmount: number,
  accessToken: string
) => {
  return triggerNotification({
    userId: sellerId,
    type: 'product_sold',
    title: `Product sold!`,
    titleAr: `تم بيع المنتج!`,
    message: `Your "${productTitle}" sold for ${saleAmount} SAR`,
    messageAr: `تم بيع "${productTitleAr}" بمبلغ ${saleAmount} ريال`,
    actionUrl: `/orders/${orderId}`,
    orderId,
    productId,
    category: 'order',
    accessToken,
  });
};

/**
 * Trigger notification when payment is received
 */
export const notifyPaymentReceived = async (
  sellerId: string,
  amount: number,
  orderId: string,
  productId: string,
  accessToken: string
) => {
  return triggerNotification({
    userId: sellerId,
    type: 'payment_received',
    title: `Payment received`,
    titleAr: `تم استلام الدفعة`,
    message: `You received ${amount} SAR`,
    messageAr: `استلمت ${amount} ريال`,
    actionUrl: `/wallet`,
    orderId,
    productId,
    category: 'order',
    accessToken,
  });
};

/**
 * Trigger notification when a review is posted
 */
export const notifyNewReview = async (
  sellerId: string,
  reviewerName: string,
  reviewerNameAr: string,
  rating: number,
  productTitle: string,
  productTitleAr: string,
  productId: string,
  accessToken: string
) => {
  return triggerNotification({
    userId: sellerId,
    type: 'new_review',
    title: `New review from ${reviewerName}`,
    titleAr: `تقييم جديد من ${reviewerNameAr}`,
    message: `${reviewerName} gave "${productTitle}" ${rating} stars`,
    messageAr: `${reviewerNameAr} أعطى "${productTitleAr}" ${rating} نجوم`,
    actionUrl: `/products/${productId}/reviews`,
    productId,
    category: 'social',
    accessToken,
  });
};

/**
 * Trigger notification for price negotiation
 */
export const notifyPriceNegotiation = async (
  recipientId: string,
  senderName: string,
  senderNameAr: string,
  productTitle: string,
  productTitleAr: string,
  offeredPrice: number,
  productId: string,
  conversationId: string,
  accessToken: string
) => {
  return triggerNotification({
    userId: recipientId,
    type: 'price_negotiation',
    title: `Price offer from ${senderName}`,
    titleAr: `عرض سعر من ${senderNameAr}`,
    message: `${senderName} offered ${offeredPrice} SAR for "${productTitle}"`,
    messageAr: `${senderNameAr} عرض ${offeredPrice} ريال لـ "${productTitleAr}"`,
    actionUrl: `/messages/${conversationId}`,
    conversationId,
    productId,
    category: 'message',
    accessToken,
  });
};

/**
 * Trigger notification when item is shipped
 */
export const notifyOrderShipped = async (
  buyerId: string,
  productTitle: string,
  productTitleAr: string,
  orderId: string,
  productId: string,
  trackingNumber?: string,
  accessToken: string
) => {
  const trackingInfo = trackingNumber ? ` (Tracking: ${trackingNumber})` : '';
  const trackingInfoAr = trackingNumber ? ` (رقم التتبع: ${trackingNumber})` : '';

  return triggerNotification({
    userId: buyerId,
    type: 'order_shipped',
    title: `Your order has been shipped`,
    titleAr: `تم شحن طلبك`,
    message: `"${productTitle}" is on its way${trackingInfo}`,
    messageAr: `"${productTitleAr}" في الطريق إليك${trackingInfoAr}`,
    actionUrl: `/orders/${orderId}/tracking`,
    orderId,
    productId,
    category: 'order',
    accessToken,
  });
};

/**
 * Trigger notification when order is delivered
 */
export const notifyOrderDelivered = async (
  buyerId: string,
  productTitle: string,
  productTitleAr: string,
  orderId: string,
  productId: string,
  accessToken: string
) => {
  return triggerNotification({
    userId: buyerId,
    type: 'order_delivered',
    title: `Order delivered!`,
    titleAr: `تم توصيل الطلب!`,
    message: `"${productTitle}" has been delivered`,
    messageAr: `تم توصيل "${productTitleAr}"`,
    actionUrl: `/orders/${orderId}`,
    orderId,
    productId,
    category: 'order',
    accessToken,
  });
};

/**
 * Trigger notification for product inquiry
 */
export const notifyProductInquiry = async (
  sellerId: string,
  inquirerName: string,
  inquirerNameAr: string,
  productTitle: string,
  productTitleAr: string,
  productId: string,
  conversationId: string,
  accessToken: string
) => {
  return triggerNotification({
    userId: sellerId,
    type: 'product_inquiry',
    title: `Product inquiry from ${inquirerName}`,
    titleAr: `استفسار عن المنتج من ${inquirerNameAr}`,
    message: `${inquirerName} asked about "${productTitle}"`,
    messageAr: `${inquirerNameAr} سأل عن "${productTitleAr}"`,
    actionUrl: `/messages/${conversationId}`,
    conversationId,
    productId,
    category: 'message',
    accessToken,
  });
};
