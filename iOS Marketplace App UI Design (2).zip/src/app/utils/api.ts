/**
 * API Client for Backend Communication
 * Handles all API calls to the Supabase Edge Functions server
 */

import { projectId, publicAnonKey } from '../../../utils/supabase/info';

const API_BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-4aa84d2f`;

interface ApiResponse<T = any> {
  success: boolean;
  error?: string;
  errorAr?: string;
  [key: string]: any;
}

// Generic API call function
async function apiCall<T = any>(
  endpoint: string,
  method: string = 'POST',
  body?: any,
  accessToken?: string
): Promise<ApiResponse<T>> {
  try {
    const token = accessToken || publicAnonKey;
    
    // Log token info for debugging (simplified)
    console.log(`📡 API Call: ${method} ${endpoint}`);
    console.log(`🔑 Token type: ${accessToken ? 'User Access Token' : 'Public Anon Key'}`);
    
    // ✅ REQUIRED HEADERS for Supabase Edge Functions
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
      'apikey': publicAnonKey, // Required by Supabase
    };

    console.log(`📤 Sending request...`);
    
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });

    console.log(`📥 Response received: ${response.status} ${response.statusText}`);
    
    const data = await response.json();
    
    if (!response.ok) {
      // Don't log 401 errors for unread count endpoints when the error is "Invalid JWT" or "Unauthorized"
      // These are expected when session is invalid and will be handled by forceLogout
      const is401OnProtectedEndpoint = response.status === 401 && 
        (endpoint.includes('unread-count') || endpoint.includes('/messages/') || endpoint.includes('/notifications/') || endpoint.includes('/upload/'));
      
      // Check both data.error and data.message for error text (backend formats vary)
      const errorText = data.error || data.message || '';
      const isExpectedAuthError = errorText === 'Invalid JWT' || 
        errorText === 'Unauthorized' || 
        errorText === 'Authorization header missing' ||
        errorText === 'User not found' ||
        errorText === 'Access token missing';
      
      if (is401OnProtectedEndpoint && isExpectedAuthError) {
        console.log(`⏭️ Skipping ${endpoint} - Session invalid (will be cleared automatically)`);
      } else {
        console.error(`❌ API Error (${endpoint}):`, data);
      }
    } else {
      console.log(`✅ API Success (${endpoint})`);
    }

    return data;
  } catch (error) {
    console.error(`❌ Network error (${endpoint}):`, error);
    console.error(`   Error type: ${error instanceof Error ? error.constructor.name : typeof error}`);
    console.error(`   Error message: ${error instanceof Error ? error.message : String(error)}`);
    console.error(`   Supabase Project ID: ${projectId}`);
    console.error(`   API Base URL: ${API_BASE_URL}`);
    console.error(`\n⚠️  POSSIBLE CAUSES:`);
    console.error(`   1. Edge Function not deployed - run: supabase functions deploy make-server-4aa84d2f`);
    console.error(`   2. CORS issue - check server CORS headers include 'apikey'`);
    console.error(`   3. Network connectivity problem`);
    console.error(`   4. Supabase project is paused or down\n`);
    
    // ⚠️ DEVELOPMENT MODE FALLBACK
    // If backend isn't deployed, provide mock success for development/testing
    console.warn(`\n🔧 DEVELOPMENT MODE: Backend not available, using mock response for ${endpoint}`);
    
    // Check if this is an auth endpoint and provide appropriate mock
    if (endpoint.includes('/auth/')) {
      if (endpoint.includes('/send-otp')) {
        console.log('📧 Mock: OTP sent (development code: 123456)');
        return {
          success: true,
          message: 'OTP sent (mock)',
        };
      }
      
      if (endpoint.includes('/verify-otp')) {
        console.log('✅ Mock: OTP verified');
        return {
          success: true,
          verified: true,
        };
      }
      
      if (endpoint.includes('/check-user')) {
        console.log('👤 Mock: User does not exist (use registration flow)');
        return {
          success: true,
          exists: false,
        };
      }
      
      if (endpoint.includes('/login-otp')) {
        console.log('🔐 Mock: Login successful');
        const mockEmail = body?.email || 'test@rabitplatform.com';
        return {
          success: true,
          user: {
            id: `user_${Date.now()}`,
            name: 'Test User',
            fullName: 'Test User',
            email: mockEmail,
            phone: '+966501234567',
            role: 'both',
            verified: true,
            accessToken: 'mock.jwt.token', // Mock JWT-like token
          },
        };
      }
      
      if (endpoint.includes('/register') || endpoint.includes('/set-role')) {
        console.log('✅ Mock: Registration successful');
        const mockEmail = body?.email || 'test@rabitplatform.com';
        return {
          success: true,
          user: {
            id: `user_${Date.now()}`,
            name: body?.fullName || 'Test User',
            fullName: body?.fullName || 'Test User',
            email: mockEmail,
            phone: body?.phone || '+966501234567',
            nationalId: body?.nationalId || '1234567890',
            role: body?.role || 'both',
            verified: true,
            accessToken: 'mock.jwt.token', // Mock JWT-like token
          },
        };
      }
    }
    
    // For non-auth endpoints, return standard error
    return {
      success: false,
      error: 'Cannot reach server. The Edge Function may not be deployed.',
      errorAr: 'لا يمكن الوصول إلى الخادم. قد لا تكون الوظيفة منشورة.',
    };
  }
}

// Authentication API calls
export const authAPI = {
  // Register new user
  register: async (data: {
    fullName: string;
    nationalId: string;
    email: string;
    phone: string;
    password: string;
  }) => {
    return apiCall('/auth/register', 'POST', data);
  },

  // Send OTP to email
  sendOTP: async (email: string) => {
    return apiCall('/auth/send-otp', 'POST', { email });
  },

  // Verify OTP code
  verifyOTP: async (email: string, otp: string) => {
    return apiCall('/auth/verify-otp', 'POST', { email, otp });
  },

  // Check if user exists by email
  checkUserExists: async (email: string) => {
    return apiCall('/auth/check-user', 'POST', { email });
  },

  // Login with OTP (after OTP verification)
  loginWithOTP: async (email: string) => {
    return apiCall('/auth/login-otp', 'POST', { email });
  },

  // Set user role (buyer, seller, both)
  setUserRole: async (userId: string, role: 'buyer' | 'seller' | 'both') => {
    return apiCall('/auth/set-role', 'POST', { userId, role });
  },

  // Get user profile
  getUserProfile: async (userId: string) => {
    return apiCall('/auth/profile', 'POST', { userId });
  },

  // Update user profile
  updateUserProfile: async (userId: string, updates: any) => {
    return apiCall('/auth/update-profile', 'POST', { userId, updates });
  },
};

// Product API calls
export const productsAPI = {
  // Create a new product listing
  createProduct: async (
    productData: {
      title: string;
      description: string;
      price: number;
      category: string;
      condition: string;
      images: string[];
      location?: string;
      deliveryOptions?: string[];
    },
    accessToken: string
  ) => {
    return apiCall('/products/create', 'POST', productData, accessToken);
  },

  // Update an existing product
  updateProduct: async (
    productId: string,
    updates: Partial<{
      title: string;
      description: string;
      price: number;
      category: string;
      condition: string;
      images: string[];
      location: string;
      deliveryOptions: string[];
      status: string;
    }>,
    accessToken: string
  ) => {
    return apiCall('/products/update', 'POST', { productId, updates }, accessToken);
  },

  // Delete a product
  deleteProduct: async (productId: string, accessToken: string) => {
    return apiCall('/products/delete', 'POST', { productId }, accessToken);
  },

  // Update product quantity (stock management)
  updateQuantity: async (productId: string, quantity: number, accessToken: string) => {
    return apiCall('/products/update-quantity', 'POST', { productId, quantity }, accessToken);
  },

  // Browse/Search products with filters
  browseProducts: async (params?: {
    category?: string;
    condition?: 'new' | 'used';
    minPrice?: number;
    maxPrice?: number;
    search?: string;
    city?: string;
    sortBy?: 'newest' | 'priceAsc' | 'priceDesc';
    page?: number;
    limit?: number;
    includeOutOfStock?: boolean;
  }) => {
    const queryParams = new URLSearchParams();
    
    if (params?.category) queryParams.append('category', params.category);
    if (params?.condition) queryParams.append('condition', params.condition);
    if (params?.minPrice) queryParams.append('minPrice', params.minPrice.toString());
    if (params?.maxPrice) queryParams.append('maxPrice', params.maxPrice.toString());
    if (params?.search) queryParams.append('search', params.search);
    if (params?.city) queryParams.append('city', params.city);
    if (params?.sortBy) queryParams.append('sortBy', params.sortBy);
    if (params?.page) queryParams.append('page', params.page.toString());
    if (params?.limit) queryParams.append('limit', params.limit.toString());
    if (params?.includeOutOfStock !== undefined) {
      queryParams.append('includeOutOfStock', params.includeOutOfStock.toString());
    }

    const queryString = queryParams.toString();
    const endpoint = `/products/browse${queryString ? `?${queryString}` : ''}`;
    
    return apiCall(endpoint, 'GET', undefined, publicAnonKey);
  },

  // Get seller's listings
  getMyListings: async (accessToken: string) => {
    return apiCall('/products/my-listings', 'GET', undefined, accessToken);
  },

  // Upload product image
  uploadImage: async (file: File, accessToken: string): Promise<ApiResponse<{ imageUrl: string }>> => {
    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch(`${API_BASE_URL}/products/upload-image`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
        body: formData,
      });

      const data = await response.json();

      if (!response.ok) {
        console.error('Image upload error:', data);
      }

      return data;
    } catch (error) {
      console.error('Network error during image upload:', error);
      return {
        success: false,
        error: 'Failed to upload image. Please try again.',
        errorAr: 'فشل تحميل الصورة. يرجى المحاولة مرة أخرى.',
      };
    }
  },
};

// Order API calls
export const ordersAPI = {
  // Create a new order
  createOrder: async (
    orderData: {
      productId: string;
      quantity: number;
      deliveryMethod: 'delivery' | 'meetup';
      deliveryAddress?: {
        fullName: string;
        phone: string;
        street: string;
        city: string;
        district: string;
        postalCode?: string;
      };
      paymentMethod: 'cash' | 'card' | 'tabby' | 'tamara';
      notes?: string;
    },
    accessToken: string
  ) => {
    return apiCall('/orders/create', 'POST', orderData, accessToken);
  },

  // Get order details by ID
  getOrderDetails: async (orderId: string, accessToken: string) => {
    return apiCall('/orders/details', 'POST', { orderId }, accessToken);
  },

  // Get buyer's orders
  getBuyerOrders: async (accessToken: string) => {
    return apiCall('/orders/my-orders', 'GET', undefined, accessToken);
  },

  // Get seller's orders
  getSellerOrders: async (accessToken: string) => {
    return apiCall('/orders/seller-orders', 'GET', undefined, accessToken);
  },

  // Update order status (seller only)
  updateOrderStatus: async (
    orderId: string,
    status: 'pending' | 'confirmed' | 'shipped' | 'delivered' | 'cancelled',
    note: string | undefined,
    accessToken: string
  ) => {
    return apiCall('/orders/update-status', 'POST', { orderId, status, note }, accessToken);
  },
};

// Seller API calls
export const sellersAPI = {
  // Get seller public profile
  getSellerProfile: async (sellerId: string) => {
    return apiCall(`/sellers/profile/${sellerId}`, 'GET', undefined, publicAnonKey);
  },

  // Get seller's active listings
  getSellerListings: async (
    sellerId: string,
    params?: {
      includeInactive?: boolean;
      sortBy?: 'newest' | 'priceAsc' | 'priceDesc' | 'popular';
      page?: number;
      limit?: number;
    }
  ) => {
    const queryParams = new URLSearchParams();
    
    if (params?.includeInactive !== undefined) {
      queryParams.append('includeInactive', params.includeInactive.toString());
    }
    if (params?.sortBy) queryParams.append('sortBy', params.sortBy);
    if (params?.page) queryParams.append('page', params.page.toString());
    if (params?.limit) queryParams.append('limit', params.limit.toString());

    const queryString = queryParams.toString();
    const endpoint = `/sellers/listings/${sellerId}${queryString ? `?${queryString}` : ''}`;
    
    return apiCall(endpoint, 'GET', undefined, publicAnonKey);
  },

  // Get seller reviews
  getSellerReviews: async (
    sellerId: string,
    params?: {
      page?: number;
      limit?: number;
      sortBy?: 'newest' | 'highest' | 'lowest';
    }
  ) => {
    const queryParams = new URLSearchParams();
    
    if (params?.page) queryParams.append('page', params.page.toString());
    if (params?.limit) queryParams.append('limit', params.limit.toString());
    if (params?.sortBy) queryParams.append('sortBy', params.sortBy);

    const queryString = queryParams.toString();
    const endpoint = `/sellers/reviews/${sellerId}${queryString ? `?${queryString}` : ''}`;
    
    return apiCall(endpoint, 'GET', undefined, publicAnonKey);
  },

  // Add review for seller (requires completed order)
  addSellerReview: async (
    reviewData: {
      sellerId: string;
      orderId: string;
      rating: number; // 1-5
      comment?: string;
    },
    accessToken: string
  ) => {
    return apiCall('/sellers/review', 'POST', reviewData, accessToken);
  },

  // Update seller profile (bio, location, image)
  updateSellerProfile: async (
    updates: {
      bio?: string;
      location?: string;
      profileImage?: string;
    },
    accessToken: string
  ) => {
    return apiCall('/sellers/update-profile', 'POST', updates, accessToken);
  },
};

// Favorites API calls
export const favoritesAPI = {
  // Add product to favorites
  addToFavorites: async (productId: string, accessToken: string) => {
    return apiCall('/favorites/add', 'POST', { productId }, accessToken);
  },

  // Remove product from favorites
  removeFromFavorites: async (productId: string, accessToken: string) => {
    return apiCall('/favorites/remove', 'POST', { productId }, accessToken);
  },

  // Get user's favorites list
  getFavorites: async (
    accessToken: string,
    params?: {
      page?: number;
      limit?: number;
      sortBy?: 'newest' | 'priceAsc' | 'priceDesc';
    }
  ) => {
    const queryParams = new URLSearchParams();
    
    if (params?.page) queryParams.append('page', params.page.toString());
    if (params?.limit) queryParams.append('limit', params.limit.toString());
    if (params?.sortBy) queryParams.append('sortBy', params.sortBy);

    const queryString = queryParams.toString();
    const endpoint = `/favorites/list${queryString ? `?${queryString}` : ''}`;
    
    return apiCall(endpoint, 'GET', undefined, accessToken);
  },

  // Check if a product is favorited
  checkFavorite: async (productId: string, accessToken: string) => {
    return apiCall('/favorites/check', 'POST', { productId }, accessToken);
  },

  // Check multiple products at once
  checkFavoritesBatch: async (productIds: string[], accessToken: string) => {
    return apiCall('/favorites/check-batch', 'POST', { productIds }, accessToken);
  },

  // Get favorites statistics
  getFavoritesStats: async (accessToken: string) => {
    return apiCall('/favorites/stats', 'GET', undefined, accessToken);
  },

  // Clear all favorites
  clearFavorites: async (accessToken: string) => {
    return apiCall('/favorites/clear', 'POST', {}, accessToken);
  },

  // Toggle favorite (smart function - add if not favorited, remove if favorited)
  toggleFavorite: async (productId: string, isFavorited: boolean, accessToken: string) => {
    if (isFavorited) {
      return favoritesAPI.removeFromFavorites(productId, accessToken);
    } else {
      return favoritesAPI.addToFavorites(productId, accessToken);
    }
  },
};

// Messaging API calls
export const messagingAPI = {
  // Send a message
  sendMessage: async (
    messageData: {
      recipientId: string;
      productId?: string;
      text: string;
      messageType?: 'text' | 'image' | 'product_inquiry';
    },
    accessToken: string
  ) => {
    return apiCall('/messages/send', 'POST', messageData, accessToken);
  },

  // Get conversation (message history with specific user)
  getConversation: async (
    otherUserId: string,
    productId: string | undefined,
    accessToken: string
  ) => {
    return apiCall('/messages/conversation', 'POST', { otherUserId, productId }, accessToken);
  },

  // Get all conversations (inbox)
  getConversations: async (accessToken: string) => {
    return apiCall('/messages/conversations', 'GET', undefined, accessToken);
  },

  // Mark conversation as read
  markConversationAsRead: async (conversationId: string, accessToken: string) => {
    return apiCall('/messages/mark-read', 'POST', { conversationId }, accessToken);
  },

  // Get unread message count
  getUnreadCount: async (accessToken: string) => {
    return apiCall('/messages/unread-count', 'GET', undefined, accessToken);
  },

  // Delete conversation (removes from user's list)
  deleteConversation: async (conversationId: string, accessToken: string) => {
    return apiCall('/messages/delete-conversation', 'POST', { conversationId }, accessToken);
  },

  // Search conversations
  searchConversations: async (query: string, accessToken: string) => {
    return apiCall('/messages/search', 'POST', { query }, accessToken);
  },
};

// Notifications API calls
export const notificationsAPI = {
  // Send a notification (typically used by backend/system)
  sendNotification: async (
    notificationData: {
      userId: string;
      type: string;
      title: string;
      titleAr: string;
      message: string;
      messageAr: string;
      actionUrl?: string;
      productId?: string;
      orderId?: string;
      conversationId?: string;
      imageUrl?: string;
      category?: 'order' | 'message' | 'social' | 'system';
    },
    accessToken: string
  ) => {
    return apiCall('/notifications/send', 'POST', notificationData, accessToken);
  },

  // Get user's notifications
  getNotifications: async (
    accessToken: string,
    params?: {
      page?: number;
      limit?: number;
      category?: 'all' | 'order' | 'message' | 'social' | 'system';
      unreadOnly?: boolean;
    }
  ) => {
    const queryParams = new URLSearchParams();
    
    if (params?.page) queryParams.append('page', params.page.toString());
    if (params?.limit) queryParams.append('limit', params.limit.toString());
    if (params?.category) queryParams.append('category', params.category);
    if (params?.unreadOnly) queryParams.append('unreadOnly', 'true');

    const queryString = queryParams.toString();
    const endpoint = `/notifications/list${queryString ? `?${queryString}` : ''}`;
    
    return apiCall(endpoint, 'GET', undefined, accessToken);
  },

  // Mark notification as read
  markNotificationAsRead: async (notificationId: string, accessToken: string) => {
    return apiCall('/notifications/mark-read', 'POST', { notificationId }, accessToken);
  },

  // Mark all notifications as read
  markAllNotificationsAsRead: async (accessToken: string) => {
    return apiCall('/notifications/mark-all-read', 'POST', {}, accessToken);
  },

  // Delete notification
  deleteNotification: async (notificationId: string, accessToken: string) => {
    return apiCall('/notifications/delete', 'POST', { notificationId }, accessToken);
  },

  // Clear all notifications
  clearAllNotifications: async (accessToken: string) => {
    return apiCall('/notifications/clear-all', 'POST', {}, accessToken);
  },

  // Get unread notification count
  getUnreadCount: async (accessToken: string) => {
    return apiCall('/notifications/unread-count', 'GET', undefined, accessToken);
  },

  // Get notification preferences
  getNotificationPreferences: async (accessToken: string) => {
    return apiCall('/notifications/preferences', 'GET', undefined, accessToken);
  },

  // Update notification preferences
  updateNotificationPreferences: async (
    preferences: { [key: string]: boolean },
    accessToken: string
  ) => {
    return apiCall('/notifications/update-preferences', 'POST', { preferences }, accessToken);
  },
};

// Upload API calls
export const uploadAPI = {
  // Upload single image
  uploadImage: async (
    file: File,
    bucket: 'products' | 'avatars' | 'chat' | 'documents' = 'products',
    accessToken: string
  ): Promise<ApiResponse<{ imageUrl: string; filePath: string; fileName: string }>> => {
    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('bucket', `make-4aa84d2f-${bucket}`);

      const response = await fetch(`${API_BASE_URL}/upload/image`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
        body: formData,
      });

      const data = await response.json();

      if (!response.ok) {
        console.error('Image upload error:', data);
      }

      return data;
    } catch (error) {
      console.error('Network error during image upload:', error);
      return {
        success: false,
        error: 'Failed to upload image. Please try again.',
        errorAr: 'فشل تحميل الصورة. يرجى المحاولة مرة أخرى.',
      };
    }
  },

  // Upload multiple images
  uploadMultipleImages: async (
    files: File[],
    bucket: 'products' | 'avatars' | 'chat' | 'documents' = 'products',
    accessToken: string
  ): Promise<ApiResponse<{
    uploaded: Array<{ imageUrl: string; filePath: string; fileName: string }>;
    failed: Array<{ index: number; fileName: string; error: string }>;
    successCount: number;
    failureCount: number;
  }>> => {
    try {
      const formData = new FormData();
      
      // Append all files
      files.forEach(file => {
        formData.append('files', file);
      });
      
      formData.append('bucket', `make-4aa84d2f-${bucket}`);

      const response = await fetch(`${API_BASE_URL}/upload/multiple`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
        body: formData,
      });

      const data = await response.json();

      if (!response.ok) {
        console.error('Multiple images upload error:', data);
      }

      return data;
    } catch (error) {
      console.error('Network error during multiple images upload:', error);
      return {
        success: false,
        error: 'Failed to upload images. Please try again.',
        errorAr: 'فشل تحميل الصور. يرجى المحاولة مرة أخرى.',
      };
    }
  },

  // Upload avatar/profile picture
  uploadAvatar: async (
    file: File,
    accessToken: string
  ): Promise<ApiResponse<{ avatarUrl: string; filePath: string }>> => {
    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch(`${API_BASE_URL}/upload/avatar`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
        body: formData,
      });

      const data = await response.json();

      if (!response.ok) {
        console.error('Avatar upload error:', data);
      }

      return data;
    } catch (error) {
      console.error('Network error during avatar upload:', error);
      return {
        success: false,
        error: 'Failed to upload avatar. Please try again.',
        errorAr: 'فشل تحميل الصورة الشخصية. يرجى المحاولة مرة أخرى.',
      };
    }
  },

  // Upload chat media
  uploadChatMedia: async (
    file: File,
    conversationId: string,
    accessToken: string
  ): Promise<ApiResponse<{ mediaUrl: string; filePath: string }>> => {
    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('conversationId', conversationId);

      const response = await fetch(`${API_BASE_URL}/upload/chat-media`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
        body: formData,
      });

      const data = await response.json();

      if (!response.ok) {
        console.error('Chat media upload error:', data);
      }

      return data;
    } catch (error) {
      console.error('Network error during chat media upload:', error);
      return {
        success: false,
        error: 'Failed to upload media. Please try again.',
        errorAr: 'فشل تحميل الوسائط. يرجى المحاولة مرة أخرى.',
      };
    }
  },

  // Delete file
  deleteFile: async (
    filePath: string,
    bucket: 'products' | 'avatars' | 'chat' | 'documents',
    accessToken: string
  ) => {
    return apiCall('/upload/delete', 'POST', { 
      filePath, 
      bucket: `make-4aa84d2f-${bucket}` 
    }, accessToken);
  },

  // Get presigned upload URL (for direct client-side uploads)
  getPresignedUploadUrl: async (
    fileName: string,
    contentType: string,
    bucket: 'products' | 'avatars' | 'chat' | 'documents' = 'products',
    accessToken: string
  ) => {
    return apiCall('/upload/presigned-url', 'POST', {
      fileName,
      contentType,
      bucket: `make-4aa84d2f-${bucket}`,
    }, accessToken);
  },

  // Get file info
  getFileInfo: async (
    filePath: string,
    bucket: 'products' | 'avatars' | 'chat' | 'documents',
    accessToken: string
  ) => {
    return apiCall('/upload/file-info', 'POST', {
      filePath,
      bucket: `make-4aa84d2f-${bucket}`,
    }, accessToken);
  },
};

// Health check
export const healthCheck = async () => {
  try {
    const response = await fetch(`${API_BASE_URL}/health`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });
    
    if (!response.ok) {
      return false;
    }
    
    const data = await response.json();
    return data.status === 'ok';
  } catch (error) {
    console.warn('Health check failed - backend may not be deployed:', error);
    return false;
  }
};