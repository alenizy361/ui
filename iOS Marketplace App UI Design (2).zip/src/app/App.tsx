import React, { useState, useEffect } from "react";
import { AnimatePresence } from "motion/react";
import { toast } from "sonner";

// Main App Component - Rabit Platform
// Contexts
import { LanguageProvider, useLanguage } from "./contexts/LanguageContext";
import { AuthProvider, useAuth } from "./contexts/AuthContext";
import { AppProvider } from "./contexts/AppContext";
import { ErrorBoundary } from "./components/ErrorBoundary";

// Services
import { getConnectionStatus } from "./lib/supabase";
import { projectId } from "../../utils/supabase/info";

// Components
import { SupabaseConnectionError } from "./components/SupabaseConnectionError";
import { SupabaseSetupGuide } from "./components/SupabaseSetupGuide";
import { SupabasePausedError } from "./components/SupabasePausedError";
import { SimpleAuthTest } from "./components/SimpleAuthTest";

// Screens
import { RabitSplashScreen } from "./screens/rabit/RabitSplashScreen";
import { RabitWelcomeScreen } from "./screens/rabit/RabitWelcomeScreen";
import { RabitRegisterScreen } from "./screens/rabit/RabitRegisterScreen";
import { RabitOTPScreen } from "./screens/rabit/RabitOTPScreen";
import { RabitRegisterSuccessScreen } from "./screens/rabit/RabitRegisterSuccessScreen";
import { RabitLoginScreen } from "./screens/rabit/RabitLoginScreen";
import { RabitLoginOTPScreen } from "./screens/rabit/RabitLoginOTPScreen";
import { RabitForgotPasswordScreen } from "./screens/rabit/RabitForgotPasswordScreen";
import { RabitNewPasswordScreen } from "./screens/rabit/RabitNewPasswordScreen";
import { RabitPasswordResetSuccessScreen } from "./screens/rabit/RabitPasswordResetSuccessScreen";
import { RabitTermsAndConditionsScreen } from "./screens/rabit/RabitTermsAndConditionsScreen";
import { RabitPrivacyPolicyScreen } from "./screens/rabit/RabitPrivacyPolicyScreen";
import { RabitHelpCenterScreen } from "./screens/rabit/RabitHelpCenterScreen";
import { RabitAboutScreen } from "./screens/rabit/RabitAboutScreen";
import { RabitRoleSelectionScreen } from "./screens/rabit/RabitRoleSelectionScreen";
import { RabitBuyerHomeScreen } from "./screens/rabit/RabitBuyerHomeScreen";
import { RabitSellerHomeScreen } from "./screens/rabit/RabitSellerHomeScreen";
import { RabitCategoriesScreen } from "./screens/rabit/RabitCategoriesScreen";
import { RabitSearchScreen } from "./screens/rabit/RabitSearchScreen";
import { RabitAddProductScreen } from "./screens/rabit/RabitAddProductScreen";
import { RabitEditProductScreen } from "./screens/rabit/RabitEditProductScreen";
import { RabitProductDetailScreen } from "./screens/rabit/RabitProductDetailScreen";
import { RabitSellerProfileScreen } from "./screens/rabit/RabitSellerProfileScreen";
import { RabitChatScreen } from "./screens/rabit/RabitChatScreen";
import { RabitCheckoutScreen } from "./screens/rabit/RabitCheckoutScreen";
import { RabitPaymentScreen } from "./screens/rabit/RabitPaymentScreen";
import { RabitOrderSuccessScreen } from "./screens/rabit/RabitOrderSuccessScreen";
import { RabitOrdersScreen } from "./screens/rabit/RabitOrdersScreen";
import { RabitOrderDetailScreen } from "./screens/rabit/RabitOrderDetailScreen";
import { RabitSellerOrderDetailScreen } from "./screens/rabit/RabitSellerOrderDetailScreen";
import { RabitShipOrderScreen } from "./screens/rabit/RabitShipOrderScreen";
import { RabitOrderShippedSuccessScreen } from "./screens/rabit/RabitOrderShippedSuccessScreen";
import { RabitIssueShippingLabelScreen } from "./screens/rabit/RabitIssueShippingLabelScreen";
import { RabitShippingLabelSuccessScreen } from "./screens/rabit/RabitShippingLabelSuccessScreen";
import { RabitViewShippingLabelScreen } from "./screens/rabit/RabitViewShippingLabelScreen";
import { RabitSellerDashboardScreen } from "./screens/rabit/RabitSellerDashboardScreen";
import { RabitSellerSalesScreen } from "./screens/rabit/RabitSellerSalesScreen";
import { RabitBuyerWalletScreen } from "./screens/rabit/RabitBuyerWalletScreen";
import { RabitBuyerTransactionHistoryScreen } from "./screens/rabit/RabitBuyerTransactionHistoryScreen";
import { RabitSellerTransactionHistoryScreen } from "./screens/rabit/RabitSellerTransactionHistoryScreen";
import { RabitWithdrawalScreen } from "./screens/rabit/RabitWithdrawalScreen";
import { RabitSettingsScreen } from "./screens/rabit/RabitSettingsScreen";
import { RabitEditProfileScreen } from "./screens/rabit/RabitEditProfileScreen";
import { RabitAddressesScreen } from "./screens/rabit/RabitAddressesScreen";
import { RabitAddAddressScreen } from "./screens/rabit/RabitAddAddressScreen";
import { RabitPaymentMethodsScreen } from "./screens/rabit/RabitPaymentMethodsScreen";
import { RabitAddCardScreen } from "./screens/rabit/RabitAddCardScreen";
import { RabitNotificationsScreen } from "./screens/rabit/RabitNotificationsScreen";
import { RabitDisputeScreen } from "./screens/rabit/RabitDisputeScreen";
import { RabitFavoritesScreen } from "./screens/rabit/RabitFavoritesScreen";
import { RabitWriteReviewScreen } from "./screens/rabit/RabitWriteReviewScreen";
import { RabitReportScreen } from "./screens/rabit/RabitReportScreen";
import { RabitOrderTrackingScreen } from "./screens/rabit/RabitOrderTrackingScreen";
import { RabitMessagesScreen } from "./screens/rabit/RabitMessagesScreen";
import { RabitProductReviewsScreen } from "./screens/rabit/RabitProductReviewsScreen";
import { RabitSellerAnalyticsScreen } from "./screens/rabit/RabitSellerAnalyticsScreen";
import { RabitReturnRequestScreen } from "./screens/rabit/RabitReturnRequestScreen";
import { RabitSellerVerificationScreen } from "./screens/rabit/RabitSellerVerificationScreen";
import { RabitNotificationSettingsScreen } from "./screens/rabit/RabitNotificationSettingsScreen";
import { RabitWithdrawalHistoryScreen } from "./screens/rabit/RabitWithdrawalHistoryScreen";
import { RabitShippingInstructionsScreen } from "./screens/rabit/RabitShippingInstructionsScreen";
import { RabitShoppingCartScreen } from "./screens/rabit/RabitShoppingCartScreen";
import { RabitOnboardingTutorialScreen } from "./screens/rabit/RabitOnboardingTutorialScreen";
import RabitStorageTestScreen from "./screens/rabit/RabitStorageTestScreen";

type Screen =
  | "splash"
  | "welcome"
  | "register"
  | "otp"
  | "registerSuccess"
  | "login"
  | "loginOTP"
  | "forgotPassword"
  | "resetPasswordOTP"
  | "newPassword"
  | "passwordResetSuccess"
  | "terms"
  | "privacy"
  | "help"
  | "about"
  | "roleSelection"
  | "buyerHome"
  | "sellerHome"
  | "categories"
  | "search"
  | "addProduct"
  | "editProduct"
  | "productDetail"
  | "sellerProfile"
  | "chat"
  | "checkout"
  | "payment"
  | "orderSuccess"
  | "orders"
  | "orderDetail"
  | "sellerOrderDetail"
  | "shipOrder"
  | "orderShippedSuccess"
  | "issueShippingLabel"
  | "shippingLabelSuccess"
  | "viewShippingLabel"
  | "sellerDashboard"
  | "sellerSales"
  | "shippingInstructions"
  | "wallet"
  | "transactionHistory"
  | "withdrawal"
  | "settings"
  | "editProfile"
  | "addresses"
  | "addAddress"
  | "paymentMethods"
  | "addCard"
  | "notifications"
  | "dispute"
  | "favorites"
  | "writeReview"
  | "report"
  | "orderTracking"
  | "messages"
  | "productReviews"
  | "sellerAnalytics"
  | "returnRequest"
  | "sellerVerification"
  | "notificationSettings"
  | "withdrawalHistory"
  | "shoppingCart"
  | "onboardingTutorial"
  | "storageTest";

export interface Product {
  id: string;
  title: string;
  titleAr: string;
  price: number;
  image: string;
  seller: string;
  sellerAr: string;
  rating: number;
  category: string;
  categoryAr: string;
  condition: "new" | "used";
  city: string;
  cityAr: string;
  description: string;
  descriptionAr: string;
  images: string[];
}

export interface UserProfile {
  id: string;
  name: string;
  nameAr: string;
  email: string;
  phone: string;
  role: "buyer" | "seller" | "both";
  verified: boolean;
  rating: number;
  reviewCount: number;
}

export default function App() {
  return (
    <div className="relative w-full min-h-screen max-w-[430px] mx-auto bg-white overflow-hidden">
      <ErrorBoundary>
        <LanguageProvider>
          <AuthProvider>
            <AppProvider>
              <AppContent />
            </AppProvider>
          </AuthProvider>
        </LanguageProvider>
      </ErrorBoundary>
    </div>
  );
}

function AppContent() {
  const { user, isAuthenticated, isLoading, signUp, signIn, signOut, updateRole } = useAuth();
  const { language } = useLanguage();
  const [currentScreen, setCurrentScreen] = useState<Screen>("splash");
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [showAuthTest, setShowAuthTest] = useState(false);
  
  // Add debugging helper to window for easy console access
  useEffect(() => {
    (window as any).debugAuth = () => {
      console.log('=== AUTH DEBUG INFO ===');
      console.log('🔐 isAuthenticated:', isAuthenticated);
      console.log('⏳ isLoading:', isLoading);
      console.log('👤 user:', user);
      console.log('📧 email:', user?.email);
      console.log('🎭 role:', user?.role);
      console.log('✅ verified:', user?.verified);
      console.log('🆔 id:', user?.id);
      console.log('📱 currentScreen:', currentScreen);
      console.log('======================');
      return {
        isAuthenticated,
        isLoading,
        user,
        currentScreen,
      };
    };
    
    (window as any).showAuthTest = () => {
      setShowAuthTest(true);
      console.log('✅ Auth test page enabled');
    };
    
    console.log('💡 Tip: Run debugAuth() in console to check current auth state');
    console.log('💡 Tip: Run showAuthTest() to show simple auth test page');
  }, [user, isAuthenticated, isLoading, currentScreen]);
  
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedSellerId, setSelectedSellerId] = useState<string | null>(null);
  const [orderNumber, setOrderNumber] = useState("");
  const [currentMode, setCurrentMode] = useState<"buyer" | "seller">("buyer"); // Track current mode for "both" users
  const [screenHistory, setScreenHistory] = useState<Screen[]>([]); // Navigation history
  const [chatWithBuyer, setChatWithBuyer] = useState<{ name: string; nameAr: string } | null>(null); // For seller-buyer chat
  const [shippedOrderData, setShippedOrderData] = useState<{
    orderNumber: string;
    productTitle: string;
    productTitleAr: string;
    earnings: number;
  } | null>(null);
  const [orderStatus, setOrderStatus] = useState<"pending" | "shipped" | "delivered">("pending"); // Track order status
  const [hasShippingLabel, setHasShippingLabel] = useState(false); // Track if shipping label was issued
  const [registrationEmail, setRegistrationEmail] = useState<string>(""); // Store email from registration
  const [registeredUserId, setRegisteredUserId] = useState<string>(""); // Store user ID after registration
  const [emailConfirmationRequired, setEmailConfirmationRequired] = useState<boolean>(false); // Track if email confirmation is needed
  const [showSetupGuide, setShowSetupGuide] = useState<boolean>(false); // Show Supabase setup guide
  const [loginEmail, setLoginEmail] = useState<string>(""); // Store email from login
  const [splashShown, setSplashShown] = useState(false);
  const [registrationData, setRegistrationData] = useState<{
    email: string;
    password: string;
    name: string;
    phone: string;
    nationalId: string;
  } | null>(null); // Store registration data for role selection
  
  // Connection status checking
  const [connectionChecked, setConnectionChecked] = useState(false);
  const [connectionFailed, setConnectionFailed] = useState(false);
  const [projectPaused, setProjectPaused] = useState(false);

  // Set RTL for Arabic
  useEffect(() => {
    document.documentElement.setAttribute("dir", "rtl");
    document.documentElement.setAttribute("lang", "ar");
  }, []);

  // Check Supabase connection on mount
  useEffect(() => {
    const checkConnection = async () => {
      console.log('🔍 [App] Checking Supabase connection...');
      
      // Wait a bit for the connection test in supabase.ts to complete
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const status = getConnectionStatus();
      console.log('📊 [App] Connection status:', status);
      
      if (status.status === 'failed') {
        console.error('❌ [App] Connection failed:', status.error);
        
        // Check if it's a timeout error (indicates paused project)
        if (status.error?.includes('timeout') || status.error?.includes('fetch') || status.error?.includes('Failed to fetch')) {
          console.error('⏸️ [App] Project appears to be paused (timeout/fetch error)');
          setProjectPaused(true);
        }
        
        setConnectionFailed(true);
      } else if (status.status === 'connected') {
        console.log('✅ [App] Connection successful');
        setConnectionFailed(false);
        setProjectPaused(false);
      }
      
      setConnectionChecked(true);
    };
    
    checkConnection();
  }, []);

  // Check authentication on mount - skip splash if user is logged in
  useEffect(() => {
    if (!isLoading && connectionChecked) {
      console.log('🔍 [App] Auth check - isAuthenticated:', isAuthenticated, 'user:', user?.email, 'role:', user?.role);
      
      if (isAuthenticated && user) {
        // User is logged in, sync userProfile
        console.log('✅ [App] User authenticated, syncing profile...');
        setUserProfile(user);
        
        // Only redirect if we're still on splash/welcome screens
        if (currentScreen === "splash" || currentScreen === "welcome") {
          console.log('🏠 [App] Redirecting authenticated user...');
          
          // Check if user has a role set
          if (!user.role || user.role === 'none') {
            console.log('🎭 [App] User has no role, navigating to role selection');
            setCurrentScreen("roleSelection");
          } else if (user.role === "seller") {
            console.log('🏪 [App] Navigating to seller home');
            setCurrentScreen("sellerHome");
            setCurrentMode("seller");
          } else if (user.role === "both") {
            console.log('🛍️ [App] Navigating to buyer home (both role)');
            setCurrentScreen("buyerHome");
            setCurrentMode("buyer");
          } else if (user.role === "buyer") {
            console.log('🛍️ [App] Navigating to buyer home');
            setCurrentScreen("buyerHome");
            setCurrentMode("buyer");
          } else {
            // Fallback for unknown roles
            console.log('⚠️ [App] Unknown role:', user.role, '- defaulting to role selection');
            setCurrentScreen("roleSelection");
          }
        }
      } else {
        console.log('ℹ️ [App] User not authenticated, splash will show');
      }
    }
  }, [isLoading, isAuthenticated, user, connectionChecked]); // Only depend on user.id to avoid infinite loops

  const generateOrderNumber = () => {
    return `RBT-2024-${Math.floor(Math.random() * 10000).toString().padStart(4, "0")}`;
  };

  // Helper to navigate to correct home based on user role
  const navigateToHome = () => {
    if (!userProfile) {
      setCurrentScreen("buyerHome");
      return;
    }
    if (userProfile.role === "seller") {
      setCurrentScreen("sellerHome");
    } else {
      setCurrentScreen("buyerHome");
    }
  };

  // Navigate to a screen and save history
  const navigateToScreen = (screen: Screen) => {
    setScreenHistory(prev => [...prev, currentScreen]);
    setCurrentScreen(screen);
  };

  // Go back to previous screen
  const goBack = () => {
    if (screenHistory.length > 0) {
      const previousScreen = screenHistory[screenHistory.length - 1];
      setScreenHistory(prev => prev.slice(0, -1));
      setCurrentScreen(previousScreen);
    }
  };

  return (
    <>
      {/* Auth Test Mode */}
      {showAuthTest && <SimpleAuthTest />}
      
      {!showAuthTest && (
        <>
          {/* Show paused error if project is paused */}
          {connectionChecked && connectionFailed && projectPaused && (
            <SupabasePausedError
              projectId={projectId}
              onRetry={() => {
                setConnectionChecked(false);
                setConnectionFailed(false);
                setProjectPaused(false);
                window.location.reload();
              }}
            />
          )}
          
          {/* Show connection error if Supabase has other issues */}
          {connectionChecked && connectionFailed && !projectPaused && (
            <SupabaseConnectionError
              projectId={projectId}
              onRetry={() => {
                setConnectionChecked(false);
                setConnectionFailed(false);
                window.location.reload();
              }}
            />
          )}
          
          {/* Show app content only when connection is good */}
          {connectionChecked && !connectionFailed && (
            <AnimatePresence mode="wait">
          {currentScreen === "splash" && (
            <RabitSplashScreen
              key="splash"
              onComplete={() => setCurrentScreen("welcome")}
            />
          )}

          {currentScreen === "welcome" && (
            <RabitWelcomeScreen
              key="welcome"
              onRegister={() => setCurrentScreen("register")}
              onLogin={() => setCurrentScreen("login")}
              onTerms={() => navigateToScreen("terms")}
              onPrivacy={() => navigateToScreen("privacy")}
            />
          )}

          {currentScreen === "register" && (
            <RabitRegisterScreen
              key="register"
              onBack={() => setCurrentScreen("welcome")}
              onContinue={async (email, password, fullName, phone, nationalId) => {
                console.log('✅ [App] Registration form completed');
                console.log('📧 [App] Email:', email);
                
                // Store registration data for role selection
                setRegistrationData({
                  email,
                  password,
                  name: fullName,
                  phone,
                  nationalId,
                });
                
                setRegistrationEmail(email);
                
                // Go to role selection FIRST
                console.log('→ [App] Going to role selection');
                setCurrentScreen("roleSelection");
              }}
            />
          )}

          {currentScreen === "login" && (
            <RabitLoginScreen
              key="login"
              onBack={() => setCurrentScreen("welcome")}
              onRegister={() => setCurrentScreen("register")}
              onSuccess={() => {
                console.log('🏠 [App] Login success callback');
                // Navigate based on user role from auth context
                if (user?.role === "seller") {
                  console.log('→ [App] Navigating to seller home');
                  setCurrentScreen("sellerHome");
                } else if (user?.role === "buyer") {
                  console.log('→ [App] Navigating to buyer home');
                  setCurrentScreen("buyerHome");
                } else if (user?.role === "both") {
                  console.log('→ [App] Navigating to buyer home (both role)');
                  setCurrentScreen("buyerHome");
                } else {
                  // No valid role yet, go to role selection
                  console.log('→ [App] No valid role, going to role selection');
                  setCurrentScreen("roleSelection");
                }
              }}
            />
          )}

          {currentScreen === "loginOTP" && (
            <RabitLoginOTPScreen
              key="loginOTP"
              email={loginEmail}
              onBack={() => setCurrentScreen("login")}
              onVerified={(loggedInUser) => {
                // Sync user profile
                setUserProfile(loggedInUser);
                // Navigate to appropriate home based on role
                if (loggedInUser.role === "seller") {
                  setCurrentScreen("sellerHome");
                } else {
                  setCurrentScreen("buyerHome");
                }
              }}
            />
          )}

          {currentScreen === "otp" && (
            <RabitOTPScreen
              key="otp"
              email={registrationEmail}
              onBack={() => setCurrentScreen("register")}
              onVerify={() => setCurrentScreen("registerSuccess")}
            />
          )}

          {currentScreen === "registerSuccess" && (
            <RabitRegisterSuccessScreen
              key="registerSuccess"
              emailConfirmationRequired={emailConfirmationRequired}
              onShowSetupGuide={emailConfirmationRequired ? () => setShowSetupGuide(true) : undefined}
              onContinue={async () => {
                // If email confirmation is required, go to login
                if (emailConfirmationRequired) {
                  console.log('📧 [App] Email confirmation required, redirecting to login');
                  setCurrentScreen("login");
                  return;
                }
                
                // ✅ Otherwise, wait for Supabase onAuthStateChange to fire
                console.log('🔍 [App] Waiting for authentication session...');
                console.log('📊 [App] Current auth state - isAuthenticated:', isAuthenticated, 'user:', user?.email);
                
                // Poll for authentication state (max 5 seconds)
                let attempts = 0;
                const maxAttempts = 10; // 10 attempts x 500ms = 5 seconds
                
                const waitForAuth = async () => {
                  attempts++;
                  console.log(`⏳ [App] Waiting for session... attempt ${attempts}/${maxAttempts}`);
                  
                  if (isAuthenticated && user) {
                    console.log('✅ [App] Session established! User:', user.email);
                    setCurrentScreen("roleSelection");
                  } else if (attempts < maxAttempts) {
                    // Try again after 500ms
                    setTimeout(waitForAuth, 500);
                  } else {
                    console.error('❌ [App] Session not established after 5 seconds');
                    console.log('💡 [App] Email confirmation may still be enabled in Supabase Dashboard');
                    console.log('💡 [App] Redirecting to login...');
                    setCurrentScreen("login");
                  }
                };
                
                // Start waiting
                waitForAuth();
              }}
            />
          )}

          {currentScreen === "roleSelection" && (
            <RabitRoleSelectionScreen
              key="roleSelection"
              onRoleSelect={async (role) => {
                // Check if we're coming from registration (have registration data)
                if (registrationData) {
                  // NEW REGISTRATION FLOW: Call signUp with the selected role
                  console.log('📝 [App] Signing up new user with role:', role);
                  
                  const result = await signUp(
                    registrationData.email,
                    registrationData.password,
                    registrationData.fullName,
                    registrationData.phone,
                    role
                  );
                  
                  if (!result.success) {
                    console.error('❌ [App] Sign up failed:', result.error);
                    toast.error(
                      language === 'ar' 
                        ? `فشل التسجيل: ${result.error}`
                        : `Registration failed: ${result.error}`,
                      { duration: 4000 }
                    );
                    return;
                  }
                  
                  console.log('✅ [App] Sign up successful!');
                  
                  // Clear registration data
                  setRegistrationData(null);
                  
                  // Navigate to appropriate home
                  if (role === "buyer") {
                    setCurrentScreen("buyerHome");
                  } else if (role === "seller") {
                    setCurrentScreen("sellerHome");
                  } else {
                    setCurrentScreen("buyerHome");
                  }
                } else {
                  // EXISTING USER FLOW: Update role for already logged-in user
                  console.log('🔄 [App] Updating role for existing user:', role);
                  
                  const result = await updateRole(role);
                  
                  if (!result.success) {
                    console.error("❌ [App] Failed to update role:", result.error);
                    toast.error(
                      language === 'ar' 
                        ? `فشل تعيين الدور: ${result.error}`
                        : `Failed to set role: ${result.error}`,
                      { duration: 4000 }
                    );
                    return;
                  }
                  
                  console.log('✅ [App] Role updated successfully');
                  
                  // Navigate to appropriate home based on role
                  if (role === "buyer") {
                    setCurrentScreen("buyerHome");
                  } else if (role === "seller") {
                    setCurrentScreen("sellerHome");
                  } else {
                    setCurrentScreen("buyerHome");
                  }
                }
              }}
            />
          )}

          {currentScreen === "buyerHome" && (
            <RabitBuyerHomeScreen
              key="buyerHome"
              onProductClick={(product) => {
                setSelectedProduct(product);
                setCurrentScreen("productDetail");
              }}
              onSearchClick={() => setCurrentScreen("search")}
              onCategoryClick={() => setCurrentScreen("categories")}
              onOrdersClick={() => setCurrentScreen("orders")}
              onWalletClick={() => {
                setCurrentMode("buyer"); // Set mode to buyer
                setCurrentScreen("wallet");
              }}
              onSettingsClick={() => setCurrentScreen("settings")}
              onNotificationsClick={() => setCurrentScreen("notifications")}
              onFavoritesClick={() => setCurrentScreen("favorites")}
              onCartClick={() => setCurrentScreen("shoppingCart")}
              onMessagesClick={() => setCurrentScreen("messages")}
              onSwitchToSeller={
                userProfile?.role === "both"
                  ? () => {
                      setCurrentMode("seller"); // Switch to seller mode
                      setCurrentScreen("sellerHome");
                    }
                  : undefined
              }
              canSwitchToSeller={userProfile?.role === "both"}
            />
          )}

          {currentScreen === "sellerHome" && (
            <RabitSellerHomeScreen
              key="sellerHome"
              onAddProductClick={() => setCurrentScreen("addProduct")}
              onProductClick={(product) => {
                setSelectedProduct(product);
                setCurrentScreen("editProduct");
              }}
              onOrdersClick={() => setCurrentScreen("sellerSales")}
              onWalletClick={() => {
                setCurrentMode("seller"); // Set mode to seller
                setCurrentScreen("sellerSales"); // Navigate to sales (which shows revenue)
              }}
              onSettingsClick={() => setCurrentScreen("settings")}
              onNotificationsClick={() => setCurrentScreen("notifications")}
              onCategoriesClick={() => setCurrentScreen("categories")}
              onMessagesClick={() => setCurrentScreen("messages")}
              onAnalyticsClick={() => setCurrentScreen("sellerAnalytics")}
              onVerificationClick={() => setCurrentScreen("sellerVerification")}
              onWithdrawalHistoryClick={() => setCurrentScreen("withdrawalHistory")}
              onSwitchToBuyer={
                userProfile?.role === "both"
                  ? () => {
                      setCurrentMode("buyer"); // Switch to buyer mode
                      setCurrentScreen("buyerHome");
                    }
                  : undefined
              }
              canSwitchToBuyer={userProfile?.role === "both"}
            />
          )}

          {currentScreen === "categories" && (
            <RabitCategoriesScreen
              key="categories"
              onBack={navigateToHome}
              onProductClick={(product) => {
                setSelectedProduct(product);
                setCurrentScreen("productDetail");
              }}
            />
          )}

          {currentScreen === "search" && (
            <RabitSearchScreen
              key="search"
              onBack={navigateToHome}
              onProductClick={(product) => {
                setSelectedProduct(product);
                setCurrentScreen("productDetail");
              }}
            />
          )}

          {currentScreen === "addProduct" && (
            <RabitAddProductScreen
              key="addProduct"
              onBack={navigateToHome}
              onPublishSuccess={navigateToHome}
            />
          )}

          {currentScreen === "editProduct" && selectedProduct && (
            <RabitEditProductScreen
              key="editProduct"
              product={selectedProduct}
              onBack={navigateToHome}
              onUpdateSuccess={navigateToHome}
            />
          )}

          {currentScreen === "productDetail" && selectedProduct && (
            <RabitProductDetailScreen
              key="productDetail"
              product={selectedProduct}
              onBack={navigateToHome}
              onBuyNow={() => setCurrentScreen("checkout")}
              onChatWithSeller={() => setCurrentScreen("chat")}
              onSellerClick={() => setCurrentScreen("sellerProfile")}
              onReport={() => setCurrentScreen("report")}
            />
          )}

          {currentScreen === "sellerProfile" && (
            <RabitSellerProfileScreen
              key="sellerProfile"
              sellerId="seller-1"
              onBack={() => setCurrentScreen("productDetail")}
              onProductClick={(product) => {
                setSelectedProduct(product);
                setCurrentScreen("productDetail");
              }}
              onContactSeller={() => {
                if (selectedProduct) {
                  setCurrentScreen("chat");
                }
              }}
            />
          )}

          {currentScreen === "chat" && (selectedProduct || chatWithBuyer) && (
            <RabitChatScreen
              key="chat"
              product={selectedProduct}
              chatWith={chatWithBuyer}
              onBack={() => {
                // If coming from seller order detail, go back there
                if (chatWithBuyer && !selectedProduct) {
                  setChatWithBuyer(null);
                  setCurrentScreen("sellerOrderDetail");
                } else {
                  setCurrentScreen("productDetail");
                }
              }}
            />
          )}

          {currentScreen === "checkout" && selectedProduct && (
            <RabitCheckoutScreen
              key="checkout"
              product={selectedProduct}
              onBack={() => setCurrentScreen("productDetail")}
              onContinueToPayment={() => setCurrentScreen("payment")}
            />
          )}

          {currentScreen === "payment" && selectedProduct && (
            <RabitPaymentScreen
              key="payment"
              product={selectedProduct}
              onBack={() => setCurrentScreen("checkout")}
              onPaymentSuccess={() => {
                setOrderNumber(generateOrderNumber());
                setCurrentScreen("orderSuccess");
              }}
            />
          )}

          {currentScreen === "orderSuccess" && (
            <RabitOrderSuccessScreen
              key="orderSuccess"
              orderNumber={orderNumber}
              onViewOrders={() => setCurrentScreen("orders")}
              onContinueShopping={navigateToHome}
            />
          )}

          {currentScreen === "orders" && (
            <RabitOrdersScreen
              key="orders"
              userRole={userProfile?.role || "buyer"}
              onBack={navigateToHome}
              onOrderClick={(order) => {
                setOrderNumber(order.orderNumber);
                setCurrentScreen("orderDetail");
              }}
              onShipNow={(order) => {
                setOrderNumber(order.orderNumber);
                setCurrentScreen("shipOrder");
              }}
              onOpenDispute={() => {
                setOrderNumber("RBT-2024-1234");
                setCurrentScreen("dispute");
              }}
              onWriteReview={() => setCurrentScreen("writeReview")}
            />
          )}

          {currentScreen === "orderDetail" && (
            <RabitOrderDetailScreen
              key="orderDetail"
              orderNumber={orderNumber || "RBT-2024-1234"}
              productTitle="آيفون 14 برو ماكس - 256 جيجا"
              productImage="https://images.unsplash.com/photo-1678685888221-cda773a3dcdb?w=400"
              price={4500}
              platformFee={225}
              deliveryFee={0}
              sellerName="أحمد التميمي"
              status="shipped"
              orderDate="اليوم، 10:30 ص"
              estimatedDelivery="غداً، 6:00 م"
              shippingAddress={{
                name: "أحمد الراشد",
                phone: "+966 50 123 4567",
                city: "الرياض",
                district: "العليا",
                street: "شارع الملك فهد",
                building: "مبنى 123، الطابق 5",
              }}
              onBack={() => setCurrentScreen("orders")}
              onChatSeller={() => setCurrentScreen("chat")}
              onWriteReview={() => setCurrentScreen("writeReview")}
              onReportIssue={() => setCurrentScreen("dispute")}
              onTrackOrder={() => setCurrentScreen("orderTracking")}
              onRequestReturn={() => setCurrentScreen("returnRequest")}
            />
          )}

          {currentScreen === "sellerOrderDetail" && (
            <RabitSellerOrderDetailScreen
              key="sellerOrderDetail"
              orderId="sale1"
              orderNumber={orderNumber || "#ORD-2401"}
              productTitle="iPhone 14 Pro Max"
              productTitleAr="آيفون 14 برو ماكس"
              productImage="https://images.unsplash.com/photo-1678685888221-cda773a3dcdb?w=400"
              price={4500}
              platformFee={225}
              buyerName="Ahmed Al-Rashid"
              buyerNameAr="أحمد الراشد"
              buyerPhone="+966 50 123 4567"
              status={orderStatus}
              orderDate="2024-01-22"
              shippingAddress={{
                name: "أحمد الراشد",
                phone: "+966 50 123 4567",
                city: "الرياض",
                district: "العليا",
                street: "شارع الملك فهد",
                building: "مبنى 123، اطابق 5",
              }}
              onBack={() => setCurrentScreen("sellerSales")}
              hasShippingLabel={hasShippingLabel}
              onIssueShippingLabel={() => setCurrentScreen("issueShippingLabel")}
              onViewShippingLabel={() => setCurrentScreen("viewShippingLabel")}
              onMarkAsShipped={() => {
                // Update order status to shipped
                setOrderStatus("shipped");
                // Store order data and navigate to success screen
                setShippedOrderData({
                  orderNumber: orderNumber || "#ORD-2401",
                  productTitle: "iPhone 14 Pro Max",
                  productTitleAr: "آيفون 14 برو ماكس",
                  earnings: 4500 - 225, // price - platformFee
                });
                setCurrentScreen("orderShippedSuccess");
              }}
              onChatBuyer={() => {
                setChatWithBuyer({ name: "Ahmed Al-Rashid", nameAr: "أحمد الراشد" });
                setCurrentScreen("chat");
              }}
            />
          )}

          {currentScreen === "shipOrder" && (
            <RabitShipOrderScreen
              key="shipOrder"
              orderNumber={orderNumber || "RBT-2024-1234"}
              productTitle="آيفون 14 برو مكس - 256 جيجا"
              productImage="https://images.unsplash.com/photo-1678685888221-cda773a3dcdb?w=400"
              price={4500}
              buyerName="أحمد الراشد"
              buyerPhone="+966 50 123 4567"
              shippingAddress={{
                name: "أحمد لراشد",
                phone: "+966 50 123 4567",
                city: "الرياض",
                district: "العليا",
                street: "شارع الملك فهد",
                building: "مبنى 123، الطابق 5",
              }}
              onBack={() => setCurrentScreen("orders")}
              onConfirmShip={() => setCurrentScreen("orders")}
            />
          )}

          {currentScreen === "orderShippedSuccess" && shippedOrderData && (
            <RabitOrderShippedSuccessScreen
              key="orderShippedSuccess"
              orderNumber={shippedOrderData.orderNumber}
              productTitle={shippedOrderData.productTitle}
              productTitleAr={shippedOrderData.productTitleAr}
              earnings={shippedOrderData.earnings}
              onContinue={() => {
                setShippedOrderData(null);
                setCurrentScreen("sellerSales");
              }}
              onViewOrder={() => {
                setOrderNumber(shippedOrderData.orderNumber);
                setCurrentScreen("sellerOrderDetail");
              }}
            />
          )}

          {currentScreen === "issueShippingLabel" && (
            <RabitIssueShippingLabelScreen
              key="issueShippingLabel"
              orderNumber={orderNumber || "#ORD-2401"}
              productTitle="iPhone 14 Pro Max"
              productTitleAr="آيفون 14 برو ماكس"
              shippingAddress={{
                name: "أحمد الراشد",
                phone: "+966 50 123 4567",
                city: "الرياض",
                district: "العليا",
                street: "شارع الملك فهد",
                building: "مبنى 123، الطابق 5",
              }}
              shippingCost={35}
              walletBalance={2500}
              onBack={() => setCurrentScreen("sellerOrderDetail")}
              onPaymentComplete={() => setCurrentScreen("shippingLabelSuccess")}
            />
          )}

          {currentScreen === "shippingLabelSuccess" && (
            <RabitShippingLabelSuccessScreen
              key="shippingLabelSuccess"
              orderNumber={orderNumber || "#ORD-2401"}
              trackingNumber={"RBT-TRK-" + Math.random().toString(36).substring(7).toUpperCase()}
              shippingCost={35}
              paymentMethod="wallet"
              onDownloadLabel={() => {
                // In real app, would trigger PDF download
                console.log("Download shipping label");
              }}
              onContinue={() => {
                // After payment, mark that label has been issued
                setHasShippingLabel(true);
                setCurrentScreen("sellerOrderDetail");
              }}
            />
          )}

          {currentScreen === "viewShippingLabel" && (
            <RabitViewShippingLabelScreen
              key="viewShippingLabel"
              orderNumber={orderNumber || "#ORD-2401"}
              trackingNumber={"RBT-TRK-" + Math.random().toString(36).substring(7).toUpperCase()}
              productTitle="iPhone 14 Pro Max"
              productTitleAr="آيفون 14 برو ماكس"
              shippingAddress={{
                name: "أحمد الراشد",
                phone: "+966 50 123 4567",
                city: "الرياض",
                district: "العليا",
                street: "شارع الملك فهد",
                building: "مبنى 123، الطابق 5",
              }}
              issuedDate="اليوم، 10:30 ص"
              onBack={() => setCurrentScreen("sellerOrderDetail")}
              onDownloadLabel={() => {
                // In real app, would trigger PDF download
                console.log("Download shipping label");
              }}
            />
          )}

          {currentScreen === "sellerDashboard" && (
            <RabitSellerDashboardScreen
              key="sellerDashboard"
              onBack={navigateToHome}
              onShipNow={() => {
                setOrderNumber("RBT-2024-1234");
                setCurrentScreen("shipOrder");
              }}
              onEditProduct={(product) => {
                setSelectedProduct(product);
                setCurrentScreen("editProduct");
              }}
              onDeleteProduct={(productId) => {
                // TODO: Connect to real backend when ready
                // Show success toast for demo
                toast.success(
                  language === 'ar'
                    ? '🗑️ تم حذف المنتج بنجاح'
                    : '🗑️ Product deleted successfully',
                  { duration: 2000 }
                );
                console.log("Delete product:", productId);
              }}
            />
          )}

          {currentScreen === "sellerSales" && (
            <RabitSellerSalesScreen
              key="sellerSales"
              onBack={navigateToHome}
              onSaleClick={(saleId) => {
                setOrderNumber("#ORD-" + saleId.replace("sale", "240"));
                setCurrentScreen("sellerOrderDetail");
              }}
              onWithdraw={() => setCurrentScreen("withdrawal")}
            />
          )}

          {currentScreen === "shippingInstructions" && (
            <RabitShippingInstructionsScreen
              key="shippingInstructions"
              onBack={() => setCurrentScreen("orders")}
              onComplete={() => setCurrentScreen("orders")}
            />
          )}

          {currentScreen === "wallet" && (
            <>
              {/* BUYER WALLET - Only purchases and payment methods */}
              {(userProfile?.role === "buyer" || (userProfile?.role === "both" && currentMode === "buyer")) && (
                <RabitBuyerWalletScreen
                  key="wallet-buyer"
                  onBack={navigateToHome}
                  onViewTransactions={() => setCurrentScreen("transactionHistory")}
                  onPaymentMethods={() => setCurrentScreen("paymentMethods")}
                />
              )}
              
              {/* SELLER WALLET - Income, earnings, and withdrawals */}
              {(userProfile?.role === "seller" || (userProfile?.role === "both" && currentMode === "seller")) && (
                <RabitSellerSalesScreen
                  key="wallet-seller"
                  onBack={navigateToHome}
                  onWithdraw={() => setCurrentScreen("withdrawal")}
                  onViewTransactions={() => setCurrentScreen("transactionHistory")}
                />
              )}
            </>
          )}

          {currentScreen === "transactionHistory" && (
            <>
              {/* BUYER TRANSACTION HISTORY */}
              {(userProfile?.role === "buyer" || (userProfile?.role === "both" && currentMode === "buyer")) && (
                <RabitBuyerTransactionHistoryScreen
                  key="transactionHistory-buyer"
                  onBack={navigateToHome}
                />
              )}
              
              {/* SELLER TRANSACTION HISTORY */}
              {(userProfile?.role === "seller" || (userProfile?.role === "both" && currentMode === "seller")) && (
                <RabitSellerTransactionHistoryScreen
                  key="transactionHistory-seller"
                  onBack={navigateToHome}
                />
              )}
            </>
          )}

          {currentScreen === "withdrawal" && (
            <RabitWithdrawalScreen
              key="withdrawal"
              availableBalance={118750}
              onBack={() => setCurrentScreen("sellerSales")}
              onWithdrawalSuccess={() => setCurrentScreen("sellerSales")}
            />
          )}

          {currentScreen === "settings" && (
            <RabitSettingsScreen
              key="settings"
              userProfile={userProfile}
              onBack={navigateToHome}
              onSwitchRole={(newRole) => {
                if (userProfile) {
                  setUserProfile({ ...userProfile, role: newRole });
                  // Navigate to appropriate home after role change
                  if (newRole === "seller") {
                    setCurrentScreen("sellerHome");
                  } else {
                    setCurrentScreen("buyerHome");
                  }
                }
              }}
              onEditProfile={() => setCurrentScreen("editProfile")}
              onManageAddresses={() => setCurrentScreen("addresses")}
              onManagePaymentMethods={() => setCurrentScreen("paymentMethods")}
              onNotificationSettings={() => setCurrentScreen("notificationSettings")}
              onTerms={() => navigateToScreen("terms")}
              onPrivacy={() => navigateToScreen("privacy")}
              onHelp={() => navigateToScreen("help")}
              onAbout={() => navigateToScreen("about")}
              onLogout={() => {
                // Clear user profile and return to welcome screen
                setUserProfile(null);
                setCurrentScreen("welcome");
                signOut();
              }}
            />
          )}

          {currentScreen === "editProfile" && userProfile && (
            <RabitEditProfileScreen
              key="editProfile"
              userProfile={userProfile}
              onBack={() => setCurrentScreen("settings")}
              onUpdateSuccess={(updatedProfile) => {
                setUserProfile(updatedProfile);
                setCurrentScreen("settings");
              }}
            />
          )}

          {currentScreen === "addresses" && (
            <RabitAddressesScreen
              key="addresses"
              onBack={navigateToHome}
              onAddAddress={() => setCurrentScreen("addAddress")}
              onEditAddress={(addressId) => {
                // In a real app, you'd load the address data
                setCurrentScreen("addAddress");
              }}
            />
          )}

          {currentScreen === "addAddress" && (
            <RabitAddAddressScreen
              key="addAddress"
              onBack={() => setCurrentScreen("addresses")}
              onSaveSuccess={() => setCurrentScreen("addresses")}
            />
          )}

          {currentScreen === "paymentMethods" && (
            <RabitPaymentMethodsScreen
              key="paymentMethods"
              onBack={navigateToHome}
              onAddCard={() => setCurrentScreen("addCard")}
            />
          )}

          {currentScreen === "addCard" && (
            <RabitAddCardScreen
              key="addCard"
              onBack={() => setCurrentScreen("paymentMethods")}
              onSaveSuccess={() => setCurrentScreen("paymentMethods")}
            />
          )}

          {currentScreen === "notifications" && (
            <RabitNotificationsScreen
              key="notifications"
              onBack={navigateToHome}
              userRole={userProfile?.role || "buyer"}
              onNavigateToOrders={() => setCurrentScreen("orders")}
              onNavigateToShipping={(orderId) => {
                setOrderNumber(orderId);
                setCurrentScreen("shipOrder");
              }}
              onNavigateToChat={() => setCurrentScreen("chat")}
              onNavigateToWallet={() => setCurrentScreen("wallet")}
              onNavigateToReviews={() => setCurrentScreen("orders")}
            />
          )}

          {currentScreen === "dispute" && (
            <RabitDisputeScreen
              key="dispute"
              orderId={orderNumber || "RBT-2024-1234"}
              onBack={() => setCurrentScreen("orders")}
            />
          )}

          {currentScreen === "favorites" && (
            <RabitFavoritesScreen
              key="favorites"
              onBack={navigateToHome}
              onProductClick={(product) => {
                setSelectedProduct(product);
                setCurrentScreen("productDetail");
              }}
            />
          )}

          {currentScreen === "writeReview" && selectedProduct && (
            <RabitWriteReviewScreen
              key="writeReview"
              orderId={orderNumber || "RBT-2024-1234"}
              productTitle={selectedProduct.titleAr}
              sellerName={selectedProduct.sellerAr}
              onBack={navigateToHome}
              onSubmitSuccess={navigateToHome}
            />
          )}

          {currentScreen === "report" && selectedProduct && (
            <RabitReportScreen
              key="report"
              itemType="product"
              itemId={selectedProduct.id}
              itemTitle={selectedProduct.titleAr}
              onBack={navigateToHome}
              onSubmitSuccess={navigateToHome}
            />
          )}

          {currentScreen === "forgotPassword" && (
            <RabitForgotPasswordScreen
              key="forgotPassword"
              onBack={() => setCurrentScreen("login")}
              onContinue={(phoneOrEmail, method) => setCurrentScreen("resetPasswordOTP")}
            />
          )}

          {currentScreen === "resetPasswordOTP" && (
            <RabitOTPScreen
              key="resetPasswordOTP"
              phone="501234567"
              onBack={() => setCurrentScreen("forgotPassword")}
              onVerify={() => setCurrentScreen("newPassword")}
            />
          )}

          {currentScreen === "newPassword" && (
            <RabitNewPasswordScreen
              key="newPassword"
              onBack={() => setCurrentScreen("resetPasswordOTP")}
              onSuccess={() => setCurrentScreen("passwordResetSuccess")}
            />
          )}

          {currentScreen === "passwordResetSuccess" && (
            <RabitPasswordResetSuccessScreen
              key="passwordResetSuccess"
              onContinue={() => setCurrentScreen("login")}
            />
          )}

          {currentScreen === "terms" && (
            <RabitTermsAndConditionsScreen
              key="terms"
              onBack={goBack}
            />
          )}

          {currentScreen === "privacy" && (
            <RabitPrivacyPolicyScreen
              key="privacy"
              onBack={goBack}
            />
          )}

          {currentScreen === "help" && (
            <RabitHelpCenterScreen
              key="help"
              onBack={goBack}
            />
          )}

          {currentScreen === "about" && (
            <RabitAboutScreen
              key="about"
              onBack={goBack}
            />
          )}

          {currentScreen === "orderTracking" && (
            <RabitOrderTrackingScreen
              key="orderTracking"
              orderNumber={orderNumber || "RBT-2024-1234"}
              onBack={() => setCurrentScreen("orderDetail")}
              onContactSeller={() => setCurrentScreen("chat")}
              onViewDetails={() => setCurrentScreen("orderDetail")}
            />
          )}

          {currentScreen === "messages" && (
            <RabitMessagesScreen
              key="messages"
              userRole={userProfile?.role || "buyer"}
              onBack={navigateToHome}
              onChatClick={(messageId) => setCurrentScreen("chat")}
            />
          )}

          {currentScreen === "productReviews" && selectedProduct && (
            <RabitProductReviewsScreen
              key="productReviews"
              productName={selectedProduct.titleAr}
              averageRating={selectedProduct.rating}
              totalReviews={127}
              onBack={() => setCurrentScreen("productDetail")}
            />
          )}

          {currentScreen === "sellerAnalytics" && (
            <RabitSellerAnalyticsScreen
              key="sellerAnalytics"
              onBack={() => setCurrentScreen("sellerHome")}
            />
          )}

          {currentScreen === "returnRequest" && selectedProduct && (
            <RabitReturnRequestScreen
              key="returnRequest"
              orderNumber={orderNumber || "RBT-2024-1234"}
              productName={selectedProduct.titleAr}
              productImage={selectedProduct.image}
              orderTotal={selectedProduct.price}
              onBack={() => setCurrentScreen("orderDetail")}
              onSubmitSuccess={() => setCurrentScreen("orders")}
            />
          )}

          {currentScreen === "sellerVerification" && (
            <RabitSellerVerificationScreen
              key="sellerVerification"
              onBack={() => setCurrentScreen("settings")}
              onVerificationSuccess={() => setCurrentScreen("sellerHome")}
            />
          )}

          {currentScreen === "notificationSettings" && (
            <RabitNotificationSettingsScreen
              key="notificationSettings"
              onBack={() => setCurrentScreen("settings")}
              onSaveSuccess={() => setCurrentScreen("settings")}
            />
          )}

          {currentScreen === "withdrawalHistory" && (
            <RabitWithdrawalHistoryScreen
              key="withdrawalHistory"
              onBack={() => setCurrentScreen("sellerSales")}
            />
          )}

          {currentScreen === "shoppingCart" && (
            <RabitShoppingCartScreen
              key="shoppingCart"
              onBack={navigateToHome}
              onCheckout={(items) => {
                // In real app, you'd handle multiple items
                if (items.length > 0) {
                  setCurrentScreen("checkout");
                }
              }}
              onProductClick={(productId) => {
                // In real app, load product by ID
                setCurrentScreen("productDetail");
              }}
            />
          )}

          {currentScreen === "onboardingTutorial" && (
            <RabitOnboardingTutorialScreen
              key="onboardingTutorial"
              onComplete={() => setCurrentScreen("welcome")}
              onSkip={() => setCurrentScreen("welcome")}
            />
          )}

          {currentScreen === "storageTest" && (
            <RabitStorageTestScreen
              key="storageTest"
              onBack={navigateToHome}
            />
          )}
        </AnimatePresence>
      )}
        </>
      )}
    </>
  );
}