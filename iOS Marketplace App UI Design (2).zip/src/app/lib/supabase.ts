/**
 * Supabase Client Configuration
 * 
 * PRODUCTION-READY - Uses real Supabase APIs only
 * NO Edge Functions, NO mocks, NO fake sessions
 */

import { createClient } from '@supabase/supabase-js';
import { projectId, publicAnonKey } from '../../../utils/supabase/info';

// Construct Supabase URL from project ID
const supabaseUrl = `https://${projectId}.supabase.co`;
const supabaseAnonKey = publicAnonKey;

// Validate that credentials exist
if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error(
    '❌ Missing Supabase credentials. Please check /utils/supabase/info.tsx'
  );
}

console.log('🔧 [Supabase] Initializing client...');
console.log('📍 [Supabase] Project ID:', projectId);
console.log('🌐 [Supabase] URL:', supabaseUrl);
console.log('🔑 [Supabase] Anon Key exists:', !!supabaseAnonKey);
console.log('🔑 [Supabase] Anon Key length:', supabaseAnonKey?.length);

// Export for backwards compatibility
export { supabaseUrl, supabaseAnonKey, projectId };

// Create the Supabase client with production configuration
export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    // Enable session persistence in localStorage
    persistSession: true,
    // Auto refresh tokens before they expire
    autoRefreshToken: true,
    // Detect session in URL (for email confirmation redirects)
    detectSessionInUrl: true,
    // Use localStorage for session storage
    storage: {
      getItem: (key: string) => {
        if (typeof window !== 'undefined') {
          const item = window.localStorage.getItem(key);
          console.log(`📖 [Storage] Reading key "${key}":`, item ? 'Found' : 'Not found');
          return item;
        }
        return null;
      },
      setItem: (key: string, value: string) => {
        if (typeof window !== 'undefined') {
          console.log(`💾 [Storage] Saving key "${key}"`, value.substring(0, 50) + '...');
          window.localStorage.setItem(key, value);
        }
      },
      removeItem: (key: string) => {
        if (typeof window !== 'undefined') {
          console.log(`🗑️ [Storage] Removing key "${key}"`);
          window.localStorage.removeItem(key);
        }
      },
    },
    // Storage key prefix
    storageKey: 'rabit-auth-token',
    // Flow type for PKCE (more secure)
    flowType: 'implicit',
  },
  global: {
    headers: {
      'X-Client-Info': 'rabit-marketplace',
    },
  },
});

console.log('✅ [Supabase] Client initialized successfully');

// Connection status
let connectionStatus: 'checking' | 'connected' | 'failed' = 'checking';
let connectionError: string | null = null;

// Test connection on initialization
(async () => {
  try {
    console.log('🔍 [Supabase] Testing connection...');
    
    // Clean up old session keys that might interfere
    if (typeof window !== 'undefined') {
      // Remove old migration keys
      localStorage.removeItem('rabit_token_version');
      localStorage.removeItem('rabit_user_profile');
      sessionStorage.removeItem('migration_banner_shown');
      console.log('🧹 [Supabase] Cleaned up old session keys');
    }
    
    const { data, error } = await supabase.auth.getSession();
    
    if (error) {
      console.error('❌ [Supabase] Connection test failed:', error.message);
      console.error('💡 [Supabase] Possible issues:');
      console.error('   1. Check if your Supabase project is active (not paused)');
      console.error('   2. Verify project URL:', supabaseUrl);
      console.error('   3. Verify anon key is correct');
      console.error('   4. Check network connectivity');
      connectionStatus = 'failed';
      connectionError = error.message;
    } else {
      console.log('✅ [Supabase] Connection test successful');
      console.log('👤 [Supabase] Current session:', data.session ? 'Active' : 'None');
      connectionStatus = 'connected';
    }
  } catch (error: any) {
    console.error('❌ [Supabase] Connection test error:', error.message);
    console.error('🔧 [Supabase] Full error:', error);
    connectionStatus = 'failed';
    connectionError = error.message;
  }
})();

export function getConnectionStatus() {
  return { status: connectionStatus, error: connectionError };
}

/**
 * Get the current session
 */
export async function getSession() {
  try {
    const { data, error } = await supabase.auth.getSession();
    
    if (error) {
      console.error('❌ [Supabase Auth] Error getting session:', error.message);
      return null;
    }
    
    return data.session;
  } catch (error: any) {
    console.error('❌ [Supabase Auth] Session retrieval failed:', error.message);
    return null;
  }
}

/**
 * Get the current user
 */
export async function getCurrentUser() {
  try {
    const { data, error } = await supabase.auth.getUser();
    
    if (error) {
      console.error('❌ [Supabase Auth] Error getting user:', error.message);
      return null;
    }
    
    return data.user;
  } catch (error: any) {
    console.error('❌ [Supabase Auth] User retrieval failed:', error.message);
    return null;
  }
}

/**
 * Sign out the current user
 */
export async function signOut() {
  try {
    const { error } = await supabase.auth.signOut();
    
    if (error) {
      console.error('❌ [Supabase Auth] Error signing out:', error.message);
      throw error;
    }
    
    // Clear all local storage related to auth
    localStorage.removeItem('rabit_user_profile');
    localStorage.removeItem('rabit_token_version');
    
  } catch (error: any) {
    console.error('❌ [Supabase Auth] Sign out failed:', error.message);
    throw error;
  }
}

/**
 * Check if user is authenticated
 */
export async function isAuthenticated(): Promise<boolean> {
  const session = await getSession();
  return !!session && !!session.user;
}