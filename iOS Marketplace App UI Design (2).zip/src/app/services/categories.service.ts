/**
 * Categories Service
 * Handles category management and product filtering by category
 */

import { supabase } from '../lib/supabase';

export interface Category {
  id: string;
  name: string;
  name_ar: string;
  icon: string;
  icon_component: string;
  gradient: string;
  product_count: number;
  description?: string;
  description_ar?: string;
  is_active: boolean;
  display_order: number;
  created_at: string;
  updated_at: string;
}

export interface CategoryWithProducts extends Category {
  products?: any[];
}

/**
 * Get all active categories with product counts
 */
export async function getCategories(): Promise<{
  success: boolean;
  categories?: Category[];
  error?: string;
}> {
  try {
    console.log('📂 Fetching categories from database...');

    const { data, error } = await supabase
      .from('categories')
      .select('*')
      .eq('is_active', true)
      .order('display_order', { ascending: true });

    if (error) {
      console.error('❌ Error fetching categories:', error);
      return {
        success: false,
        error: error.message,
      };
    }

    // Update product counts dynamically
    const categoriesWithCounts = await Promise.all(
      (data || []).map(async (category) => {
        const { count } = await supabase
          .from('products')
          .select('*', { count: 'exact', head: true })
          .eq('category', category.name)
          .eq('status', 'active');

        return {
          ...category,
          product_count: count || 0,
        };
      })
    );

    console.log('✅ Fetched categories:', categoriesWithCounts.length);

    return {
      success: true,
      categories: categoriesWithCounts,
    };
  } catch (err: any) {
    console.error('❌ Exception fetching categories:', err);
    return {
      success: false,
      error: err.message || 'Failed to fetch categories',
    };
  }
}

/**
 * Get products for a specific category
 */
export async function getCategoryProducts(categoryName: string): Promise<{
  success: boolean;
  products?: any[];
  error?: string;
}> {
  try {
    console.log('📦 Fetching products for category:', categoryName);

    const { data, error } = await supabase
      .from('products')
      .select('*')
      .eq('category', categoryName)
      .eq('status', 'active')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('❌ Error fetching category products:', error);
      return {
        success: false,
        error: error.message,
      };
    }

    console.log('✅ Fetched products for category:', data?.length || 0);

    return {
      success: true,
      products: data || [],
    };
  } catch (err: any) {
    console.error('❌ Exception fetching category products:', err);
    return {
      success: false,
      error: err.message || 'Failed to fetch category products',
    };
  }
}

/**
 * Get a single category by ID
 */
export async function getCategory(categoryId: string): Promise<{
  success: boolean;
  category?: Category;
  error?: string;
}> {
  try {
    const { data, error } = await supabase
      .from('categories')
      .select('*')
      .eq('id', categoryId)
      .eq('is_active', true)
      .single();

    if (error) {
      console.error('❌ Error fetching category:', error);
      return {
        success: false,
        error: error.message,
      };
    }

    // Get product count
    const { count } = await supabase
      .from('products')
      .select('*', { count: 'exact', head: true })
      .eq('category', data.name)
      .eq('status', 'active');

    return {
      success: true,
      category: {
        ...data,
        product_count: count || 0,
      },
    };
  } catch (err: any) {
    console.error('❌ Exception fetching category:', err);
    return {
      success: false,
      error: err.message || 'Failed to fetch category',
    };
  }
}

/**
 * Get category by name (for filtering products)
 */
export async function getCategoryByName(
  categoryName: string,
  language: 'ar' | 'en' = 'ar'
): Promise<{
  success: boolean;
  category?: Category;
  error?: string;
}> {
  try {
    const field = language === 'ar' ? 'name_ar' : 'name';
    
    const { data, error } = await supabase
      .from('categories')
      .select('*')
      .eq(field, categoryName)
      .eq('is_active', true)
      .single();

    if (error) {
      console.error('❌ Error fetching category by name:', error);
      return {
        success: false,
        error: error.message,
      };
    }

    return {
      success: true,
      category: data,
    };
  } catch (err: any) {
    console.error('❌ Exception fetching category by name:', err);
    return {
      success: false,
      error: err.message || 'Failed to fetch category',
    };
  }
}

/**
 * Update category product count
 * (Usually called after product creation/deletion)
 */
export async function updateCategoryCount(categoryName: string): Promise<void> {
  try {
    const { count } = await supabase
      .from('products')
      .select('*', { count: 'exact', head: true })
      .eq('category', categoryName)
      .eq('status', 'active');

    await supabase
      .from('categories')
      .update({ product_count: count || 0 })
      .eq('name', categoryName);

    console.log(`✅ Updated category count for ${categoryName}:`, count);
  } catch (err: any) {
    console.error('❌ Error updating category count:', err);
  }
}