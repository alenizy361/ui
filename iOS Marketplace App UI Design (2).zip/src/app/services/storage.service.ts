/**
 * Storage Service
 * 
 * PRODUCTION-READY - Uses real Supabase Storage APIs only
 * NO manual fetch, NO fake tokens, NO 401 errors
 * 
 * Handles image uploads for products and user profiles
 * 
 * ⚠️ IMPORTANT SETUP REQUIRED (One-time setup in Supabase Dashboard):
 * 
 * 1. GO TO: Supabase Dashboard > Storage
 * 
 * 2. CREATE TWO BUCKETS:
 *    a) Name: "product-images"
 *       - Public bucket: YES (check the box)
 *       - File size limit: 5242880 (5MB)
 *    
 *    b) Name: "profile-images"
 *       - Public bucket: YES (check the box)
 *       - File size limit: 2097152 (2MB)
 * 
 * 3. CONFIGURE RLS POLICIES for each bucket:
 *    
 *    For "product-images":
 *    - Policy 1 (INSERT): Allow authenticated users to upload
 *      Name: "Authenticated users can upload product images"
 *      Allowed operation: INSERT
 *      Policy definition: (auth.role() = 'authenticated')
 *    
 *    - Policy 2 (SELECT): Allow public read access
 *      Name: "Public can view product images"
 *      Allowed operation: SELECT
 *      Policy definition: true
 *    
 *    For "profile-images":
 *    - Policy 1 (INSERT/UPDATE): Users can upload their own profile images
 *      Name: "Users can upload their own profile images"
 *      Allowed operations: INSERT, UPDATE
 *      Policy definition: (auth.uid()::text = (storage.foldername(name))[1])
 *    
 *    - Policy 2 (SELECT): Allow public read access
 *      Name: "Public can view profile images"
 *      Allowed operation: SELECT
 *      Policy definition: true
 * 
 * 4. DONE! The storage service will now work correctly.
 */

import { supabase } from '../lib/supabase';

const PRODUCT_IMAGES_BUCKET = 'product-images';
const PROFILE_IMAGES_BUCKET = 'profile-images';

/**
 * Check if bucket exists
 * NOTE: We don't create buckets automatically because that requires service role.
 * Buckets must be created manually in the Supabase Dashboard.
 */
async function checkBucketExists(bucketName: string): Promise<{
  exists: boolean;
  error?: string;
}> {
  try {
    const { data: buckets, error: listError } = await supabase.storage.listBuckets();
    
    if (listError) {
      console.error('❌ [Storage] Failed to list buckets:', listError);
      return { exists: false, error: listError.message };
    }

    const bucketExists = buckets?.some(b => b.name === bucketName);
    
    if (!bucketExists) {
      const setupMessage = `
⚠️ STORAGE SETUP REQUIRED ⚠️

The "${bucketName}" bucket does not exist.

Please create it manually in Supabase Dashboard:

1. Go to: Supabase Dashboard > Storage
2. Click "New bucket"
3. Name: "${bucketName}"
4. Public bucket: YES (check the box)
5. Click "Create bucket"
6. Configure RLS policies (see documentation in storage.service.ts)

After creating the bucket, try uploading again.
      `.trim();
      
      console.error('❌ [Storage]', setupMessage);
      return { 
        exists: false, 
        error: `SETUP_REQUIRED: Bucket "${bucketName}" not found. Please create it in Supabase Dashboard first.`
      };
    }
    
    return { exists: true };
  } catch (error: any) {
    console.error('❌ [Storage] Bucket check error:', error);
    return { exists: false, error: error.message };
  }
}

/**
 * Upload product image
 * Returns public URL of uploaded image
 */
export async function uploadProductImage(file: File): Promise<{
  success: boolean;
  url?: string;
  error?: string;
}> {
  try {
    // Check if user is authenticated
    const { data: { session } } = await supabase.auth.getSession();
    
    if (!session) {
      console.error('❌ [Storage Service] Not authenticated - session:', session);
      return {
        success: false,
        error: 'Please sign in to upload images',
      };
    }

    console.log('✅ [Storage Service] User authenticated, session exists');

    // Validate file
    if (!file) {
      return {
        success: false,
        error: 'No file provided',
      };
    }

    // Validate file type
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    if (!allowedTypes.includes(file.type)) {
      return {
        success: false,
        error: 'Only JPEG, PNG, and WebP images are allowed',
      };
    }

    // Validate file size (max 5MB)
    const maxSize = 5 * 1024 * 1024; // 5MB
    if (file.size > maxSize) {
      return {
        success: false,
        error: 'Image size must be less than 5MB',
      };
    }

    // Ensure bucket exists
    const bucketCheck = await checkBucketExists(PRODUCT_IMAGES_BUCKET);
    if (!bucketCheck.exists) {
      return {
        success: false,
        error: bucketCheck.error,
      };
    }

    // Generate unique file name
    const fileExt = file.name.split('.').pop();
    const fileName = `${session.user.id}/${Date.now()}.${fileExt}`;

    console.log('📤 [Storage Service] Uploading product image:', fileName);
    console.log('📦 [Storage Service] File size:', (file.size / 1024).toFixed(2), 'KB');
    console.log('🪣 [Storage Service] Bucket:', PRODUCT_IMAGES_BUCKET);

    // Upload to Supabase Storage
    const { data, error } = await supabase.storage
      .from(PRODUCT_IMAGES_BUCKET)
      .upload(fileName, file, {
        cacheControl: '3600',
        upsert: false,
      });

    if (error) {
      console.error('❌ [Storage Service] Upload failed:', error);
      
      // Provide helpful error messages
      let errorMessage = error.message;
      let errorType = 'generic';
      
      if (error.message.includes('bucket') || error.message.includes('not found')) {
        errorMessage = 'Storage bucket not configured. Please contact support or create the "product-images" bucket in Supabase dashboard.';
        errorType = 'bucket-missing';
      } else if (error.message.includes('policy') || error.message.includes('row-level security')) {
        errorMessage = 'RLS_POLICY_ERROR: Storage access denied. Row-Level Security policies need to be configured.';
        errorType = 'rls-policy';
      } else if (error.message.includes('JWT')) {
        errorMessage = 'Authentication error. Please sign in again.';
        errorType = 'auth';
      }
      
      console.error('Upload failed:', {
        success: false,
        error: errorMessage,
        errorType,
      });
      
      return {
        success: false,
        error: errorMessage,
      };
    }

    // Get public URL
    const { data: { publicUrl } } = supabase.storage
      .from(PRODUCT_IMAGES_BUCKET)
      .getPublicUrl(data.path);

    console.log('✅ [Storage Service] Upload successful');
    console.log('🔗 [Storage Service] Public URL:', publicUrl);

    return {
      success: true,
      url: publicUrl,
    };
  } catch (error: any) {
    console.error('❌ [Storage Service] Upload error:', error);
    return {
      success: false,
      error: error.message || 'Failed to upload image',
    };
  }
}

/**
 * Upload profile image
 */
export async function uploadProfileImage(file: File): Promise<{
  success: boolean;
  url?: string;
  error?: string;
}> {
  try {
    // Check if user is authenticated
    const { data: { session } } = await supabase.auth.getSession();
    
    if (!session) {
      console.error('❌ [Storage Service] Not authenticated');
      return {
        success: false,
        error: 'Please sign in to upload images',
      };
    }

    // Validate file
    if (!file) {
      return {
        success: false,
        error: 'No file provided',
      };
    }

    // Validate file type
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    if (!allowedTypes.includes(file.type)) {
      return {
        success: false,
        error: 'Only JPEG, PNG, and WebP images are allowed',
      };
    }

    // Validate file size (max 2MB for profile)
    const maxSize = 2 * 1024 * 1024; // 2MB
    if (file.size > maxSize) {
      return {
        success: false,
        error: 'Profile image size must be less than 2MB',
      };
    }

    // Ensure bucket exists
    const bucketCheck = await checkBucketExists(PROFILE_IMAGES_BUCKET);
    if (!bucketCheck.exists) {
      return {
        success: false,
        error: bucketCheck.error,
      };
    }

    // Generate unique file name
    const fileExt = file.name.split('.').pop();
    const fileName = `${session.user.id}/profile.${fileExt}`;

    console.log('📤 [Storage Service] Uploading profile image:', fileName);

    // Upload to Supabase Storage (upsert to replace existing)
    const { data, error } = await supabase.storage
      .from(PROFILE_IMAGES_BUCKET)
      .upload(fileName, file, {
        cacheControl: '3600',
        upsert: true, // Replace existing profile image
      });

    if (error) {
      console.error('❌ [Storage Service] Upload failed:', error.message);
      return {
        success: false,
        error: error.message,
      };
    }

    // Get public URL
    const { data: { publicUrl } } = supabase.storage
      .from(PROFILE_IMAGES_BUCKET)
      .getPublicUrl(data.path);

    console.log('✅ [Storage Service] Profile image upload successful:', publicUrl);

    return {
      success: true,
      url: publicUrl,
    };
  } catch (error: any) {
    console.error('❌ [Storage Service] Upload error:', error);
    return {
      success: false,
      error: error.message || 'Failed to upload profile image',
    };
  }
}

/**
 * Delete product image
 */
export async function deleteProductImage(url: string): Promise<{
  success: boolean;
  error?: string;
}> {
  try {
    // Check if user is authenticated
    const { data: { session } } = await supabase.auth.getSession();
    
    if (!session) {
      return {
        success: false,
        error: 'Please sign in to delete images',
      };
    }

    // Extract path from URL
    const path = url.split('/').slice(-2).join('/');

    console.log('🗑️ [Storage Service] Deleting product image:', path);

    // Delete from Supabase Storage
    const { error } = await supabase.storage
      .from(PRODUCT_IMAGES_BUCKET)
      .remove([path]);

    if (error) {
      console.error('❌ [Storage Service] Delete failed:', error.message);
      return {
        success: false,
        error: error.message,
      };
    }

    console.log('✅ [Storage Service] Image deleted successfully');

    return {
      success: true,
    };
  } catch (error: any) {
    console.error('❌ [Storage Service] Delete error:', error);
    return {
      success: false,
      error: error.message || 'Failed to delete image',
    };
  }
}

/**
 * Get signed URL for private images (if needed)
 */
export async function getSignedUrl(
  bucket: string,
  path: string,
  expiresIn: number = 3600
): Promise<{
  success: boolean;
  url?: string;
  error?: string;
}> {
  try {
    const { data, error } = await supabase.storage
      .from(bucket)
      .createSignedUrl(path, expiresIn);

    if (error) {
      console.error('❌ [Storage Service] Signed URL failed:', error.message);
      return {
        success: false,
        error: error.message,
      };
    }

    return {
      success: true,
      url: data.signedUrl,
    };
  } catch (error: any) {
    console.error('❌ [Storage Service] Signed URL error:', error);
    return {
      success: false,
      error: error.message || 'Failed to generate signed URL',
    };
  }
}