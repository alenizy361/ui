/**
 * Authentication Service
 * 
 * PRODUCTION-READY - Uses real Supabase Auth API
 * NO mocks, NO fake sessions, NO Edge Functions
 */

import { supabase } from '../lib/supabase';

export interface UserProfile {
  id: string;
  email: string;
  name: string;
  phone: string;
  nationalId?: string;
  role: 'buyer' | 'seller' | 'both' | 'none';
  verified: boolean;
  profileImage?: string;
  createdAt?: string;
}

export interface SignUpData {
  email: string;
  password: string;
  name: string;
  phone: string;
  nationalId: string;
  role?: 'buyer' | 'seller' | 'both'; // Add optional role parameter
}

export interface SignInData {
  email: string;
  password: string;
}

/**
 * Sign up a new user with Supabase Auth
 */
export async function signUp(data: SignUpData): Promise<{
  success: boolean;
  user?: UserProfile;
  session?: Session | null;
  needsEmailConfirmation?: boolean;
  error?: string;
}> {
  try {
    const { email, password, name, phone, nationalId, role } = data;

    console.log('🔐 [Auth Service] Starting sign up process...');
    console.log('📧 [Auth Service] Email:', email);
    console.log('🎭 [Auth Service] Role:', role || 'none (will select later)');

    // Validate inputs
    if (!email || !password || !name || !phone) {
      console.error('❌ [Auth Service] Missing required fields');
      return {
        success: false,
        error: 'All fields are required',
      };
    }

    console.log('✅ [Auth Service] All required fields present');
    console.log('📤 [Auth Service] Calling Supabase signUp...');

    // Call Supabase auth (no timeout race, let Supabase handle it)
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          name,
          phone,
          national_id: nationalId,
          role: role || 'none', // Use provided role or default to 'none'
        },
        emailRedirectTo: window.location.origin,
      },
    });

    console.log('📥 [Auth Service] Supabase response received');

    if (authError) {
      console.error('❌ [Auth Service] Sign up failed:', authError.message);
      console.error('❌ [Auth Service] Error details:', authError);
      
      // Provide helpful error messages based on error type
      let errorMessage = authError.message;
      
      if (authError.message.includes('already registered')) {
        errorMessage = 'This email is already registered. Please sign in instead.';
      } else if (authError.message.includes('fetch') || authError.message.includes('network')) {
        errorMessage = 'Cannot connect to Supabase. Please check:\n' +
          '1. Your internet connection\n' +
          '2. If your Supabase project is paused (go to dashboard and resume it)\n' +
          '3. If your Supabase project URL is correct';
      } else if (authError.message.includes('invalid') && authError.message.includes('email')) {
        errorMessage = 'Email validation failed. This is a Supabase configuration issue.\n\n' +
          'To fix this:\n' +
          '1. Go to: Supabase Dashboard → Authentication → Providers\n' +
          '2. Check "Email" provider settings\n' +
          '3. Disable any strict email validation\n' +
          '4. Disable "Enable email confirmations" in URL Configuration\n\n' +
          'Original error: ' + authError.message;
        
        // Also log detailed instructions
        console.error('🔧 [Auth Service] EMAIL VALIDATION ERROR - HOW TO FIX:');
        console.error('1. Go to: https://supabase.com/dashboard/project/YOUR_PROJECT_ID/auth/url-configuration');
        console.error('2. Scroll to "Email Auth" section');
        console.error('3. DISABLE "Enable email confirmations"');
        console.error('4. Click Save');
        console.error('5. Also check: Authentication → Providers → Email → Make sure no domain restrictions');
      }
      
      return {
        success: false,
        error: errorMessage,
      };
    }

    if (!authData || !authData.user) {
      console.error('❌ [Auth Service] No user returned from Supabase');
      console.log('📊 [Auth Service] Auth data:', authData);
      return {
        success: false,
        error: 'Sign up failed - no user returned',
      };
    }

    // Check if session was created (email confirmation disabled) or not (email confirmation enabled)
    if (authData.session) {
      console.log('✅ [Auth Service] Sign up successful with immediate session!');
      console.log('📧 [Auth Service] User email:', authData.user.email);
      console.log('🎫 [Auth Service] Session created:', authData.session.access_token.substring(0, 20) + '...');
      return { success: true, user: authData.user, session: authData.session };
    } else {
      console.log('✅ [Auth Service] Sign up successful!');
      console.log('📧 [Auth Service] User email:', authData.user.email);
      console.log('📬 [Auth Service] Email confirmation required - check your inbox!');
      console.log('💡 [Auth Service] To disable confirmations: Dashboard → Authentication → Email Templates → Disable "Confirm signup"');
      return { success: true, user: authData.user, session: null, needsEmailConfirmation: true };
    }
  } catch (error: any) {
    console.error('❌ [Auth Service] Sign up error:', error);
    console.error('❌ [Auth Service] Error stack:', error.stack);
    
    let errorMessage = error.message || 'Sign up failed';
    
    if (error.message?.includes('timeout') || error.message?.includes('Timeout')) {
      errorMessage = 'Connection timeout. Please check your internet and Supabase project status.';
    }
    
    return {
      success: false,
      error: errorMessage,
    };
  }
}

/**
 * Sign in with email and password
 */
export async function signIn(data: SignInData): Promise<{
  success: boolean;
  user?: UserProfile;
  session?: any;
  error?: string;
}> {
  try {
    const { email, password } = data;

    console.log('🔐 [Auth Service] Starting sign in process...');
    console.log('📧 [Auth Service] Email:', email);
    console.log('⏳ [Auth Service] Calling Supabase signInWithPassword...');

    // Call Supabase auth (no timeout race, let Supabase handle it)
    const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    console.log('📥 [Auth Service] Response received from Supabase');

    if (authError) {
      console.error('❌ [Auth Service] Sign in failed:', authError.message);
      console.error('❌ [Auth Service] Error details:', authError);
      
      // Provide helpful error messages
      let errorMessage = authError.message;
      
      if (authError.message.includes('Invalid login credentials')) {
        errorMessage = 'Invalid email or password';
      } else if (authError.message.includes('Email not confirmed')) {
        errorMessage = 'Please confirm your email first';
      } else if (authError.message.includes('fetch') || authError.message.includes('network')) {
        errorMessage = 'Cannot connect to server. Please check:\n' +
          '1. Your internet connection\n' +
          '2. If your Supabase project is paused (Resume it in the dashboard)\n' +
          '3. Try again in a few moments';
      }
      
      return {
        success: false,
        error: errorMessage,
      };
    }

    if (!authData || !authData.user || !authData.session) {
      console.error('❌ [Auth Service] No user or session returned');
      console.log('📊 [Auth Service] Auth data:', authData);
      
      // Check if email confirmation might be the issue
      if (authData?.user && !authData.session) {
        console.error('❌ [Auth Service] NO SESSION CREATED!');
        console.error('💡 [Auth Service] This means email confirmation is ENABLED in Supabase');
        console.error('💡 [Auth Service] Please disable it: Dashboard → Authentication → Settings → Email Confirmations → Disable');
        console.error('💡 [Auth Service] Or check your email for confirmation link');
        return {
          success: false,
          error: 'Email not confirmed. Please check your email or disable email confirmation in Supabase.',
        };
      }
      
      return {
        success: false,
        error: 'Sign in failed - no session created',
      };
    }

    console.log('✅ [Auth Service] Sign in successful!');
    console.log('👤 [Auth Service] User ID:', authData.user.id);
    console.log('📧 [Auth Service] User email:', authData.user.email);
    console.log('🎫 [Auth Service] Session created:', !!authData.session);

    const userProfile: UserProfile = {
      id: authData.user.id,
      email: authData.user.email!,
      name: authData.user.user_metadata?.name || '',
      phone: authData.user.user_metadata?.phone || '',
      nationalId: authData.user.user_metadata?.national_id,
      role: authData.user.user_metadata?.role || 'none',
      verified: authData.user.email_confirmed_at !== null,
      profileImage: authData.user.user_metadata?.profile_image,
      createdAt: authData.user.created_at,
    };

    console.log('✅ [Auth Service] User profile created:', userProfile);

    return {
      success: true,
      user: userProfile,
      session: authData.session,
    };
  } catch (error: any) {
    console.error('❌ [Auth Service] Sign in error:', error);
    console.error('❌ [Auth Service] Error details:', error);
    
    let errorMessage = error.message || 'Sign in failed';
    
    if (error.message?.includes('timeout') || error.message?.includes('Timeout')) {
      errorMessage = 'Connection timeout. Please check your internet and Supabase project status.';
    }
    
    return {
      success: false,
      error: errorMessage,
    };
  }
}

/**
 * Get current user profile from Supabase
 */
export async function getUserProfile(): Promise<{
  success: boolean;
  user?: UserProfile;
  error?: string;
}> {
  try {
    console.log('🔍 [Auth Service] Getting user profile...');

    const { data: { user }, error } = await supabase.auth.getUser();

    if (error) {
      console.error('❌ [Auth Service] Error getting user:', error.message);
      return {
        success: false,
        error: error.message,
      };
    }

    if (!user) {
      console.log('ℹ️ [Auth Service] No user found');
      return {
        success: false,
        error: 'No user found',
      };
    }

    const userProfile: UserProfile = {
      id: user.id,
      email: user.email!,
      name: user.user_metadata?.name || '',
      phone: user.user_metadata?.phone || '',
      nationalId: user.user_metadata?.national_id,
      role: user.user_metadata?.role || 'none',
      verified: user.email_confirmed_at !== null,
      profileImage: user.user_metadata?.profile_image,
      createdAt: user.created_at,
    };

    console.log('✅ [Auth Service] User profile loaded');

    return {
      success: true,
      user: userProfile,
    };
  } catch (error: any) {
    console.error('❌ [Auth Service] Error getting user profile:', error);
    return {
      success: false,
      error: error.message,
    };
  }
}

/**
 * Sign out current user
 */
export async function signOutUser(): Promise<{
  success: boolean;
  error?: string;
}> {
  try {
    console.log('🔓 [Auth Service] Signing out...');

    const { error } = await supabase.auth.signOut();

    if (error) {
      console.error('❌ [Auth Service] Error signing out:', error.message);
      return {
        success: false,
        error: error.message,
      };
    }

    console.log('✅ [Auth Service] Sign out successful');

    return {
      success: true,
    };
  } catch (error: any) {
    console.error('❌ [Auth Service] Error signing out:', error);
    return {
      success: false,
      error: error.message,
    };
  }
}

/**
 * Update user role
 */
export async function updateUserRole(role: 'buyer' | 'seller' | 'both'): Promise<{
  success: boolean;
  user?: UserProfile;
  error?: string;
}> {
  try {
    console.log('🔄 [Auth Service] Updating user role to:', role);

    const { data, error } = await supabase.auth.updateUser({
      data: {
        role,
      },
    });

    if (error) {
      console.error('❌ [Auth Service] Error updating role:', error.message);
      return {
        success: false,
        error: error.message,
      };
    }

    if (!data || !data.user) {
      console.error('❌ [Auth Service] No user returned after role update');
      return {
        success: false,
        error: 'Failed to update role',
      };
    }

    const userProfile: UserProfile = {
      id: data.user.id,
      email: data.user.email!,
      name: data.user.user_metadata?.name || '',
      phone: data.user.user_metadata?.phone || '',
      nationalId: data.user.user_metadata?.national_id,
      role: data.user.user_metadata?.role || 'none',
      verified: data.user.email_confirmed_at !== null,
      profileImage: data.user.user_metadata?.profile_image,
      createdAt: data.user.created_at,
    };

    console.log('✅ [Auth Service] Role updated successfully');

    return {
      success: true,
      user: userProfile,
    };
  } catch (error: any) {
    console.error('❌ [Auth Service] Error updating role:', error);
    return {
      success: false,
      error: error.message,
    };
  }
}