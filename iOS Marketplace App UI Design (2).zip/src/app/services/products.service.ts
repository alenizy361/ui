/**
 * Products Service
 * 
 * Direct Supabase database integration for product management
 * NO Edge Functions, NO API calls - pure supabase-js
 */

import { supabase } from '../lib/supabase';

export interface Product {
  id?: string;
  title: string;
  description: string;
  price: number;
  category: string;
  condition: 'new' | 'used';
  images: string[];
  location?: string;
  quantity?: number;
  delivery_options?: string[];
  seller_id?: string;
  created_at?: string;
  updated_at?: string;
}

/**
 * Create a new product
 */
export async function createProduct(productData: Product): Promise<{
  success: boolean;
  product?: any;
  error?: string;
}> {
  try {
    // Check authentication
    const { data: { session } } = await supabase.auth.getSession();
    
    if (!session) {
      return {
        success: false,
        error: 'Please sign in to create a product',
      };
    }

    console.log('📦 [Products Service] Creating product:', productData.title);

    // Insert product into database
    const { data, error } = await supabase
      .from('products')
      .insert([
        {
          title: productData.title,
          description: productData.description,
          price: productData.price,
          category: productData.category,
          condition: productData.condition,
          images: productData.images,
          location: productData.location,
          quantity: productData.quantity || 1,
          delivery_options: productData.delivery_options || [],
          seller_id: session.user.id,
        },
      ])
      .select()
      .single();

    if (error) {
      console.error('❌ [Products Service] Create failed:', error);
      
      // Provide helpful error messages
      let errorMessage = error.message;
      
      if (error.message.includes('relation') || error.message.includes('does not exist') || error.code === 'PGRST205') {
        errorMessage = 'DATABASE_SETUP_REQUIRED: Products table does not exist. Please create it in Supabase Dashboard.\n\n' +
                      'SOLUTION:\n' +
                      '1. Open Supabase Dashboard → SQL Editor\n' +
                      '2. Copy SQL from /DATABASE_SETUP_REQUIRED.md\n' +
                      '3. Run the SQL script\n' +
                      '4. Refresh and try again';
      } else if (error.message.includes('policy') || error.message.includes('row-level security')) {
        errorMessage = 'RLS_POLICY_ERROR: Database access denied. Row-Level Security policies need to be configured.';
      } else if (error.message.includes('JWT')) {
        errorMessage = 'Authentication error. Please sign in again.';
      }
      
      return {
        success: false,
        error: errorMessage,
      };
    }

    console.log('✅ [Products Service] Product created successfully:', data.id);

    return {
      success: true,
      product: data,
    };
  } catch (error: any) {
    console.error('❌ [Products Service] Create error:', error);
    return {
      success: false,
      error: error.message || 'Failed to create product',
    };
  }
}

/**
 * Get products (browse/search)
 */
export async function getProducts(filters?: {
  category?: string;
  search?: string;
  seller_id?: string;
  limit?: number;
}): Promise<{
  success: boolean;
  products?: any[];
  error?: string;
}> {
  try {
    let query = supabase
      .from('products')
      .select('*')
      .order('created_at', { ascending: false });

    // Apply filters
    if (filters?.category) {
      query = query.eq('category', filters.category);
    }
    
    if (filters?.seller_id) {
      query = query.eq('seller_id', filters.seller_id);
    }
    
    if (filters?.search) {
      query = query.or(`title.ilike.%${filters.search}%,description.ilike.%${filters.search}%`);
    }
    
    if (filters?.limit) {
      query = query.limit(filters.limit);
    }

    const { data, error } = await query;

    if (error) {
      console.error('❌ [Products Service] Get products failed:', error);
      return {
        success: false,
        error: error.message,
      };
    }

    return {
      success: true,
      products: data || [],
    };
  } catch (error: any) {
    console.error('❌ [Products Service] Get products error:', error);
    return {
      success: false,
      error: error.message || 'Failed to fetch products',
    };
  }
}

/**
 * Get a single product by ID
 */
export async function getProductById(productId: string): Promise<{
  success: boolean;
  product?: any;
  error?: string;
}> {
  try {
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .eq('id', productId)
      .single();

    if (error) {
      console.error('❌ [Products Service] Get product failed:', error);
      return {
        success: false,
        error: error.message,
      };
    }

    return {
      success: true,
      product: data,
    };
  } catch (error: any) {
    console.error('❌ [Products Service] Get product error:', error);
    return {
      success: false,
      error: error.message || 'Failed to fetch product',
    };
  }
}

/**
 * Update a product
 */
export async function updateProduct(
  productId: string,
  updates: Partial<Product>
): Promise<{
  success: boolean;
  product?: any;
  error?: string;
}> {
  try {
    // Check authentication
    const { data: { session } } = await supabase.auth.getSession();
    
    if (!session) {
      return {
        success: false,
        error: 'Please sign in to update a product',
      };
    }

    console.log('📝 [Products Service] Updating product:', productId);

    // Update product
    const { data, error } = await supabase
      .from('products')
      .update({
        ...updates,
        updated_at: new Date().toISOString(),
      })
      .eq('id', productId)
      .eq('seller_id', session.user.id) // Ensure user owns the product
      .select()
      .single();

    if (error) {
      console.error('❌ [Products Service] Update failed:', error);
      return {
        success: false,
        error: error.message,
      };
    }

    console.log('✅ [Products Service] Product updated successfully');

    return {
      success: true,
      product: data,
    };
  } catch (error: any) {
    console.error('❌ [Products Service] Update error:', error);
    return {
      success: false,
      error: error.message || 'Failed to update product',
    };
  }
}

/**
 * Delete a product
 */
export async function deleteProduct(productId: string): Promise<{
  success: boolean;
  error?: string;
}> {
  try {
    // Check authentication
    const { data: { session } } = await supabase.auth.getSession();
    
    if (!session) {
      return {
        success: false,
        error: 'Please sign in to delete a product',
      };
    }

    console.log('🗑️ [Products Service] Deleting product:', productId);

    // Delete product
    const { error } = await supabase
      .from('products')
      .delete()
      .eq('id', productId)
      .eq('seller_id', session.user.id); // Ensure user owns the product

    if (error) {
      console.error('❌ [Products Service] Delete failed:', error);
      return {
        success: false,
        error: error.message,
      };
    }

    console.log('✅ [Products Service] Product deleted successfully');

    return {
      success: true,
    };
  } catch (error: any) {
    console.error('❌ [Products Service] Delete error:', error);
    return {
      success: false,
      error: error.message || 'Failed to delete product',
    };
  }
}

/**
 * Get seller's products
 */
export async function getSellerProducts(): Promise<{
  success: boolean;
  products?: any[];
  error?: string;
}> {
  try {
    // Check authentication
    const { data: { session } } = await supabase.auth.getSession();
    
    if (!session) {
      return {
        success: false,
        error: 'Please sign in to view your products',
      };
    }

    const { data, error } = await supabase
      .from('products')
      .select('*')
      .eq('seller_id', session.user.id)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('❌ [Products Service] Get seller products failed:', error);
      return {
        success: false,
        error: error.message,
      };
    }

    return {
      success: true,
      products: data || [],
    };
  } catch (error: any) {
    console.error('❌ [Products Service] Get seller products error:', error);
    return {
      success: false,
      error: error.message || 'Failed to fetch your products',
    };
  }
}