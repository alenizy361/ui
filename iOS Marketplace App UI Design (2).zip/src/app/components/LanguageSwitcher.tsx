import { motion } from "motion/react";
import { useLanguage } from "../contexts/LanguageContext";
import { triggerHaptic } from "../utils/haptics";

interface LanguageSwitcherProps {
  variant?: "default" | "compact";
  className?: string;
}

export function LanguageSwitcher({ variant = "default", className = "" }: LanguageSwitcherProps) {
  const { language, setLanguage } = useLanguage();

  const handleLanguageChange = (lang: 'ar' | 'en') => {
    setLanguage(lang);
    triggerHaptic('light');
  };

  if (variant === "compact") {
    return (
      <div className={`flex items-center gap-1 bg-white/80 backdrop-blur-xl rounded-full p-1 shadow-md border border-white/60 ${className}`}>
        <button
          onClick={() => handleLanguageChange('ar')}
          className={`px-3 py-1.5 rounded-full transition-all duration-300 text-xs font-bold ${
            language === 'ar'
              ? 'bg-[#163300] text-white shadow-sm'
              : 'text-[#6a6c6a] hover:text-[#163300]'
          }`}
        >
          ع
        </button>
        <button
          onClick={() => handleLanguageChange('en')}
          className={`px-3 py-1.5 rounded-full transition-all duration-300 text-xs font-bold ${
            language === 'en'
              ? 'bg-[#163300] text-white shadow-sm'
              : 'text-[#6a6c6a] hover:text-[#163300]'
          }`}
        >
          EN
        </button>
      </div>
    );
  }

  return (
    <div className={`flex items-center gap-1 bg-white/80 backdrop-blur-xl rounded-full p-1 shadow-lg border border-white/60 ${className}`}>
      <button
        onClick={() => handleLanguageChange('ar')}
        className={`px-4 py-2 rounded-full transition-all duration-300 flex items-center gap-2 ${
          language === 'ar'
            ? 'bg-[#163300] text-white shadow-md'
            : 'text-[#6a6c6a] hover:text-[#163300]'
        }`}
      >
        <span className="text-sm font-bold">عربي</span>
      </button>
      <button
        onClick={() => handleLanguageChange('en')}
        className={`px-4 py-2 rounded-full transition-all duration-300 flex items-center gap-2 ${
          language === 'en'
            ? 'bg-[#163300] text-white shadow-md'
            : 'text-[#6a6c6a] hover:text-[#163300]'
        }`}
      >
        <span className="text-sm font-bold">EN</span>
      </button>
    </div>
  );
}
