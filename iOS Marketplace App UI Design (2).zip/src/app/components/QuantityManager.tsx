import { motion } from "motion/react";
import { Plus, Minus, Package } from "lucide-react";
import { useState } from "react";
import { useLanguage } from "../contexts/LanguageContext";
import { getTranslation } from "../utils/translations";

interface QuantityManagerProps {
  productId: string;
  currentQuantity: number;
  productName: string;
  onQuantityChange: (productId: string, newQuantity: number) => void;
  variant?: "compact" | "full"; // compact for product cards, full for detail views
}

export function QuantityManager({ 
  productId, 
  currentQuantity, 
  productName,
  onQuantityChange,
  variant = "compact" 
}: QuantityManagerProps) {
  const { language, isRTL } = useLanguage();
  const t = getTranslation(language);
  const [quantity, setQuantity] = useState(currentQuantity);
  const [isUpdating, setIsUpdating] = useState(false);

  const handleDecrease = () => {
    if (quantity > 0) {
      const newQty = quantity - 1;
      setQuantity(newQty);
      updateQuantity(newQty);
    }
  };

  const handleIncrease = () => {
    const newQty = quantity + 1;
    setQuantity(newQty);
    updateQuantity(newQty);
  };

  const handleInputChange = (value: string) => {
    const newQty = parseInt(value) || 0;
    if (newQty >= 0) {
      setQuantity(newQty);
      updateQuantity(newQty);
    }
  };

  const updateQuantity = async (newQty: number) => {
    setIsUpdating(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));
    onQuantityChange(productId, newQty);
    setIsUpdating(false);
  };

  const isOutOfStock = quantity === 0;
  const isLowStock = quantity > 0 && quantity <= 5;

  if (variant === "compact") {
    return (
      <div className="flex items-center gap-2">
        {/* Stock Status Badge */}
        <div className={`px-2 py-1 rounded-full text-xs font-medium ${
          isOutOfStock 
            ? 'bg-[#cb272f]/10 text-[#cb272f]' 
            : isLowStock 
            ? 'bg-[#ff8c00]/10 text-[#ff8c00]' 
            : 'bg-[#163300]/10 text-[#163300]'
        }`}>
          {isOutOfStock 
            ? t.outOfStock 
            : `${quantity} ${language === 'ar' ? 'متبقي' : 'left'}`}
        </div>

        {/* Quantity Controls */}
        <div className="flex items-center gap-1 bg-[rgba(22,51,0,0.07843)] rounded-[8px] px-1 py-1">
          <button
            onClick={handleDecrease}
            disabled={isOutOfStock || isUpdating}
            className="w-6 h-6 rounded-[6px] bg-white border border-[rgba(14,15,12,0.12157)] flex items-center justify-center hover:bg-[#163300] hover:text-white transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
          >
            <Minus className="w-3 h-3" />
          </button>
          
          <input
            type="number"
            value={quantity}
            onChange={(e) => handleInputChange(e.target.value)}
            disabled={isUpdating}
            className="w-10 h-6 text-center bg-transparent text-sm font-medium text-[#0e0f0c] focus:outline-none"
            min="0"
          />
          
          <button
            onClick={handleIncrease}
            disabled={isUpdating}
            className="w-6 h-6 rounded-[6px] bg-white border border-[rgba(14,15,12,0.12157)] flex items-center justify-center hover:bg-[#163300] hover:text-white transition-colors disabled:opacity-30"
          >
            <Plus className="w-3 h-3" />
          </button>
        </div>
      </div>
    );
  }

  // Full variant for detail views
  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white border border-[rgba(14,15,12,0.12157)] rounded-[12px] p-4"
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      <div className={`flex items-center justify-between mb-4 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
        <div className="flex items-center gap-2">
          <Package className="w-5 h-5 text-[#163300]" />
          <h3 className={`font-medium text-[#0e0f0c] ${isRTL ? 'text-right' : 'text-left'}`}>
            {t.availableStock}
          </h3>
        </div>
        
        {/* Stock Status */}
        <div className={`px-3 py-1.5 rounded-full text-sm font-medium ${
          isOutOfStock 
            ? 'bg-[#cb272f]/10 text-[#cb272f]' 
            : isLowStock 
            ? 'bg-[#ff8c00]/10 text-[#ff8c00]' 
            : 'bg-[#163300]/10 text-[#163300]'
        }`}>
          {isOutOfStock 
            ? t.outOfStock 
            : isLowStock
            ? `⚠️ ${quantity} ${language === 'ar' ? 'فقط متبقي' : 'only left'}`
            : `✓ ${t.inStock}`}
        </div>
      </div>

      {/* Product Name */}
      <p className={`text-sm text-[#6a6c6a] mb-3 ${isRTL ? 'text-right' : 'text-left'}`}>
        {productName}
      </p>

      {/* Quantity Controls */}
      <div className={`flex items-center gap-4 ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
        <div className="flex items-center gap-2 bg-[rgba(22,51,0,0.07843)] rounded-[10px] px-2 py-2">
          <button
            onClick={handleDecrease}
            disabled={isOutOfStock || isUpdating}
            className="w-10 h-10 rounded-[8px] bg-white border border-[rgba(14,15,12,0.12157)] flex items-center justify-center hover:bg-[#163300] hover:text-white transition-all disabled:opacity-30 disabled:cursor-not-allowed active:scale-95"
          >
            <Minus className="w-5 h-5" />
          </button>
          
          <input
            type="number"
            value={quantity}
            onChange={(e) => handleInputChange(e.target.value)}
            disabled={isUpdating}
            className="w-20 h-10 text-center bg-transparent text-lg font-bold text-[#0e0f0c] focus:outline-none"
            min="0"
          />
          
          <button
            onClick={handleIncrease}
            disabled={isUpdating}
            className="w-10 h-10 rounded-[8px] bg-white border border-[rgba(14,15,12,0.12157)] flex items-center justify-center hover:bg-[#163300] hover:text-white transition-all disabled:opacity-30 active:scale-95"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1">
          <p className={`text-xs text-[#6a6c6a] ${isRTL ? 'text-right' : 'text-left'}`}>
            {isUpdating 
              ? (language === 'ar' ? 'جاري التحديث...' : 'Updating...') 
              : (language === 'ar' ? 'انقر لتحديث الكمية' : 'Click to update quantity')}
          </p>
        </div>
      </div>

      {/* Warning for low stock */}
      {isLowStock && !isOutOfStock && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          className="mt-3 p-2 bg-[#ff8c00]/10 border border-[#ff8c00]/30 rounded-[8px]"
        >
          <p className={`text-xs text-[#ff8c00] ${isRTL ? 'text-right' : 'text-left'}`}>
            ⚠️ {language === 'ar' 
              ? 'المخزون منخفض! فكر في إعادة التخزين' 
              : 'Low stock! Consider restocking'}
          </p>
        </motion.div>
      )}

      {/* Out of stock message */}
      {isOutOfStock && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          className="mt-3 p-2 bg-[#cb272f]/10 border border-[#cb272f]/30 rounded-[8px]"
        >
          <p className={`text-xs text-[#cb272f] ${isRTL ? 'text-right' : 'text-left'}`}>
            🚫 {language === 'ar' 
              ? 'المنتج غير متاح. سيتم إخفاؤه من النتائج' 
              : 'Product out of stock. Will be hidden from search'}
          </p>
        </motion.div>
      )}
    </motion.div>
  );
}
