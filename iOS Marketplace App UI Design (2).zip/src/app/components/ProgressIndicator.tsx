import { motion } from "motion/react";
import { CheckCircle2, Circle } from "lucide-react";

interface Step {
  label: string;
  status: "completed" | "current" | "upcoming";
}

interface ProgressIndicatorProps {
  steps: Step[];
  orientation?: "horizontal" | "vertical";
}

export function ProgressIndicator({ steps, orientation = "horizontal" }: ProgressIndicatorProps) {
  if (orientation === "vertical") {
    return (
      <div className="space-y-4">
        {steps.map((step, index) => (
          <div key={index} className="flex items-start gap-3">
            <div className="flex flex-col items-center">
              {step.status === "completed" ? (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", stiffness: 200 }}
                >
                  <CheckCircle2 className="w-6 h-6 text-[#163300]" />
                </motion.div>
              ) : step.status === "current" ? (
                <motion.div
                  animate={{ scale: [1, 1.1, 1] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                >
                  <Circle className="w-6 h-6 text-[#9fe870] fill-[#9fe870]" />
                </motion.div>
              ) : (
                <Circle className="w-6 h-6 text-[#6a6c6a] opacity-30" />
              )}
              {index < steps.length - 1 && (
                <div
                  className={`w-0.5 h-8 mt-2 ${
                    step.status === "completed" ? "bg-[#163300]" : "bg-[rgba(14,15,12,0.12157)]"
                  }`}
                />
              )}
            </div>
            <div className="flex-1 pt-1">
              <p
                className={`text-sm font-medium ${
                  step.status === "current"
                    ? "text-[#163300]"
                    : step.status === "completed"
                    ? "text-[#6a6c6a]"
                    : "text-[#6a6c6a] opacity-50"
                }`}
              >
                {step.label}
              </p>
            </div>
          </div>
        ))}
      </div>
    );
  }

  // Horizontal orientation
  return (
    <div className="flex items-center justify-between">
      {steps.map((step, index) => (
        <div key={index} className="flex items-center flex-1">
          <div className="flex flex-col items-center flex-1">
            {step.status === "completed" ? (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 200 }}
              >
                <CheckCircle2 className="w-8 h-8 text-[#163300]" />
              </motion.div>
            ) : step.status === "current" ? (
              <motion.div
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              >
                <Circle className="w-8 h-8 text-[#9fe870] fill-[#9fe870]" />
              </motion.div>
            ) : (
              <Circle className="w-8 h-8 text-[#6a6c6a] opacity-30" />
            )}
            <p
              className={`text-xs font-medium mt-2 text-center ${
                step.status === "current"
                  ? "text-[#163300]"
                  : step.status === "completed"
                  ? "text-[#6a6c6a]"
                  : "text-[#6a6c6a] opacity-50"
              }`}
            >
              {step.label}
            </p>
          </div>
          {index < steps.length - 1 && (
            <div
              className={`h-0.5 flex-1 -mt-8 ${
                step.status === "completed" ? "bg-[#163300]" : "bg-[rgba(14,15,12,0.12157)]"
              }`}
            />
          )}
        </div>
      ))}
    </div>
  );
}
