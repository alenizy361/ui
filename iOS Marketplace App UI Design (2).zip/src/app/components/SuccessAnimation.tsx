import { motion } from "motion/react";
import { CheckCircle2, Sparkles, LucideIcon } from "lucide-react";
import { ReactNode } from "react";

interface SuccessAnimationProps {
  icon?: LucideIcon;
  title: string;
  description?: string;
  children?: ReactNode;
  showConfetti?: boolean;
}

export function SuccessAnimation({
  icon: Icon,
  title,
  description,
  children,
  showConfetti = true,
}: SuccessAnimationProps) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-white z-50 flex flex-col items-center justify-center px-6"
    >
      {/* Confetti particles */}
      {showConfetti && (
        <>
          {Array.from({ length: 12 }).map((_, i) => (
            <motion.div
              key={i}
              initial={{
                opacity: 0,
                scale: 0,
                x: 0,
                y: 0,
              }}
              animate={{
                opacity: [0, 1, 1, 0],
                scale: [0, 1, 1, 0.5],
                x: Math.cos((i * 2 * Math.PI) / 12) * 150,
                y: Math.sin((i * 2 * Math.PI) / 12) * 150,
              }}
              transition={{
                duration: 1.2,
                delay: 0.3,
                ease: "easeOut",
              }}
              className="absolute"
              style={{
                left: "50%",
                top: "35%",
              }}
            >
              <Sparkles
                className="w-4 h-4"
                style={{
                  color: i % 2 === 0 ? "#9fe870" : "#163300",
                }}
              />
            </motion.div>
          ))}
        </>
      )}

      {/* Main icon with bounce */}
      <motion.div
        initial={{ scale: 0, rotate: -180 }}
        animate={{ scale: 1, rotate: 0 }}
        transition={{
          type: "spring",
          stiffness: 200,
          damping: 15,
          delay: 0.1,
        }}
        className="mb-6"
      >
        {Icon ? (
          <div className="w-24 h-24 rounded-full bg-[#e2f6d5] flex items-center justify-center relative">
            <Icon className="w-12 h-12 text-[#163300]" />
            {/* Checkmark overlay */}
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.3, type: "spring", stiffness: 200 }}
              className="absolute -top-1 -right-1 bg-[#163300] rounded-full p-1"
            >
              <CheckCircle2 className="w-6 h-6 text-[#9fe870]" />
            </motion.div>
          </div>
        ) : (
          <div className="w-24 h-24 rounded-full bg-[#e2f6d5] flex items-center justify-center">
            <CheckCircle2 className="w-16 h-16 text-[#163300]" />
          </div>
        )}
      </motion.div>

      {/* Title with slide up */}
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="text-2xl font-bold text-[#0e0f0c] mb-3 text-center"
      >
        {title}
      </motion.h2>

      {/* Description */}
      {description && (
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="text-base text-[#6a6c6a] text-center mb-8 max-w-[300px]"
        >
          {description}
        </motion.p>
      )}

      {/* Children content */}
      {children && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="w-full"
        >
          {children}
        </motion.div>
      )}

      {/* Loading dots */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
        className="flex gap-2 mt-8"
      >
        {[0, 1, 2].map((i) => (
          <motion.div
            key={i}
            animate={{
              scale: [1, 1.3, 1],
              opacity: [0.5, 1, 0.5],
            }}
            transition={{
              duration: 1,
              repeat: Infinity,
              delay: i * 0.2,
            }}
            className="w-2 h-2 rounded-full bg-[#163300]"
          />
        ))}
      </motion.div>
    </motion.div>
  );
}
