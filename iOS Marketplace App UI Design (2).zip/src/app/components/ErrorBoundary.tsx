import React from "react";
import { motion } from "motion/react";
import { AlertCircle, RefreshCw, Home } from "lucide-react";

interface Props {
  children: React.ReactNode;
  onReset?: () => void;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error("Error caught by boundary:", error, errorInfo);
  }

  handleReset = () => {
    this.setState({ hasError: false, error: null });
    if (this.props.onReset) {
      this.props.onReset();
    }
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-gradient-to-b from-[#fafafa] to-white flex items-center justify-center p-6">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-md w-full"
          >
            {/* Error Icon */}
            <div className="flex justify-center mb-6">
              <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-red-50 to-red-100 flex items-center justify-center shadow-lg">
                <AlertCircle className="w-12 h-12 text-red-500" />
              </div>
            </div>

            {/* Error Message */}
            <div className="text-center mb-8">
              <h1 className="text-2xl font-bold text-[#0a0b09] mb-3">
                عذراً، حدث خطأ ما
              </h1>
              <p className="text-[#6a6c6a] text-sm leading-relaxed mb-4">
                واجهنا مشكلة غير متوقعة. يمكنك المحاولة مرة أخرى أو العودة للصفحة الرئيسية.
              </p>
              {this.state.error && (
                <div className="bg-red-50 border border-red-200 rounded-2xl p-4 text-right">
                  <p className="text-xs text-red-600 font-mono break-all">
                    {this.state.error.message}
                  </p>
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="space-y-3">
              <motion.button
                whileTap={{ scale: 0.98 }}
                onClick={this.handleReset}
                className="w-full py-4 bg-gradient-to-br from-[#163300] to-[#0f2409] text-white font-semibold rounded-2xl shadow-lg hover:shadow-xl transition-all duration-200 flex items-center justify-center gap-2"
              >
                <RefreshCw className="w-5 h-5" />
                حاول مرة أخرى
              </motion.button>

              <motion.button
                whileTap={{ scale: 0.98 }}
                onClick={() => window.location.href = "/"}
                className="w-full py-4 bg-[#f0fde8] border border-[rgba(22,51,0,0.15)] text-[#163300] font-semibold rounded-2xl hover:bg-[#e2fad5] transition-all duration-200 flex items-center justify-center gap-2"
              >
                <Home className="w-5 h-5" />
                العودة للرئيسية
              </motion.button>
            </div>
          </motion.div>
        </div>
      );
    }

    return this.props.children;
  }
}
