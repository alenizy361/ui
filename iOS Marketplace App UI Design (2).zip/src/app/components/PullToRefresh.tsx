import { motion, useMotionValue, useTransform, animate } from "motion/react";
import { RefreshCw } from "lucide-react";
import { ReactNode, useEffect, useState, useRef, TouchEvent } from "react";
import { triggerHaptic } from "../utils/haptics";

interface PullToRefreshProps {
  onRefresh: () => Promise<void>;
  children: ReactNode;
  threshold?: number;
}

export function PullToRefresh({ onRefresh, children, threshold = 80 }: PullToRefreshProps) {
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [pullDistance, setPullDistance] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const touchStartY = useRef(0);
  const hasTriggered = useRef(false);

  const rotate = (pullDistance / threshold) * 360;
  const opacity = Math.min(pullDistance / threshold, 1);
  const scale = 0.5 + (pullDistance / threshold) * 0.5;

  const handleTouchStart = (e: TouchEvent) => {
    if (containerRef.current && containerRef.current.scrollTop === 0) {
      touchStartY.current = e.touches[0].clientY;
    }
  };

  const handleTouchMove = (e: TouchEvent) => {
    if (isRefreshing || !containerRef.current) return;
    
    const scrollTop = containerRef.current.scrollTop;
    if (scrollTop === 0 && touchStartY.current > 0) {
      const touchY = e.touches[0].clientY;
      const distance = touchY - touchStartY.current;
      
      if (distance > 0) {
        // Prevent default only when pulling down at the top
        e.preventDefault();
        const dampedDistance = Math.min(distance * 0.5, threshold * 1.5);
        setPullDistance(dampedDistance);
        
        // Trigger haptic when crossing threshold
        if (dampedDistance > threshold && !hasTriggered.current) {
          triggerHaptic("selection");
          hasTriggered.current = true;
        } else if (dampedDistance <= threshold && hasTriggered.current) {
          hasTriggered.current = false;
        }
      }
    }
  };

  const handleTouchEnd = async () => {
    if (pullDistance > threshold && !isRefreshing) {
      setIsRefreshing(true);
      triggerHaptic("medium");
      setPullDistance(threshold);
      
      try {
        await onRefresh();
        triggerHaptic("success");
      } catch (error) {
        triggerHaptic("error");
      } finally {
        setIsRefreshing(false);
        hasTriggered.current = false;
      }
    }
    
    touchStartY.current = 0;
    hasTriggered.current = false;
    
    if (!isRefreshing) {
      setPullDistance(0);
    }
  };

  useEffect(() => {
    if (!isRefreshing && pullDistance > 0) {
      const animation = setInterval(() => {
        setPullDistance(prev => {
          const next = prev - 10;
          if (next <= 0) {
            clearInterval(animation);
            return 0;
          }
          return next;
        });
      }, 16);
      return () => clearInterval(animation);
    }
  }, [isRefreshing, pullDistance]);

  return (
    <div className="relative h-full overflow-hidden">
      {/* Refresh Indicator */}
      <div
        className="absolute top-0 left-0 right-0 flex items-center justify-center h-20 z-10 pointer-events-none"
        style={{ 
          opacity,
          transform: `translateY(${Math.min(pullDistance - 20, 0)}px)`
        }}
      >
        <div 
          className="flex flex-col items-center gap-2"
          style={{ transform: `scale(${scale})` }}
        >
          <div
            style={{ 
              transform: `rotate(${isRefreshing ? 0 : rotate}deg)`,
              transition: isRefreshing ? 'none' : 'transform 0.1s ease-out'
            }}
            className={isRefreshing ? 'animate-spin' : ''}
          >
            <RefreshCw className={`w-6 h-6 ${hasTriggered.current || isRefreshing ? 'text-[#163300]' : 'text-[#6a6c6a]'}`} />
          </div>
          {pullDistance > threshold && !isRefreshing && (
            <p className="text-xs text-[#163300] font-medium">
              اترك للتحديث
            </p>
          )}
          {isRefreshing && (
            <p className="text-xs text-[#163300] font-medium">
              جاري التحديث...
            </p>
          )}
        </div>
      </div>

      {/* Content - Native Scrollable Container */}
      <div
        ref={containerRef}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        className="h-full overflow-y-auto overflow-x-hidden overscroll-none"
        style={{
          transform: `translateY(${pullDistance}px)`,
          transition: pullDistance === 0 ? 'transform 0.3s ease-out' : 'none',
          WebkitOverflowScrolling: 'touch'
        }}
      >
        {children}
      </div>
    </div>
  );
}