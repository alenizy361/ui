/**
 * Supabase Paused Error Screen
 */

import { motion } from 'motion/react';
import { AlertCircle, ExternalLink, RefreshCw, Coffee } from 'lucide-react';

interface SupabasePausedErrorProps {
  projectId: string;
  onRetry: () => void;
}

export function SupabasePausedError({ projectId, onRetry }: SupabasePausedErrorProps) {
  const dashboardUrl = `https://supabase.com/dashboard/project/${projectId}`;

  return (
    <div className="fixed inset-0 z-[9999] bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-3xl shadow-2xl max-w-lg w-full overflow-hidden"
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white p-8">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
              <Coffee className="w-8 h-8" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">Project Paused</h1>
              <p className="text-sm text-white/90">Your Supabase project is sleeping</p>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-8 space-y-6">
          {/* Problem */}
          <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
            <div className="flex gap-3">
              <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold text-yellow-900 mb-1">Connection Timeout</h3>
                <p className="text-sm text-yellow-800">
                  All API calls are timing out. This typically means your Supabase project has been automatically paused due to inactivity.
                </p>
              </div>
            </div>
          </div>

          {/* Solution */}
          <div>
            <h3 className="font-semibold text-gray-900 mb-3">How to Fix:</h3>
            <ol className="space-y-3 text-sm text-gray-700">
              <li className="flex gap-3">
                <span className="flex-shrink-0 w-6 h-6 bg-[#163300] text-white rounded-full flex items-center justify-center text-xs font-bold">
                  1
                </span>
                <span>
                  Go to your Supabase Dashboard using the button below
                </span>
              </li>
              <li className="flex gap-3">
                <span className="flex-shrink-0 w-6 h-6 bg-[#163300] text-white rounded-full flex items-center justify-center text-xs font-bold">
                  2
                </span>
                <span>
                  Look for a <strong>"Project Paused"</strong> banner at the top
                </span>
              </li>
              <li className="flex gap-3">
                <span className="flex-shrink-0 w-6 h-6 bg-[#163300] text-white rounded-full flex items-center justify-center text-xs font-bold">
                  3
                </span>
                <span>
                  Click <strong>"Resume Project"</strong> and wait 1-2 minutes
                </span>
              </li>
              <li className="flex gap-3">
                <span className="flex-shrink-0 w-6 h-6 bg-[#163300] text-white rounded-full flex items-center justify-center text-xs font-bold">
                  4
                </span>
                <span>
                  Come back here and click <strong>"Retry Connection"</strong>
                </span>
              </li>
            </ol>
          </div>

          {/* Project Info */}
          <div className="bg-gray-50 rounded-xl p-4">
            <p className="text-xs text-gray-600 mb-2">Project ID:</p>
            <code className="text-xs font-mono text-gray-900 bg-white px-3 py-2 rounded-lg border border-gray-200 block">
              {projectId}
            </code>
          </div>

          {/* Actions */}
          <div className="flex flex-col gap-3">
            <a
              href={dashboardUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full bg-gradient-to-r from-[#163300] to-[#1e4400] text-white py-4 rounded-xl font-semibold flex items-center justify-center gap-2 hover:shadow-lg transition-all"
            >
              <ExternalLink className="w-5 h-5" />
              Open Supabase Dashboard
            </a>

            <button
              onClick={onRetry}
              className="w-full border-2 border-gray-200 text-gray-700 py-4 rounded-xl font-semibold flex items-center justify-center gap-2 hover:border-gray-300 hover:bg-gray-50 transition-all"
            >
              <RefreshCw className="w-5 h-5" />
              Retry Connection
            </button>
          </div>

          {/* Help */}
          <div className="text-center">
            <p className="text-xs text-gray-500">
              Note: Free tier projects pause automatically after ~7 days of inactivity
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
