import { 
  Smartphone, 
  Shirt, 
  Home, 
  Dumbbell, 
  Sparkles, 
  Car, 
  BookOpen, 
  Gamepad2,
  type LucideIcon 
} from "lucide-react";

interface CategoryIconProps {
  iconName: string;
  gradient: string;
  isActive?: boolean;
  size?: "sm" | "md" | "lg";
}

const iconMap: Record<string, LucideIcon> = {
  Smartphone,
  Shirt,
  Home,
  Dumbbell,
  Sparkles,
  Car,
  BookOpen,
  Gamepad2,
};

export function CategoryIcon({ iconName, gradient, isActive = false, size = "md" }: CategoryIconProps) {
  const Icon = iconMap[iconName];
  
  if (!Icon) return null;

  const sizeClasses = {
    sm: "w-5 h-5",
    md: "w-6 h-6",
    lg: "w-8 h-8",
  };

  return (
    <div
      className={`rounded-xl flex items-center justify-center transition-all duration-200 ${
        isActive
          ? "bg-white/20 p-2.5"
          : `bg-gradient-to-br ${gradient} p-2.5`
      }`}
    >
      <Icon className={`${sizeClasses[size]} ${isActive ? 'text-white' : 'text-white'} stroke-[2.5]`} />
    </div>
  );
}
