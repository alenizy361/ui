import { motion } from "motion/react";
import { ReactNode, InputHTMLAttributes, ChangeEvent } from "react";

interface WiseInputProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'onChange'> {
  label?: string;
  error?: string;
  leftIcon?: ReactNode;
  rightIcon?: ReactNode;
  helperText?: string;
  onChange?: (value: string) => void;
}

export function WiseInput({
  label,
  error,
  leftIcon,
  rightIcon,
  helperText,
  className = "",
  onChange,
  ...props
}: WiseInputProps) {
  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (onChange) {
      onChange(e.target.value);
    }
  };

  return (
    <div className="w-full">
      {label && (
        <label className="block text-sm font-medium text-[#0e0f0c] mb-2">
          {label}
        </label>
      )}
      <div className="relative">
        {leftIcon && (
          <div className="absolute left-4 top-1/2 -translate-y-1/2 text-[#6a6c6a]">
            {leftIcon}
          </div>
        )}
        <motion.input
          whileFocus={{ scale: 1.005 }}
          className={`
            w-full h-[48px] px-4 rounded-[10px]
            bg-[rgba(22,51,0,0.07843)]
            border border-transparent
            text-[#0e0f0c] placeholder:text-[#6a6c6a]
            transition-all duration-200
            focus:outline-none focus:ring-2 focus:ring-[#163300] focus:bg-white
            ${error ? "border-[#cb272f] focus:ring-[#cb272f]" : ""}
            ${leftIcon ? "pl-12" : ""}
            ${rightIcon ? "pr-12" : ""}
            ${className}
          `}
          onChange={handleChange}
          {...props}
        />
        {rightIcon && (
          <div className="absolute right-4 top-1/2 -translate-y-1/2 text-[#6a6c6a]">
            {rightIcon}
          </div>
        )}
      </div>
      {error && (
        <motion.p
          initial={{ opacity: 0, y: -4 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-1 text-xs text-[#cb272f]"
        >
          {error}
        </motion.p>
      )}
      {helperText && !error && (
        <p className="mt-1 text-xs text-[#6a6c6a]">{helperText}</p>
      )}
    </div>
  );
}