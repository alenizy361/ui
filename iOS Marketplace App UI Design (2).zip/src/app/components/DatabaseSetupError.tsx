/**
 * Database Setup Error Component
 * 
 * Shows when database tables are missing with setup instructions
 */

import { motion, AnimatePresence } from "motion/react";
import { AlertCircle, Database, ExternalLink, Copy, CheckCircle } from "lucide-react";
import { useState } from "react";
import { WiseButton } from "./WiseButton";

interface DatabaseSetupErrorProps {
  tableName: string;
  errorMessage: string;
  projectId: string;
  onDismiss: () => void;
}

export function DatabaseSetupError({ 
  tableName, 
  errorMessage, 
  projectId,
  onDismiss 
}: DatabaseSetupErrorProps) {
  const [copied, setCopied] = useState(false);

  const handleCopySQL = () => {
    const sql = getTableSQL(tableName);
    navigator.clipboard.writeText(sql);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleOpenSQLEditor = () => {
    window.open(
      `https://supabase.com/dashboard/project/${projectId}/sql/new`,
      '_blank'
    );
  };

  const handleOpenDocs = () => {
    window.open('/DATABASE_SETUP_REQUIRED.md', '_blank');
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
        onClick={onDismiss}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          onClick={(e) => e.stopPropagation()}
          className="bg-white rounded-[20px] shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-[#163300] to-[#1a3d00] p-6 rounded-t-[20px]">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0">
                <Database className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h2 className="text-xl font-bold text-white mb-1">
                  Database Setup Required
                </h2>
                <p className="text-white/80 text-sm">
                  The <span className="font-mono bg-white/20 px-2 py-0.5 rounded">{tableName}</span> table needs to be created
                </p>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="p-6 space-y-4">
            {/* Error Details */}
            <div className="bg-[#cb272f]/10 border border-[#cb272f]/30 rounded-[12px] p-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-[#cb272f] flex-shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="font-medium text-[#cb272f] text-sm mb-1">
                    Error Details
                  </p>
                  <p className="text-xs text-[#0e0f0c]/70 font-mono break-all">
                    {errorMessage}
                  </p>
                </div>
              </div>
            </div>

            {/* Instructions */}
            <div className="space-y-3">
              <h3 className="font-semibold text-[#0e0f0c] flex items-center gap-2">
                <span className="w-6 h-6 bg-[#163300] text-white rounded-full flex items-center justify-center text-xs">
                  1
                </span>
                Open Supabase SQL Editor
              </h3>
              
              <WiseButton
                onClick={handleOpenSQLEditor}
                variant="primary"
                fullWidth
                size="md"
              >
                <ExternalLink className="w-4 h-4" />
                Open SQL Editor
              </WiseButton>

              <h3 className="font-semibold text-[#0e0f0c] flex items-center gap-2 mt-4">
                <span className="w-6 h-6 bg-[#163300] text-white rounded-full flex items-center justify-center text-xs">
                  2
                </span>
                Copy & Run SQL Script
              </h3>

              <button
                onClick={handleCopySQL}
                className="w-full bg-[rgba(22,51,0,0.07843)] hover:bg-[rgba(22,51,0,0.15)] border border-[rgba(14,15,12,0.12157)] rounded-[12px] p-4 transition-colors text-left"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-[#0e0f0c]">
                    SQL Script for {tableName}
                  </span>
                  <div className="flex items-center gap-2">
                    {copied ? (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="flex items-center gap-1 text-[#008026] text-sm"
                      >
                        <CheckCircle className="w-4 h-4" />
                        Copied!
                      </motion.div>
                    ) : (
                      <div className="flex items-center gap-1 text-[#163300] text-sm">
                        <Copy className="w-4 h-4" />
                        Copy
                      </div>
                    )}
                  </div>
                </div>
                <p className="text-xs text-[#6a6c6a]">
                  Click to copy the SQL script to clipboard
                </p>
              </button>

              <div className="bg-[#163300]/10 border border-[#163300]/30 rounded-[12px] p-3">
                <p className="text-xs text-[#0e0f0c]">
                  💡 <strong>Tip:</strong> After copying, paste into SQL Editor and click "Run" (or press Ctrl+Enter)
                </p>
              </div>

              <h3 className="font-semibold text-[#0e0f0c] flex items-center gap-2 mt-4">
                <span className="w-6 h-6 bg-[#163300] text-white rounded-full flex items-center justify-center text-xs">
                  3
                </span>
                Verify Setup
              </h3>

              <p className="text-sm text-[#6a6c6a]">
                After running the SQL, refresh this page and try again. The error should be gone!
              </p>
            </div>

            {/* Full Guide Link */}
            <button
              onClick={handleOpenDocs}
              className="w-full text-[#163300] hover:text-[#1a3d00] text-sm font-medium flex items-center justify-center gap-2 py-2 transition-colors"
            >
              View Full Setup Guide
              <ExternalLink className="w-4 h-4" />
            </button>
          </div>

          {/* Footer */}
          <div className="border-t border-[rgba(14,15,12,0.12157)] p-4">
            <WiseButton
              onClick={onDismiss}
              variant="secondary"
              fullWidth
              size="md"
            >
              Close
            </WiseButton>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

/**
 * Get SQL script for creating a table
 */
function getTableSQL(tableName: string): string {
  if (tableName === 'products') {
    return `-- ============================================
-- RABIT PLATFORM - PRODUCTS TABLE SETUP
-- ============================================

-- Create products table
CREATE TABLE IF NOT EXISTS public.products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  price DECIMAL(10, 2) NOT NULL,
  category TEXT NOT NULL,
  condition TEXT NOT NULL CHECK (condition IN ('new', 'used')),
  images TEXT[] NOT NULL DEFAULT '{}',
  location TEXT,
  quantity INTEGER NOT NULL DEFAULT 1,
  delivery_options TEXT[] DEFAULT '{}',
  seller_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT products_price_positive CHECK (price > 0),
  CONSTRAINT products_quantity_positive CHECK (quantity >= 0)
);

-- Create indexes
CREATE INDEX IF NOT EXISTS products_seller_id_idx ON public.products(seller_id);
CREATE INDEX IF NOT EXISTS products_category_idx ON public.products(category);
CREATE INDEX IF NOT EXISTS products_created_at_idx ON public.products(created_at DESC);
CREATE INDEX IF NOT EXISTS products_price_idx ON public.products(price);

-- Enable RLS
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;

-- Drop existing policies
DROP POLICY IF EXISTS "Anyone can view products" ON public.products;
DROP POLICY IF EXISTS "Users can create their own products" ON public.products;
DROP POLICY IF EXISTS "Users can update their own products" ON public.products;
DROP POLICY IF EXISTS "Users can delete their own products" ON public.products;

-- RLS Policies
CREATE POLICY "Anyone can view products"
ON public.products FOR SELECT
USING (true);

CREATE POLICY "Users can create their own products"
ON public.products FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = seller_id);

CREATE POLICY "Users can update their own products"
ON public.products FOR UPDATE
TO authenticated
USING (auth.uid() = seller_id)
WITH CHECK (auth.uid() = seller_id);

CREATE POLICY "Users can delete their own products"
ON public.products FOR DELETE
TO authenticated
USING (auth.uid() = seller_id);

-- Auto-update trigger
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS update_products_updated_at ON public.products;
CREATE TRIGGER update_products_updated_at
BEFORE UPDATE ON public.products
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

-- Verify
SELECT 'Products table created successfully!' AS status;`;
  }

  return `-- SQL for ${tableName} table (not available)`;
}