import { motion, AnimatePresence } from "motion/react";
import { ReactNode } from "react";

interface ScreenTransitionProps {
  children: ReactNode;
  direction?: "forward" | "back";
}

export function ScreenTransition({
  children,
  direction = "forward",
}: ScreenTransitionProps) {
  const variants = {
    enter: {
      x: direction === "forward" ? "100%" : "-30%",
      opacity: direction === "forward" ? 1 : 0,
    },
    center: {
      x: 0,
      opacity: 1,
    },
    exit: {
      x: direction === "forward" ? "-30%" : "100%",
      opacity: direction === "forward" ? 0 : 1,
    },
  };

  return (
    <motion.div
      variants={variants}
      initial="enter"
      animate="center"
      exit="exit"
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
      className="absolute inset-0 bg-background"
    >
      {children}
    </motion.div>
  );
}
