import { motion } from "motion/react";
import { ReactNode } from "react";

interface HapticButtonProps {
  children: ReactNode;
  onClick: () => void;
  variant?: "primary" | "secondary" | "danger" | "ghost";
  size?: "sm" | "md" | "lg";
  fullWidth?: boolean;
  disabled?: boolean;
  className?: string;
}

export function HapticButton({
  children,
  onClick,
  variant = "primary",
  size = "md",
  fullWidth = false,
  disabled = false,
  className = "",
}: HapticButtonProps) {
  const triggerHaptic = () => {
    // Trigger haptic feedback if available
    if (window.navigator && (window.navigator as any).vibrate) {
      (window.navigator as any).vibrate(10);
    }
  };

  const handleClick = () => {
    if (!disabled) {
      triggerHaptic();
      onClick();
    }
  };

  const baseClass = "font-medium rounded-[10px] transition-all duration-200 flex items-center justify-center gap-2";
  
  const variantClasses = {
    primary: "bg-[#163300] text-white hover:bg-[#1a3d00] active:bg-[#0f2200]",
    secondary: "bg-[rgba(22,51,0,0.07843)] text-[#163300] hover:bg-[rgba(22,51,0,0.12)] active:bg-[rgba(22,51,0,0.15)]",
    danger: "bg-[#cb272f] text-white hover:bg-[#b52228] active:bg-[#9f1e24]",
    ghost: "bg-transparent text-[#163300] hover:bg-[rgba(22,51,0,0.05)] active:bg-[rgba(22,51,0,0.1)]",
  };

  const sizeClasses = {
    sm: "px-3 py-2 text-sm",
    md: "px-4 py-3 text-base",
    lg: "px-6 py-4 text-lg",
  };

  const widthClass = fullWidth ? "w-full" : "";
  const disabledClass = disabled ? "opacity-50 cursor-not-allowed" : "cursor-pointer";

  return (
    <motion.button
      onClick={handleClick}
      whileTap={{ scale: disabled ? 1 : 0.98 }}
      transition={{ type: "spring", stiffness: 400, damping: 17 }}
      className={`${baseClass} ${variantClasses[variant]} ${sizeClasses[size]} ${widthClass} ${disabledClass} ${className}`}
      disabled={disabled}
    >
      {children}
    </motion.button>
  );
}
