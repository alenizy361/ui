import { motion, AnimatePresence } from "motion/react";
import { X, Copy, Check } from "lucide-react";
import { useState } from "react";

interface ShareDialogProps {
  isOpen: boolean;
  onClose: () => void;
  productTitle: string;
  productPrice: number;
  shareUrl: string;
}

export function ShareDialog({ isOpen, onClose, productTitle, productPrice, shareUrl }: ShareDialogProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const shareText = `${productTitle} - ${productPrice} ر.س\n${shareUrl}`;

  const shareOptions = [
    {
      name: "واتساب",
      icon: "💬",
      color: "#25D366",
      url: `https://wa.me/?text=${encodeURIComponent(shareText)}`,
    },
    {
      name: "تويتر",
      icon: "🐦",
      color: "#1DA1F2",
      url: `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}`,
    },
    {
      name: "فيسبوك",
      icon: "📘",
      color: "#1877F2",
      url: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`,
    },
    {
      name: "تيليجرام",
      icon: "✈️",
      color: "#0088cc",
      url: `https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(productTitle)}`,
    },
  ];

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-end justify-center" style={{ fontFamily: 'Cairo, sans-serif' }}>
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        />

        {/* Dialog */}
        <motion.div
          initial={{ opacity: 0, y: 100 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 100 }}
          className="relative bg-white rounded-t-[24px] w-full max-w-[430px] p-6 shadow-2xl"
        >
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <button
              onClick={onClose}
              className="w-10 h-10 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center"
            >
              <X className="w-6 h-6 text-[#0e0f0c]" />
            </button>
            <h2 className="text-xl font-bold text-[#0e0f0c]">مشاركة المنتج</h2>
            <div className="w-10" />
          </div>

          {/* Share Options */}
          <div className="grid grid-cols-4 gap-4 mb-6">
            {shareOptions.map((option) => (
              <a
                key={option.name}
                href={option.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex flex-col items-center gap-2"
              >
                <div
                  className="w-16 h-16 rounded-full flex items-center justify-center text-3xl"
                  style={{ backgroundColor: `${option.color}15` }}
                >
                  {option.icon}
                </div>
                <span className="text-xs text-[#6a6c6a] text-center">{option.name}</span>
              </a>
            ))}
          </div>

          {/* Copy Link */}
          <div className="border-t border-[rgba(14,15,12,0.12157)] pt-6">
            <p className="text-sm font-semibold text-[#0e0f0c] mb-3 text-right">نسخ الرابط</p>
            <div className="flex gap-2">
              <button
                onClick={handleCopy}
                className={`px-4 py-3 rounded-[10px] font-medium transition-all ${
                  copied
                    ? "bg-[#008026] text-white"
                    : "bg-[#163300] text-white hover:bg-[#1a3d00]"
                }`}
              >
                {copied ? (
                  <Check className="w-5 h-5" />
                ) : (
                  <Copy className="w-5 h-5" />
                )}
              </button>
              <div className="flex-1 px-4 py-3 rounded-[10px] bg-[rgba(22,51,0,0.07843)] text-[#6a6c6a] text-sm overflow-hidden text-ellipsis whitespace-nowrap text-right">
                {shareUrl}
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
