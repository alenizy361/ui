import { motion } from "motion/react";
import { LucideIcon } from "lucide-react";

interface EmptyStateProps {
  icon: LucideIcon;
  title: string;
  description?: string;
  action?: {
    label: string;
    onClick: () => void;
  };
  iconColor?: string;
}

export function EmptyState({
  icon: Icon,
  title,
  description,
  action,
  iconColor = "#6a6c6a",
}: EmptyStateProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col items-center justify-center py-16 px-6 text-center"
    >
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 0.1, type: "spring", stiffness: 200 }}
        className="w-20 h-20 rounded-full bg-[rgba(22,51,0,0.07843)] flex items-center justify-center mb-6"
      >
        <Icon className="w-10 h-10" style={{ color: iconColor }} />
      </motion.div>

      <h3 className="text-lg font-bold text-[#0e0f0c] mb-2">{title}</h3>
      
      {description && (
        <p className="text-sm text-[#6a6c6a] mb-6 max-w-[280px]">
          {description}
        </p>
      )}

      {action && (
        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={action.onClick}
          className="px-6 py-3 bg-[#163300] text-white rounded-[10px] font-medium hover:bg-[#1a3d00] transition-colors"
        >
          {action.label}
        </motion.button>
      )}
    </motion.div>
  );
}
