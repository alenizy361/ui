import { motion } from "motion/react";
import { Loader2, Check, AlertCircle } from "lucide-react";
import { ButtonHTMLAttributes, ReactNode } from "react";

type ButtonState = "default" | "loading" | "success" | "error";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  children: ReactNode;
  variant?: "primary" | "secondary" | "ghost";
  state?: ButtonState;
  fullWidth?: boolean;
}

export function Button({
  children,
  variant = "primary",
  state = "default",
  fullWidth = false,
  disabled,
  ...props
}: ButtonProps) {
  const variants = {
    primary: "bg-[#030213] text-white shadow-md",
    secondary: "bg-[#f3f3f5] text-[#030213]",
    ghost: "bg-transparent text-[#030213]",
  };

  const isDisabled = disabled || state === "loading" || state === "success";

  return (
    <motion.button
      whileTap={!isDisabled ? { scale: 0.98 } : {}}
      transition={{ duration: 0.2, ease: "easeOut" }}
      className={`
        relative px-6 py-4 rounded-[14px] flex items-center justify-center gap-2
        transition-all duration-200
        ${variants[variant]}
        ${fullWidth ? "w-full" : ""}
        ${isDisabled ? "opacity-50 cursor-not-allowed" : "active:shadow-sm"}
        ${state === "success" ? "bg-green-600" : ""}
        ${state === "error" ? "bg-red-600 text-white" : ""}
      `}
      disabled={isDisabled}
      {...props}
    >
      {state === "loading" && (
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.2 }}
        >
          <Loader2 className="w-5 h-5 animate-spin" />
        </motion.div>
      )}
      {state === "success" && (
        <motion.div
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ type: "spring", stiffness: 300, damping: 20 }}
        >
          <Check className="w-5 h-5" />
        </motion.div>
      )}
      {state === "error" && (
        <motion.div
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
        >
          <AlertCircle className="w-5 h-5" />
        </motion.div>
      )}
      <span className={state !== "default" ? "opacity-0 absolute" : ""}>
        {children}
      </span>
      {state === "loading" && <span>Loading...</span>}
      {state === "success" && <span>Success</span>}
      {state === "error" && <span>Error</span>}
    </motion.button>
  );
}
