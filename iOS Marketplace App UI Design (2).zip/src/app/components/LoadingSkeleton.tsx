import { motion } from "motion/react";

interface LoadingSkeletonProps {
  variant?: "product" | "order" | "message" | "text";
  count?: number;
}

export function LoadingSkeleton({ variant = "product", count = 3 }: LoadingSkeletonProps) {
  const shimmer = {
    animate: {
      backgroundPosition: ["200% 0", "-200% 0"],
    },
    transition: {
      duration: 2,
      repeat: Infinity,
      ease: "linear",
    },
  };

  const baseClass = "bg-gradient-to-r from-[rgba(22,51,0,0.05)] via-[rgba(22,51,0,0.1)] to-[rgba(22,51,0,0.05)] bg-[length:200%_100%] rounded-lg";

  const ProductSkeleton = () => (
    <div className="bg-white rounded-[12px] border border-[rgba(14,15,12,0.12157)] p-4 mb-3">
      <div className="flex gap-4">
        <motion.div
          {...shimmer}
          className={`w-24 h-24 flex-shrink-0 ${baseClass}`}
          style={{ backgroundImage: "linear-gradient(90deg, rgba(22,51,0,0.05) 0%, rgba(22,51,0,0.1) 50%, rgba(22,51,0,0.05) 100%)" }}
        />
        <div className="flex-1">
          <motion.div {...shimmer} className={`h-4 w-3/4 mb-3 ${baseClass}`} />
          <motion.div {...shimmer} className={`h-6 w-1/2 mb-2 ${baseClass}`} />
          <motion.div {...shimmer} className={`h-3 w-full ${baseClass}`} />
        </div>
      </div>
    </div>
  );

  const OrderSkeleton = () => (
    <div className="bg-white rounded-[12px] border border-[rgba(14,15,12,0.12157)] p-4 mb-3">
      <div className="flex items-center justify-between mb-3">
        <motion.div {...shimmer} className={`h-4 w-32 ${baseClass}`} />
        <motion.div {...shimmer} className={`h-6 w-20 rounded-full ${baseClass}`} />
      </div>
      <div className="flex gap-3 mb-3">
        <motion.div {...shimmer} className={`w-16 h-16 rounded-lg ${baseClass}`} />
        <div className="flex-1">
          <motion.div {...shimmer} className={`h-4 w-2/3 mb-2 ${baseClass}`} />
          <motion.div {...shimmer} className={`h-5 w-1/3 ${baseClass}`} />
        </div>
      </div>
      <motion.div {...shimmer} className={`h-10 w-full rounded-lg ${baseClass}`} />
    </div>
  );

  const MessageSkeleton = () => (
    <div className="mb-4">
      <div className="flex gap-3 mb-2">
        <motion.div {...shimmer} className={`w-10 h-10 rounded-full ${baseClass}`} />
        <div className="flex-1">
          <motion.div {...shimmer} className={`h-3 w-24 mb-2 ${baseClass}`} />
          <motion.div {...shimmer} className={`h-16 w-3/4 rounded-2xl ${baseClass}`} />
        </div>
      </div>
    </div>
  );

  const TextSkeleton = () => (
    <div className="space-y-2 mb-4">
      <motion.div {...shimmer} className={`h-4 w-full ${baseClass}`} />
      <motion.div {...shimmer} className={`h-4 w-5/6 ${baseClass}`} />
      <motion.div {...shimmer} className={`h-4 w-4/6 ${baseClass}`} />
    </div>
  );

  const renderSkeleton = () => {
    switch (variant) {
      case "product":
        return <ProductSkeleton />;
      case "order":
        return <OrderSkeleton />;
      case "message":
        return <MessageSkeleton />;
      case "text":
        return <TextSkeleton />;
      default:
        return <ProductSkeleton />;
    }
  };

  return (
    <div className="w-full">
      {Array.from({ length: count }).map((_, index) => (
        <div key={index}>{renderSkeleton()}</div>
      ))}
    </div>
  );
}
