/**
 * Email Validation Error Helper
 * Shows when Supabase rejects emails due to configuration
 */

import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle, ExternalLink, Copy, CheckCircle } from 'lucide-react';
import { useState } from 'react';

interface EmailValidationErrorProps {
  show: boolean;
  onClose: () => void;
  email: string;
  projectId: string;
}

export function EmailValidationError({ show, onClose, email, projectId }: EmailValidationErrorProps) {
  const [copied, setCopied] = useState(false);
  
  const dashboardUrl = `https://supabase.com/dashboard/project/${projectId}/auth/url-configuration`;
  
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <AnimatePresence>
      {show && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 z-[9998]"
          />
          
          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="fixed inset-4 z-[9999] flex items-center justify-center pointer-events-none"
          >
            <div className="bg-white rounded-3xl shadow-2xl max-w-lg w-full overflow-hidden pointer-events-auto" dir="ltr">
              {/* Header */}
              <div className="bg-gradient-to-r from-red-500 to-orange-500 text-white p-6">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                    <AlertTriangle className="w-6 h-6" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold">Email Validation Error</h2>
                    <p className="text-sm text-white/90">Supabase Configuration Issue</p>
                  </div>
                </div>
              </div>

              {/* Content */}
              <div className="p-6 space-y-4">
                {/* Problem */}
                <div className="bg-red-50 border border-red-200 rounded-xl p-4">
                  <div className="flex gap-3">
                    <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <h3 className="font-semibold text-red-900 mb-1">Email Rejected</h3>
                      <p className="text-sm text-red-800 mb-2">
                        Supabase rejected the email: <code className="bg-red-100 px-2 py-0.5 rounded font-mono">{email}</code>
                      </p>
                      <p className="text-xs text-red-700">
                        This is a <strong>Supabase configuration issue</strong>, not a problem with your app code.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Solution */}
                <div>
                  <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                    <span className="w-6 h-6 bg-[#163300] text-white rounded-full flex items-center justify-center text-xs">!</span>
                    Quick Fix (2 minutes):
                  </h3>
                  
                  <ol className="space-y-3 text-sm text-gray-700">
                    <li className="flex gap-3">
                      <span className="flex-shrink-0 w-6 h-6 bg-[#163300] text-white rounded-full flex items-center justify-center text-xs font-bold">
                        1
                      </span>
                      <div className="flex-1">
                        <p className="font-medium mb-1">Open Supabase Auth Settings:</p>
                        <a
                          href={dashboardUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-2 text-[#163300] hover:underline"
                        >
                          <ExternalLink className="w-4 h-4" />
                          Open Dashboard
                        </a>
                      </div>
                    </li>
                    
                    <li className="flex gap-3">
                      <span className="flex-shrink-0 w-6 h-6 bg-[#163300] text-white rounded-full flex items-center justify-center text-xs font-bold">
                        2
                      </span>
                      <div className="flex-1">
                        <p className="font-medium mb-1">Disable Email Confirmations:</p>
                        <p className="text-xs text-gray-600">
                          Scroll down to <strong>"Email Auth"</strong> section → Find <strong>"Enable email confirmations"</strong> → <strong>Turn it OFF</strong> → Click <strong>Save</strong>
                        </p>
                      </div>
                    </li>
                    
                    <li className="flex gap-3">
                      <span className="flex-shrink-0 w-6 h-6 bg-[#163300] text-white rounded-full flex items-center justify-center text-xs font-bold">
                        3
                      </span>
                      <div className="flex-1">
                        <p className="font-medium mb-1">Check Email Provider:</p>
                        <p className="text-xs text-gray-600">
                          Go to <strong>Authentication → Providers → Email</strong> → Make sure it's enabled and has no domain restrictions
                        </p>
                      </div>
                    </li>
                    
                    <li className="flex gap-3">
                      <span className="flex-shrink-0 w-6 h-6 bg-[#163300] text-white rounded-full flex items-center justify-center text-xs font-bold">
                        4
                      </span>
                      <div className="flex-1">
                        <p className="font-medium mb-1">Try Again:</p>
                        <p className="text-xs text-gray-600">
                          Come back here and try signing up again
                        </p>
                      </div>
                    </li>
                  </ol>
                </div>

                {/* Dashboard URL Copy */}
                <div className="bg-gray-50 rounded-xl p-3">
                  <p className="text-xs text-gray-600 mb-2">Dashboard URL:</p>
                  <div className="flex items-center gap-2">
                    <code className="flex-1 text-xs font-mono text-gray-900 bg-white px-3 py-2 rounded-lg border border-gray-200 overflow-x-auto">
                      {dashboardUrl}
                    </code>
                    <button
                      onClick={() => copyToClipboard(dashboardUrl)}
                      className="flex-shrink-0 p-2 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                      title="Copy URL"
                    >
                      {copied ? (
                        <CheckCircle className="w-4 h-4 text-green-600" />
                      ) : (
                        <Copy className="w-4 h-4 text-gray-600" />
                      )}
                    </button>
                  </div>
                </div>

                {/* Why this happens */}
                <div className="border-t pt-4">
                  <details className="text-xs text-gray-600">
                    <summary className="cursor-pointer font-medium text-gray-700 hover:text-gray-900">
                      Why is this happening?
                    </summary>
                    <p className="mt-2 leading-relaxed">
                      Supabase has strict email validation enabled by default to prevent spam and abuse. 
                      For development and testing, you need to disable email confirmations so users can 
                      sign up instantly without verifying their email. This is safe for development but 
                      should be re-enabled in production.
                    </p>
                  </details>
                </div>
              </div>

              {/* Footer */}
              <div className="border-t p-4 flex gap-3">
                <a
                  href={dashboardUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 bg-gradient-to-r from-[#163300] to-[#1e4400] text-white py-3 rounded-xl font-semibold flex items-center justify-center gap-2 hover:shadow-lg transition-all"
                >
                  <ExternalLink className="w-4 h-4" />
                  Fix in Dashboard
                </a>
                <button
                  onClick={onClose}
                  className="px-6 py-3 rounded-xl font-semibold border-2 border-gray-200 hover:border-gray-300 transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
