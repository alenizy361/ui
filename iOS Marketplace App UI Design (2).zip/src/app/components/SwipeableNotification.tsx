import { motion, PanInfo, useMotionValue, useTransform } from "motion/react";
import { Trash2 } from "lucide-react";
import { useState } from "react";
import { triggerHaptic } from "../utils/haptics";

interface SwipeableNotificationProps {
  id: string;
  children: React.ReactNode;
  onDelete: () => void;
  onTap: () => void;
}

export function SwipeableNotification({
  id,
  children,
  onDelete,
  onTap,
}: SwipeableNotificationProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [dragDistance, setDragDistance] = useState(0);
  const x = useMotionValue(0);
  const swipeThreshold = -100; // Swipe left threshold

  // Background color based on drag distance
  const backgroundColor = useTransform(
    x,
    [swipeThreshold, 0],
    ["rgba(239, 68, 68, 1)", "rgba(239, 68, 68, 0)"]
  );

  // Delete icon opacity
  const deleteOpacity = useTransform(
    x,
    [swipeThreshold, 0],
    [1, 0]
  );

  // Delete icon scale
  const deleteScale = useTransform(
    x,
    [swipeThreshold, 0],
    [1, 0.5]
  );

  const handleDragStart = () => {
    setIsDragging(true);
    setDragDistance(0);
    triggerHaptic("selection");
  };

  const handleDragEnd = (event: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
    const totalDistance = Math.abs(info.offset.x);
    
    // If swiped past threshold, delete
    if (info.offset.x < swipeThreshold) {
      triggerHaptic("success");
      onDelete();
    } else {
      // Snap back
      triggerHaptic("light");
    }

    // Reset dragging state after a short delay to prevent tap from firing
    setTimeout(() => {
      setIsDragging(false);
      setDragDistance(totalDistance);
    }, 100);
  };

  const handleDrag = (event: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
    const currentX = x.get();
    
    // Haptic feedback when reaching threshold (crossing from right to left)
    if (currentX <= swipeThreshold && dragDistance > swipeThreshold) {
      triggerHaptic("medium");
    }
    
    setDragDistance(currentX);
  };

  const handleTap = () => {
    // Only trigger tap if it wasn't a drag
    if (!isDragging && Math.abs(dragDistance) < 10) {
      onTap();
    }
  };

  return (
    <div className="relative overflow-hidden rounded-3xl">
      {/* Delete Background */}
      <motion.div
        style={{ backgroundColor }}
        className="absolute inset-0 flex items-center justify-start px-6 rounded-3xl"
      >
        <motion.div
          style={{ 
            opacity: deleteOpacity,
            scale: deleteScale,
          }}
          className="flex flex-col items-center gap-1"
        >
          <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center border border-white/30">
            <Trash2 className="w-6 h-6 text-white" strokeWidth={2.5} />
          </div>
          <span className="text-xs text-white font-bold">حذف</span>
        </motion.div>
      </motion.div>

      {/* Swipeable Content */}
      <motion.div
        drag="x"
        dragConstraints={{ left: -200, right: 0 }}
        dragElastic={{ left: 0.2, right: 0 }}
        style={{ x }}
        onDragStart={handleDragStart}
        onDrag={handleDrag}
        onDragEnd={handleDragEnd}
        onTap={handleTap}
        className="relative z-10 cursor-pointer"
        whileTap={!isDragging ? { scale: 0.98 } : {}}
      >
        {children}
      </motion.div>
    </div>
  );
}