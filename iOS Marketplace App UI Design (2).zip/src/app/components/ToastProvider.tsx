import { Toaster } from "sonner";

export function ToastProvider() {
  return (
    <Toaster
      position="top-center"
      dir="rtl"
      toastOptions={{
        style: {
          background: "#fff",
          color: "#0e0f0c",
          border: "1px solid rgba(14,15,12,0.12157)",
          borderRadius: "12px",
          fontSize: "14px",
          fontFamily: "Cairo, -apple-system, sans-serif",
        },
        className: "toast-rabit",
      }}
      richColors
    />
  );
}
