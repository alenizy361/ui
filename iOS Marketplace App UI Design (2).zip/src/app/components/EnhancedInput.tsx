import { motion, AnimatePresence } from "motion/react";
import { AlertCircle, CheckCircle2, Eye, EyeOff } from "lucide-react";
import { useState, InputHTMLAttributes } from "react";

interface EnhancedInputProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
  error?: string;
  success?: boolean;
  helperText?: string;
  showPasswordToggle?: boolean;
}

export function EnhancedInput({
  label,
  error,
  success,
  helperText,
  showPasswordToggle,
  type = "text",
  className = "",
  ...props
}: EnhancedInputProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [isFocused, setIsFocused] = useState(false);

  const inputType = showPasswordToggle ? (showPassword ? "text" : "password") : type;

  return (
    <div className="w-full">
      <label className="block text-sm font-medium text-[#0e0f0c] mb-2 text-right">
        {label}
      </label>

      <div className="relative">
        <motion.input
          {...props}
          type={inputType}
          onFocus={(e) => {
            setIsFocused(true);
            props.onFocus?.(e);
          }}
          onBlur={(e) => {
            setIsFocused(false);
            props.onBlur?.(e);
          }}
          className={`
            w-full px-4 py-3 pr-12 rounded-[10px] border text-right
            transition-all duration-200
            ${error 
              ? "border-[#cb272f] focus:border-[#cb272f] focus:ring-2 focus:ring-[#cb272f]/20" 
              : success
              ? "border-[#163300] focus:border-[#163300] focus:ring-2 focus:ring-[#163300]/20"
              : "border-[rgba(14,15,12,0.12157)] focus:border-[#163300] focus:ring-2 focus:ring-[#163300]/10"
            }
            ${className}
          `}
          style={{
            outline: "none",
          }}
        />

        {/* Border animation */}
        <AnimatePresence>
          {isFocused && !error && (
            <motion.div
              initial={{ scaleX: 0 }}
              animate={{ scaleX: 1 }}
              exit={{ scaleX: 0 }}
              className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#163300]"
              style={{ originX: 0.5 }}
            />
          )}
        </AnimatePresence>

        {/* Status icons */}
        <div className="absolute left-4 top-1/2 -translate-y-1/2 flex items-center gap-2">
          {showPasswordToggle && (
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="text-[#6a6c6a] hover:text-[#163300] transition-colors"
            >
              {showPassword ? (
                <EyeOff className="w-5 h-5" />
              ) : (
                <Eye className="w-5 h-5" />
              )}
            </button>
          )}

          {error && (
            <motion.div
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ type: "spring", stiffness: 200 }}
            >
              <AlertCircle className="w-5 h-5 text-[#cb272f]" />
            </motion.div>
          )}

          {success && !error && (
            <motion.div
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ type: "spring", stiffness: 200 }}
            >
              <CheckCircle2 className="w-5 h-5 text-[#163300]" />
            </motion.div>
          )}
        </div>
      </div>

      {/* Helper text / Error message */}
      <AnimatePresence mode="wait">
        {error && (
          <motion.p
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="text-sm text-[#cb272f] mt-2 text-right flex items-center gap-1 justify-end"
          >
            {error}
          </motion.p>
        )}

        {!error && helperText && (
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-sm text-[#6a6c6a] mt-2 text-right"
          >
            {helperText}
          </motion.p>
        )}
      </AnimatePresence>
    </div>
  );
}
