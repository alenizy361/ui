import React from 'react';
import { motion } from 'motion/react';
import { AlertCircle, ExternalLink, RefreshCw, Wifi, WifiOff } from 'lucide-react';

interface SupabaseConnectionErrorProps {
  onRetry?: () => void;
}

export function SupabaseConnectionError({ onRetry }: SupabaseConnectionErrorProps) {
  const projectId = "wfpsfiivvfnriqehlwas";
  const dashboardUrl = `https://supabase.com/dashboard/project/${projectId}`;

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-white to-orange-50 flex items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-lg w-full"
      >
        {/* Error Icon */}
        <div className="flex justify-center mb-6">
          <motion.div
            animate={{
              scale: [1, 1.1, 1],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            className="w-24 h-24 rounded-3xl bg-gradient-to-br from-red-100 to-orange-100 flex items-center justify-center shadow-xl relative"
          >
            <WifiOff className="w-12 h-12 text-red-600" strokeWidth={2.5} />
            <motion.div
              animate={{
                scale: [1, 1.5, 1],
                opacity: [0.5, 0, 0.5],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut",
              }}
              className="absolute inset-0 bg-red-400 rounded-3xl blur-xl"
            />
          </motion.div>
        </div>

        {/* Error Message */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-[#0a0b09] mb-3">
            لا يمكن الاتصال بـ Supabase
          </h1>
          <p className="text-[#6a6c6a] mb-6 leading-relaxed">
            مشروع Supabase الخاص بك قد يكون متوقفاً مؤقتاً أو يواجه مشاكل في الاتصال.
          </p>

          {/* Instructions */}
          <div className="bg-white border-2 border-red-200 rounded-2xl p-6 text-right mb-6 shadow-lg">
            <div className="flex items-start gap-3 mb-4">
              <AlertCircle className="w-6 h-6 text-red-600 flex-shrink-0 mt-1" />
              <div className="flex-1">
                <h3 className="font-bold text-[#0a0b09] mb-3">يرجى اتباع الخطوات التالية:</h3>
                <ol className="space-y-3 text-sm text-[#6a6c6a]">
                  <li className="flex items-start gap-3">
                    <span className="flex-shrink-0 w-6 h-6 rounded-full bg-red-100 text-red-700 font-bold text-xs flex items-center justify-center">
                      1
                    </span>
                    <span className="flex-1">
                      افتح{' '}
                      <a
                        href={dashboardUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[#163300] font-bold hover:underline inline-flex items-center gap-1"
                      >
                        لوحة تحكم Supabase
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    </span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="flex-shrink-0 w-6 h-6 rounded-full bg-red-100 text-red-700 font-bold text-xs flex items-center justify-center">
                      2
                    </span>
                    <span className="flex-1">
                      تحقق من حالة المشروع - إذا كان <strong>متوقفاً مؤقتاً (Paused)</strong>، انقر على زر{' '}
                      <strong className="text-[#163300]">Resume Project</strong>
                    </span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="flex-shrink-0 w-6 h-6 rounded-full bg-red-100 text-red-700 font-bold text-xs flex items-center justify-center">
                      3
                    </span>
                    <span className="flex-1">
                      انتظر 1-2 دقيقة حتى يتم تشغيل المشروع، ثم انقر على "إعادة المحاولة" بالأسفل
                    </span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="flex-shrink-0 w-6 h-6 rounded-full bg-red-100 text-red-700 font-bold text-xs flex items-center justify-center">
                      4
                    </span>
                    <span className="flex-1">
                      تحقق من اتصالك بالإنترنت
                    </span>
                  </li>
                </ol>
              </div>
            </div>
          </div>

          {/* Project Info */}
          <div className="bg-gray-50 border border-gray-200 rounded-xl p-4 text-right mb-6">
            <p className="text-xs text-[#6a6c6a] mb-1">معرف المشروع:</p>
            <p className="font-mono text-sm text-[#0a0b09] break-all">{projectId}</p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          <motion.button
            whileTap={{ scale: 0.98 }}
            onClick={onRetry || (() => window.location.reload())}
            className="w-full py-4 bg-gradient-to-br from-[#163300] to-[#0f2409] text-white font-semibold rounded-2xl shadow-lg hover:shadow-xl transition-all duration-200 flex items-center justify-center gap-2"
          >
            <RefreshCw className="w-5 h-5" />
            إعادة المحاولة
          </motion.button>

          <motion.a
            whileTap={{ scale: 0.98 }}
            href={dashboardUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-4 bg-white border-2 border-[#163300] text-[#163300] font-semibold rounded-2xl hover:bg-[#f0fde8] transition-all duration-200 flex items-center justify-center gap-2"
          >
            <ExternalLink className="w-5 h-5" />
            فتح لوحة التحكم Supabase
          </motion.a>
        </div>

        {/* Technical Details (collapsed by default) */}
        <details className="mt-6 bg-gray-100 rounded-xl p-4 text-right">
          <summary className="cursor-pointer text-sm font-semibold text-[#6a6c6a] mb-2">
            تفاصيل تقنية
          </summary>
          <div className="text-xs text-[#6a6c6a] font-mono space-y-1 pt-2 border-t border-gray-300">
            <p>URL: https://{projectId}.supabase.co</p>
            <p>Error: Connection timeout (10 seconds)</p>
            <p>Status: Cannot reach Supabase API</p>
          </div>
        </details>
      </motion.div>
    </div>
  );
}
