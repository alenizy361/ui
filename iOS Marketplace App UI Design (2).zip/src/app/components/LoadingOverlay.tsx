import { motion } from "motion/react";
import { Loader2 } from "lucide-react";

export function LoadingOverlay() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/20 backdrop-blur-sm flex items-center justify-center z-50"
    >
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-white rounded-[20px] p-6 shadow-2xl"
      >
        <Loader2 className="w-12 h-12 animate-spin text-[#030213]" />
      </motion.div>
    </motion.div>
  );
}
