# 🎨 Rabit Platform - Premium Component Library

## Overview
This directory contains all reusable UI components for the Rabit Platform, featuring Wise-inspired design system, comprehensive animations, and production-ready patterns.

---

## 🆕 **NEW PREMIUM COMPONENTS**

### 1. **ToastProvider** 
**File:** `ToastProvider.tsx`

**Purpose:** Global toast notification system with Arabic RTL support.

**Usage:**
```tsx
import { ToastProvider } from './components/ToastProvider';
import { toast } from 'sonner';

// In your App.tsx
<ToastProvider />

// Trigger toasts from anywhere
toast.success('تم الحفظ بنجاح!');
toast.error('حدث خطأ، حاول مرة أخرى');
toast.warning('تحذير: يجب ملء جميع الحقول');
toast.info('معلومة جديدة متاحة');

// With custom duration
toast.success('تم الحفظ!', { duration: 3000 });

// With action button
toast('لديك رسالة جديدة', {
  action: {
    label: 'عرض',
    onClick: () => navigate('/messages'),
  },
});
```

**Features:**
- ✅ RTL support
- ✅ Auto-dismiss (default 4s)
- ✅ Swipe to dismiss
- ✅ Rich colors (success, error, warning, info)
- ✅ Cairo font integration

---

### 2. **EmptyState**
**File:** `EmptyState.tsx`

**Purpose:** Beautiful empty state screens with icons and optional CTAs.

**Usage:**
```tsx
import { EmptyState } from './components/EmptyState';
import { ShoppingBag } from 'lucide-react';

<EmptyState
  icon={ShoppingBag}
  title="لا توجد منتجات"
  description="لم تقم بإضافة أي منتجات بعد"
  iconColor="#163300"
  action={{
    label: 'إضافة منتج',
    onClick: () => navigate('/add-product'),
  }}
/>
```

**Features:**
- ✅ Animated icon entrance
- ✅ Lucide icon support
- ✅ Optional description
- ✅ Optional CTA button
- ✅ Custom icon colors

---

### 3. **LoadingSkeleton**
**File:** `LoadingSkeleton.tsx`

**Purpose:** Shimmer loading skeletons for better perceived performance.

**Usage:**
```tsx
import { LoadingSkeleton } from './components/LoadingSkeleton';

// Product grid loading
<LoadingSkeleton variant="product" count={3} />

// Order list loading
<LoadingSkeleton variant="order" count={5} />

// Chat messages loading
<LoadingSkeleton variant="message" count={4} />

// Text content loading
<LoadingSkeleton variant="text" count={3} />
```

**Variants:**
- **product**: Product card with image + text
- **order**: Order card with status badge
- **message**: Chat message bubble
- **text**: Paragraph lines

**Features:**
- ✅ Smooth shimmer animation
- ✅ Wise green color palette
- ✅ Customizable count
- ✅ Multiple variants

---

### 4. **ProgressIndicator**
**File:** `ProgressIndicator.tsx`

**Purpose:** Visual progress tracking for multi-step flows.

**Usage:**
```tsx
import { ProgressIndicator } from './components/ProgressIndicator';

const steps = [
  { label: 'تأكيد الطلب', status: 'completed' as const },
  { label: 'الشحن', status: 'current' as const },
  { label: 'التسليم', status: 'upcoming' as const },
];

// Vertical (timeline style)
<ProgressIndicator steps={steps} orientation="vertical" />

// Horizontal (stepper style)
<ProgressIndicator steps={steps} orientation="horizontal" />
```

**Step Statuses:**
- **completed**: ✅ Green checkmark
- **current**: ⭕ Pulsing green circle
- **upcoming**: ○ Gray outline circle

**Features:**
- ✅ Animated checkmarks
- ✅ Pulsing current step
- ✅ Connected lines
- ✅ Vertical/horizontal layouts

---

### 5. **PullToRefresh**
**File:** `PullToRefresh.tsx`

**Purpose:** iOS-style pull-to-refresh interaction.

**Usage:**
```tsx
import { PullToRefresh } from './components/PullToRefresh';

<PullToRefresh onRefresh={async () => {
  await fetchLatestData();
}}>
  {/* Your scrollable content */}
  <div className="space-y-4">
    {products.map(p => <ProductCard key={p.id} {...p} />)}
  </div>
</PullToRefresh>
```

**Features:**
- ✅ Drag-based trigger
- ✅ Rotating refresh icon
- ✅ Elastic bounce animation
- ✅ Async await support
- ✅ Native-like feel

---

### 6. **HapticButton**
**File:** `HapticButton.tsx`

**Purpose:** Buttons with haptic feedback simulation.

**Usage:**
```tsx
import { HapticButton } from './components/HapticButton';

<HapticButton
  onClick={handleSubmit}
  variant="primary"
  size="lg"
  fullWidth
>
  تأكيد الدفع
</HapticButton>

<HapticButton
  onClick={handleCancel}
  variant="secondary"
  size="md"
>
  إلغاء
</HapticButton>

<HapticButton
  onClick={handleDelete}
  variant="danger"
  size="sm"
  disabled={isLoading}
>
  حذف
</HapticButton>
```

**Variants:**
- **primary**: Green background, white text
- **secondary**: Light green background, dark text
- **danger**: Red background, white text
- **ghost**: Transparent, hover effect

**Sizes:**
- **sm**: Small (32px)
- **md**: Medium (48px)
- **lg**: Large (56px)

**Features:**
- ✅ Vibration API integration
- ✅ Scale press animation
- ✅ All Wise color variants
- ✅ Disabled states
- ✅ Full width option

---

### 7. **SuccessAnimation**
**File:** `SuccessAnimation.tsx`

**Purpose:** Full-screen success animations with confetti.

**Usage:**
```tsx
import { SuccessAnimation } from './components/SuccessAnimation';
import { Package } from 'lucide-react';

{showSuccess && (
  <SuccessAnimation
    icon={Package}
    title="تم نشر المنتج بنجاح!"
    description="سيظهر منتجك في السوق خلال دقائق"
    showConfetti={true}
  >
    {/* Optional content */}
    <div className="bg-white rounded-xl p-4 border">
      <p>منتج: آيفون 14 برو ماكس</p>
      <p>السعر: ٤٬٥٠٠ ر.س</p>
    </div>
  </SuccessAnimation>
)}
```

**Features:**
- ✅ Confetti particles (12 sparkles)
- ✅ Bouncing icon entrance
- ✅ Checkmark overlay
- ✅ Slide-up text animation
- ✅ Loading dots indicator
- ✅ Optional children content

---

### 8. **EnhancedInput**
**File:** `EnhancedInput.tsx`

**Purpose:** Form input with validation, icons, and animations.

**Usage:**
```tsx
import { EnhancedInput } from './components/EnhancedInput';

const [email, setEmail] = useState('');
const [error, setError] = useState('');

<EnhancedInput
  label="البريد الإلكتروني"
  type="email"
  value={email}
  onChange={(e) => setEmail(e.target.value)}
  error={error}
  success={!error && email.length > 0}
  helperText="سنرسل لك رمز التحقق"
  placeholder="example@email.com"
/>

// Password with toggle
<EnhancedInput
  label="كلمة المرور"
  type="password"
  showPasswordToggle
  value={password}
  onChange={(e) => setPassword(e.target.value)}
/>
```

**Features:**
- ✅ Animated border on focus
- ✅ Error/success icons
- ✅ Password visibility toggle
- ✅ Smooth error transitions
- ✅ Helper text
- ✅ RTL support

---

## 🎯 **EXISTING COMPONENTS**

### **WiseButton**
**File:** `WiseButton.tsx`

Primary button component with all states.

```tsx
<WiseButton
  variant="primary"
  size="lg"
  loading={isSubmitting}
  disabled={!isValid}
  fullWidth
  onClick={handleSubmit}
>
  إرسال
</WiseButton>
```

**States:**
- Default
- Hover
- Pressed (scale 0.98)
- Loading (spinner)
- Success (checkmark)
- Error (X icon)
- Disabled

---

## 📋 **COMPONENT PATTERNS**

### **1. Toast Notifications**
```tsx
// Success after action
const handleSave = async () => {
  try {
    await saveData();
    toast.success('تم الحفظ بنجاح!');
  } catch (error) {
    toast.error('فشل الحفظ، حاول مرة أخرى');
  }
};
```

### **2. Loading States**
```tsx
{isLoading ? (
  <LoadingSkeleton variant="product" count={3} />
) : products.length === 0 ? (
  <EmptyState
    icon={Package}
    title="لا توجد منتجات"
    action={{ label: 'إضافة منتج', onClick: addProduct }}
  />
) : (
  <ProductGrid products={products} />
)}
```

### **3. Success Flows**
```tsx
const [showSuccess, setShowSuccess] = useState(false);

const handlePublish = async () => {
  await publishProduct();
  setShowSuccess(true);
  setTimeout(() => {
    setShowSuccess(false);
    navigate('/home');
  }, 3000);
};

{showSuccess && (
  <SuccessAnimation
    icon={Package}
    title="تم النشر!"
  />
)}
```

### **4. Form Validation**
```tsx
<EnhancedInput
  label="السعر"
  type="number"
  value={price}
  onChange={(e) => {
    setPrice(e.target.value);
    if (parseFloat(e.target.value) <= 0) {
      setError('السعر يجب أن يكون أكبر من صفر');
    } else {
      setError('');
    }
  }}
  error={error}
  success={!error && price}
/>
```

---

## 🎨 **DESIGN SYSTEM INTEGRATION**

All components use the Wise design system:

**Colors:**
- Primary: `#163300` (Forest Green)
- Accent: `#9fe870` (Bright Green)
- Background: `rgba(22,51,0,0.07843)`
- Border: `rgba(14,15,12,0.12157)`
- Error: `#cb272f`
- Success: `#008026`
- Warning: `#df8700`

**Typography:**
- Font: Cairo (Arabic), Inter (English)
- Weights: 400 (normal), 500 (medium), 600 (semibold)

**Animations:**
- Duration: 200-300ms
- Easing: spring (stiffness: 200-400)
- Scale: 0.98 for press states

**Spacing:**
- Gap: 3 (12px), 4 (16px), 6 (24px)
- Padding: 3, 4, 6
- Border radius: 10px (medium), 12px (large)

---

## 🚀 **PERFORMANCE TIPS**

1. **Use Loading Skeletons**: Show immediately while data loads
2. **Toast Sparingly**: Max 1 toast at a time
3. **Animate Wisely**: Only animate user-triggered actions
4. **Lazy Load**: Import heavy components only when needed
5. **Memoize**: Use React.memo for lists with EmptyState

---

## ✅ **ACCESSIBILITY**

All components include:
- ✅ Proper ARIA labels
- ✅ Keyboard navigation
- ✅ Focus indicators
- ✅ Screen reader support
- ✅ Semantic HTML
- ✅ RTL text direction

---

## 📱 **MOBILE-FIRST**

Every component is optimized for:
- ✅ Touch targets (min 44x44px)
- ✅ Responsive sizing
- ✅ Swipe gestures
- ✅ iOS safe areas
- ✅ Haptic feedback

---

## 🎯 **WHEN TO USE WHAT**

| Scenario | Component | Example |
|----------|-----------|---------|
| Data fetching | LoadingSkeleton | Product list loading |
| No results | EmptyState | Empty cart, no orders |
| User action feedback | Toast | Save success, delete error |
| Multi-step process | ProgressIndicator | Order tracking, checkout |
| Major success | SuccessAnimation | Order placed, product published |
| Form input | EnhancedInput | Login, registration, add product |
| Primary action | HapticButton | Submit, confirm, save |
| List refresh | PullToRefresh | Home feed, product list |

---

## 🎊 **YOU NOW HAVE:**

✅ **Toast Notifications** - Instant user feedback  
✅ **Empty States** - Beautiful no-data screens  
✅ **Loading Skeletons** - Perceived performance boost  
✅ **Progress Indicators** - Visual step tracking  
✅ **Pull to Refresh** - Native mobile feel  
✅ **Haptic Buttons** - Tactile feedback  
✅ **Success Animations** - Celebration moments  
✅ **Enhanced Inputs** - Smart form fields  

**Your Rabit Platform is now truly PRODUCTION-READY!** 🚀
