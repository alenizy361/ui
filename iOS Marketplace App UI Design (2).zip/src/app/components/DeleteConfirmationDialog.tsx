import { motion, AnimatePresence } from "motion/react";
import { AlertTriangle, X } from "lucide-react";
import { useLanguage } from "../contexts/LanguageContext";
import { WiseButton } from "./WiseButton";

interface DeleteConfirmationDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  productName: string;
  isDeleting?: boolean;
}

export function DeleteConfirmationDialog({
  isOpen,
  onClose,
  onConfirm,
  productName,
  isDeleting = false,
}: DeleteConfirmationDialogProps) {
  const { language, isRTL } = useLanguage();

  const content = {
    ar: {
      deleteProduct: "حذف المنتج",
      areYouSure: "هل أنت متأكد؟",
      warning: "هذا الإجراء لا يمكن التراجع عنه. سيتم حذف المنتج نهائياً من قائمتك وجميع الصور المرفقة.",
      productToDelete: "المنتج المراد حذفه:",
      cancel: "إلغاء",
      confirmDelete: "تأكيد الحذف",
      deleting: "جاري الحذف...",
    },
    en: {
      deleteProduct: "Delete Product",
      areYouSure: "Are you sure?",
      warning: "This action cannot be undone. The product will be permanently deleted from your listings along with all associated images.",
      productToDelete: "Product to delete:",
      cancel: "Cancel",
      confirmDelete: "Confirm Delete",
      deleting: "Deleting...",
    },
  };
  const c = content[language];

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-end justify-center px-4 pb-4"
          style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
          dir={isRTL ? 'rtl' : 'ltr'}
        >
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={!isDeleting ? onClose : undefined}
            className="absolute inset-0 bg-black/50 backdrop-blur-sm"
          />

          {/* Dialog */}
          <motion.div
            initial={{ opacity: 0, y: 100, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.95 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="relative w-full max-w-md bg-white rounded-[20px] shadow-2xl overflow-hidden"
          >
            {/* Close Button */}
            {!isDeleting && (
              <button
                onClick={onClose}
                className={`absolute top-4 ${isRTL ? 'left-4' : 'right-4'} w-8 h-8 rounded-full bg-[rgba(14,15,12,0.07843)] flex items-center justify-center hover:bg-[rgba(14,15,12,0.12)] transition-colors z-10`}
              >
                <X className="w-5 h-5 text-[#0e0f0c]" />
              </button>
            )}

            {/* Content */}
            <div className="p-6 pt-8">
              {/* Icon */}
              <div className="flex justify-center mb-4">
                <div className="w-16 h-16 rounded-full bg-[#cb272f]/10 flex items-center justify-center">
                  <AlertTriangle className="w-8 h-8 text-[#cb272f]" />
                </div>
              </div>

              {/* Title */}
              <h2 className="text-xl font-bold text-center text-[#0e0f0c] mb-2">
                {c.areYouSure}
              </h2>

              {/* Warning Message */}
              <p className="text-sm text-center text-[#6a6c6a] mb-4 leading-relaxed">
                {c.warning}
              </p>

              {/* Product Name Box */}
              <div className="bg-[rgba(203,39,47,0.05)] border border-[#cb272f]/20 rounded-[12px] p-4 mb-6">
                <p className="text-xs text-[#6a6c6a] mb-1">{c.productToDelete}</p>
                <p className="font-semibold text-[#0e0f0c]">{productName}</p>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3">
                <WiseButton
                  onClick={onClose}
                  variant="secondary"
                  fullWidth
                  disabled={isDeleting}
                >
                  {c.cancel}
                </WiseButton>
                <WiseButton
                  onClick={onConfirm}
                  variant="primary"
                  fullWidth
                  disabled={isDeleting}
                  className="bg-[#cb272f] hover:bg-[#b02329] active:bg-[#9a1f24]"
                >
                  {isDeleting ? c.deleting : c.confirmDelete}
                </WiseButton>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
