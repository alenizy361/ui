import { ReactNode } from 'react';
import { useLanguage } from '../contexts/LanguageContext';

interface ScreenWrapperProps {
  children: ReactNode;
  className?: string;
}

/**
 * Wrapper component that applies language-specific styling to screens
 * Use this to wrap your screen content for automatic RTL/LTR support
 */
export function ScreenWrapper({ children, className = '' }: ScreenWrapperProps) {
  const { language, isRTL } = useLanguage();

  return (
    <div
      className={className}
      style={{ fontFamily: language === 'ar' ? 'Cairo, sans-serif' : 'system-ui, -apple-system, sans-serif' }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {children}
    </div>
  );
}
