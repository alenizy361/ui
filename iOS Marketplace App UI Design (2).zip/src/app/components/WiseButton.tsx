import { motion } from "motion/react";
import { ReactNode } from "react";

interface WiseButtonProps {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "outline" | "ghost" | "danger";
  size?: "sm" | "md" | "lg";
  disabled?: boolean;
  loading?: boolean;
  fullWidth?: boolean;
  className?: string;
}

export function WiseButton({
  children,
  onClick,
  variant = "primary",
  size = "md",
  disabled = false,
  loading = false,
  fullWidth = false,
  className = "",
}: WiseButtonProps) {
  const baseStyles = "inline-flex items-center justify-center transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed";
  
  const variantStyles = {
    primary: "bg-[#163300] text-white hover:bg-[#0d1f00] active:bg-[#0e0f0c]",
    secondary: "bg-[#e2f6d5] text-[#163300] hover:bg-[#d3f2c0] active:bg-[#c5edab]",
    outline: "border-2 border-[#163300] text-[#163300] hover:bg-[rgba(22,51,0,0.07843)] active:bg-[rgba(22,51,0,0.12941)]",
    ghost: "text-[#163300] hover:bg-[rgba(22,51,0,0.07843)] active:bg-[rgba(22,51,0,0.12941)]",
    danger: "bg-[#cb272f] text-white hover:bg-[#a01e25] active:bg-[#8a1a20]",
  };

  const sizeStyles = {
    sm: "h-[32px] px-4 rounded-full text-sm",
    md: "h-[48px] px-6 rounded-full text-base",
    lg: "h-[56px] px-8 rounded-full text-lg",
  };

  const widthStyles = fullWidth ? "w-full" : "";

  return (
    <motion.button
      whileTap={{ scale: disabled ? 1 : 0.98 }}
      onClick={onClick}
      disabled={disabled || loading}
      className={`
        ${baseStyles}
        ${variantStyles[variant]}
        ${sizeStyles[size]}
        ${widthStyles}
        ${className}
      `}
    >
      {loading ? (
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-5 h-5 border-2 border-current border-t-transparent rounded-full"
        />
      ) : (
        children
      )}
    </motion.button>
  );
}