import { motion } from "motion/react";
import { CheckCircle2, Circle, ExternalLink, AlertTriangle, ChevronRight, AlertCircle } from "lucide-react";
import { WiseButton } from "./WiseButton";
import { useState } from "react";

interface SupabaseSetupGuideProps {
  projectId: string;
  onComplete: () => void;
}

export function SupabaseSetupGuide({ projectId, onComplete }: SupabaseSetupGuideProps) {
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);
  
  const dashboardUrl = `https://supabase.com/dashboard/project/${projectId}`;
  
  const steps = [
    {
      id: 1,
      title: "Disable Email Confirmation",
      description: "Allow users to login immediately after signup",
      instructions: [
        `Go to: ${dashboardUrl}/auth/providers`,
        'Find "Email" provider',
        'Scroll to "Confirm email" setting',
        'Toggle it OFF (disable)',
        'Click "Save"',
      ],
      link: `${dashboardUrl}/auth/providers`,
    },
    {
      id: 2,
      title: "Create Storage Buckets",
      description: "Create public buckets for product and profile images",
      instructions: [
        `Go to: ${dashboardUrl}/storage/buckets`,
        'Click "New bucket"',
        'Bucket name: "product-images"',
        'Set "Public bucket": ON',
        'Click "Save"',
        'Repeat for "profile-images" bucket',
      ],
      link: `${dashboardUrl}/storage/buckets`,
    },
    {
      id: 3,
      title: "Configure Storage Policies",
      description: "Allow authenticated users to upload images",
      instructions: [
        'Click on "product-images" bucket',
        'Go to "Policies" tab',
        'Click "New Policy"',
        'Choose "For full customization"',
        'Policy name: "Allow authenticated uploads"',
        'Target roles: "authenticated"',
        'Check all operations (SELECT, INSERT, UPDATE, DELETE)',
        'Click "Review" then "Save"',
        'Repeat for "profile-images" bucket',
      ],
      link: `${dashboardUrl}/storage/policies`,
    },
  ];

  const toggleStep = (stepId: number) => {
    if (completedSteps.includes(stepId)) {
      setCompletedSteps(completedSteps.filter(id => id !== stepId));
    } else {
      setCompletedSteps([...completedSteps, stepId]);
    }
  };

  const allStepsCompleted = completedSteps.length === steps.length;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
        style={{ fontFamily: 'system-ui, -apple-system, sans-serif' }}
      >
        {/* Header */}
        <div className="sticky top-0 bg-gradient-to-br from-[#163300] to-[#0e2200] text-white p-6 rounded-t-3xl">
          <div className="flex items-center gap-3 mb-2">
            <AlertTriangle className="w-8 h-8 text-[#9fe870]" />
            <h2 className="text-2xl font-bold">Supabase Setup Required</h2>
          </div>
          <p className="text-white/80 text-sm">
            Complete these steps to enable authentication and storage
          </p>
        </div>

        {/* Steps */}
        <div className="p-6 space-y-4">
          {steps.map((step, index) => {
            const isCompleted = completedSteps.includes(step.id);
            
            return (
              <motion.div
                key={step.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`border-2 rounded-2xl p-4 transition-all ${
                  isCompleted
                    ? 'border-[#9fe870] bg-[#9fe870]/5'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                {/* Step Header */}
                <div className="flex items-start gap-3 mb-3">
                  <button
                    onClick={() => toggleStep(step.id)}
                    className="mt-1 flex-shrink-0"
                  >
                    {isCompleted ? (
                      <CheckCircle2 className="w-6 h-6 text-[#163300]" />
                    ) : (
                      <Circle className="w-6 h-6 text-gray-300" />
                    )}
                  </button>
                  <div className="flex-1">
                    <h3 className="font-bold text-lg text-[#0e0f0c] mb-1">
                      Step {step.id}: {step.title}
                    </h3>
                    <p className="text-sm text-[#6a6c6a]">{step.description}</p>
                  </div>
                </div>

                {/* Instructions */}
                <div className="ml-9 space-y-2">
                  <ol className="space-y-2">
                    {step.instructions.map((instruction, idx) => (
                      <li
                        key={idx}
                        className="text-sm text-[#0e0f0c] flex items-start gap-2"
                      >
                        <span className="text-[#9fe870] font-bold flex-shrink-0">
                          {idx + 1}.
                        </span>
                        <span className="font-mono text-xs bg-gray-100 px-2 py-1 rounded flex-1">
                          {instruction}
                        </span>
                      </li>
                    ))}
                  </ol>

                  {/* Open Dashboard Button */}
                  <a
                    href={step.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-sm text-[#163300] font-semibold hover:text-[#9fe870] transition-colors mt-2"
                  >
                    <ExternalLink className="w-4 h-4" />
                    Open in Supabase Dashboard
                  </a>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="sticky bottom-0 bg-white border-t border-gray-200 p-6 rounded-b-3xl">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm text-[#6a6c6a]">
              {completedSteps.length} of {steps.length} steps completed
            </span>
            <div className="flex gap-2">
              {steps.map(step => (
                <div
                  key={step.id}
                  className={`w-2 h-2 rounded-full transition-colors ${
                    completedSteps.includes(step.id)
                      ? 'bg-[#9fe870]'
                      : 'bg-gray-200'
                  }`}
                />
              ))}
            </div>
          </div>

          <WiseButton
            onClick={onComplete}
            variant={allStepsCompleted ? "primary" : "secondary"}
            fullWidth
            size="lg"
            disabled={!allStepsCompleted}
          >
            {allStepsCompleted
              ? "✓ I've completed all steps - Test the app!"
              : `Complete ${steps.length - completedSteps.length} more step${steps.length - completedSteps.length !== 1 ? 's' : ''}`}
          </WiseButton>

          {!allStepsCompleted && (
            <p className="text-xs text-center text-[#6a6c6a] mt-3">
              Mark each step as complete after finishing it
            </p>
          )}
        </div>
      </motion.div>
    </div>
  );
}