/**
 * Simple Auth Test - Verify Supabase auth is working
 */

import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';

export function SimpleAuthTest() {
  const { user, isAuthenticated, signUp, signIn, signOut } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [status, setStatus] = useState('');

  const handleSignUp = async () => {
    setStatus('Signing up...');
    const result = await signUp(email, password, name, phone, 'buyer');
    if (result.success) {
      setStatus('✅ Sign up successful!');
    } else {
      setStatus(`❌ Sign up failed: ${result.error}`);
    }
  };

  const handleSignIn = async () => {
    setStatus('Signing in...');
    const result = await signIn(email, password);
    if (result.success) {
      setStatus('✅ Sign in successful!');
    } else {
      setStatus(`❌ Sign in failed: ${result.error}`);
    }
  };

  const handleSignOut = async () => {
    setStatus('Signing out...');
    await signOut();
    setStatus('✅ Signed out');
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-md mx-auto bg-white rounded-lg shadow-lg p-6 space-y-4">
        <h1 className="text-2xl font-bold text-center mb-6">Auth Test</h1>

        {/* Status Display */}
        <div className="p-4 bg-gray-100 rounded">
          <div className="text-sm font-semibold mb-2">Current Status:</div>
          <div className="space-y-1 text-xs">
            <div>Authenticated: {isAuthenticated ? '✅ YES' : '❌ NO'}</div>
            {user && (
              <>
                <div>Email: {user.email}</div>
                <div>Name: {user.name}</div>
                <div>Role: {user.role}</div>
                <div>ID: {user.id}</div>
              </>
            )}
            {status && <div className="mt-2 font-bold">{status}</div>}
          </div>
        </div>

        {/* Sign Out Button (if logged in) */}
        {isAuthenticated ? (
          <button
            onClick={handleSignOut}
            className="w-full bg-red-600 text-white py-2 px-4 rounded hover:bg-red-700"
          >
            Sign Out
          </button>
        ) : (
          <>
            {/* Input Fields */}
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full border rounded px-3 py-2"
            />
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full border rounded px-3 py-2"
            />
            <input
              type="text"
              placeholder="Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full border rounded px-3 py-2"
            />
            <input
              type="tel"
              placeholder="Phone"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full border rounded px-3 py-2"
            />

            {/* Action Buttons */}
            <button
              onClick={handleSignUp}
              className="w-full bg-green-600 text-white py-2 px-4 rounded hover:bg-green-700"
            >
              Sign Up
            </button>
            <button
              onClick={handleSignIn}
              className="w-full bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700"
            >
              Sign In
            </button>
          </>
        )}
      </div>
    </div>
  );
}