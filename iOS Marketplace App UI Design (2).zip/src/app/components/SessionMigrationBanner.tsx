/**
 * Session Migration Banner
 * DISABLED - Using real Supabase sessions now, no migration needed
 */

import { useEffect, useState } from 'react';
import { X } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export function SessionMigrationBanner() {
  // Always return null - banner is disabled
  return null;
}