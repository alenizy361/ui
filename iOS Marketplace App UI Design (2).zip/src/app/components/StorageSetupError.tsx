import { motion } from "motion/react";
import { AlertCircle, ExternalLink, ChevronRight } from "lucide-react";
import { WiseButton } from "./WiseButton";
import { useLanguage } from "../contexts/LanguageContext";

interface StorageSetupErrorProps {
  projectId: string;
  errorMessage?: string;
  onRetry: () => void;
  onShowFullGuide: () => void;
}

export function StorageSetupError({ projectId, errorMessage, onRetry, onShowFullGuide }: StorageSetupErrorProps) {
  const { language, isRTL } = useLanguage();
  
  const storageUrl = `https://supabase.com/dashboard/project/${projectId}/storage/buckets`;
  
  // Detect if this is a bucket missing error or RLS policy error
  const isBucketMissing = errorMessage?.includes('SETUP_REQUIRED') || errorMessage?.includes('not found');
  const isRLSError = errorMessage?.includes('RLS_POLICY_ERROR') || errorMessage?.includes('row-level security');

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      style={{ direction: isRTL ? 'rtl' : 'ltr' }}
    >
      <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-6">
        {/* Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
            <AlertCircle className="w-6 h-6 text-red-600" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-[#163300]">
              {isRTL ? 'خطأ في رفع الصورة' : 'Image Upload Failed'}
            </h2>
            <p className="text-sm text-gray-600">
              {isBucketMissing 
                ? (isRTL ? 'Bucket غير موجود' : 'Bucket not found')
                : (isRTL ? 'سياسات الوصول غير مُعدّة' : 'Storage policies not configured')}
            </p>
          </div>
        </div>

        {/* Error Message */}
        <div className="bg-red-50 rounded-2xl p-4 mb-6 border-2 border-red-200">
          <p className="text-sm text-red-900 font-medium mb-2">
            {isBucketMissing 
              ? (isRTL 
                ? '⚠️ Bucket غير موجود في Supabase'
                : '⚠️ Storage bucket does not exist')
              : (isRTL 
                ? '⚠️ فشل رفع الصورة بسبب سياسات الوصول (RLS)'
                : '⚠️ Upload failed due to Row-Level Security (RLS) policies')}
          </p>
          <p className="text-xs text-red-800">
            {isBucketMissing
              ? (isRTL 
                ? 'يجب إنشاء buckets في Supabase Dashboard أولاً'
                : 'You need to create the storage buckets in Supabase Dashboard first')
              : (isRTL 
                ? 'يجب إضافة سياسات للسماح للمستخدمين المسجلين برفع الصور'
                : 'You need to add policies to allow authenticated users to upload images')}
          </p>
        </div>

        {/* Quick Fix Instructions */}
        <div className="mb-6">
          <h3 className="font-bold text-[#163300] mb-3 text-sm">
            {isBucketMissing
              ? (isRTL ? 'الحل السريع (2 خطوات):' : 'Quick Fix (2 steps):')
              : (isRTL ? 'الحل السريع (3 خطوات):' : 'Quick Fix (3 steps):')}
          </h3>
          
          <div className="space-y-3">
            <div className="flex items-start gap-3 bg-gray-50 rounded-xl p-3">
              <div className="w-6 h-6 bg-[#9fe870] rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-xs font-bold text-[#163300]">1</span>
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-[#163300] mb-1">
                  {isRTL ? 'افتح Storage في Supabase' : 'Open Storage in Supabase'}
                </p>
                <a
                  href={storageUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-xs text-blue-600 hover:text-blue-700"
                >
                  <ExternalLink className="w-3 h-3" />
                  {isRTL ? 'فتح Dashboard' : 'Open Dashboard'}
                </a>
              </div>
            </div>

            {isBucketMissing && (
              <div className="flex items-start gap-3 bg-gray-50 rounded-xl p-3">
                <div className="w-6 h-6 bg-[#9fe870] rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-xs font-bold text-[#163300]">2</span>
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-[#163300] mb-2">
                    {isRTL ? 'إنشاء Buckets الجديدة' : 'Create New Buckets'}
                  </p>
                  <div className="space-y-1 text-xs text-gray-700">
                    <div className="flex items-start gap-1.5">
                      <ChevronRight className="w-3 h-3 mt-0.5 flex-shrink-0" />
                      <span>{isRTL ? 'انقر: "New bucket"' : 'Click: "New bucket"'}</span>
                    </div>
                    <div className="flex items-start gap-1.5">
                      <ChevronRight className="w-3 h-3 mt-0.5 flex-shrink-0" />
                      <span>{isRTL ? 'الاسم: "product-images" (Public ✓)' : 'Name: "product-images" (Public ✓)'}</span>
                    </div>
                    <div className="flex items-start gap-1.5">
                      <ChevronRight className="w-3 h-3 mt-0.5 flex-shrink-0" />
                      <span>{isRTL ? 'الاسم: "profile-images" (Public ✓)' : 'Name: "profile-images" (Public ✓)'}</span>
                    </div>
                    <div className="flex items-start gap-1.5">
                      <ChevronRight className="w-3 h-3 mt-0.5 flex-shrink-0" />
                      <span>{isRTL ? 'انقر: "Save" لكل bucket' : 'Click: "Save" for each bucket'}</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {!isBucketMissing && (
              <>
                <div className="flex items-start gap-3 bg-gray-50 rounded-xl p-3">
                  <div className="w-6 h-6 bg-[#9fe870] rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-xs font-bold text-[#163300]">2</span>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-[#163300] mb-1">
                      {isRTL ? 'لكل bucket، انقر عليه' : 'For each bucket, click on it'}
                    </p>
                    <p className="text-xs text-gray-600">
                      {isRTL 
                        ? 'product-images و profile-images'
                        : 'product-images and profile-images'}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 bg-gray-50 rounded-xl p-3">
                  <div className="w-6 h-6 bg-[#9fe870] rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-xs font-bold text-[#163300]">3</span>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-[#163300] mb-2">
                      {isRTL ? 'أضف سياسة الوصول' : 'Add access policy'}
                    </p>
                    <div className="space-y-1 text-xs text-gray-700">
                      <div className="flex items-start gap-1.5">
                        <ChevronRight className="w-3 h-3 mt-0.5 flex-shrink-0" />
                        <span>{isRTL ? 'انتقل إلى: Configuration → Policies' : 'Go to: Configuration → Policies'}</span>
                      </div>
                      <div className="flex items-start gap-1.5">
                        <ChevronRight className="w-3 h-3 mt-0.5 flex-shrink-0" />
                        <span>{isRTL ? 'انقر: New Policy' : 'Click: New Policy'}</span>
                      </div>
                      <div className="flex items-start gap-1.5">
                        <ChevronRight className="w-3 h-3 mt-0.5 flex-shrink-0" />
                        <span>{isRTL ? 'اختر: "Allow public access"' : 'Select: "Allow public access"'}</span>
                      </div>
                      <div className="flex items-start gap-1.5">
                        <ChevronRight className="w-3 h-3 mt-0.5 flex-shrink-0" />
                        <span>{isRTL ? 'انقر: Use this template → Save' : 'Click: Use this template → Save'}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Actions */}
        <div className="space-y-3">
          <WiseButton
            onClick={onRetry}
            variant="primary"
            fullWidth
          >
            {isRTL ? 'إعادة المحاولة' : 'Retry Upload'}
          </WiseButton>
          
          <button
            onClick={onShowFullGuide}
            className="w-full text-sm text-[#163300] font-medium hover:text-[#9fe870] transition-colors"
          >
            {isRTL ? 'عرض دليل الإعداد الكامل' : 'Show Full Setup Guide'}
          </button>
        </div>
      </div>
    </motion.div>
  );
}