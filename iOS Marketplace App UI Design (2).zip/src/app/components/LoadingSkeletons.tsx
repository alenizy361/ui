import { motion } from "motion/react";

export function ProductCardSkeleton() {
  return (
    <div className="bg-white rounded-2xl border border-[rgba(0,0,0,0.06)] overflow-hidden shadow-card">
      {/* Image Skeleton */}
      <div className="relative w-full aspect-square bg-gradient-to-br from-[#fafafa] to-[#f0f0f0] animate-pulse" />

      {/* Content Skeleton */}
      <div className="p-4 space-y-3">
        {/* Title */}
        <div className="h-5 bg-gradient-to-r from-[#fafafa] to-[#f0f0f0] rounded-lg animate-pulse w-3/4" />
        
        {/* Price & Seller */}
        <div className="flex items-center justify-between gap-2">
          <div className="h-6 bg-gradient-to-r from-[#fafafa] to-[#f0f0f0] rounded-lg animate-pulse w-20" />
          <div className="h-4 bg-gradient-to-r from-[#fafafa] to-[#f0f0f0] rounded-lg animate-pulse w-24" />
        </div>

        {/* Location & Rating */}
        <div className="flex items-center gap-2">
          <div className="h-4 bg-gradient-to-r from-[#fafafa] to-[#f0f0f0] rounded-full animate-pulse w-12" />
          <div className="h-4 bg-gradient-to-r from-[#fafafa] to-[#f0f0f0] rounded-lg animate-pulse w-16" />
        </div>
      </div>
    </div>
  );
}

export function ProductGridSkeleton({ count = 6 }: { count?: number }) {
  return (
    <div className="grid grid-cols-2 gap-4 p-4">
      {Array.from({ length: count }).map((_, i) => (
        <ProductCardSkeleton key={i} />
      ))}
    </div>
  );
}

export function OrderCardSkeleton() {
  return (
    <div className="bg-white rounded-2xl border border-[rgba(0,0,0,0.06)] p-5 shadow-card">
      <div className="flex gap-4">
        {/* Image */}
        <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#fafafa] to-[#f0f0f0] animate-pulse flex-shrink-0" />
        
        {/* Content */}
        <div className="flex-1 space-y-3">
          <div className="h-5 bg-gradient-to-r from-[#fafafa] to-[#f0f0f0] rounded-lg animate-pulse w-3/4" />
          <div className="h-4 bg-gradient-to-r from-[#fafafa] to-[#f0f0f0] rounded-lg animate-pulse w-1/2" />
          <div className="h-6 bg-gradient-to-r from-[#fafafa] to-[#f0f0f0] rounded-xl animate-pulse w-20" />
        </div>
      </div>
    </div>
  );
}

export function ChatMessageSkeleton() {
  return (
    <div className="space-y-4">
      {/* Received message */}
      <div className="flex gap-2 items-end">
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#fafafa] to-[#f0f0f0] animate-pulse flex-shrink-0" />
        <div className="bg-[#fafafa] rounded-2xl rounded-br-md p-4 max-w-[70%]">
          <div className="h-4 bg-gradient-to-r from-[#e5e5e5] to-[#d4d4d4] rounded animate-pulse w-48 mb-2" />
          <div className="h-4 bg-gradient-to-r from-[#e5e5e5] to-[#d4d4d4] rounded animate-pulse w-32" />
        </div>
      </div>

      {/* Sent message */}
      <div className="flex gap-2 items-end justify-end">
        <div className="bg-[#f0fde8] rounded-2xl rounded-bl-md p-4 max-w-[70%]">
          <div className="h-4 bg-gradient-to-r from-[#e2fad5] to-[#d4f4c1] rounded animate-pulse w-40" />
        </div>
      </div>
    </div>
  );
}

export function ProfileSkeleton() {
  return (
    <div className="p-6 space-y-6">
      {/* Avatar & Name */}
      <div className="flex items-center gap-4">
        <div className="w-20 h-20 rounded-full bg-gradient-to-br from-[#fafafa] to-[#f0f0f0] animate-pulse" />
        <div className="flex-1 space-y-2">
          <div className="h-6 bg-gradient-to-r from-[#fafafa] to-[#f0f0f0] rounded-lg animate-pulse w-32" />
          <div className="h-4 bg-gradient-to-r from-[#fafafa] to-[#f0f0f0] rounded-lg animate-pulse w-24" />
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        {[1, 2, 3].map((i) => (
          <div key={i} className="bg-[#fafafa] rounded-2xl p-4 space-y-2">
            <div className="h-8 bg-gradient-to-r from-[#e5e5e5] to-[#d4d4d4] rounded-lg animate-pulse w-12 mx-auto" />
            <div className="h-3 bg-gradient-to-r from-[#e5e5e5] to-[#d4d4d4] rounded animate-pulse w-16 mx-auto" />
          </div>
        ))}
      </div>
    </div>
  );
}

export function ListItemSkeleton() {
  return (
    <div className="bg-white rounded-2xl border border-[rgba(0,0,0,0.06)] p-4 flex items-center gap-3 shadow-card">
      <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#fafafa] to-[#f0f0f0] animate-pulse flex-shrink-0" />
      <div className="flex-1 space-y-2">
        <div className="h-5 bg-gradient-to-r from-[#fafafa] to-[#f0f0f0] rounded-lg animate-pulse w-3/4" />
        <div className="h-3 bg-gradient-to-r from-[#fafafa] to-[#f0f0f0] rounded animate-pulse w-1/2" />
      </div>
    </div>
  );
}
