import { motion } from "motion/react";
import { LucideIcon } from "lucide-react";

interface CategoryPillProps {
  label: string;
  active?: boolean;
  onClick?: () => void;
  icon?: LucideIcon;
  variant?: "default" | "gradient";
}

/**
 * CategoryPill - Modern category/filter button
 * 
 * Features:
 * - Active/Inactive states with gradient
 * - Smooth transitions
 * - Optional icon support
 * - Tap animation
 */
export function CategoryPill({
  label,
  active = false,
  onClick,
  icon: Icon,
  variant = "default",
}: CategoryPillProps) {
  const activeClasses = variant === "gradient"
    ? "bg-gradient-to-br from-[#163300] to-[#0f2409] text-white shadow-sm"
    : "bg-gradient-to-br from-[#163300] to-[#0f2409] text-white shadow-sm";

  const inactiveClasses = "bg-[#f0fde8] border border-[rgba(22,51,0,0.15)] text-[#163300] hover:bg-[#e2fad5]";

  return (
    <motion.button
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
      className={`
        px-5 py-2.5 rounded-xl whitespace-nowrap 
        transition-all duration-200 
        flex items-center gap-2
        ${active ? activeClasses : inactiveClasses}
      `}
    >
      {Icon && <Icon className="w-4 h-4" />}
      <span className="text-sm font-medium">{label}</span>
    </motion.button>
  );
}
