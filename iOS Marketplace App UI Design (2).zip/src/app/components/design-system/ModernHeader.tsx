import { motion } from "motion/react";
import { Bell, Settings } from "lucide-react";
import { ReactNode } from "react";

interface ModernHeaderProps {
  title: string;
  subtitle?: string;
  badge?: string;
  badgeVariant?: "buyer" | "seller" | "both";
  notificationCount?: number;
  onNotifications?: () => void;
  onSettings?: () => void;
  switchButton?: ReactNode;
  actionButton?: ReactNode;
}

/**
 * ModernHeader - Reusable gradient header with glassmorphism
 * 
 * Features:
 * - Gradient background with decorative blur elements
 * - Glassmorphism buttons
 * - Role badge
 * - Notification count
 * - Customizable action buttons
 */
export function ModernHeader({
  title,
  subtitle,
  badge,
  badgeVariant = "buyer",
  notificationCount = 0,
  onNotifications,
  onSettings,
  switchButton,
  actionButton,
}: ModernHeaderProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gradient-to-br from-[#163300] via-[#0f2409] to-[#163300] px-6 pt-12 pb-8 relative overflow-hidden"
    >
      {/* Decorative background elements */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-[#9fe870] opacity-5 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-48 h-48 bg-[#9fe870] opacity-5 rounded-full blur-3xl" />

      {/* Header Content */}
      <div className="flex items-center justify-between mb-6 relative z-10">
        {/* Left Actions */}
        <div className="flex gap-2">
          {onNotifications && (
            <button
              onClick={onNotifications}
              className="w-11 h-11 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center text-white relative border border-white/10 transition-all duration-200 hover:bg-white/20 active:scale-95"
            >
              <Bell className="w-5 h-5" />
              {notificationCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#ef4444] rounded-full text-white text-[10px] flex items-center justify-center font-bold shadow-lg">
                  {notificationCount}
                </span>
              )}
            </button>
          )}
          {onSettings && (
            <button
              onClick={onSettings}
              className="w-11 h-11 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center text-white border border-white/10 transition-all duration-200 hover:bg-white/20 active:scale-95"
            >
              <Settings className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Right Content */}
        <div className="text-right">
          <div className="flex items-center gap-2 mb-1">
            {badge && (
              <span className="px-3 py-1.5 bg-[#9fe870] text-[#163300] text-xs font-bold rounded-xl shadow-lg">
                {badge}
              </span>
            )}
            <h1 className="text-2xl font-bold text-white">{title}</h1>
          </div>
          {subtitle && <p className="text-sm text-white/70">{subtitle}</p>}
        </div>
      </div>

      {/* Switch Button (if provided) */}
      {switchButton && <div className="mb-4 relative z-10">{switchButton}</div>}

      {/* Action Button (if provided) */}
      {actionButton && <div className="relative z-10">{actionButton}</div>}
    </motion.div>
  );
}
