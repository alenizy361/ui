import { motion } from "motion/react";
import { ReactNode } from "react";
import { LucideIcon } from "lucide-react";

interface ModernButtonProps {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "accent" | "ghost" | "glass" | "danger";
  size?: "sm" | "md" | "lg";
  fullWidth?: boolean;
  icon?: LucideIcon;
  iconPosition?: "left" | "right";
  disabled?: boolean;
  className?: string;
}

/**
 * ModernButton - Versatile button component with modern styling
 * 
 * Variants:
 * - primary: Green gradient
 * - secondary: Light green background
 * - accent: Bright green
 * - ghost: Transparent with border
 * - glass: Glassmorphism effect
 * - danger: Red gradient for destructive actions
 * 
 * Features:
 * - Multiple sizes
 * - Icon support
 * - Hover & active states
 * - Tap animation
 * - Full width option
 */
export function ModernButton({
  children,
  onClick,
  variant = "primary",
  size = "md",
  fullWidth = false,
  icon: Icon,
  iconPosition = "left",
  disabled = false,
  className = "",
}: ModernButtonProps) {
  // Size classes
  const sizeClasses = {
    sm: "h-10 px-4 text-sm",
    md: "h-14 px-6 text-base",
    lg: "h-16 px-8 text-lg",
  };

  // Variant classes
  const variantClasses = {
    primary: "bg-gradient-to-br from-[#163300] to-[#0f2409] text-white hover:shadow-button",
    secondary: "bg-[#f0fde8] text-[#163300] border border-[rgba(22,51,0,0.15)] hover:bg-[#e2fad5]",
    accent: "bg-[#9fe870] text-[#163300] hover:bg-[#b5ff8a] hover:shadow-button",
    ghost: "bg-transparent text-[#163300] border border-[rgba(0,0,0,0.15)] hover:bg-[#f0fde8]",
    glass: "bg-white/10 backdrop-blur-md text-white border border-white/20 hover:bg-white/20",
    danger: "bg-gradient-to-br from-[#ef4444] to-[#dc2626] text-white hover:shadow-button",
  };

  return (
    <motion.button
      whileTap={{ scale: disabled ? 1 : 0.97 }}
      onClick={disabled ? undefined : onClick}
      disabled={disabled}
      className={`
        rounded-2xl font-medium
        transition-all duration-200
        flex items-center justify-center gap-2
        active:scale-95
        disabled:opacity-50 disabled:cursor-not-allowed
        ${sizeClasses[size]}
        ${variantClasses[variant]}
        ${fullWidth ? "w-full" : ""}
        ${className}
      `}
    >
      {Icon && iconPosition === "left" && <Icon className="w-5 h-5" />}
      {children}
      {Icon && iconPosition === "right" && <Icon className="w-5 h-5" />}
    </motion.button>
  );
}