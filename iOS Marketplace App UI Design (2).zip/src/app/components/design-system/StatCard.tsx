import { motion } from "motion/react";
import { LucideIcon } from "lucide-react";

interface StatCardProps {
  label: string;
  value: string | number;
  icon: LucideIcon;
  trend?: "up" | "down" | "neutral";
  trendValue?: string;
  color?: "green" | "blue" | "orange" | "red";
  delay?: number;
  onClick?: () => void;
}

/**
 * StatCard - Modern statistics card for dashboards
 * 
 * Features:
 * - Icon with colored background
 * - Trend indicator
 * - Hover effect
 * - Entry animation
 * - Multiple color variants
 */
export function StatCard({
  label,
  value,
  icon: Icon,
  trend,
  trendValue,
  color = "green",
  delay = 0,
  onClick,
}: StatCardProps) {
  const colorClasses = {
    green: "bg-[#f0fde8] text-[#163300]",
    blue: "bg-blue-50 text-blue-600",
    orange: "bg-orange-50 text-orange-600",
    red: "bg-red-50 text-red-600",
  };

  const trendColors = {
    up: "text-[#10b981]",
    down: "text-[#ef4444]",
    neutral: "text-[#6a6c6a]",
  };

  const Component = onClick ? motion.button : motion.div;

  return (
    <Component
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.3 }}
      whileTap={onClick ? { scale: 0.97 } : undefined}
      onClick={onClick}
      className={`
        bg-white rounded-2xl p-5 border border-[rgba(0,0,0,0.08)]
        transition-all duration-200
        ${onClick ? 'cursor-pointer hover:border-[rgba(22,51,0,0.2)]' : ''}
      `}
      style={{ boxShadow: 'var(--shadow-card)' }}
      onMouseEnter={(e) => e.currentTarget.style.boxShadow = 'var(--shadow-card-hover)'}
      onMouseLeave={(e) => e.currentTarget.style.boxShadow = 'var(--shadow-card)'}
    >
      <div className="flex items-start justify-between mb-3">
        <div className={`w-12 h-12 rounded-2xl ${colorClasses[color]} flex items-center justify-center`}>
          <Icon className="w-6 h-6" />
        </div>
        {trend && trendValue && (
          <span className={`text-xs font-medium ${trendColors[trend]}`}>
            {trend === "up" ? "↑" : trend === "down" ? "↓" : "→"} {trendValue}
          </span>
        )}
      </div>
      <p className="text-2xl font-bold text-[#0a0b09] mb-1">{value}</p>
      <p className="text-sm text-[#6a6c6a]">{label}</p>
    </Component>
  );
}
