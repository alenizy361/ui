import { motion } from "motion/react";
import { ReactNode } from "react";

interface ModernCardProps {
  children: ReactNode;
  onClick?: () => void;
  delay?: number;
  className?: string;
  hoverable?: boolean;
  gradient?: boolean;
}

/**
 * ModernCard - Reusable card with modern shadows and hover effects
 * 
 * Features:
 * - Modern rounded corners (20px)
 * - Dynamic shadow elevation
 * - Hover effects
 * - Entry animation
 * - Optional gradient background
 */
export function ModernCard({
  children,
  onClick,
  delay = 0,
  className = "",
  hoverable = true,
  gradient = false,
}: ModernCardProps) {
  const baseClasses = `
    bg-white rounded-2xl border transition-all duration-200
    ${gradient ? 'bg-gradient-to-br from-white to-[#f0fde8]' : ''}
    ${onClick ? 'cursor-pointer' : ''}
    ${className}
  `;

  if (onClick && hoverable) {
    return (
      <motion.button
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay, duration: 0.3 }}
        whileTap={{ scale: 0.97 }}
        onClick={onClick}
        className={baseClasses + " border-[rgba(0,0,0,0.08)] hover:border-[rgba(22,51,0,0.2)]"}
        style={{ boxShadow: 'var(--shadow-card)' }}
        onMouseEnter={(e) => e.currentTarget.style.boxShadow = 'var(--shadow-card-hover)'}
        onMouseLeave={(e) => e.currentTarget.style.boxShadow = 'var(--shadow-card)'}
      >
        {children}
      </motion.button>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.3 }}
      className={baseClasses + " border-[rgba(0,0,0,0.08)]"}
      style={{ boxShadow: hoverable ? 'var(--shadow-card)' : 'none' }}
      onMouseEnter={hoverable ? (e) => e.currentTarget.style.boxShadow = 'var(--shadow-card-hover)' : undefined}
      onMouseLeave={hoverable ? (e) => e.currentTarget.style.boxShadow = 'var(--shadow-card)' : undefined}
    >
      {children}
    </motion.div>
  );
}
