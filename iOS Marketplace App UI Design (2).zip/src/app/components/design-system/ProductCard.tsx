import { motion } from "motion/react";

interface ProductCardProps {
  id: string;
  titleAr: string;
  sellerAr: string;
  price: number;
  rating: number;
  image: string;
  verified?: boolean;
  onClick?: () => void;
  delay?: number;
}

/**
 * ProductCard - Modern product display card
 * 
 * Features:
 * - Image zoom on hover
 * - Dynamic shadow elevation
 * - Verified badge
 * - Star rating
 * - RTL layout
 * - Entry animation
 */
export function ProductCard({
  titleAr,
  sellerAr,
  price,
  rating,
  image,
  verified = false,
  onClick,
  delay = 0,
}: ProductCardProps) {
  return (
    <motion.button
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.3 }}
      whileTap={{ scale: 0.97 }}
      onClick={onClick}
      className="bg-white rounded-2xl overflow-hidden border border-[rgba(0,0,0,0.08)] hover:border-[rgba(22,51,0,0.2)] transition-all duration-200 group text-right"
      style={{ boxShadow: 'var(--shadow-card)' }}
      onMouseEnter={(e) => e.currentTarget.style.boxShadow = 'var(--shadow-card-hover)'}
      onMouseLeave={(e) => e.currentTarget.style.boxShadow = 'var(--shadow-card)'}
    >
      {/* Product Image */}
      <div className="aspect-square bg-[#fafafa] relative overflow-hidden">
        <img
          src={image}
          alt={titleAr}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
          loading="lazy"
        />
        {verified && (
          <div className="absolute top-2 left-2 w-7 h-7 bg-[#163300] rounded-xl flex items-center justify-center shadow-md">
            <span className="text-white text-xs font-bold">✓</span>
          </div>
        )}
      </div>

      {/* Product Info */}
      <div className="p-3.5">
        <p className="text-sm font-semibold text-[#0a0b09] mb-1 truncate">
          {titleAr}
        </p>
        <p className="text-xs text-[#6a6c6a] mb-2.5">{sellerAr}</p>
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs text-[#6a6c6a] flex items-center gap-1">
            <span className="text-[#f59e0b]">★</span>
            {rating}
          </span>
          <span className="font-bold text-[#163300] text-base">{price} ر.س</span>
        </div>
        
        {/* Payment Options */}
        <div className="flex items-center gap-1.5 pt-2 border-t border-[rgba(0,0,0,0.06)]">
          <span className="text-[9px] text-[#6a6c6a]">أو قسمها</span>
          <div className="flex items-center gap-1">
            {/* Tabby Logo */}
            <div className="h-3.5 px-1.5 bg-[#3AFFA3] rounded flex items-center justify-center">
              <span className="text-[8px] font-bold text-black" style={{ fontFamily: 'system-ui, sans-serif' }}>tabby</span>
            </div>
            {/* Tamara Logo */}
            <div className="h-3.5 px-1.5 bg-black rounded flex items-center justify-center">
              <span className="text-[8px] font-bold text-white" style={{ fontFamily: 'system-ui, sans-serif' }}>tamara</span>
            </div>
          </div>
        </div>
      </div>
    </motion.button>
  );
}