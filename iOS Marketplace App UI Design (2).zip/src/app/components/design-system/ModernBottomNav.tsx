import { LucideIcon } from "lucide-react";

interface NavItem {
  id: string;
  label: string;
  icon: LucideIcon;
  onClick: () => void;
}

interface ModernBottomNavProps {
  items: NavItem[];
  activeTab: string;
}

/**
 * ModernBottomNav - Bottom navigation with glassmorphism
 * 
 * Features:
 * - Glassmorphism background
 * - Active state with pill background
 * - Scale animation on active
 * - Smooth transitions
 * - RTL support
 * - Top shadow for elevation
 */
export function ModernBottomNav({ items, activeTab }: ModernBottomNavProps) {
  return (
    <div 
      className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-lg border-t border-[rgba(0,0,0,0.06)] px-6 py-4" 
      style={{ boxShadow: '0 -4px 12px rgba(0, 0, 0, 0.04)' }}
    >
      <div className="flex justify-around items-center max-w-[430px] mx-auto">
        {items.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          
          return (
            <button
              key={item.id}
              onClick={item.onClick}
              className={`flex flex-col items-center gap-1.5 transition-all duration-200 ${
                isActive ? "text-[#163300] scale-105" : "text-[#6a6c6a] scale-100"
              }`}
            >
              <div
                className={`p-2 rounded-xl transition-all duration-200 ${
                  isActive ? "bg-[#f0fde8]" : "bg-transparent"
                }`}
              >
                <Icon className="w-5 h-5" />
              </div>
              <span className="text-xs font-medium">{item.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
