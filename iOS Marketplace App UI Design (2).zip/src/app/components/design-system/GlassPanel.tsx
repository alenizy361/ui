import { ReactNode } from "react";
import { motion } from "motion/react";

interface GlassPanelProps {
  children: ReactNode;
  className?: string;
  variant?: "light" | "dark" | "white";
  blur?: "sm" | "md" | "lg";
  border?: boolean;
  animate?: boolean;
}

/**
 * GlassPanel - Glassmorphism container component
 * 
 * Features:
 * - Multiple glass variants
 * - Configurable blur intensity
 * - Optional border
 * - Entry animation
 * - Backdrop blur support
 */
export function GlassPanel({
  children,
  className = "",
  variant = "light",
  blur = "md",
  border = true,
  animate = false,
}: GlassPanelProps) {
  const variantClasses = {
    light: "bg-white/10",
    dark: "bg-[#163300]/10",
    white: "bg-white/95",
  };

  const blurClasses = {
    sm: "backdrop-blur-sm",
    md: "backdrop-blur-md",
    lg: "backdrop-blur-lg",
  };

  const borderClasses = border ? "border border-white/20" : "";

  const content = (
    <div
      className={`
        ${variantClasses[variant]}
        ${blurClasses[blur]}
        ${borderClasses}
        rounded-2xl
        ${className}
      `}
    >
      {children}
    </div>
  );

  if (animate) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        {content}
      </motion.div>
    );
  }

  return content;
}
