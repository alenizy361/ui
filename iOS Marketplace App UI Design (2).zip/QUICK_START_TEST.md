# 🚀 Quick Start - Test Categories NOW!

## Step 1: Run SQL Script (5 minutes)

1. **Open Supabase Dashboard**
   - Go to: https://supabase.com/dashboard
   - Select your Rabit Platform project

2. **Open SQL Editor**
   - Click "SQL Editor" in left sidebar
   - Click "New Query"

3. **Run the Script**
   - Open `/DATABASE_TABLES_COMPLETE.sql` in your code editor
   - Copy the ENTIRE file
   - Paste into Supabase SQL Editor
   - Click "Run" button (or press Cmd/Ctrl + Enter)

4. **Wait for Success**
   - Should see: "Success. No rows returned"
   - This means all tables were created!

5. **Verify Tables Created**
   - Click "Database" → "Tables" in left sidebar
   - You should see NEW tables:
     - ✅ categories
     - ✅ profiles
     - ✅ addresses
     - ✅ orders
     - ✅ reviews
     - ✅ messages
     - ✅ conversations
     - ✅ notifications
     - ✅ favorites
     - ✅ order_tracking
     - ✅ product_views

6. **Check Categories Data**
   - Click on "categories" table
   - Should see 8 rows with categories like:
     - Electronics / إلكترونيات
     - Fashion / أزياء
     - Home & Garden / المنزل والحديقة
     - etc.

---

## Step 2: Test the App (2 minutes)

### Test Buyer Home Screen:

1. **Open your app** in browser
2. **Sign in** as a buyer (or create account)
3. **Look at categories section**
   - Should see 8 categories with icons
   - Each shows product count (might be 0 if you haven't added products)

4. **Click on a category** (e.g., Electronics)
   - Should filter products
   - Only shows products in that category

5. **Pull down to refresh**
   - Should see loading animation
   - Data refreshes from database

6. **Open Browser Console** (F12)
   - Should see:
     ```
     📂 Fetching categories from database...
     ✅ Fetched categories: 8
     ✅ Loaded categories: 8
     ```

### Test Categories Screen:

1. **Click "View All"** button next to categories
2. **Should navigate to Categories screen**
3. **See all 8 categories** in a grid
4. **Click a category** → Shows products in that category
5. **Click "Cancel"** → Goes back to all categories

---

## Step 3: Add Products to Test Filtering (3 minutes)

1. **Switch to Seller Mode**
2. **Click "Add Product"** button
3. **Fill in product details:**
   - Title: "iPhone 15 Pro"
   - Description: "Latest iPhone"
   - Price: 4500
   - **Category: Select "Electronics"** ← IMPORTANT!
   - Upload an image
   - Select condition
   - Set quantity

4. **Click "Publish"**
5. **Wait for success animation**

6. **Switch back to Buyer Mode**
7. **Go to home screen**
8. **Click "Electronics" category**
9. **Should see your iPhone product!**
10. **Check category badge** → Should show "1 منتج" (1 product)

### Add More Products:

Repeat for different categories:
- Add "T-Shirt" → Category: **Fashion**
- Add "Football" → Category: **Sports**
- Add "Novel" → Category: **Books**

Then test filtering:
- Click "Fashion" → See only T-Shirt
- Click "Sports" → See only Football
- Click "Electronics" → See only iPhone

---

## Step 4: Verify Everything Works

### ✅ Checklist:

- [ ] Categories load on home screen
- [ ] Categories show in categories screen
- [ ] Product counts are accurate (0 or actual number)
- [ ] Clicking category filters products
- [ ] Products appear in correct category
- [ ] Pull-to-refresh updates data
- [ ] Browser console shows success messages
- [ ] No errors in console
- [ ] Arabic/English switching works
- [ ] Category icons display

### 🐛 If Something Doesn't Work:

1. **Check Browser Console** (F12)
   - Look for error messages
   - Red text means something failed

2. **Check Supabase Dashboard**
   - Database → Tables → categories
   - Should have 8 rows

3. **Check Products Table**
   - Database → Tables → products
   - Verify products have correct `category` field
   - Must match category names EXACTLY

4. **Check RLS Policies**
   - Database → Tables → categories → Policies
   - Should have "Categories are viewable by everyone" policy

---

## 🎯 Expected Results

### On Home Screen:
```
┌─────────────────────────┐
│  Categories             │
├─────────────────────────┤
│ 📱          👔          │
│ Electronics Fashion     │
│ 1 منتج      0 منتج     │
│                         │
│ 🏡          ⚽          │
│ Home        Sports      │
│ 0 منتج      1 منتج     │
└─────────────────────────┘
```

### In Browser Console:
```
📂 Fetching categories from database...
✅ Fetched categories: 8
✅ Loaded categories: 8

📦 Fetching products for category: Electronics
✅ Fetched products for category: 1

Refreshing buyer home data...
✅ Loaded categories: 8
```

---

## 🎊 Success Criteria

You'll know it's working when:
1. ✅ You see 8 categories on screen
2. ✅ Product counts are real (not fake 234)
3. ✅ Clicking category shows actual products
4. ✅ Adding product updates count immediately
5. ✅ Console shows database fetch messages
6. ✅ No errors in console

---

## 🚨 Common Issues & Fixes

### Issue: "Categories don't load"

**Solution:**
```sql
-- Run in Supabase SQL Editor
SELECT * FROM categories;
-- Should return 8 rows
-- If not, run the full SQL script again
```

### Issue: "Product count shows 0 but I added products"

**Solution:**
```sql
-- Check your product's category field
SELECT id, title, category FROM products;

-- Make sure it matches exactly:
-- "Electronics" not "electronics" or "Electroincs"
```

### Issue: "Console shows error: relation 'categories' does not exist"

**Solution:**
- SQL script didn't run successfully
- Go back to Step 1 and run it again

### Issue: "RLS policy error"

**Solution:**
```sql
-- Verify RLS policy exists
SELECT * FROM pg_policies WHERE tablename = 'categories';

-- If missing, run this:
CREATE POLICY "Categories are viewable by everyone"
  ON categories FOR SELECT
  USING (is_active = true);
```

---

## 📞 Need Help?

Check these files for details:
- `/CATEGORIES_IMPLEMENTATION_COMPLETE.md` - Full implementation details
- `/MOCK_DATA_AUDIT.md` - What else needs to be done
- `/DATABASE_TABLES_COMPLETE.sql` - Database schema

---

## ✅ You're Done!

If you see categories loading and filtering working, **YOU'RE ALL SET!**

Categories are now 100% real, no mock data! 🎉

**Next:** Choose another feature to implement (Search, Seller Dashboard, Orders, Messages...)
